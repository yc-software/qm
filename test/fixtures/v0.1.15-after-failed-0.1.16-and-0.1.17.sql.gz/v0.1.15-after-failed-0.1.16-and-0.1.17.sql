--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: item_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.item_kind AS ENUM (
    'UserMessage',
    'SteeringMessage',
    'AgentMessage',
    'Reasoning',
    'ToolCall',
    'ToolResult',
    'Elicitation',
    'ElicitationResponse',
    'Wake',
    'Error',
    'ContextCompaction',
    'Retraction',
    'Stop',
    'RuntimeChange'
);


--
-- Name: wake_cause; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.wake_cause AS ENUM (
    'cron',
    'webhook',
    'child_done',
    'system'
);


--
-- Name: acl_grants_bump_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.acl_grants_bump_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        INSERT INTO acl_grants_version(only_row, v) VALUES (TRUE, 1)
        ON CONFLICT (tenant_id, only_row) DO UPDATE SET v = acl_grants_version.v + 1;
        RETURN NULL;
      END
      $$;


--
-- Name: claim_ack_emoji(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_ack_emoji() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM ack_emoji ORDER BY tenant_id, id $$;


--
-- Name: claim_ack_emoji_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_ack_emoji_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'ack_emoji'::text FROM ack_emoji $$;


--
-- Name: claim_ambient_cursors(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_ambient_cursors() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM ambient_cursors ORDER BY tenant_id, id $$;


--
-- Name: claim_ambient_cursors_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_ambient_cursors_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'ambient_cursors'::text FROM ambient_cursors $$;


--
-- Name: claim_approval_grant_modes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_approval_grant_modes() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM approval_grant_modes ORDER BY tenant_id, id $$;


--
-- Name: claim_approval_grant_modes_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_approval_grant_modes_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'approval_grant_modes'::text FROM approval_grant_modes $$;


--
-- Name: claim_approval_grants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_approval_grants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM approval_grants ORDER BY tenant_id, id $$;


--
-- Name: claim_approval_grants_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_approval_grants_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'approval_grants'::text FROM approval_grants $$;


--
-- Name: claim_approval_grants_tenants_by_actorid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_approval_grants_tenants_by_actorid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'approval_grants'::text FROM approval_grants WHERE lower(json->>'actorId') = lower(value) $$;


--
-- Name: claim_approvals(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_approvals() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM approvals ORDER BY tenant_id, id $$;


--
-- Name: claim_approvals_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_approvals_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'approvals'::text FROM approvals $$;


--
-- Name: claim_approvals_tenants_by_sessionid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_approvals_tenants_by_sessionid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'approvals'::text FROM approvals WHERE lower(json->>'sessionId') = lower(value) $$;


--
-- Name: claim_available_runs(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_available_runs(now bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ SELECT r.tenant_id, r.id FROM runs r WHERE r.status='pending' AND r.retry_after <= $1
         AND NOT EXISTS (
           SELECT 1 FROM runs blocked WHERE blocked.tenant_id=r.tenant_id AND blocked.session_id=r.session_id
             AND (blocked.status='running' OR (blocked.status='pending' AND blocked.retry_after > $1))
         ) LIMIT 1 $_$;


--
-- Name: claim_aws_deploy_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_aws_deploy_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM aws_deploy_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_aws_deploy_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_aws_deploy_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'aws_deploy_bodies'::text FROM aws_deploy_bodies $$;


--
-- Name: claim_aws_sandbox_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_aws_sandbox_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM aws_sandbox_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_aws_sandbox_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_aws_sandbox_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'aws_sandbox_bodies'::text FROM aws_sandbox_bodies $$;


--
-- Name: claim_base_model_configs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_base_model_configs() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM base_model_configs ORDER BY tenant_id, id $$;


--
-- Name: claim_base_model_configs_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_base_model_configs_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'base_model_configs'::text FROM base_model_configs $$;


--
-- Name: claim_branding_configs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_branding_configs() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM branding_configs ORDER BY tenant_id, id $$;


--
-- Name: claim_branding_configs_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_branding_configs_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'branding_configs'::text FROM branding_configs $$;


--
-- Name: claim_browse_max_steps_configs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_browse_max_steps_configs() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM browse_max_steps_configs ORDER BY tenant_id, id $$;


--
-- Name: claim_browse_max_steps_configs_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_browse_max_steps_configs_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'browse_max_steps_configs'::text FROM browse_max_steps_configs $$;


--
-- Name: claim_browser_sessions(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_browser_sessions() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM browser_sessions ORDER BY tenant_id, id $$;


--
-- Name: claim_browser_sessions_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_browser_sessions_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'browser_sessions'::text FROM browser_sessions $$;


--
-- Name: claim_channel_header_pin_flag(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_channel_header_pin_flag() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM channel_header_pin_flag ORDER BY tenant_id, id $$;


--
-- Name: claim_channel_header_pin_flag_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_channel_header_pin_flag_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'channel_header_pin_flag'::text FROM channel_header_pin_flag $$;


--
-- Name: claim_command_policies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_command_policies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM command_policies ORDER BY tenant_id, id $$;


--
-- Name: claim_command_policies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_command_policies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'command_policies'::text FROM command_policies $$;


--
-- Name: claim_composio_returns(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_composio_returns() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM composio_returns ORDER BY tenant_id, id $$;


--
-- Name: claim_composio_returns_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_composio_returns_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'composio_returns'::text FROM composio_returns $$;


--
-- Name: claim_connector_clients(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_connector_clients() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM connector_clients ORDER BY tenant_id, id $$;


--
-- Name: claim_connector_clients_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_connector_clients_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'connector_clients'::text FROM connector_clients $$;


--
-- Name: claim_consent_links(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_consent_links() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM consent_links ORDER BY tenant_id, id $$;


--
-- Name: claim_consent_links_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_consent_links_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'consent_links'::text FROM consent_links $$;


--
-- Name: claim_context_requests(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_context_requests() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM context_requests ORDER BY tenant_id, id $$;


--
-- Name: claim_context_requests_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_context_requests_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'context_requests'::text FROM context_requests $$;


--
-- Name: claim_crons(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_crons() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM crons ORDER BY tenant_id, id $$;


--
-- Name: claim_crons_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_crons_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'crons'::text FROM crons $$;


--
-- Name: claim_crons_tenants_by_ownerscopeid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_crons_tenants_by_ownerscopeid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'crons'::text FROM crons WHERE lower(json->>'ownerScopeId') = lower(value) $$;


--
-- Name: claim_custom_model_providers(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_custom_model_providers() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM custom_model_providers ORDER BY tenant_id, id $$;


--
-- Name: claim_custom_model_providers_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_custom_model_providers_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'custom_model_providers'::text FROM custom_model_providers $$;


--
-- Name: claim_deactivated_principals(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_deactivated_principals() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM deactivated_principals ORDER BY tenant_id, id $$;


--
-- Name: claim_deactivated_principals_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_deactivated_principals_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'deactivated_principals'::text FROM deactivated_principals $$;


--
-- Name: claim_deliveries(text, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_deliveries(text, bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ SELECT pg_advisory_xact_lock(hashtext('deliveries:claim:' || $1));
          UPDATE deliveries SET claim_expires_at = (EXTRACT(EPOCH FROM clock_timestamp()) * 1000)::BIGINT + $2
            WHERE (tenant_id, id) IN (
              SELECT tenant_id, id FROM deliveries d
               WHERE delivered_at IS NULL AND expired_at IS NULL AND NOT shadow
  AND (claim_expires_at IS NULL OR claim_expires_at <= (EXTRACT(EPOCH FROM clock_timestamp()) * 1000)::BIGINT) AND destination->>'type' = $1
                 AND NOT EXISTS (
                   SELECT 1 FROM deliveries o
                    WHERE o.tenant_id = d.tenant_id AND o.destination->>'type' = $1
                      AND o.destination->>'target' = d.destination->>'target'
                      AND o.delivered_at IS NULL AND o.expired_at IS NULL AND NOT o.shadow
                      AND (o.claim_expires_at > (EXTRACT(EPOCH FROM clock_timestamp()) * 1000)::BIGINT OR (o.created_at, o.id) < (d.created_at, d.id)))
               ORDER BY created_at
               FOR UPDATE SKIP LOCKED)
            RETURNING tenant_id, id::text $_$;


--
-- Name: claim_deploy_git_repos(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_deploy_git_repos() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM deploy_git_repos ORDER BY tenant_id, id $$;


--
-- Name: claim_deploy_git_repos_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_deploy_git_repos_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'deploy_git_repos'::text FROM deploy_git_repos $$;


--
-- Name: claim_deployment_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_deployment_identity() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM deployment_identity ORDER BY tenant_id, id $$;


--
-- Name: claim_deployment_identity_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_deployment_identity_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'deployment_identity'::text FROM deployment_identity $$;


--
-- Name: claim_deployments(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_deployments() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM deployments ORDER BY tenant_id, id $$;


--
-- Name: claim_deployments_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_deployments_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'deployments'::text FROM deployments $$;


--
-- Name: claim_do_managed_agents_sandbox_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_do_managed_agents_sandbox_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM do_managed_agents_sandbox_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_do_managed_agents_sandbox_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_do_managed_agents_sandbox_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'do_managed_agents_sandbox_bodies'::text FROM do_managed_agents_sandbox_bodies $$;


--
-- Name: claim_e2b_sandbox_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_e2b_sandbox_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM e2b_sandbox_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_e2b_sandbox_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_e2b_sandbox_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'e2b_sandbox_bodies'::text FROM e2b_sandbox_bodies $$;


--
-- Name: claim_egress_policies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_egress_policies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM egress_policies ORDER BY tenant_id, id $$;


--
-- Name: claim_egress_policies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_egress_policies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'egress_policies'::text FROM egress_policies $$;


--
-- Name: claim_expired_file_uploads(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_expired_file_uploads(bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ WITH due AS (
             SELECT tenant_id, id FROM file_uploads
             WHERE expires_at <= $1 AND next_attempt_at <= $1 AND state NOT IN ('complete','aborted','failed')
             ORDER BY next_attempt_at, expires_at, id FOR UPDATE SKIP LOCKED LIMIT 100
           ) UPDATE file_uploads SET next_attempt_at=$1+60000 FROM due
             WHERE file_uploads.tenant_id=due.tenant_id AND file_uploads.id=due.id
             RETURNING file_uploads.tenant_id, file_uploads.id $_$;


--
-- Name: claim_expired_process_sessions(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_expired_process_sessions(bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ SELECT tenant_id, process_id FROM process_sessions WHERE status = 'running' AND expires_at <= $1 $_$;


--
-- Name: claim_expired_runs(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_expired_runs(now bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ SELECT tenant_id, id FROM runs WHERE status='running' AND lease_expires_at IS NOT NULL AND lease_expires_at <= $1 $_$;


--
-- Name: claim_external_members(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_external_members() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM external_members ORDER BY tenant_id, id $$;


--
-- Name: claim_external_members_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_external_members_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'external_members'::text FROM external_members $$;


--
-- Name: claim_external_slack_participants_flag(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_external_slack_participants_flag() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM external_slack_participants_flag ORDER BY tenant_id, id $$;


--
-- Name: claim_external_slack_participants_flag_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_external_slack_participants_flag_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'external_slack_participants_flag'::text FROM external_slack_participants_flag $$;


--
-- Name: claim_feature_flags(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_feature_flags() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM feature_flags ORDER BY tenant_id, id $$;


--
-- Name: claim_feature_flags_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_feature_flags_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'feature_flags'::text FROM feature_flags $$;


--
-- Name: claim_file_upload(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_file_upload(text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ SELECT tenant_id, id FROM file_uploads WHERE id = $1 $_$;


--
-- Name: claim_fly_deploy_configs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_fly_deploy_configs() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM fly_deploy_configs ORDER BY tenant_id, id $$;


--
-- Name: claim_fly_deploy_configs_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_fly_deploy_configs_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'fly_deploy_configs'::text FROM fly_deploy_configs $$;


--
-- Name: claim_idempotency(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_idempotency() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM idempotency ORDER BY tenant_id, id $$;


--
-- Name: claim_idempotency_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_idempotency_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'idempotency'::text FROM idempotency $$;


--
-- Name: claim_individual_model_auth_flag(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_individual_model_auth_flag() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM individual_model_auth_flag ORDER BY tenant_id, id $$;


--
-- Name: claim_individual_model_auth_flag_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_individual_model_auth_flag_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'individual_model_auth_flag'::text FROM individual_model_auth_flag $$;


--
-- Name: claim_interactive_fast_mode_flag(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_interactive_fast_mode_flag() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM interactive_fast_mode_flag ORDER BY tenant_id, id $$;


--
-- Name: claim_interactive_fast_mode_flag_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_interactive_fast_mode_flag_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'interactive_fast_mode_flag'::text FROM interactive_fast_mode_flag $$;


--
-- Name: claim_keychain_asks(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_keychain_asks() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM keychain_asks ORDER BY tenant_id, id $$;


--
-- Name: claim_keychain_asks_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_keychain_asks_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'keychain_asks'::text FROM keychain_asks $$;


--
-- Name: claim_keychain_credentials(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_keychain_credentials() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM keychain_credentials ORDER BY tenant_id, id $$;


--
-- Name: claim_keychain_credentials_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_keychain_credentials_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'keychain_credentials'::text FROM keychain_credentials $$;


--
-- Name: claim_keychain_credentials_tenants_by_ownerid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_keychain_credentials_tenants_by_ownerid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'keychain_credentials'::text FROM keychain_credentials WHERE lower(json->>'ownerId') = lower(value) $$;


--
-- Name: claim_keychain_grants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_keychain_grants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM keychain_grants ORDER BY tenant_id, id $$;


--
-- Name: claim_keychain_grants_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_keychain_grants_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'keychain_grants'::text FROM keychain_grants $$;


--
-- Name: claim_keychain_grants_tenants_by_ownerid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_keychain_grants_tenants_by_ownerid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'keychain_grants'::text FROM keychain_grants WHERE lower(json->>'ownerId') = lower(value) $$;


--
-- Name: claim_loop_ingress(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_ingress() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM loop_ingress ORDER BY tenant_id, id $$;


--
-- Name: claim_loop_ingress_deliveries(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_ingress_deliveries() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM loop_ingress_deliveries ORDER BY tenant_id, id $$;


--
-- Name: claim_loop_ingress_deliveries_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_ingress_deliveries_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'loop_ingress_deliveries'::text FROM loop_ingress_deliveries $$;


--
-- Name: claim_loop_ingress_deliveries_tenants_by_queuekey(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_ingress_deliveries_tenants_by_queuekey(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'loop_ingress_deliveries'::text FROM loop_ingress_deliveries WHERE lower(json->>'queueKey') = lower(value) $$;


--
-- Name: claim_loop_ingress_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_ingress_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'loop_ingress'::text FROM loop_ingress $$;


--
-- Name: claim_loop_ingress_tenants_by_loopid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_ingress_tenants_by_loopid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'loop_ingress'::text FROM loop_ingress WHERE lower(json->>'loopId') = lower(value) $$;


--
-- Name: claim_loop_items(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_items() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM loop_items ORDER BY tenant_id, id $$;


--
-- Name: claim_loop_items_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_items_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'loop_items'::text FROM loop_items $$;


--
-- Name: claim_loop_items_tenants_by_loopid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_items_tenants_by_loopid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'loop_items'::text FROM loop_items WHERE lower(json->>'loopId') = lower(value) $$;


--
-- Name: claim_loop_outputs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_outputs() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM loop_outputs ORDER BY tenant_id, id $$;


--
-- Name: claim_loop_outputs_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_outputs_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'loop_outputs'::text FROM loop_outputs $$;


--
-- Name: claim_loop_outputs_tenants_by_itemid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_outputs_tenants_by_itemid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'loop_outputs'::text FROM loop_outputs WHERE lower(json->>'itemId') = lower(value) $$;


--
-- Name: claim_loop_ship_grants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_ship_grants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM loop_ship_grants ORDER BY tenant_id, id $$;


--
-- Name: claim_loop_ship_grants_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loop_ship_grants_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'loop_ship_grants'::text FROM loop_ship_grants $$;


--
-- Name: claim_loops(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loops() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM loops ORDER BY tenant_id, id $$;


--
-- Name: claim_loops_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_loops_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'loops'::text FROM loops $$;


--
-- Name: claim_mcp_servers(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_mcp_servers() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM mcp_servers ORDER BY tenant_id, id $$;


--
-- Name: claim_mcp_servers_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_mcp_servers_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'mcp_servers'::text FROM mcp_servers $$;


--
-- Name: claim_memory_registry(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_memory_registry() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM memory_registry ORDER BY tenant_id, id $$;


--
-- Name: claim_memory_registry_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_memory_registry_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'memory_registry'::text FROM memory_registry $$;


--
-- Name: claim_memory_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_memory_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, 'memory'::text FROM memory_facts WHERE deleted_at IS NULL
           UNION SELECT tenant_id, 'memory'::text FROM memory_fact_vectors $$;


--
-- Name: claim_memory_tidy_profiles(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_memory_tidy_profiles() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM memory_tidy_profiles ORDER BY tenant_id, id $$;


--
-- Name: claim_memory_tidy_profiles_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_memory_tidy_profiles_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'memory_tidy_profiles'::text FROM memory_tidy_profiles $$;


--
-- Name: claim_modal_sandbox_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_modal_sandbox_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM modal_sandbox_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_modal_sandbox_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_modal_sandbox_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'modal_sandbox_bodies'::text FROM modal_sandbox_bodies $$;


--
-- Name: claim_model_credentials(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_model_credentials() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM model_credentials ORDER BY tenant_id, id $$;


--
-- Name: claim_model_credentials_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_model_credentials_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'model_credentials'::text FROM model_credentials $$;


--
-- Name: claim_model_registry(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_model_registry() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM model_registry ORDER BY tenant_id, id $$;


--
-- Name: claim_model_registry_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_model_registry_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'model_registry'::text FROM model_registry $$;


--
-- Name: claim_monitors(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_monitors() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM monitors ORDER BY tenant_id, id $$;


--
-- Name: claim_monitors_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_monitors_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'monitors'::text FROM monitors $$;


--
-- Name: claim_monitors_tenants_by_ownerscopeid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_monitors_tenants_by_ownerscopeid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'monitors'::text FROM monitors WHERE lower(json->>'ownerScopeId') = lower(value) $$;


--
-- Name: claim_oauth_flows(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_oauth_flows() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM oauth_flows ORDER BY tenant_id, id $$;


--
-- Name: claim_oauth_flows_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_oauth_flows_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'oauth_flows'::text FROM oauth_flows $$;


--
-- Name: claim_org_ambient_flag(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_org_ambient_flag() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM org_ambient_flag ORDER BY tenant_id, id $$;


--
-- Name: claim_org_ambient_flag_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_org_ambient_flag_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'org_ambient_flag'::text FROM org_ambient_flag $$;


--
-- Name: claim_pending_returns(integer, text, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_pending_returns(lim integer, after_id text, now bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ SELECT tenant_id, id FROM (SELECT * FROM (
           SELECT * FROM runs WHERE status IN ('done','failed') AND returned_at IS NULL
           AND session_id LIKE 'agent:main:subagent:%' AND id > $2
           UNION
           SELECT child.* FROM runs wake JOIN runs child
           ON child.tenant_id = wake.tenant_id AND child.id = substring(wake.idempotency_key FROM length('subagent-return:') + 1)
           WHERE wake.status = 'pending' AND wake.attempts = 0 AND wake.turn_user_seq IS NULL
           AND wake.idempotency_key LIKE 'subagent-return:%'
           AND child.status IN ('done','failed') AND child.session_id LIKE 'agent:main:subagent:%'
           AND child.id > $2
         ) pending) due WHERE retry_after <= $3 ORDER BY id LIMIT $1 $_$;


--
-- Name: claim_porter_deploy_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_porter_deploy_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM porter_deploy_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_porter_deploy_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_porter_deploy_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'porter_deploy_bodies'::text FROM porter_deploy_bodies $$;


--
-- Name: claim_projects(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_projects() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM projects ORDER BY tenant_id, id $$;


--
-- Name: claim_projects_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_projects_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'projects'::text FROM projects $$;


--
-- Name: claim_pruned_cron_fires(integer, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_pruned_cron_fires(keep_per_cron integer, ended_before bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ DELETE FROM cron_fires cf
              USING (SELECT tenant_id, cron_id, fire_key,
                            ROW_NUMBER() OVER (PARTITION BY tenant_id, cron_id ORDER BY fired_at DESC, fire_key DESC) AS rn
                       FROM cron_fires) ranked
              WHERE cf.tenant_id = ranked.tenant_id AND cf.cron_id = ranked.cron_id AND cf.fire_key = ranked.fire_key
                AND ranked.rn > keep_per_cron
                AND cf.ended_at IS NOT NULL AND cf.ended_at < ended_before
              RETURNING cf.tenant_id, jsonb_build_array(cf.cron_id, cf.fire_key)::text $$;


--
-- Name: claim_pruned_signals(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_pruned_signals(before bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ DELETE FROM run_signals WHERE consumed_at IS NOT NULL AND consumed_at < $1 RETURNING tenant_id, id::text $_$;


--
-- Name: claim_render_app_storage(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_app_storage() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM render_app_storage ORDER BY tenant_id, id $$;


--
-- Name: claim_render_app_storage_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_app_storage_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'render_app_storage'::text FROM render_app_storage $$;


--
-- Name: claim_render_deploy_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_deploy_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM render_deploy_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_render_deploy_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_deploy_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'render_deploy_bodies'::text FROM render_deploy_bodies $$;


--
-- Name: claim_render_deploy_credentials(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_deploy_credentials() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM render_deploy_credentials ORDER BY tenant_id, id $$;


--
-- Name: claim_render_deploy_credentials_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_deploy_credentials_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'render_deploy_credentials'::text FROM render_deploy_credentials $$;


--
-- Name: claim_render_sandbox_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_sandbox_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM render_sandbox_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_render_sandbox_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_sandbox_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'render_sandbox_bodies'::text FROM render_sandbox_bodies $$;


--
-- Name: claim_render_sandbox_cleanup(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_sandbox_cleanup() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM render_sandbox_cleanup ORDER BY tenant_id, id $$;


--
-- Name: claim_render_sandbox_cleanup_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_sandbox_cleanup_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'render_sandbox_cleanup'::text FROM render_sandbox_cleanup $$;


--
-- Name: claim_render_scratch_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_scratch_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM render_scratch_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_render_scratch_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_render_scratch_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'render_scratch_bodies'::text FROM render_scratch_bodies $$;


--
-- Name: claim_runs(bigint, text, bigint, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_runs(lease_until bigint, worker text, now bigint, lim integer) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ WITH picked AS (
         SELECT candidate.tenant_id, candidate.id FROM runs candidate WHERE candidate.status='pending' AND candidate.retry_after <= $3
  AND NOT EXISTS (
    SELECT 1 FROM runs sibling WHERE sibling.tenant_id=candidate.tenant_id AND sibling.session_id=candidate.session_id
      AND (sibling.status='running' OR (sibling.status='pending'
        AND (sibling.retry_after > $3 OR (CASE
    WHEN (sibling.claim_priority > 0 AND sibling.last_stop::jsonb->>'kind' = 'parked') IS NOT TRUE AND (candidate.claim_priority > 0 AND candidate.last_stop::jsonb->>'kind' = 'parked') IS NOT TRUE
      THEN (sibling.created_at, sibling.seq) < (candidate.created_at, candidate.seq)
    ELSE ((CASE WHEN sibling.claim_priority <> 0 THEN 1
    WHEN EXISTS (
      SELECT 1 FROM runs ahead WHERE ahead.tenant_id=sibling.tenant_id AND ahead.session_id=sibling.session_id AND ahead.status='pending'
        AND ahead.claim_priority > 0 AND (ahead.claim_priority > 0 AND ahead.last_stop::jsonb->>'kind' = 'parked') IS NOT TRUE
        AND (ahead.created_at, ahead.seq) < (sibling.created_at, sibling.seq)
    ) THEN 1 ELSE 0 END), sibling.created_at, sibling.seq) < ((CASE WHEN candidate.claim_priority <> 0 THEN 1
    WHEN EXISTS (
      SELECT 1 FROM runs ahead WHERE ahead.tenant_id=candidate.tenant_id AND ahead.session_id=candidate.session_id AND ahead.status='pending'
        AND ahead.claim_priority > 0 AND (ahead.claim_priority > 0 AND ahead.last_stop::jsonb->>'kind' = 'parked') IS NOT TRUE
        AND (ahead.created_at, ahead.seq) < (candidate.created_at, candidate.seq)
    ) THEN 1 ELSE 0 END), candidate.created_at, candidate.seq) END))))
    OFFSET 0
  )
         ORDER BY candidate.claim_priority ASC, candidate.created_at ASC, candidate.seq ASC FOR UPDATE SKIP LOCKED LIMIT $4
       )
       UPDATE runs SET status='running', lease_token=gen_random_uuid()::text, lease_expires_at=$1, worker_id=$2,
         attempts=attempts+1, started_at=COALESCE(started_at,$3)
       FROM picked WHERE runs.tenant_id = picked.tenant_id AND runs.id = picked.id RETURNING runs.tenant_id, runs.id $_$;


--
-- Name: claim_sandbox_defaults(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sandbox_defaults() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM sandbox_defaults ORDER BY tenant_id, id $$;


--
-- Name: claim_sandbox_defaults_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sandbox_defaults_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'sandbox_defaults'::text FROM sandbox_defaults $$;


--
-- Name: claim_sandbox_resource_rollout(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sandbox_resource_rollout() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM sandbox_resource_rollout ORDER BY tenant_id, id $$;


--
-- Name: claim_sandbox_resource_rollout_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sandbox_resource_rollout_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'sandbox_resource_rollout'::text FROM sandbox_resource_rollout $$;


--
-- Name: claim_sandbox_resources(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sandbox_resources() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM sandbox_resources ORDER BY tenant_id, id $$;


--
-- Name: claim_sandbox_resources_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sandbox_resources_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'sandbox_resources'::text FROM sandbox_resources $$;


--
-- Name: claim_sandbox_routing(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sandbox_routing() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM sandbox_routing ORDER BY tenant_id, id $$;


--
-- Name: claim_sandbox_routing_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sandbox_routing_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'sandbox_routing'::text FROM sandbox_routing $$;


--
-- Name: claim_secret_drops(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_secret_drops() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM secret_drops ORDER BY tenant_id, id $$;


--
-- Name: claim_secret_drops_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_secret_drops_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'secret_drops'::text FROM secret_drops $$;


--
-- Name: claim_security_postures(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_security_postures() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM security_postures ORDER BY tenant_id, id $$;


--
-- Name: claim_security_postures_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_security_postures_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'security_postures'::text FROM security_postures $$;


--
-- Name: claim_session_mailbox(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_session_mailbox() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM session_mailbox ORDER BY tenant_id, id $$;


--
-- Name: claim_session_mailbox_by_wake(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_session_mailbox_by_wake(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM session_mailbox WHERE lower(json->>'wake') = lower(value) ORDER BY tenant_id, id $$;


--
-- Name: claim_session_mailbox_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_session_mailbox_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'session_mailbox'::text FROM session_mailbox $$;


--
-- Name: claim_session_mailbox_tenants_by_recipientid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_session_mailbox_tenants_by_recipientid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'session_mailbox'::text FROM session_mailbox WHERE lower(json->>'recipientId') = lower(value) $$;


--
-- Name: claim_session_mailbox_tenants_by_wake(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_session_mailbox_tenants_by_wake(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'session_mailbox'::text FROM session_mailbox WHERE lower(json->>'wake') = lower(value) $$;


--
-- Name: claim_session_shares(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_session_shares() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM session_shares ORDER BY tenant_id, id $$;


--
-- Name: claim_session_shares_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_session_shares_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'session_shares'::text FROM session_shares $$;


--
-- Name: claim_sharing_postures(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sharing_postures() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM sharing_postures ORDER BY tenant_id, id $$;


--
-- Name: claim_sharing_postures_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sharing_postures_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'sharing_postures'::text FROM sharing_postures $$;


--
-- Name: claim_signaled_runs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_signaled_runs() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, run_id FROM run_signals WHERE consumed_at IS NULL ORDER BY tenant_id, run_id $$;


--
-- Name: claim_skill_bundles(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_skill_bundles() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM skill_bundles ORDER BY tenant_id, id $$;


--
-- Name: claim_skill_bundles_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_skill_bundles_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'skill_bundles'::text FROM skill_bundles $$;


--
-- Name: claim_skill_packs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_skill_packs() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM skill_packs ORDER BY tenant_id, id $$;


--
-- Name: claim_skill_packs_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_skill_packs_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'skill_packs'::text FROM skill_packs $$;


--
-- Name: claim_skills(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_skills() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM skills ORDER BY tenant_id, id $$;


--
-- Name: claim_skills_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_skills_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'skills'::text FROM skills $$;


--
-- Name: claim_skills_tenants_by_scopeid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_skills_tenants_by_scopeid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'skills'::text FROM skills WHERE lower(json->>'scopeId') = lower(value) $$;


--
-- Name: claim_slack_accounts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_accounts() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM slack_accounts ORDER BY tenant_id, id $$;


--
-- Name: claim_slack_accounts_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_accounts_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'slack_accounts'::text FROM slack_accounts $$;


--
-- Name: claim_slack_emoji_catalog(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_emoji_catalog() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM slack_emoji_catalog ORDER BY tenant_id, id $$;


--
-- Name: claim_slack_emoji_catalog_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_emoji_catalog_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'slack_emoji_catalog'::text FROM slack_emoji_catalog $$;


--
-- Name: claim_slack_installation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_installation() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM slack_installation ORDER BY tenant_id, id $$;


--
-- Name: claim_slack_installation_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_installation_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'slack_installation'::text FROM slack_installation $$;


--
-- Name: claim_slack_session_status(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_session_status() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM slack_session_status ORDER BY tenant_id, id $$;


--
-- Name: claim_slack_session_status_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_session_status_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'slack_session_status'::text FROM slack_session_status $$;


--
-- Name: claim_slack_staged_envelopes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_staged_envelopes() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM slack_staged_envelopes ORDER BY tenant_id, id $$;


--
-- Name: claim_slack_staged_envelopes_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_staged_envelopes_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'slack_staged_envelopes'::text FROM slack_staged_envelopes $$;


--
-- Name: claim_slack_task_acknowledgements(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_task_acknowledgements() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM slack_task_acknowledgements ORDER BY tenant_id, id $$;


--
-- Name: claim_slack_task_acknowledgements_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_slack_task_acknowledgements_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'slack_task_acknowledgements'::text FROM slack_task_acknowledgements $$;


--
-- Name: claim_smolmachines_sandbox_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_smolmachines_sandbox_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM smolmachines_sandbox_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_smolmachines_sandbox_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_smolmachines_sandbox_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'smolmachines_sandbox_bodies'::text FROM smolmachines_sandbox_bodies $$;


--
-- Name: claim_soul_configs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_soul_configs() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM soul_configs ORDER BY tenant_id, id $$;


--
-- Name: claim_soul_configs_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_soul_configs_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'soul_configs'::text FROM soul_configs $$;


--
-- Name: claim_soul_history(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_soul_history() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM soul_history ORDER BY tenant_id, id $$;


--
-- Name: claim_soul_history_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_soul_history_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'soul_history'::text FROM soul_history $$;


--
-- Name: claim_spend_limit_configs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_spend_limit_configs() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM spend_limit_configs ORDER BY tenant_id, id $$;


--
-- Name: claim_spend_limit_configs_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_spend_limit_configs_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'spend_limit_configs'::text FROM spend_limit_configs $$;


--
-- Name: claim_sprites_initialization(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sprites_initialization() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM sprites_initialization ORDER BY tenant_id, id $$;


--
-- Name: claim_sprites_initialization_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_sprites_initialization_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'sprites_initialization'::text FROM sprites_initialization $$;


--
-- Name: claim_stranded_cron_fires(bigint, text, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_stranded_cron_fires(ended bigint, stranded_note text, fired_before bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ UPDATE cron_fires SET status = 'failed', ended_at = ended, note = stranded_note
              WHERE status = 'running' AND fired_at <= fired_before
              RETURNING tenant_id, jsonb_build_array(cron_id, fire_key)::text $$;


--
-- Name: claim_suggested_activity_profiles(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_suggested_activity_profiles() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM suggested_activity_profiles ORDER BY tenant_id, id $$;


--
-- Name: claim_suggested_activity_profiles_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_suggested_activity_profiles_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'suggested_activity_profiles'::text FROM suggested_activity_profiles $$;


--
-- Name: claim_superserve_sandbox_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_superserve_sandbox_bodies() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM superserve_sandbox_bodies ORDER BY tenant_id, id $$;


--
-- Name: claim_superserve_sandbox_bodies_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_superserve_sandbox_bodies_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'superserve_sandbox_bodies'::text FROM superserve_sandbox_bodies $$;


--
-- Name: claim_swarms(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_swarms() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM swarms ORDER BY tenant_id, id $$;


--
-- Name: claim_swarms_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_swarms_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'swarms'::text FROM swarms $$;


--
-- Name: claim_swarms_tenants_by_pending(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_swarms_tenants_by_pending(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'swarms'::text FROM swarms WHERE lower(json->>'pending') = lower(value) $$;


--
-- Name: claim_terminal_runs(bigint, bigint, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_terminal_runs(before bigint, after_finished bigint, after_id text, lim integer) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ SELECT tenant_id, id FROM runs WHERE status IN ('done','failed') AND finished_at <= $1
         AND (finished_at > $2 OR (finished_at = $2 AND id > $3))
       ORDER BY finished_at, id LIMIT $4 $_$;


--
-- Name: claim_waiting_runs(bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_waiting_runs(created_before bigint, now bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ SELECT candidate.tenant_id, candidate.id FROM runs candidate WHERE candidate.status='pending' AND candidate.retry_after <= $2
  AND NOT EXISTS (
    SELECT 1 FROM runs sibling WHERE sibling.tenant_id=candidate.tenant_id AND sibling.session_id=candidate.session_id
      AND (sibling.status='running' OR (sibling.status='pending'
        AND (sibling.retry_after > $2 OR (CASE
    WHEN (sibling.claim_priority > 0 AND sibling.last_stop::jsonb->>'kind' = 'parked') IS NOT TRUE AND (candidate.claim_priority > 0 AND candidate.last_stop::jsonb->>'kind' = 'parked') IS NOT TRUE
      THEN (sibling.created_at, sibling.seq) < (candidate.created_at, candidate.seq)
    ELSE ((CASE WHEN sibling.claim_priority <> 0 THEN 1
    WHEN EXISTS (
      SELECT 1 FROM runs ahead WHERE ahead.tenant_id=sibling.tenant_id AND ahead.session_id=sibling.session_id AND ahead.status='pending'
        AND ahead.claim_priority > 0 AND (ahead.claim_priority > 0 AND ahead.last_stop::jsonb->>'kind' = 'parked') IS NOT TRUE
        AND (ahead.created_at, ahead.seq) < (sibling.created_at, sibling.seq)
    ) THEN 1 ELSE 0 END), sibling.created_at, sibling.seq) < ((CASE WHEN candidate.claim_priority <> 0 THEN 1
    WHEN EXISTS (
      SELECT 1 FROM runs ahead WHERE ahead.tenant_id=candidate.tenant_id AND ahead.session_id=candidate.session_id AND ahead.status='pending'
        AND ahead.claim_priority > 0 AND (ahead.claim_priority > 0 AND ahead.last_stop::jsonb->>'kind' = 'parked') IS NOT TRUE
        AND (ahead.created_at, ahead.seq) < (candidate.created_at, candidate.seq)
    ) THEN 1 ELSE 0 END), candidate.created_at, candidate.seq) END))))
    OFFSET 0
  )
         AND candidate.claim_priority=0 AND candidate.created_at <= $1 LIMIT 1 $_$;


--
-- Name: claim_web_ui_state(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_web_ui_state() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM web_ui_state ORDER BY tenant_id, id $$;


--
-- Name: claim_web_ui_state_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_web_ui_state_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'web_ui_state'::text FROM web_ui_state $$;


--
-- Name: claim_webhook_history(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_webhook_history() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM webhook_history ORDER BY tenant_id, id $$;


--
-- Name: claim_webhook_history_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_webhook_history_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'webhook_history'::text FROM webhook_history $$;


--
-- Name: claim_webhooks(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_webhooks() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM webhooks ORDER BY tenant_id, id $$;


--
-- Name: claim_webhooks_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_webhooks_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'webhooks'::text FROM webhooks $$;


--
-- Name: claim_webhooks_tenants_by_ownerscopeid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_webhooks_tenants_by_ownerscopeid(value text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'webhooks'::text FROM webhooks WHERE lower(json->>'ownerScopeId') = lower(value) $$;


--
-- Name: claim_webui_model_configs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_webui_model_configs() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT tenant_id, id FROM webui_model_configs ORDER BY tenant_id, id $$;


--
-- Name: claim_webui_model_configs_tenants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_webui_model_configs_tenants() RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT DISTINCT tenant_id, 'webui_model_configs'::text FROM webui_model_configs $$;


--
-- Name: expire_deliveries(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.expire_deliveries(bigint) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ UPDATE deliveries SET expired_at = (EXTRACT(EPOCH FROM clock_timestamp()) * 1000)::BIGINT
            WHERE (tenant_id, id) IN (SELECT tenant_id, id FROM deliveries WHERE delivered_at IS NULL AND expired_at IS NULL AND NOT shadow
  AND (claim_expires_at IS NULL OR claim_expires_at <= (EXTRACT(EPOCH FROM clock_timestamp()) * 1000)::BIGINT) AND destination->'webTranscript'->>'kind' IS DISTINCT FROM 'slack_reply'
  AND created_at <= (EXTRACT(EPOCH FROM clock_timestamp()) * 1000)::BIGINT - $1 FOR UPDATE SKIP LOCKED)
            RETURNING tenant_id, id::text $_$;


--
-- Name: forbid_direct_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_direct_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     IF pg_trigger_depth() > 1 THEN RETURN OLD; END IF;
     RAISE EXCEPTION 'DELETE on % is only allowed through its session', TG_TABLE_NAME
       USING ERRCODE = 'integrity_constraint_violation';
   END $$;


--
-- Name: forbid_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     RAISE EXCEPTION '% on % is forbidden', TG_OP, TG_TABLE_NAME USING ERRCODE = 'integrity_constraint_violation';
   END $$;


--
-- Name: invalidate_request_spend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_request_spend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
           BEGIN
             INSERT INTO session_spend_dirty(day)
             SELECT DISTINCT floor(at::numeric / 86400000)::bigint
               FROM (VALUES
                 (CASE WHEN TG_OP <> 'INSERT' AND OLD.usage_json IS NOT NULL THEN OLD.created_at END),
                 (CASE WHEN TG_OP <> 'DELETE' AND NEW.usage_json IS NOT NULL THEN NEW.created_at END)
               ) changed(at) WHERE at IS NOT NULL
             ON CONFLICT DO NOTHING;
             RETURN NULL;
           END $$;


--
-- Name: invalidate_session_spend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_session_spend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
           BEGIN
             IF TG_OP = 'UPDATE' AND ROW(OLD.id, OLD.scope_id, OLD.origin, OLD.thread_ref, OLD.parent_session_id)
                  IS NOT DISTINCT FROM ROW(NEW.id, NEW.scope_id, NEW.origin, NEW.thread_ref, NEW.parent_session_id) THEN
               RETURN NULL;
             END IF;
             INSERT INTO session_spend_dirty(session_id)
             SELECT DISTINCT id FROM (VALUES (OLD.id), (NEW.id)) changed(id) WHERE id IS NOT NULL;
             RETURN NULL;
           END $$;


--
-- Name: memory_fact_vectors_bits(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.memory_fact_vectors_bits() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
          NEW.embedding_bits := binary_quantize(NEW.embedding);
          RETURN NEW;
        END $$;


--
-- Name: memory_facts_text_hash(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.memory_facts_text_hash() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        NEW.text_hash := encode(sha256(convert_to(NEW.text, 'UTF8')), 'hex');
        RETURN NEW;
      END $$;


--
-- Name: qm_boot_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_boot_tenant() RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public'
    AS $$
      SELECT CASE WHEN count(*) = 1 THEN (array_agg(id))[1] END FROM (SELECT id FROM public.tenants LIMIT 2) one
    $$;


--
-- Name: qm_bound_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_bound_tenant() RETURNS uuid
    LANGUAGE plpgsql STABLE PARALLEL SAFE
    AS $$
DECLARE
  bound text := current_setting('qm.tenant_id', true);
BEGIN
  IF bound IS NULL OR bound = '' THEN
    RAISE insufficient_privilege USING MESSAGE = 'No tenant is bound to this query';
  END IF;
  RETURN bound::uuid;
END $$;


--
-- Name: qm_host_tenant(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_host_tenant(requested text) RETURNS TABLE(tenant_id uuid, multi boolean, retired boolean)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
      SELECT (SELECT h.tenant_id FROM tenant_hosts h WHERE h.host = lower(requested)),
        EXISTS (SELECT 1 FROM tenant_hosts) OR EXISTS (SELECT 1 FROM retired_tenant_hosts),
        EXISTS (SELECT 1 FROM retired_tenant_hosts r WHERE r.host = lower(requested))
    $$;


--
-- Name: qm_retire_tenant_hosts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_retire_tenant_hosts() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
      BEGIN
        INSERT INTO retired_tenant_hosts(host) SELECT h.host FROM tenant_hosts h WHERE h.tenant_id = OLD.id
          ON CONFLICT (host) DO NOTHING;
        RETURN OLD;
      END
    $$;


--
-- Name: qm_set_tenant_handle(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_set_tenant_handle(handle text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  BEGIN
    IF qm_tenant_handle(jsonb_build_object('handle', handle)) IS DISTINCT FROM handle THEN
      RAISE invalid_parameter_value USING MESSAGE = 'invalid app handle';
    END IF;
    UPDATE tenants SET settings = jsonb_set(settings, '{handle}', to_jsonb(handle)) WHERE id = qm_bound_tenant();
  END $$;


--
-- Name: qm_sole_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_sole_tenant(OUT sole uuid, OUT tenants bigint) RETURNS record
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
       SELECT CASE WHEN count(*) = 1 THEN min(id::text)::uuid END, count(*) FROM tenants
     $$;


--
-- Name: qm_tenant_for_app_handle(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_for_app_handle(handle text) RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT id FROM tenants WHERE qm_tenant_handle(settings) = lower(handle)
$$;


--
-- Name: qm_tenant_for_app_host(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_for_app_host(label text) RETURNS uuid
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  DECLARE found uuid;
  BEGIN
    IF strpos(label, '-') > 1 THEN
      found := qm_tenant_for_app_handle(split_part(label, '-', 1));
      IF found IS NOT NULL THEN RETURN found; END IF;
    END IF;
    RETURN qm_tenant_for_deployment(label);
  END $$;


--
-- Name: qm_tenant_handle(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_handle(settings jsonb) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $_$
      SELECT CASE WHEN h ~ '^[a-z0-9]{2,61}$' AND h <> ALL (ARRAY['auth', 'slack', 'mt', 'www', 'api', 'docs', 'apps', 'admin']) THEN h END
        FROM (SELECT coalesce(settings->>'handle',
          regexp_replace(lower(coalesce(settings->>'orgSlug', '')), '[^a-z0-9]', '', 'g')) AS h) picked
    $_$;


--
-- Name: qm_tenant_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_id() RETURNS uuid
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$ SELECT id FROM qm_tenant $$;


--
-- Name: qm_tenant_settings(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_settings() RETURNS jsonb
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
      SELECT settings FROM tenants WHERE id = qm_bound_tenant()
    $$;


--
-- Name: qm_tenants_for_email(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenants_for_email(email text) RETURNS TABLE(tenant_id uuid)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ BEGIN
      RETURN QUERY
        SELECT m.tenant_id FROM directory_members m
         WHERE lower(m.principal_id) = lower(email) AND m.type = 'internal'
        UNION
        SELECT g.tenant_id FROM admin_grants g WHERE lower(g.principal_id) = lower(email)
        UNION
        SELECT l.tenant_id FROM user_links l JOIN users u ON u.tenant_id = l.tenant_id AND u.id = l.user_id
            AND u.kind = 'person' AND u.offboarded_at IS NULL WHERE l.alias_id = lower(btrim(email));
    END $$;


--
-- Name: spend_usage_json(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.spend_usage_json(t text) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE
    AS $$
             DECLARE j jsonb;
             BEGIN
               IF t IS NULL OR octet_length(t) > 2000 OR NOT pg_input_is_valid(t, 'jsonb') THEN
                 RETURN NULL;
               END IF;
               j := t::jsonb;
               IF pg_input_is_valid(j ->> 'costUsd', 'double precision') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'input', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'output', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheRead', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheWrite', 'bigint') IS NOT FALSE THEN
                 RETURN j;
               END IF;
               RETURN NULL;
             END
             $$;


--
-- Name: undelivered_delivery_tenants(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.undelivered_delivery_tenants(text) RETURNS TABLE(tenant_id uuid, id text)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$ SELECT DISTINCT tenant_id, $1 FROM deliveries
            WHERE delivered_at IS NULL AND expired_at IS NULL AND NOT shadow AND destination->>'type' = $1 $_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ack_emoji; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: ack_emoji_picks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji_picks (
    id bigint NOT NULL,
    org_id text NOT NULL,
    surface text NOT NULL,
    channel text NOT NULL,
    ts text NOT NULL,
    outcome text NOT NULL,
    picked text,
    icon text,
    message text,
    candidates text,
    model text,
    latency_ms integer,
    created_at bigint NOT NULL
);


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ack_emoji_picks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ack_emoji_picks_id_seq OWNED BY public.ack_emoji_picks.id;


--
-- Name: acl_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acl_grants (
    owner_scope_id text NOT NULL,
    path text NOT NULL,
    grantee_scope_id text NOT NULL,
    permission text NOT NULL,
    granted_by text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: acl_grants_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acl_grants_version (
    only_row boolean DEFAULT true NOT NULL,
    v bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    CONSTRAINT acl_grants_version_only_row_check CHECK (only_row)
);


--
-- Name: admin_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_grants (
    principal_id text NOT NULL,
    scope_id text NOT NULL,
    role text NOT NULL,
    granted_by text,
    created_at bigint,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: ambient_cursors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ambient_cursors (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: ambient_judgments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ambient_judgments (
    id bigint NOT NULL,
    org_id text NOT NULL,
    surface text NOT NULL,
    container text NOT NULL,
    decision text NOT NULL,
    reason text,
    asked_by text,
    prompt text,
    model text,
    latency_ms integer,
    ts_from text,
    ts_to text,
    created_at bigint NOT NULL
);


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ambient_judgments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ambient_judgments_id_seq OWNED BY public.ambient_judgments.id;


--
-- Name: app_page_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_page_views (
    id bigint NOT NULL,
    deployment_id text NOT NULL,
    version integer,
    viewer text,
    auth_mode text NOT NULL,
    at bigint NOT NULL,
    path text NOT NULL,
    ip text,
    user_agent text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: app_page_views_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.app_page_views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: app_page_views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.app_page_views_id_seq OWNED BY public.app_page_views.id;


--
-- Name: approval_grant_modes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grant_modes (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: approval_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grants (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approvals (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    at bigint NOT NULL,
    principal_id text NOT NULL,
    action text NOT NULL,
    resource text NOT NULL,
    scope_label text NOT NULL,
    status text,
    detail text,
    idempotency_key text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: auth_broker_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_broker_sessions (
    token_hash text NOT NULL,
    email text NOT NULL,
    authenticated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    absolute_expires_at timestamp with time zone NOT NULL,
    idle_seconds integer NOT NULL
);


--
-- Name: auto_flagger_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_flagger_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: aws_deploy_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aws_deploy_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: aws_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aws_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: base_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.base_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blobs (
    tenant_id uuid NOT NULL,
    sha256 bytea NOT NULL,
    size bigint NOT NULL,
    mime text,
    storage_key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT blobs_sha256_check CHECK ((length(sha256) = 32)),
    CONSTRAINT blobs_size_check CHECK ((size >= 0)),
    CONSTRAINT blobs_storage_key_check CHECK ((storage_key <> ''::text))
);


--
-- Name: branding_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: browse_max_steps_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_max_steps_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: browse_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: browser_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browser_sessions (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: budget_spend; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_spend (
    id bigint NOT NULL,
    principal_id text NOT NULL,
    at bigint NOT NULL,
    usd double precision NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: budget_spend_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budget_spend_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budget_spend_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budget_spend_id_seq OWNED BY public.budget_spend.id;


--
-- Name: channel_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_files (
    org_id text NOT NULL,
    container text NOT NULL,
    ts text NOT NULL,
    file_id text NOT NULL,
    name text,
    mimetype text,
    created_at bigint NOT NULL,
    title text,
    size bigint
);


--
-- Name: channel_header_pin_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_header_pin_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: channel_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_messages (
    org_id text NOT NULL,
    container text NOT NULL,
    ts text NOT NULL,
    sub text,
    author_id text,
    author_name text,
    text text DEFAULT ''::text NOT NULL,
    mentions jsonb,
    self boolean DEFAULT false NOT NULL,
    bot boolean DEFAULT false NOT NULL,
    mentions_self boolean DEFAULT false NOT NULL,
    edited_at bigint,
    deleted boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    handled boolean DEFAULT false NOT NULL,
    tsv tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(text, ''::text))) STORED,
    deleted_at bigint,
    broadcast boolean DEFAULT false NOT NULL,
    subtype text,
    bot_id text
);


--
-- Name: channel_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_policy (
    org_id text NOT NULL,
    container text NOT NULL,
    orders text DEFAULT ''::text NOT NULL,
    bots jsonb DEFAULT '{}'::jsonb NOT NULL,
    set_by text,
    updated_at bigint NOT NULL,
    ambient_enabled boolean
);


--
-- Name: channel_policy_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_policy_history (
    id bigint NOT NULL,
    org_id text NOT NULL,
    container text NOT NULL,
    orders text NOT NULL,
    set_by text,
    session_id text,
    created_at bigint NOT NULL,
    bots jsonb,
    ambient_enabled boolean
);


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.channel_policy_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.channel_policy_history_id_seq OWNED BY public.channel_policy_history.id;


--
-- Name: channel_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_state (
    org_id text NOT NULL,
    container text NOT NULL,
    last_ts text,
    oldest_ts text,
    name text,
    kind text,
    members jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: command_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.command_policies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: composio_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.composio_returns (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: connector_clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_clients (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: consent_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consent_links (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: context_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.context_requests (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: credential_daily_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_daily_calls (
    slug text NOT NULL,
    day bigint NOT NULL,
    sent integer NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: credential_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_usage (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    slug text NOT NULL,
    host text NOT NULL,
    status text NOT NULL,
    upstream_status integer,
    scope_label text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: credential_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credential_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credential_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credential_usage_id_seq OWNED BY public.credential_usage.id;


--
-- Name: cron_fires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cron_fires (
    cron_id text NOT NULL,
    fire_key text NOT NULL,
    thread_ref text NOT NULL,
    session_id text,
    fired_at bigint NOT NULL,
    scheduled_at bigint,
    ended_at bigint,
    status text,
    note text,
    reply text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: crons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crons (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: custom_model_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_model_providers (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deactivated_principals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deactivated_principals (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: decision_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_providers (
    provider_id text NOT NULL,
    protocol text NOT NULL,
    base_url text,
    credential text,
    updated_by text NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: decision_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_rules (
    rule_id text NOT NULL,
    hook text NOT NULL,
    question text NOT NULL,
    options json NOT NULL,
    provider_id text NOT NULL,
    model text NOT NULL,
    mode text NOT NULL,
    on_error text NOT NULL,
    updated_by text NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    CONSTRAINT decision_rules_mode_check CHECK ((mode = ANY (ARRAY['off'::text, 'observe'::text, 'enforce'::text])))
);


--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deliveries (
    id text NOT NULL,
    idempotency_key text NOT NULL,
    destination jsonb NOT NULL,
    text text NOT NULL,
    created_at bigint NOT NULL,
    delivered_at bigint,
    attachments jsonb,
    provenance jsonb,
    recipient_thread_ref text,
    shadow boolean DEFAULT false NOT NULL,
    deliver_latency_ms integer,
    slack_api_ms integer,
    claim_expires_at bigint,
    expired_at bigint,
    source_cron_id text,
    failed_reason text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deploy_git_repos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deploy_git_repos (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deployment_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_access (
    id text NOT NULL,
    last_access_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deployment_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_identity (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deployment_layer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_layer (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: deployments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployments (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_channel_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_channel_members (
    org_id text NOT NULL,
    channel_id text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_channels (
    org_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    name_lc text NOT NULL,
    is_private boolean DEFAULT false NOT NULL,
    is_external boolean DEFAULT false NOT NULL,
    roster_known boolean DEFAULT false NOT NULL,
    observed_at bigint,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_group_members (
    org_id text NOT NULL,
    group_id text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_groups (
    org_id text NOT NULL,
    group_id text NOT NULL,
    roster_known boolean DEFAULT false NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_members (
    org_id text NOT NULL,
    principal_id text NOT NULL,
    display_name text NOT NULL,
    display_name_lc text NOT NULL,
    type text NOT NULL,
    slack_id text,
    avatar_url text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_meta (
    org_id text NOT NULL,
    workspace_url text,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_sync; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_sync (
    org_id text NOT NULL,
    members_hash text,
    channels_hash text,
    groups_hash text,
    channel_members_synced boolean DEFAULT false NOT NULL,
    updated_at bigint NOT NULL,
    members_synced_at bigint,
    channels_synced_at bigint,
    groups_synced_at bigint,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: do_managed_agents_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.do_managed_agents_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: durable_map_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.durable_map_versions (
    tbl text NOT NULL,
    v bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: e2b_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.e2b_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: egress_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_events (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    source text NOT NULL,
    host text NOT NULL,
    allowed boolean NOT NULL,
    scope_label text NOT NULL,
    port integer,
    verdict text,
    via text,
    peer_ip text,
    principal_id text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: egress_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.egress_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: egress_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.egress_events_id_seq OWNED BY public.egress_events.id;


--
-- Name: egress_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_policies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: environment_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environment_attachments (
    scope_id text NOT NULL,
    environment_id text NOT NULL,
    attached_by text NOT NULL,
    attached_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: environments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environments (
    id text NOT NULL,
    org_id text NOT NULL,
    name text,
    owner_actor_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: error_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.error_events (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    scope_label text NOT NULL,
    category text NOT NULL,
    code text NOT NULL,
    message text NOT NULL,
    session_id text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: error_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.error_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: error_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.error_events_id_seq OWNED BY public.error_events.id;


--
-- Name: external_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_members (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: external_slack_participants_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_slack_participants_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: file_artifact_deletions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_artifact_deletions (
    id text NOT NULL,
    deleted_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: file_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_artifacts (
    id text NOT NULL,
    kind text DEFAULT 'file'::text NOT NULL,
    owner_scope_id text NOT NULL,
    path text NOT NULL,
    name text NOT NULL,
    mimetype text NOT NULL,
    size_bytes bigint NOT NULL,
    blob_key text,
    sha256 text,
    direction text NOT NULL,
    created_by text NOT NULL,
    created_in_scope text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    source text DEFAULT 'live'::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: file_uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_uploads (
    id text NOT NULL,
    actor_id text NOT NULL,
    state text NOT NULL,
    size_bytes bigint NOT NULL,
    expires_at bigint NOT NULL,
    data jsonb NOT NULL,
    next_attempt_at bigint DEFAULT 0 NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: fly_deploy_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fly_deploy_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: fly_deploy_ports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fly_deploy_ports (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: fly_peer_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fly_peer_claims (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: individual_model_auth_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.individual_model_auth_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: instance_heartbeats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.instance_heartbeats (
    instance_id text NOT NULL,
    build_sha text NOT NULL,
    started_at bigint NOT NULL,
    beat_at timestamp with time zone NOT NULL,
    running boolean DEFAULT false NOT NULL
);


--
-- Name: interactive_fast_mode_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interactive_fast_mode_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    tenant_id uuid NOT NULL,
    session_id text NOT NULL,
    seq bigint NOT NULL,
    turn_id uuid,
    kind public.item_kind NOT NULL,
    author text,
    call_id text,
    elicit_id text,
    wake_cause public.wake_cause,
    error_code text,
    text text,
    tool text,
    step integer,
    variant text,
    is_error boolean,
    hidden boolean,
    external_id text,
    through_seq bigint,
    approved boolean,
    blob_sha bytea,
    search tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, COALESCE(text, ''::text))) STORED,
    body jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT items_approved_kind CHECK (((approved IS NULL) OR (kind = 'ElicitationResponse'::public.item_kind))),
    CONSTRAINT items_author_check CHECK ((author <> ''::text)),
    CONSTRAINT items_author_kind CHECK (((author IS NULL) OR (kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'ElicitationResponse'::public.item_kind, 'Stop'::public.item_kind, 'RuntimeChange'::public.item_kind])))),
    CONSTRAINT items_blob_sha_kind CHECK (((blob_sha IS NULL) OR (kind = 'ToolResult'::public.item_kind))),
    CONSTRAINT items_body_check CHECK ((jsonb_typeof(body) = 'object'::text)),
    CONSTRAINT items_call_id_check CHECK ((call_id <> ''::text)),
    CONSTRAINT items_call_id_kind CHECK (((call_id IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind])))),
    CONSTRAINT items_elicit_id_check CHECK ((elicit_id <> ''::text)),
    CONSTRAINT items_elicit_id_kind CHECK (((elicit_id IS NOT NULL) = (kind = ANY (ARRAY['Elicitation'::public.item_kind, 'ElicitationResponse'::public.item_kind])))),
    CONSTRAINT items_error_code_check CHECK ((error_code <> ''::text)),
    CONSTRAINT items_error_code_kind CHECK (((error_code IS NOT NULL) = (kind = 'Error'::public.item_kind))),
    CONSTRAINT items_external_id_check CHECK ((external_id <> ''::text)),
    CONSTRAINT items_external_id_kind CHECK (((external_id IS NULL) OR (kind = 'UserMessage'::public.item_kind))),
    CONSTRAINT items_hidden_kind CHECK (((hidden IS NULL) OR (kind = 'UserMessage'::public.item_kind))),
    CONSTRAINT items_is_error_kind CHECK (((is_error IS NULL) OR (kind = 'ToolResult'::public.item_kind))),
    CONSTRAINT items_seq_check CHECK ((seq >= 0)),
    CONSTRAINT items_step_check CHECK ((step >= 0)),
    CONSTRAINT items_step_kind CHECK (((step IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind, 'Reasoning'::public.item_kind, 'AgentMessage'::public.item_kind])))),
    CONSTRAINT items_text_check CHECK ((text <> ''::text)),
    CONSTRAINT items_text_kind CHECK (((text IS NULL) OR (kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'AgentMessage'::public.item_kind, 'Reasoning'::public.item_kind, 'ToolResult'::public.item_kind, 'Error'::public.item_kind, 'ContextCompaction'::public.item_kind])))),
    CONSTRAINT items_through_seq_kind CHECK (((through_seq IS NULL) OR (kind = 'ContextCompaction'::public.item_kind))),
    CONSTRAINT items_tool_check CHECK ((tool <> ''::text)),
    CONSTRAINT items_tool_kind CHECK (((tool IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind])))),
    CONSTRAINT items_variant_check CHECK ((variant = ANY (ARRAY['narration'::text, 'files_delivered'::text]))),
    CONSTRAINT items_variant_kind CHECK (((variant IS NULL) OR (kind = 'AgentMessage'::public.item_kind))),
    CONSTRAINT items_wake_cause_kind CHECK (((wake_cause IS NOT NULL) = (kind = 'Wake'::public.item_kind)))
);


--
-- Name: keychain_asks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_asks (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: keychain_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_credentials (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: keychain_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_grants (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: llm_prompt_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_prompt_envelopes (
    hash text NOT NULL,
    body text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid NOT NULL
);


--
-- Name: loop_ingress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_ingress (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loop_ingress_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_ingress_deliveries (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loop_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_items (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loop_outputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_outputs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loop_ship_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_ship_grants (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loops (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_servers (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: memory_fact_vectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_fact_vectors (
    scope_id text NOT NULL,
    model text NOT NULL,
    fact_id bigint NOT NULL,
    fact_hash text NOT NULL,
    dimensions integer NOT NULL,
    embedding public.vector NOT NULL,
    embedding_bits bit varying,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    CONSTRAINT memory_fact_vectors_check CHECK ((public.vector_dims(embedding) = dimensions)),
    CONSTRAINT memory_fact_vectors_dimensions_check CHECK (((dimensions >= 1) AND (dimensions <= 16000)))
);


--
-- Name: memory_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_facts (
    id bigint NOT NULL,
    scope_id text NOT NULL,
    text text NOT NULL,
    sensitivity text NOT NULL,
    sources text[] DEFAULT '{}'::text[] NOT NULL,
    source_unknown boolean NOT NULL,
    author text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    deleted_at bigint,
    text_hash text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: memory_facts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.memory_facts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: memory_facts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.memory_facts_id_seq OWNED BY public.memory_facts.id;


--
-- Name: memory_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_registry (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: memory_tidy_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_tidy_profiles (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: modal_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modal_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: model_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_credentials (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: model_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_registry (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: monitors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monitors (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: oauth_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_flows (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: org_ambient_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_ambient_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.participants (
    session_id text NOT NULL,
    principal_id text NOT NULL,
    valid_from bigint DEFAULT 0 NOT NULL,
    valid_to bigint,
    valid_from_seq integer DEFAULT 0,
    valid_to_seq integer,
    title text,
    archived boolean DEFAULT false NOT NULL,
    pinned boolean DEFAULT false NOT NULL,
    color text,
    read_at bigint,
    tenant_id uuid NOT NULL
);


--
-- Name: people_directory_urls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.people_directory_urls (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: porter_deploy_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.porter_deploy_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: principal_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.principal_links (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: process_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_sessions (
    process_id text NOT NULL,
    scope_id text NOT NULL,
    kind text NOT NULL,
    command text NOT NULL,
    started_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    status text NOT NULL,
    session_ref text,
    run_id text,
    sandbox_id text,
    purpose text,
    credential_files jsonb,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: qm_schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_schema_migrations (
    id text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: qm_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: qm_tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_tenant (
    id uuid NOT NULL
);


--
-- Name: rate_limit_windows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limit_windows (
    principal_id text NOT NULL,
    window_start bigint NOT NULL,
    count integer NOT NULL
);


--
-- Name: render_app_storage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_app_storage (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: render_deploy_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_deploy_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: render_deploy_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_deploy_credentials (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: render_sandbox_bases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_sandbox_bases (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: render_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: render_sandbox_cleanup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_sandbox_cleanup (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: render_scratch_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_scratch_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: retired_tenant_hosts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retired_tenant_hosts (
    host text NOT NULL,
    retired_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT retired_tenant_hosts_host_check CHECK (((host = lower(host)) AND (host <> ''::text)))
);


--
-- Name: run_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_activity (
    id bigint NOT NULL,
    run_id text NOT NULL,
    seq bigint NOT NULL,
    parent_seq bigint,
    type text NOT NULL,
    payload jsonb NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: run_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_activity_id_seq OWNED BY public.run_activity.id;


--
-- Name: run_signals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_signals (
    id bigint NOT NULL,
    run_id text NOT NULL,
    kind text NOT NULL,
    text text,
    payload jsonb,
    created_at bigint NOT NULL,
    consumed_at bigint,
    dedupe_key text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: run_signals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_signals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_signals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_signals_id_seq OWNED BY public.run_signals.id;


--
-- Name: runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runs (
    id text NOT NULL,
    session_id text NOT NULL,
    status text NOT NULL,
    request text NOT NULL,
    result text,
    idempotency_key text,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    lease_token text,
    lease_expires_at bigint,
    worker_id text,
    created_at bigint NOT NULL,
    started_at bigint,
    finished_at bigint,
    delivery_state text,
    error_attempts integer DEFAULT 0 NOT NULL,
    seq bigint NOT NULL,
    turn_user_seq bigint,
    retry_after bigint DEFAULT 0 NOT NULL,
    returned_at bigint,
    last_stop text,
    claim_priority smallint DEFAULT 2 NOT NULL,
    preemptions integer DEFAULT 0 NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: runs_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.runs_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: runs_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.runs_seq_seq OWNED BY public.runs.seq;


--
-- Name: sandbox_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_defaults (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: sandbox_resource_rollout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_resource_rollout (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: sandbox_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_resources (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: sandbox_routing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_routing (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: secret_drops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secret_drops (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: security_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_postures (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: session_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_goals (
    session_id text NOT NULL,
    objective text NOT NULL,
    status text NOT NULL,
    floor jsonb,
    token_cap bigint,
    tokens_used bigint DEFAULT 0 NOT NULL,
    active_ms bigint,
    active_since timestamp with time zone,
    completion_note text,
    cancel_note text,
    governor jsonb,
    pause_reason text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    tenant_id uuid NOT NULL,
    CONSTRAINT session_goals_status_check CHECK ((status = ANY (ARRAY['active'::text, 'paused'::text, 'complete'::text, 'cancelled'::text])))
);


--
-- Name: session_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_leases (
    session_id text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    holder text,
    acquired_at bigint,
    tenant_id uuid NOT NULL
);


--
-- Name: session_llm_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_llm_requests (
    id text NOT NULL,
    session_id text NOT NULL,
    turn_seq integer,
    step integer NOT NULL,
    model text NOT NULL,
    scope_label text NOT NULL,
    truncated boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    ttft_ms integer,
    duration_ms integer,
    step_gap_ms integer,
    tool_wall_json text,
    usage_json text,
    transport_json text,
    gap_phases_json text,
    prompt_hash text,
    tenant_id uuid NOT NULL
);


--
-- Name: session_mailbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_mailbox (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: session_pins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_pins (
    id text NOT NULL,
    session_id text NOT NULL,
    text text,
    entry_seq integer,
    added_by text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid NOT NULL
);


--
-- Name: session_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_shares (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: session_spend_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_spend_days (
    day bigint NOT NULL,
    rows jsonb NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid NOT NULL
);


--
-- Name: session_spend_dirty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_spend_dirty (
    day bigint,
    session_id text,
    writer xid8 DEFAULT pg_current_xact_id() NOT NULL,
    tenant_id uuid NOT NULL,
    CONSTRAINT session_spend_dirty_check CHECK ((num_nonnulls(day, session_id) = 1))
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    type text NOT NULL,
    scope_id text NOT NULL,
    thread_ref text NOT NULL,
    created_at bigint NOT NULL,
    title text,
    channel_name text,
    surface text,
    last_activity bigint,
    messages integer,
    turns integer,
    forked_from_session_id text,
    forked_from_title text,
    fork_boundary_seq integer,
    origin text,
    origin_id text,
    parent_session_id text,
    spawn_meta text,
    first_user_preview text,
    last_user_preview text,
    client_tools jsonb,
    last_user_activity bigint,
    side_chat jsonb,
    slack_binding jsonb,
    runtime jsonb,
    persona_id text,
    tenant_id uuid NOT NULL,
    CONSTRAINT sessions_fork_provenance_pair CHECK (((forked_from_session_id IS NULL) = (fork_boundary_seq IS NULL)))
)
WITH (fillfactor='70');


--
-- Name: sharing_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sharing_postures (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: skill_bundles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_bundles (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: skill_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_packs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skills (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_accounts (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_emoji_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_emoji_catalog (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_installation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_installation (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_session_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_session_status (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_staged_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_staged_envelopes (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_task_acknowledgements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_task_acknowledgements (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: smolmachines_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smolmachines_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: soul_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: soul_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_history (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: source_auth_replay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_auth_replay (
    event_id text NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: spend_limit_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spend_limit_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: sprites_initialization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sprites_initialization (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: suggested_activity_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suggested_activity_profiles (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: superserve_config_epochs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superserve_config_epochs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: superserve_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superserve_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: swarms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.swarms (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_members (
    team_id text NOT NULL,
    principal_id text NOT NULL,
    role text NOT NULL,
    added_by text NOT NULL,
    added_at bigint NOT NULL,
    CONSTRAINT team_members_role_check CHECK ((role = ANY (ARRAY['member'::text, 'admin'::text])))
);


--
-- Name: team_rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_rooms (
    team_id text NOT NULL,
    scope_id text NOT NULL
);


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    team_id text NOT NULL,
    name text NOT NULL,
    isolated_in_open boolean DEFAULT false NOT NULL,
    created_by text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT tenants_settings_check CHECK ((jsonb_typeof(settings) = 'object'::text))
);


--
-- Name: turn_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.turn_metrics (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    scope_label text NOT NULL,
    session_id text,
    turn_seq integer,
    run_id text,
    status text NOT NULL,
    total_ms integer NOT NULL,
    ttft_ms integer,
    intake_preamble_ms integer,
    dispatch_ms integer,
    provisioned boolean,
    cold_start boolean,
    model_calls integer,
    tool_calls integer,
    provision_ms integer,
    materialize_ms integer,
    creds_ms integer,
    layers_ms integer,
    compile_ms integer,
    recall_ms integer,
    exec_ms integer,
    stream_ms integer,
    lease_ms integer,
    capture_ms integer,
    ingress_ms integer,
    detect_ms integer,
    compact_ms integer,
    queue_ms integer,
    deliver_ms integer,
    slack_inflight_ms integer,
    resumed_from_seq integer,
    cache_read bigint,
    cache_write bigint,
    uncached_input bigint,
    lease_wait_ms integer
);


--
-- Name: turn_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.turn_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: turn_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.turn_metrics_id_seq OWNED BY public.turn_metrics.id;


--
-- Name: unfulfilled_insights_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unfulfilled_insights_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: web_ui_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_ui_state (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: webhook_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_history (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: webui_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webui_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: ack_emoji_picks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks ALTER COLUMN id SET DEFAULT nextval('public.ack_emoji_picks_id_seq'::regclass);


--
-- Name: ambient_judgments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments ALTER COLUMN id SET DEFAULT nextval('public.ambient_judgments_id_seq'::regclass);


--
-- Name: app_page_views id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_page_views ALTER COLUMN id SET DEFAULT nextval('public.app_page_views_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: budget_spend id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_spend ALTER COLUMN id SET DEFAULT nextval('public.budget_spend_id_seq'::regclass);


--
-- Name: channel_policy_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history ALTER COLUMN id SET DEFAULT nextval('public.channel_policy_history_id_seq'::regclass);


--
-- Name: credential_usage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage ALTER COLUMN id SET DEFAULT nextval('public.credential_usage_id_seq'::regclass);


--
-- Name: egress_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events ALTER COLUMN id SET DEFAULT nextval('public.egress_events_id_seq'::regclass);


--
-- Name: error_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events ALTER COLUMN id SET DEFAULT nextval('public.error_events_id_seq'::regclass);


--
-- Name: memory_facts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts ALTER COLUMN id SET DEFAULT nextval('public.memory_facts_id_seq'::regclass);


--
-- Name: run_activity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity ALTER COLUMN id SET DEFAULT nextval('public.run_activity_id_seq'::regclass);


--
-- Name: run_signals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals ALTER COLUMN id SET DEFAULT nextval('public.run_signals_id_seq'::regclass);


--
-- Name: runs seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs ALTER COLUMN seq SET DEFAULT nextval('public.runs_seq_seq'::regclass);


--
-- Name: turn_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.turn_metrics ALTER COLUMN id SET DEFAULT nextval('public.turn_metrics_id_seq'::regclass);


--
-- Data for Name: ack_emoji; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ack_emoji (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: ack_emoji_picks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ack_emoji_picks (id, org_id, surface, channel, ts, outcome, picked, icon, message, candidates, model, latency_ms, created_at) VALUES
	(1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1);


--
-- Data for Name: acl_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.acl_grants (owner_scope_id, path, grantee_scope_id, permission, granted_by, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: acl_grants_version; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: admin_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.admin_grants (principal_id, scope_id, role, granted_by, created_at, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: ambient_cursors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ambient_cursors (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: ambient_judgments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ambient_judgments (id, org_id, surface, container, decision, reason, asked_by, prompt, model, latency_ms, ts_from, ts_to, created_at) VALUES
	(1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 1);


--
-- Data for Name: app_page_views; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_grant_modes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_grant_modes (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: approval_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_grants (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: approvals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approvals (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_log (id, at, principal_id, action, resource, scope_label, status, detail, idempotency_key, tenant_id) VALUES
	(1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: auth_broker_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_broker_sessions (token_hash, email, authenticated_at, expires_at, absolute_expires_at, idle_seconds) VALUES
	('upgrade-check', 'upgrade-check', '2026-11-11 19:05:25.475767+00', '2026-11-11 19:05:25.475767+00', '2026-11-11 19:05:25.475767+00', 1);


--
-- Data for Name: auto_flagger_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auto_flagger_configs (id, json) VALUES
	('upgrade-check', '{}');


--
-- Data for Name: aws_deploy_bodies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: aws_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.aws_sandbox_bodies (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: base_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.base_model_configs (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: blobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: branding_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.branding_configs (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: browse_max_steps_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.browse_max_steps_configs (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: browse_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.browse_model_configs (id, json) VALUES
	('upgrade-check', '{}');


--
-- Data for Name: browser_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.browser_sessions (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: budget_spend; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_files; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_files (org_id, container, ts, file_id, name, mimetype, created_at, title, size) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 1);


--
-- Data for Name: channel_header_pin_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_header_pin_flag (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: channel_messages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_messages (org_id, container, ts, sub, author_id, author_name, text, mentions, self, bot, mentions_self, edited_at, deleted, created_at, handled, deleted_at, broadcast, subtype, bot_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '', '{}', false, false, false, 1, false, 1, false, 1, false, 'upgrade-check', 'upgrade-check');


--
-- Data for Name: channel_policy; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_policy (org_id, container, orders, bots, set_by, updated_at, ambient_enabled) VALUES
	('upgrade-check', 'upgrade-check', '', '{}', 'upgrade-check', 1, false);


--
-- Data for Name: channel_policy_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_policy_history (id, org_id, container, orders, set_by, session_id, created_at, bots, ambient_enabled) VALUES
	(1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, '{}', false);


--
-- Data for Name: channel_state; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_state (org_id, container, last_ts, oldest_ts, name, kind, members, updated_at) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '[]', 1);


--
-- Data for Name: command_policies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.command_policies (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: composio_returns; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.composio_returns (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: connector_clients; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.connector_clients (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: consent_links; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.consent_links (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: context_requests; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.context_requests (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: credential_daily_calls; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.credential_daily_calls (slug, day, sent, tenant_id) VALUES
	('upgrade-check', 1, 1, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: credential_usage; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.credential_usage (id, ts, slug, host, status, upstream_status, scope_label, principal_id, tenant_id) VALUES
	(1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: cron_fires; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.cron_fires (cron_id, fire_key, thread_ref, session_id, fired_at, scheduled_at, ended_at, status, note, reply, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: crons; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.crons (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: custom_model_providers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.custom_model_providers (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: deactivated_principals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deactivated_principals (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: decision_providers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.decision_providers (provider_id, protocol, base_url, credential, updated_by, updated_at, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: decision_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deliveries (id, idempotency_key, destination, text, created_at, delivered_at, attachments, provenance, recipient_thread_ref, shadow, deliver_latency_ms, slack_api_ms, claim_expires_at, expired_at, source_cron_id, failed_reason, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', '{}', 'upgrade-check', 1, 1, '{}', '{}', 'upgrade-check', false, 1, 1, 1, 1, 'upgrade-check', NULL, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: deploy_git_repos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deploy_git_repos (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: deployment_access; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deployment_access (id, last_access_at, tenant_id) VALUES
	('upgrade-check', 1, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: deployment_identity; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deployment_identity (id, json, tenant_id) VALUES
	('singleton', '{"orgId": "default-org"}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: deployment_layer; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deployment_layer (id, json) VALUES
	('upgrade-check', '{}');


--
-- Data for Name: deployments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deployments (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: directory_channel_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_channel_members (org_id, channel_id, principal_id, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: directory_channels; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_channels (org_id, channel_id, name, name_lc, is_private, is_external, roster_known, observed_at, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', false, false, false, 1, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: directory_group_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_group_members (org_id, group_id, principal_id, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: directory_groups; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_groups (org_id, group_id, roster_known, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', false, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: directory_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_members (org_id, principal_id, display_name, display_name_lc, type, slack_id, avatar_url, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: directory_meta; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_meta (org_id, workspace_url, updated_at, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 1, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: directory_sync; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_sync (org_id, members_hash, channels_hash, groups_hash, channel_members_synced, updated_at, members_synced_at, channels_synced_at, groups_synced_at, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', false, 1, 1, 1, 1, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: do_managed_agents_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.do_managed_agents_sandbox_bodies (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: durable_map_versions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.durable_map_versions (tbl, v, tenant_id) VALUES
	('deployment_identity', 1, 'ee4a3194-8db6-4173-9d32-006834a7795e'),
	('skills', 87, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: e2b_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.e2b_sandbox_bodies (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: egress_events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.egress_events (id, ts, source, host, allowed, scope_label, port, verdict, via, peer_ip, principal_id, tenant_id) VALUES
	(1, 1, 'upgrade-check', 'upgrade-check', false, 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: egress_policies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.egress_policies (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: environment_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.environment_attachments (scope_id, environment_id, attached_by, attached_at, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: environments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.environments (id, org_id, name, owner_actor_id, created_at, updated_at, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: error_events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.error_events (id, ts, scope_label, category, code, message, session_id, tenant_id) VALUES
	(1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: external_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.external_members (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: external_slack_participants_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.external_slack_participants_flag (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.feature_flags (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: file_artifact_deletions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.file_artifact_deletions (id, deleted_at, tenant_id) VALUES
	('upgrade-check', 1, 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: file_artifacts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.file_artifacts (id, kind, owner_scope_id, path, name, mimetype, size_bytes, blob_key, sha256, direction, created_by, created_in_scope, created_at, updated_at, enabled, source, tenant_id) VALUES
	('upgrade-check', 'file', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, true, 'live', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: file_uploads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: fly_deploy_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: fly_deploy_ports; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: fly_peer_claims; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: idempotency; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.idempotency (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: individual_model_auth_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.individual_model_auth_flag (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: instance_heartbeats; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: interactive_fast_mode_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.interactive_fast_mode_flag (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: keychain_asks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.keychain_asks (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: keychain_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.keychain_credentials (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: keychain_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.keychain_grants (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: llm_prompt_envelopes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: loop_ingress; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loop_ingress (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: loop_ingress_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loop_ingress_deliveries (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: loop_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loop_items (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: loop_outputs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loop_outputs (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: loop_ship_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loop_ship_grants (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: loops; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loops (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: mcp_servers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.mcp_servers (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: memory_fact_vectors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: memory_facts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.memory_facts (id, scope_id, text, sensitivity, sources, source_unknown, author, created_at, updated_at, deleted_at, text_hash, tenant_id) VALUES
	(1, 'upgrade-check', 'upgrade-check', 'upgrade-check', '{}', false, 'upgrade-check', 1, 1, 1, '0e86a3eb66c5a39e77dfdae108be1e0783a1b87813898cda9bb68ba8143b7999', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: memory_registry; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: memory_tidy_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.memory_tidy_profiles (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: modal_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.modal_sandbox_bodies (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: model_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.model_credentials (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: model_registry; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.model_registry (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: monitors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.monitors (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: oauth_flows; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.oauth_flows (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: org_ambient_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.org_ambient_flag (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: participants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: people_directory_urls; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.people_directory_urls (id, json) VALUES
	('upgrade-check', '{}');


--
-- Data for Name: porter_deploy_bodies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: principal_links; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.principal_links (id, json) VALUES
	('upgrade-check', '{}');


--
-- Data for Name: process_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.process_sessions (process_id, scope_id, kind, command, started_at, expires_at, status, session_ref, run_id, sandbox_id, purpose, credential_files, tenant_id) VALUES
	('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.projects (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: qm_schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_schema_migrations (id, checksum, applied_at) VALUES
	('acl/grants/0001', '11758af3276004ec5ba9f283d35867d074999b2413b1ab6d74a4545e8fba16fa', '2026-11-11 19:05:13.979332+00'),
	('acl/grants/0002', '86f3cbd7981ea8e137a31f6e66936ce53654c013c6f20dbb9924692a2263ed0d', '2026-11-11 19:05:13.98417+00'),
	('acl/grants/0003-file-ids', '2ad7a5a68acb5da6ed801d2b4c1d56391e14bf1eef0356948f661c5a293825de', '2026-11-11 19:05:13.990193+00'),
	('admin/audit-log/0001', '542f2a64d2814b329f2c1ad2eb8ed2728e8044b78efa6343eafb5598bc83cb1d', '2026-11-11 19:05:13.993696+00'),
	('admin/audit-log/0002', 'bce8b31764744856dab57f8ced3a2e33b36e5896ff0f915152dc466741be3828', '2026-11-11 19:05:14.00249+00'),
	('admin/grants/0001', '1a92727b41adaa11bf3029a419a8a5ca9213b0fbab91df905b7e58803cc73ce4', '2026-11-11 19:05:14.004843+00'),
	('admin/scoped-events/credential_usage/0001', '42188c2f50734398496ddd5a47a9ec3c15a507059c713a4a6ced0b0b81d908eb', '2026-11-11 19:05:14.00929+00'),
	('admin/scoped-events/credential_usage/0002', 'eb3194ec38847b601025c41b99616c4385770930074e808b21e53af9463d7ad0', '2026-11-11 19:05:14.019479+00'),
	('admin/scoped-events/credential_usage/0003', '74b2011593ba178ca8decc6f7c82528f7bd161c4651fc2700a78839dac32fc04', '2026-11-11 19:05:14.020255+00'),
	('admin/scoped-events/egress_events/0001', 'cfbf4ab51c2b0a4ac45eaeeb7a7011d7b2a4a4d9c21072473ed27400b03fe054', '2026-11-11 19:05:14.023695+00'),
	('admin/scoped-events/error_events/0001', 'd5bab01c9f83042aace325e98636b614bcb8a6d77fedaed373f02efde282f5b8', '2026-11-11 19:05:14.030189+00'),
	('admin/scoped-events/turn_metrics/0001', 'd3bbf44523fb16643f38c18151c990ccbdaa2c411e01ce686b9576fcf98a6141', '2026-11-11 19:05:14.038113+00'),
	('admin/scoped-events/turn_metrics/0002', '3a289ec6fdec4b71c08fbc03aba97b1ce3b1574b7b6deb786dcbea1b2c217c5b', '2026-11-11 19:05:14.05136+00'),
	('auth/broker-sessions/0001', '2f958c4c732f8a8a79cb1d31215236fea9565ee2ce5e62270952b889ec5c1265', '2026-11-11 19:05:14.052486+00'),
	('auth/replay-dedupe/0001', '8714fae4d626c773edfacf59d807e324955a205abb2be2bc76753cdbbc14adf7', '2026-11-11 19:05:14.059475+00'),
	('cron/fires/0001', '462f9f784160d6e31019707b7df3c35ef0a2979fd3c9fb9d4d581fb89de6cad1', '2026-11-11 19:05:14.064351+00'),
	('decisions/0001', '5259b744d814f2aae9b056e69f4488b87276b8db7eeb17d140d6e89bab93218a', '2026-11-11 19:05:14.069398+00'),
	('delivery/store/0001', '518a78830cb91440cee2642d600fb0532084bbe2e2bc4c69c47cc51756be614e', '2026-11-11 19:05:14.078087+00'),
	('delivery/store/0004', 'a712456e95a8e05c1bfa3dcfe8e2cdffe6a49c94f191bd2cb9e594277e1b895c', '2026-11-11 19:05:14.090661+00'),
	('delivery/store/0005', 'd725fa7f171c9b29c14146029a2804cf94a814e8146c8c1a2b16953310fbfd1e', '2026-11-11 19:05:14.092143+00'),
	('delivery/store/0006', '7d0550f008aa2df653dd112199318a24a7151912338aa408e499fce0d1f756a1', '2026-11-11 19:05:14.09457+00'),
	('deploy/access/0001', 'fa35b86cbdfa9e8766ac5e47ffc926986b87ec5bad3ef1d7070fb8e2a1f3f9c2', '2026-11-11 19:05:14.096234+00'),
	('directory/store/0001', 'c47a45848f9d225ff601c9df13dc272349c7df7525e7e2417f33d68be7672cc1', '2026-11-11 19:05:14.103935+00'),
	('directory/store/0002', '4da6cc4f2496dd53d6381faea3f9f8e16e55394cfe46de516a692ede8157e8b0', '2026-11-11 19:05:14.140451+00'),
	('directory/store/0003', '1aaf42502793ebc31b253b12903cf192d2d8d6bcc9e4c1d31e834ed385f2a030', '2026-11-11 19:05:14.142451+00'),
	('directory/store/0004', '5376eae39ee0e8d99157e30b6edfbe8b35a0a0998bc4766a86529a45c0e83c4d', '2026-11-11 19:05:14.150517+00'),
	('directory/store/0005', '38afbb8d963f48be05d5837f7f06e9f531229316c973c5f87eaa790e2611a8d9', '2026-11-11 19:05:14.151841+00'),
	('durable-map/ack_emoji/0001', 'b5cc8b58d6905bf400f15326b4fa4fd3517171dc7e3a2108d23ccc936612ab57', '2026-11-11 19:05:14.153234+00'),
	('durable-map/ambient_cursors/0001', 'af7f98b52db7c0fe09648b4ca964f6ccaeb1bbe283cc4d39184f8084db465551', '2026-11-11 19:05:14.160319+00'),
	('durable-map/approval_grant_modes/0001', '71fcc4c066ec51b5ea8529444cadf6b02193c31760bde9adbf1d198d31c5829a', '2026-11-11 19:05:14.164462+00'),
	('durable-map/approval_grants/0001', '584a7fe0f0a43a421793efed03be20afc249a2ce02dd3ff4924e4cd536ebbc9d', '2026-11-11 19:05:14.169264+00'),
	('durable-map/approvals/0001', 'cd76491910753bae97e30680661f57cdde84d6583d724198cba5e0d71032dcb5', '2026-11-11 19:05:14.173884+00'),
	('durable-map/approvals/lookup-sessionid-drop', 'f97131836d0b702bc1a1693e03bd5d97558a5aa95c5324ec0ce4a8b357814141', '2026-11-11 19:05:14.178312+00'),
	('durable-map/approvals/lookup-sessionid-hash', 'cc98fbd26fca3ecf2c80295e1057e90abbcde3481211ce9082daed8aeedab4f3', '2026-11-11 19:05:14.183609+00'),
	('durable-map/approvals/select-sessionid', 'e44a660c6180087f9a8b08be2493eedd0595d4029552b08e3c089d2be47796f4', '2026-11-11 19:05:14.191068+00'),
	('durable-map/approvals/stats-sessionid', 'c3c521e26580047f3e4b337f1cf2713f30c21e3d3b8c4c44d699b4dd17e7be45', '2026-11-11 19:05:14.191664+00'),
	('durable-map/approved_harness_configs/0001', 'b7b4549c3b3c96c9352eb96ce04efd9ec095b12d835025c99d23db6d7cec1189', '2026-11-11 19:05:14.193818+00'),
	('durable-map/auto_flagger_configs/0001', '9a05f950a2b795595aae939eb60be8564511ac523a19961af482051a42c16ff5', '2026-11-11 19:05:14.198197+00'),
	('durable-map/aws_sandbox_bodies/0001', '190bacea57ed75da62849825a5e3206905422d5ffc9f2192d9039222306b378d', '2026-11-11 19:05:14.202775+00'),
	('durable-map/base_model_configs/0001', '7ee3b9db6bc36c92985dddf061cba7ef0b5d736fb44452febaef04c50211624e', '2026-11-11 19:05:14.206905+00'),
	('durable-map/branding_configs/0001', '06c1123ae332e721fe619c8614392636ff446d1a47cd42396e8d3d819ade6dac', '2026-11-11 19:05:14.21118+00'),
	('durable-map/browse_max_steps_configs/0001', 'ae78a8a7cd7a78fc6886bbeb9241aadc057b4958713499e0591be82e878f2e41', '2026-11-11 19:05:14.215728+00'),
	('durable-map/browse_model_configs/0001', '1e06c0cfef0dae9b35d698363d2268d44e3715c0d51210b955f1870d67fa0c02', '2026-11-11 19:05:14.220371+00'),
	('durable-map/browser_sessions/0001', '49bcab3ee00cac7b5aa4b3eaa303cfffc34521de73d763cbc4dd204a7a0e8b6f', '2026-11-11 19:05:14.223769+00'),
	('durable-map/channel_header_pin_flag/0001', 'e8f344ed5c29eb3d19ec1a095947f1219e19ddbf0c2b70abdb0784d7c7b0465e', '2026-11-11 19:05:14.227642+00'),
	('durable-map/command_policies/0001', '3b924df4ca67254193724e9a509ce0ee76f1d52bb42c2e0f80f0d408e046749d', '2026-11-11 19:05:14.230873+00'),
	('durable-map/composio_returns/0001', 'e2c6917d12757feffde5140a25db74adeef597fecfa970ab81f5775b0d802460', '2026-11-11 19:05:14.234276+00'),
	('durable-map/connector_clients/0001', 'c8e67053c62396d17890f6d5cbccf60c2097b520ceeb1005007ce4c7ffd38ab9', '2026-11-11 19:05:14.237353+00'),
	('durable-map/connector_status/0001', '6c6632c1e1eae187d4ee42d04ff898901d613a0e7dadfd3056ebd040e97c2219', '2026-11-11 19:05:14.240526+00'),
	('durable-map/consent_links/0001', '4023e872f3c4ef2342dd2db8d0a936662868024875a139162d5c1960dfe5a6db', '2026-11-11 19:05:14.243833+00'),
	('durable-map/context_requests/0001', 'c06306bda2afa606283f9a391786e561e5f0854b3efe5c9b761813acd3238b87', '2026-11-11 19:05:14.246892+00'),
	('durable-map/crons/0001', '0235672021171d1e58bd485fae8b56090ed58be3a12b156dc7491ac3d825dea3', '2026-11-11 19:05:14.250148+00'),
	('durable-map/crons/0001-drop-run-as', '95e375cb70abd7dff68cf61a371167695b3e3427c31f38a9722142c244b0f97a', '2026-11-11 19:05:14.253401+00'),
	('durable-map/custom_model_providers/0001', '151ac01f9e2a37c511b3f56296050b37a7a4c9c13c7ef946259d5805def997d6', '2026-11-11 19:05:14.25809+00'),
	('durable-map/deactivated_principals/0001', '74cf2f5e2185abf08a2c93da115858a42c6f10fe94d814815342888e735ee355', '2026-11-11 19:05:14.261899+00'),
	('durable-map/deploy_git_repos/0001', '4957c2777766eb31eaa136953ed5046bc298d8341aab69a43545594f0970ea4c', '2026-11-11 19:05:14.265748+00'),
	('durable-map/deployment_identity/0001', '11b012ea31d25b354799885bfc8f1f68a8e9ca2108d72ccee7102a36cbaa1c1b', '2026-11-11 19:05:14.269092+00'),
	('durable-map/deployment_layer/0001', '1e9f09c7e5ca32924a4074a7cca5fff79865d31794515c02cd287b337b419803', '2026-11-11 19:05:14.272627+00'),
	('durable-map/deployments/0001', 'f592ba8aeb41d74822e3960e9632d29adfba5bd0e79c7f21fc91e7258ad0e555', '2026-11-11 19:05:14.276079+00'),
	('durable-map/do_managed_agents_sandbox_bodies/0001', '1e4868c1a418add4a2b99f2cf87f147aeafc859eb31e0cf968489ffaa91ee4ad', '2026-11-11 19:05:14.277048+00'),
	('durable-map/e2b_sandbox_bodies/0001', '86fde308e21c9f2855750b885fc7a2c860eec53662e9713979cb5af7b6a844a0', '2026-11-11 19:05:14.28076+00'),
	('durable-map/egress_policies/0001', 'e26a4391eabca30277592e928b512beacfa4d9388ebb189a6d22b7acc388c775', '2026-11-11 19:05:14.284514+00'),
	('durable-map/external_members/0001', 'ea7b43915e8761f9148a2cff9f5c401e192a25b4b71b9535c0ee4710f1fdcba6', '2026-11-11 19:05:14.288711+00'),
	('durable-map/external_slack_participants_flag/0001', '4c7dbf123c9b99cd85215958cfd9581b83e634b2e02b405548c2777001836291', '2026-11-11 19:05:14.293848+00'),
	('durable-map/feature_flags/0001', '10919fe9fb09ca1141ed38917d5d11b6dad1f53f7f35724b03ad33ebb0712319', '2026-11-11 19:05:14.298035+00'),
	('durable-map/idempotency/0001', 'e171e640e06976d6c0f869c90a3775c68a3ef228f78b56da4edbe7a0e29d7f9f', '2026-11-11 19:05:14.301627+00'),
	('durable-map/individual_model_auth_flag/0001', '80e854a8e2377cb348357c97a3485c9739f4abdd65c3bbab523a0d911b7bb19d', '2026-11-11 19:05:14.305125+00'),
	('durable-map/interactive_fast_mode_flag/0001', '3a1e6bcaa71527b414f5bb5f98610230cda67463b86823723b9283cc4b93aaf0', '2026-11-11 19:05:14.308618+00'),
	('durable-map/internal_member_overrides/0001', '6bcbee3778919e13ec0081d919f1608101a0ed474647907eac7d3fa68707efb9', '2026-11-11 19:05:14.312532+00'),
	('durable-map/keychain_asks/0001', 'aef8c37ef4fffa25f96ead4d5ae73b5bcb0b60aa7248050f9bd69d6c064a3a55', '2026-11-11 19:05:14.31658+00'),
	('durable-map/keychain_credentials/0001', 'b7dd2271dfd424898bc65f6adb658b8b51b07f0a9e6a9ef47b5e76fe51c0eda7', '2026-11-11 19:05:14.320504+00'),
	('durable-map/keychain_credentials/0002-delete-auto-captured-logins', 'e2c3d2c3fb7d240450004a535a8af950db3b6ff35ca284da0f393ec31c0b4fde', '2026-11-11 19:05:14.32512+00'),
	('durable-map/keychain_credentials/lookup-ownerid-drop', '460b2be11208138a00b181b518ca38bc58322dcd37f158ff672496b3fc1248c1', '2026-11-11 19:05:14.330274+00'),
	('durable-map/keychain_credentials/lookup-ownerid-hash', '84860ad9d9f1634d9bf17e0a928a6d11513200dc6fb43c881928bf933d6da455', '2026-11-11 19:05:14.3346+00'),
	('durable-map/keychain_credentials/select-ownerid', '6ce3ea87541dd9462ef96981c7c3aac35120340f6477a319b46806f717a90039', '2026-11-11 19:05:14.340522+00'),
	('durable-map/keychain_credentials/stats-ownerid', 'fa449596f80d2fb3d6eff92f3d52a5e82a58db3c5556520b9fc273a5403d7773', '2026-11-11 19:05:14.341062+00'),
	('durable-map/keychain_grants/0001', '6331a8b0daa7ae875d6b09457f7ca1f865812e9a036efa23186793632f94d3d4', '2026-11-11 19:05:14.342938+00'),
	('durable-map/keychain_grants/lookup-ownerid-drop', 'b0d3eb453249ac97e0271a551c0b69f7ff93591507521ae1ffde71ce0cd3cee8', '2026-11-11 19:05:14.34428+00'),
	('durable-map/keychain_grants/lookup-ownerid-hash', 'c7f3b4ab099eadee97ffb0d0e30a949b63bab34a1356773c9efa85ef5f87063e', '2026-11-11 19:05:14.347721+00'),
	('durable-map/keychain_grants/select-ownerid', '2f8bc9481bd50e162894c41aaca606fb666eadae3600ef2297512d6c27e9c33a', '2026-11-11 19:05:14.352631+00'),
	('durable-map/keychain_grants/stats-ownerid', '504fbbd9176f279f9c9ce9e2e58c475196dbbdc3c6697e81704ae568753ec676', '2026-11-11 19:05:14.353168+00'),
	('durable-map/loop_ingress_deliveries/0001', '4d2ab585c043345d1594b6415ff08408e594f3e38af807afaf2eeb21bce93f11', '2026-11-11 19:05:14.354597+00'),
	('durable-map/loop_ingress_deliveries/lookup-queuekey-drop', 'b0302105ca749092efde87bc17e75762786db0b1aff63a2fc6039ff1745241b2', '2026-11-11 19:05:14.358509+00'),
	('durable-map/loop_ingress_deliveries/lookup-queuekey-hash', 'ad86fd50b697f06a2ca776dcf2ac2881cb0cc8ac5de1a5331e30be6f2c4ed936', '2026-11-11 19:05:14.361808+00'),
	('durable-map/loop_ingress_deliveries/select-queuekey', 'f2723f1f7b7fa434f8ed9251e2ad1234e4d074d13802543abf5141cdedb5dd9f', '2026-11-11 19:05:14.368143+00'),
	('durable-map/loop_ingress_deliveries/stats-queuekey', 'c94b5443b22df93b53ad607e3a9c04ce9b40dfec6de998b771db8ff83c2ae57a', '2026-11-11 19:05:14.369052+00'),
	('durable-map/loop_ingress/0001', '9d74414c582e3fd4a3c2319f32b86f516f13ee7731fa54a8a3b567ee052c6aae', '2026-11-11 19:05:14.370512+00'),
	('durable-map/loop_ingress/lookup-loopid-drop', '9f9e885e67107f38a8a490d6653cc021582439fed748a4129d1c5a4edf87378f', '2026-11-11 19:05:14.374916+00'),
	('durable-map/loop_ingress/lookup-loopid-hash', 'd808ba6969eea145047c46626267a9bf9da846db528b5e5f0e4491732b0678c0', '2026-11-11 19:05:14.378281+00'),
	('durable-map/loop_ingress/select-loopid', '2a95bd8533d9e39901bee0c2baa743edc3a63d93c56554a95413ef915cfd5017', '2026-11-11 19:05:14.383853+00'),
	('durable-map/loop_ingress/stats-loopid', '55593a39f9c53aa1f19a0134fdc3f8f3b18cb4b432a136123f2615b115669e69', '2026-11-11 19:05:14.384823+00'),
	('durable-map/loop_items/0001', '051d43294fb2c30a5491655d2d21cfdf0f64687bbd64934e32cc05686951aa43', '2026-11-11 19:05:14.386329+00'),
	('durable-map/loop_items/lookup-loopid-drop', 'c49a0f7eb4b19400ea1739d129413d31936a49d5a53e9cb933bd11d06649f42c', '2026-11-11 19:05:14.389892+00'),
	('durable-map/loop_items/lookup-loopid-hash', 'ad7ed85cad25c85b37d0885352a4822b4ca37e01ca4ae46ebdfbed075e471908', '2026-11-11 19:05:14.392882+00'),
	('durable-map/loop_items/select-loopid', '00c11d5d6776cedd88870c3b29570b162f721eac857042c34c618a5940d8aad5', '2026-11-11 19:05:14.398576+00'),
	('durable-map/loop_items/stats-loopid', '3a20258517de4424e12f6042fd985486a0abff81806d729d669863557692f856', '2026-11-11 19:05:14.399292+00'),
	('durable-map/loop_outputs/0001', 'aa3599a15647d3a3248c397f30180b0b144407b1629f8702c23641da644b9a29', '2026-11-11 19:05:14.400436+00'),
	('durable-map/loop_outputs/lookup-itemid-drop', '6d17d66f11252bcda44b6e1004568c2879058032509a8fa29203d17e2fb4b99c', '2026-11-11 19:05:14.404291+00'),
	('durable-map/loop_outputs/lookup-itemid-hash', '0b3e31cfdd5546781ac566674717506d96b88c56e9b9ebce2de915c7527e5283', '2026-11-11 19:05:14.408126+00'),
	('durable-map/loop_outputs/select-itemid', '0a75890492f409aa80c3fc549ce0f24f6f228f110904fdbbaeabd2cec6a98829', '2026-11-11 19:05:14.413335+00'),
	('durable-map/loop_outputs/stats-itemid', '28a0babc667695fa45a675d047fe7b16d85a973238b4c3678a03e0c122b157a9', '2026-11-11 19:05:14.414228+00'),
	('durable-map/loop_ship_grants/0001', '9f567f5220fa83c5e4255f674b18dc5f75c33711447d8eaf9ad46ca710dc6919', '2026-11-11 19:05:14.415799+00'),
	('durable-map/loops/0001', '2ece5bd63a110354855bf2e0a58c31dda1c38c392fd48999aa186443db931af1', '2026-11-11 19:05:14.419145+00'),
	('durable-map/mcp_servers/0001', '656e5902aface901aa8ccea2d404b26454bdf5fc59b0523132b9c339e08b7800', '2026-11-11 19:05:14.420056+00'),
	('durable-map/memory_tidy_profiles/0001', '9b4bb200823266468b607b2f81f3a50bd860cf25c41f980ddb0a61d9ea5e643e', '2026-11-11 19:05:14.423655+00'),
	('durable-map/modal_sandbox_bodies/0001', 'e5a58d41d449a16030a2f8bce471141fe85753cf3e17fe112dfdafea1cf7ddb0', '2026-11-11 19:05:14.427385+00'),
	('durable-map/model_credentials/0001', 'ede2f544fbfa17aadf339b7830db978823fdd8ffd626f900816c22bb26817474', '2026-11-11 19:05:14.43137+00'),
	('durable-map/model_registry/0001', 'cb7c405b5b231a9f19f672884c2c8fccb470fae508f60e11ceff3eae7727e834', '2026-11-11 19:05:14.435203+00'),
	('durable-map/monitors/0001', '352b4ae3e97e45c43ffebb22ddafe1fadc56a37ac025a61d660eb0007613b580', '2026-11-11 19:05:14.439552+00'),
	('durable-map/oauth_flows/0001', '043983772bd290d5722456d63082a660c76e26fe9b6fad0e4a46baa138140f4b', '2026-11-11 19:05:14.446178+00'),
	('durable-map/org_ambient_flag/0001', '7934678d620174a9abb1571803f937a6828cfad2bfe3dd3714d73d44a2679bc5', '2026-11-11 19:05:14.458791+00'),
	('durable-map/people_directory_urls/0001', '356f938e085e5da95b899df66ffb7f8e7515e9579da8fe697774770c7a71f431', '2026-11-11 19:05:14.463671+00'),
	('durable-map/pinned_skills/0001', '74a9a9a91c910696a4ab40405eb643d62c5447aaa1430e5ef7c316c7fca980b6', '2026-11-11 19:05:14.467761+00'),
	('durable-map/principal_links/0001', '3b3529b8c4a3803a044be89c7881e1aa1e9e1b430f1e5e5d15f49d80e002c38a', '2026-11-11 19:05:14.472171+00'),
	('durable-map/projects/0001', 'c3542e30f1dc3a4200d39f2043e94c5e9e9d641902bcdc83cdde198ce79f36f3', '2026-11-11 19:05:14.477837+00'),
	('durable-map/sandbox_defaults/0001', '781d981103854e2b2c71435edb92d150e76aa8d93a4d519cd0b44c3fd2cb9921', '2026-11-11 19:05:14.48425+00'),
	('durable-map/sandbox_resources/0001', '162e15a2d6f50446d52b17d3ee77f2461ee0ec1c0207b09498e21d335ebc2bdd', '2026-11-11 19:05:14.49111+00'),
	('durable-map/secret_drops/0001', 'd53b8ea0189d918d65ec2f1f521bd1ea1ce7fdf533f516e365cc91732e016b96', '2026-11-11 19:05:14.497869+00'),
	('durable-map/security_postures/0001', '811ad86fa544d98be740f332eb0315a9935d16b5a48ba0cec1516b819998c27d', '2026-11-11 19:05:14.50451+00'),
	('durable-map/session_mailbox/0001', 'ef49edb075b1c00c3bcff3526b595f74ca1d16704e497a83fdede49f21f515d6', '2026-11-11 19:05:14.510829+00'),
	('durable-map/session_mailbox/lookup-recipientid-drop', '0515b8739e932343b78ec1052a9e80c773febf0860ded4409618c7e3e3a4aa4f', '2026-11-11 19:05:14.515405+00'),
	('durable-map/session_mailbox/lookup-recipientid-hash', 'd4acbff880f7e84d2a1f1eac9ddb44aaa1781e104830c8e2d297ad5c2b324f77', '2026-11-11 19:05:14.519457+00'),
	('durable-map/session_mailbox/select-recipientid', '0f783946ba4ea3d80a9542d6a9bc3996678cd465abf0dfa4769c6788e3efe260', '2026-11-11 19:05:14.524667+00'),
	('durable-map/session_mailbox/stats-recipientid', '6899798a87557911875dfed8682094a5f6ebc0b3f535b9794f28b4705aff0807', '2026-11-11 19:05:14.525382+00'),
	('durable-map/session_shares/0001', '77d2a755c000aad13df96fdf9433b717b79c5ad8a5e11ac671ea33379aa55f1e', '2026-11-11 19:05:14.526631+00'),
	('durable-map/sharing_postures/0001', '16f5bcc02513285518e6913f70c043dda0d44fa4d0bdbe14ec578b5f06f1d178', '2026-11-11 19:05:14.530577+00'),
	('durable-map/skill_bundles/0001', 'e3e3974648f7657b6dca0c331b64d90f36529e9c3ffec1ae05282a370c0ba1ec', '2026-11-11 19:05:14.534106+00'),
	('durable-map/skill_packs/0001', 'ec3020db9e97c12b42fd33acc59bac01b741616fb2ac31327f6180068d35f708', '2026-11-11 19:05:14.537441+00'),
	('durable-map/skills/0001', 'efe2a0c8ad67467be845d93206eddea17c15784175006b9a1cc82615ad0a33ea', '2026-11-11 19:05:14.54108+00'),
	('durable-map/slack_accounts/0001', '48ff469a6b3ccaa72d47ce443808b2be4ef38640dec7ba8733419789d5c6e8b9', '2026-11-11 19:05:14.544632+00'),
	('durable-map/slack_emoji_catalog/0001', '72e45c26308d61173a6de2ae9e78bbae52dc943e6f12981fa51455d273253a1a', '2026-11-11 19:05:14.547972+00'),
	('durable-map/slack_installation/0001', '31b96f65fded9ee0898ccf44766f6e542d30b0deb3b8da0d06381839be94764c', '2026-11-11 19:05:14.551391+00'),
	('durable-map/slack_session_status/0001', '211ec9c63a6104511f45ee1f2315e49f5b749e9fb2a8780dfdf5b6174ef0bc51', '2026-11-11 19:05:14.555322+00'),
	('durable-map/slack_staged_envelopes/0001', 'c3a5173bc2f0bf0e739fee4a59214c5e2d6236374f44a925016e74ac48188375', '2026-11-11 19:05:14.559353+00'),
	('durable-map/slack_task_acknowledgements/0001', 'bf9fad755c2e7c4dcbb795ad589832b78136e41cac793b0decf98cf180acdcc4', '2026-11-11 19:05:14.562696+00'),
	('durable-map/smolmachines_sandbox_bodies/0001', '7732ed446a800d053f5dffbcdc24b81b83e57d4cb9ce741b4a294bbd26f15c7d', '2026-11-11 19:05:14.567459+00'),
	('durable-map/soul_configs/0001', '8528037c99399b8fdcba2e29dc7dccbc0bb359d6cd5e9ca8f4e0d34a6fc7a4e3', '2026-11-11 19:05:14.571018+00'),
	('durable-map/soul_history/0001', '2a9607ecb96935a95b97fdefc042c7517a58802c4cf9fcee67d7e8da3a4603e2', '2026-11-11 19:05:14.574548+00'),
	('durable-map/suggested_activity_profiles/0001', 'f0850d1e9f12f26babce849b90b52eab95b81530aabf802e87f160a395985ba3', '2026-11-11 19:05:14.578022+00'),
	('durable-map/suggested_activity_profiles/0001-nightly-on-use', '319965364d5048237981818039583f6e2d97e2f69553906fb8311b569867d720', '2026-11-11 19:05:14.581624+00'),
	('durable-map/superserve_config_epochs/0001', '03a29556205a6f0e0a80fb7e1b828de610ad20169b342cb80623685a31496477', '2026-11-11 19:05:14.58325+00'),
	('durable-map/superserve_sandbox_bodies/0001', '49673eb711120ab7e1fb3d0b5d5dd2d9ffccaa59c331e88112d5c82d907c6220', '2026-11-11 19:05:14.586907+00'),
	('durable-map/turn_wall_clock_configs/0002-drop', '4b4ebf24b233ddccbb94d3b562b09e87adfe3e64eb1a4f2792ab192036f6b781', '2026-11-11 19:05:14.590765+00'),
	('durable-map/unfulfilled_insights_flag/0001', '6039de5aad6758a517701cab7a47ee158162e21bf79f965f71d780bf9fc41d22', '2026-11-11 19:05:14.591706+00'),
	('durable-map/web_ui_state/0001', 'c432e9df04d30e5533c79ae12ec1564541072ce1138af9ea320f08c533a7cac0', '2026-11-11 19:05:14.595477+00'),
	('durable-map/webhook_history/0001', '5d99f7bc000a792e237082339eccb490bf124c0dfe7fb14f816b8978e73ec7b4', '2026-11-11 19:05:14.59933+00'),
	('durable-map/webhooks/0001', '95a66510c7e6983e713290d0066264128baa406a19f390af6ba18873e2360c28', '2026-11-11 19:05:14.602711+00'),
	('durable-map/webhooks/0002-disable-rows-orphaned-by-webhook-removal', '5049d35f8e432183fed151377a615e25ec6a97677b7a7ec7da57b155c7425db7', '2026-11-11 19:05:14.606492+00'),
	('durable-map/webui_model_configs/0001', '37bb44ffc7579effc5c0ea6c47fc8e7a231207c2e123711daaac34b79f379983', '2026-11-11 19:05:14.607639+00'),
	('environments/store/0001', 'f6eb00919601e6c50bca7857a93061761d2bd1a31396ed7cf9373f93c8ffcae7', '2026-11-11 19:05:14.61112+00'),
	('files/artifacts/0001', '568d83afca3a8ce6287cbe85ad570612d9bb01ad0a8b7d78aa54e6fdc1dc1b0e', '2026-11-11 19:05:14.619034+00'),
	('files/artifacts/0002', 'fc47df852bd24c895b47e97d407eec54a71db90f407c5731627d82b2c63b5819', '2026-11-11 19:05:14.626915+00'),
	('memory/facts/0000-records-column', '450e71b07659508640f782635a5019fa31b906cc63fdc97e7236d28b0d4c3aea', '2026-11-11 19:05:14.630361+00'),
	('memory/facts/0001', 'cc560bef4c54ea2007b66eb46bf7258b70c9de98da901348f271c5da38c06597', '2026-11-11 19:05:14.631357+00'),
	('processes/registry/0001', '5ca2d3af76a021c55ec15829f5798347851f3d73df53f36041dc04fbb2253324', '2026-11-11 19:05:14.636489+00'),
	('processes/registry/0002', '3677d509807832aecda3cf903f22c42bc3d31a6d9c97b4156f981d376f589999', '2026-11-11 19:05:14.642691+00'),
	('processes/registry/0003', 'd24a770a83eddffda0658e3e650a3c420ffddb6f68c379d5933f720b2e98cb19', '2026-11-11 19:05:14.643792+00'),
	('processes/registry/0004', '9c17b6f267eb528657ab97b7bf27735d1c8aa5b8eaefdfe9489346839ea89052', '2026-11-11 19:05:14.644491+00'),
	('ratelimit/limiter/0001', '27463ccd35e5a63321d9a3abb88d5691a23919ad6a9cee945645ce4e487d9437', '2026-11-11 19:05:14.645209+00'),
	('resource-search/crons/0001', '1e33169a8550366f1651f4a9be634b8c04293f3cc197cbf7f741c45af798b632', '2026-11-11 19:05:14.648165+00'),
	('resource-search/deploys/0001', '97db7e33f1bd293034b3e1eb24909bb28ac2c31db3c128dc8d378bd18b91929e', '2026-11-11 19:05:14.650015+00'),
	('resource-search/skills/0001', '77217c6a8da2b9714ede4668b3b52497b83399c65bea3b9c9a311e9565d4d5ef', '2026-11-11 19:05:14.652331+00'),
	('resource-search/webhooks/0001', 'afdb2392eed83a8db7402eececbbdaebbc1563444c21616db1998fd330e40881', '2026-11-11 19:05:14.654856+00'),
	('runtime/0001-legacy-harnesses-to-pi', 'e8b19d4d99042854488bcfce78f8d8cca70f84c649117b19b609c8bf0292da3e', '2026-11-11 19:05:14.656184+00'),
	('surface-cache/ack-emoji-pick/0001', 'f810bb939d938048d4852a518c04ee315dc42e415e237a31b35129fe08678228', '2026-11-11 19:05:14.681762+00'),
	('surface-cache/ambient-judgment/0001', '70c0f2d71fdc4d464b4a9d35fcb078b5efdf4dc4fcf769f8379eaa1afb4ad61e', '2026-11-11 19:05:14.690624+00'),
	('surface-cache/channel-policy/0001', '5be6f79d080af7a40c4c28708c906359fab2e5cdb23ffd24823da12186fa19ef', '2026-11-11 19:05:14.697909+00'),
	('surface-cache/store/0001', 'd823cafcb1d6fbe0400d4ec7cbf745d768af8d02b492681092b95136b706518d', '2026-11-11 19:05:14.706896+00'),
	('surface-cache/store/0002', 'a940914e3f7a04f8508e88b31035c3b4d74438087f716b6d1832f90ed78c9357', '2026-11-11 19:05:14.733135+00'),
	('surface-cache/store/0003', 'b3f05a3e976216b758fd8482c603917505c231787c853b46e8c76a7d80377f08', '2026-11-11 19:05:14.734859+00'),
	('surface-cache/store/0004', 'e64e42c1db30b3f2fe0cf8de0a274316bba539131c677b8242cb11ab55304eee', '2026-11-11 19:05:14.738823+00'),
	('surface-cache/store/0005', '0730c53e72559cdd0eba1830f2e243dd539dabfeceb2702161fc0511dabba8e0', '2026-11-11 19:05:14.739884+00'),
	('surface-cache/store/0006', '17e5f4f46573989bf031b3c79a41f191bc614c53e265829bb7bd5a17cad19208', '2026-11-11 19:05:14.740658+00'),
	('teams/0001', '2b8c0d4f17fb526e042960f55feab31d269a33b644872e2c87266be47429a174', '2026-11-11 19:05:14.741769+00'),
	('0000-tenancy/base', 'a8d92d4e6edcca2b8e2e0635347c2bcbc549dc2826def55a9af0afe4bdeea70b', '2026-11-11 19:05:27.975491+00'),
	('0000-tenancy/sole-tenant', '7905025bbf4b0062e0694b4c91f9872e6ac97a694dac65dec579b0104fce6f24', '2026-11-11 19:05:27.981996+00'),
	('0000-tenancy/sole-tenant-search-path', 'd58bb3de5c31432bff3c79cbbb95a154e6bb773c9b074cd174061475197666cf', '2026-11-11 19:05:27.983232+00'),
	('0000-tenancy/unbound-sole-tenant', '3015703fe1161ae34c14142f25c125017c516ffac4efe11f70249d5f5750f277', '2026-11-11 19:05:27.984284+00'),
	('0001-tenancy/hosts-and-settings', '2313feb6dca8bfa9ba419f353dc72d693aef84f22de7cd4ecf1eb127a6fa80c0', '2026-11-11 19:05:27.985828+00'),
	('0001-tenancy/hosts-search-path', 'df39e37ea5acfab70ffa36507b1ea405f3a5b02311ebfeb15e1c9bc7a26ee30b', '2026-11-11 19:05:27.993804+00'),
	('0001-tenancy/retired-hosts', 'cf7c13a450c2964a8ad1b6d0402f7dad449b8c872e97ba9993d77af5691268c2', '2026-11-11 19:05:27.994889+00'),
	('0001-tenancy/tenant-row-security', '4091f31ff00a2cbe54944dd5af102622116bf96de4f91697079229dbdcc89516', '2026-11-11 19:05:28.001703+00'),
	('acl/grants/0004-grantee-index', '30382d67071399576b959afec996363d65176da58f3cde4addcc858fe6f2e7bc', '2026-11-11 19:05:28.013047+00'),
	('0000-tenancy/base/retire-0116-keys', '4add4e0eb5759478b997bce2ba07b9d67cd8015954fe9d6641e1eb2d8b411a84', '2026-11-11 19:06:58.451165+00'),
	('0000-tenancy/base/retire-0116-keys/repair', '681e2ae6d99b6bbc5aba009565329d72fcf5a8ae2487b9a2f99150a0ed93c7cb', '2026-11-11 19:06:58.458978+00'),
	('0000-tenancy/boot-tenant', '42b4aec855c64d5dec1522b130c6de57bf85a70468cfb58103a57b3579099559', '2026-11-11 19:06:58.463152+00'),
	('0000-tenancy/legacy-tenant', '28932c4baea70a5cf02697def752093ea8a406303e8b1dd4a2eb09bf5f2a6c16', '2026-11-11 19:06:58.465675+00'),
	('0000-tenancy/settings', '94dd06923e6c871bd7d4e7b464acb8a8769009a40a1f3c48df4dfab262fbf035', '2026-11-11 19:06:58.467365+00'),
	('0000-tenancy/settings/app-handles', '820b7dc0e8e78efa609128544dc5440d721b128b34b2c059888450867dccceed', '2026-11-11 19:06:58.468716+00'),
	('0000-tenancy/tenant-app-handles-dns-bound', '554013ccd9504ed3207e30f0d7476dc09dc5788fb354860010869ea40c574cb7', '2026-11-11 19:06:58.476329+00'),
	('0000-tenancy/tenant-app-hosts-by-handle', 'e39208a9b18cbe28103d4e88feab96880bac97bef9400bfafa4e2dda9f56c14e', '2026-11-11 19:06:58.479502+00'),
	('0000-tenancy/tenant-app-hosts-legacy-names', '59f25d8d9ee659b919ee4c23fe685de014add90094ee80d9af66764394c9b20c', '2026-11-11 19:06:58.481049+00'),
	('0000-tenancy/tenant-hosts-drop', 'a7d660144567980b7632f0ca254e51689ed79fac173a09aec133b041aa5e86f0', '2026-11-11 19:06:58.483144+00'),
	('0000-tenancy/tenant-row-security', '42063924e14f9f83619e277250dcd4e245748d84f9d0c297ce10b61ee7211e29', '2026-11-11 19:06:58.485817+00'),
	('acl/grants/0005-tenants/0-column', 'f737d68c8aa6a4229345423c0ee613a8b4de25e286165b8bcf8e0a684f8dadee', '2026-11-11 19:06:58.488247+00'),
	('acl/grants/0005-tenants/1-column', '97b769759893909ef3ffb6df7e4d417b19c77c6ec4297c5a4cf4c3050fcfeac7', '2026-11-11 19:06:58.491481+00'),
	('acl/grants/0005-tenants/0-stamp-column', '3f9545037119bb0429aa0ec20cb00fd2c4e67c6fbc76a355455c102af234dc07', '2026-11-11 19:06:58.491481+00'),
	('acl/grants/0005-tenants/2-keys', 'cbde6a4883cf19599ba6165f765974ebe1ff1b9ac9a4dda86d058f4b8536473c', '2026-11-11 19:06:58.502401+00'),
	('acl/grants/0005-tenants/2-references', '55fca0c96d7c30c068404bfb901e0a8ee5abfca89057d9f08bafed7c193a7801', '2026-11-11 19:06:58.503589+00'),
	('acl/grants/0005-tenants/3-policy', 'd8fb0beb7751f4b2ef1e34ac3966384134dbf9fd916cfffe7ef2e9e78c48ad76', '2026-11-11 19:06:58.50724+00'),
	('acl/grants/0005-tenants/2-tenant-policy', 'a19c0f74ed2300c5d75cf8954a7b01847219c584d24ec2b9262a4c5dfad6d468', '2026-11-11 19:06:58.50724+00'),
	('admin/audit-log/0003-tenants/0-column', 'adea9ea45b547800fe0a147aa03c620c3cccb68a126f7cf03080694b47ce601f', '2026-11-11 19:06:58.512112+00'),
	('admin/audit-log/0003-tenants/1-column', '95631dfa202f3cb536b46f68ed17702c19251dc9fa2222ff8c4bd7ae18441d45', '2026-11-11 19:06:58.51418+00'),
	('admin/audit-log/0003-tenants/0-stamp-column', '60d7201bd2723c67cf814abda086bb1a0596ee2757b163b1d79dfe008c4d9e0f', '2026-11-11 19:06:58.51418+00'),
	('admin/audit-log/0003-tenants/2-keys', '7f7e31c7d8068f329385d7bd92de3ef4ad96585a865dd16e8d7f154a99e1167a', '2026-11-11 19:06:58.523782+00'),
	('admin/audit-log/0003-tenants/2-references', '0709105d586afa79bbd4a072637aaca436c610e25fb64c84bacf92772e25f6bf', '2026-11-11 19:06:58.52467+00'),
	('admin/audit-log/0003-tenants/3-policy', '6bc9f212e3909d25dc848d0c72cdbe30dca82136f1ecba105e38ac66de897b62', '2026-11-11 19:06:58.527158+00'),
	('admin/audit-log/0003-tenants/2-tenant-policy', '3ade1dc5080480bddbb18fcbc687af42230482cd4ac7827799bbca8937077000', '2026-11-11 19:06:58.527158+00'),
	('admin/grants/0002-tenants/0-column', 'dcc9fbe2c870fc969a7cc31e4c7055db4f3fde7c7fa9de237f76eb67a6cf0b48', '2026-11-11 19:06:58.531483+00'),
	('admin/grants/0002-tenants/1-column', '39f7a0209e23553794c692c833a60ab1094063cc367ee0631c307dc26e920b5c', '2026-11-11 19:06:58.533783+00'),
	('admin/grants/0002-tenants/0-stamp-column', 'd4888c32eeca3e52c988495bf5a2f0cbbaec3e5784be0cd566492f110f062e59', '2026-11-11 19:06:58.533783+00'),
	('admin/grants/0002-tenants/2-keys', 'e842d47c703d11538a2e40ce335a6459bfa5c8182545d4a6209fd3fe1188ae3d', '2026-11-11 19:06:58.538942+00'),
	('admin/grants/0002-tenants/2-references', '64623d668fe93098e96abe61cd84b873261555d6bd58d6e1099661c0a3161694', '2026-11-11 19:06:58.539828+00'),
	('admin/grants/0002-tenants/3-policy', '5831cfdc278dc36247c43e6a17d9d318f90b872629f8b34163ddb699c6e23db2', '2026-11-11 19:06:58.541548+00'),
	('admin/grants/0002-tenants/2-tenant-policy', 'a5fd382eeb924484aca2b06a6a4421556a3d13bc97fad5ba9fa4c579627296c9', '2026-11-11 19:06:58.541548+00'),
	('admin/scoped-events/credential_usage/0004-daily-calls-tenants/0-column', '0d0f1d9f4b1599897ed64d8f14e0a11ea1b557ec9fb99f6025a88d3fd44106d4', '2026-11-11 19:06:58.546293+00'),
	('admin/scoped-events/credential_usage/0004-daily-calls-tenants/1-column', '475118d285fec4a1c33785b80992d8321e8838a9aa586141f719a4555669c86f', '2026-11-11 19:06:58.547923+00'),
	('admin/scoped-events/credential_usage/0004-daily-calls-tenants/0-stamp-column', '8029df248ce7afb66521676fe91003777c5c493637e8ca55c0506d91fd2435e3', '2026-11-11 19:06:58.547923+00'),
	('admin/scoped-events/credential_usage/0004-daily-calls-tenants/2-keys', '889475897a978c828b8e30078503df7f395e0691f8dac83216d2204a80dec889', '2026-11-11 19:06:58.552889+00'),
	('admin/scoped-events/credential_usage/0004-daily-calls-tenants/2-references', 'd4e656c95600ba35aab91c33ea59169eda12244d96d7d7138d9db7a96ee19f68', '2026-11-11 19:06:58.553653+00'),
	('admin/scoped-events/credential_usage/0004-daily-calls-tenants/3-policy', 'cb2ae263be2a3b6f549bc634b8152923a1310e3c2ccd204d4bdd40693ad16185', '2026-11-11 19:06:58.555579+00'),
	('admin/scoped-events/credential_usage/0004-daily-calls-tenants/2-tenant-policy', '87ec5131c0ea82769998388014a073a29584378de88fc8a3068727fdef9874b5', '2026-11-11 19:06:58.555579+00'),
	('admin/scoped-events/credential_usage/0100/0-column', 'c99f612d56a9d4ffd29c7391a30fe7da1109c400d3858b8081846be9682ae50d', '2026-11-11 19:06:58.558186+00'),
	('admin/scoped-events/credential_usage/0100/1-column', 'bf18623df629d07a5b89b9e73b53959fcef4030c34ed522d1e7d2241aef8a71f', '2026-11-11 19:06:58.560058+00'),
	('admin/scoped-events/credential_usage/0100/0-stamp-column', 'b5b32d382d8a099f587f11bafb3126571d1b884161dd060ef24231384b3c359d', '2026-11-11 19:06:58.560058+00'),
	('admin/scoped-events/credential_usage/0100/2-keys', '663a13c75ad528e97ddfbc78b8f1ac6c2ee3cfde2687736fd741269385ea1880', '2026-11-11 19:06:58.564568+00'),
	('admin/scoped-events/credential_usage/0100/2-references', '2efda9df21727e5072a49a9fa02ab02813ff35d9277546c1fdde73f00ee6888e', '2026-11-11 19:06:58.565283+00'),
	('admin/scoped-events/credential_usage/0100/3-policy', 'd1c752948322c04277093ee6401fa3b2aba21bb51e80ecd88b2d35063aec3faa', '2026-11-11 19:06:58.56718+00'),
	('admin/scoped-events/credential_usage/0100/2-tenant-policy', '79482d2ca1075f3a5b280bfdd550b437abda6552c95bd8e36b57ce2f0572d3c9', '2026-11-11 19:06:58.56718+00'),
	('admin/scoped-events/egress_events/0100/0-column', '450f7243731b626df3a6d6a56144009e2bf34ae2b9cd0d3d2d977f8e744b1b70', '2026-11-11 19:06:58.570123+00'),
	('admin/scoped-events/egress_events/0100/1-column', 'efcf1aa8dcd4d3b0523e9a9fde245aef6330522cb0cf5a997572bfc2ce576994', '2026-11-11 19:06:58.571972+00'),
	('admin/scoped-events/egress_events/0100/0-stamp-column', 'f4c167a6cdbc632f238a46644ef01bde1eb2ec706f769eedda0f392878ad19af', '2026-11-11 19:06:58.571972+00'),
	('admin/scoped-events/egress_events/0100/2-keys', '12ad00df69a8435fc560d47d8460c5dc18255cc42a76e44e3724a486c0274ebe', '2026-11-11 19:06:58.57859+00'),
	('admin/scoped-events/egress_events/0100/2-references', '252d936baea587a37bbcb8f3fc35b2815ace13a101845ba45f41474fb6cb3e0d', '2026-11-11 19:06:58.57954+00'),
	('admin/scoped-events/egress_events/0100/3-policy', 'd6570281681a63d54d0001bb12c93202ba7a5a3479eee388f1fcbc2c7e2d4198', '2026-11-11 19:06:58.582932+00'),
	('admin/scoped-events/egress_events/0100/2-tenant-policy', '103ce117a65e546665b9da8d464ddf7634eb7719f27db6e7cd61263180dd7e65', '2026-11-11 19:06:58.582932+00'),
	('admin/scoped-events/error_events/0100/0-column', '2b1e3b441d88807e36e2ff09cebeb59719fe7988156d37795485451914573d1f', '2026-11-11 19:06:58.587559+00'),
	('admin/scoped-events/error_events/0100/1-column', 'f0fdead9c296ef7f7c41ce55308282e15f0efb4d0011e48fb130a018ca8bcfba', '2026-11-11 19:06:58.590097+00'),
	('admin/scoped-events/error_events/0100/0-stamp-column', '1cd303489c5aa70ae68ece2d64a88738a52f29a7de535427e22e31c578623b6e', '2026-11-11 19:06:58.590097+00'),
	('admin/scoped-events/error_events/0100/2-keys', 'be4906db5356943fc00c32d19e2cd751f3eb91e8d0b73bee4ae5fe8285859524', '2026-11-11 19:06:58.600841+00'),
	('admin/scoped-events/error_events/0100/2-references', '36d69cd7271e793c1463330767a9b88b82990f9d213471ff76a8c61756edb706', '2026-11-11 19:06:58.602093+00'),
	('admin/scoped-events/error_events/0100/3-policy', 'c772afaaf54f4f0c94ea5906d3cb8c068e4777b38daf7b7a5b830dfc578c562b', '2026-11-11 19:06:58.604386+00'),
	('admin/scoped-events/error_events/0100/2-tenant-policy', '6d4965eb38a44bfc6742af1f202a9c41616457810ae403fe872c13852ed0eea4', '2026-11-11 19:06:58.604386+00'),
	('cron/fires/0002-tenants/0-column', 'd2a94361967c465388d5dd7a1a0f0f18ef394d0db602951c7b96891cc67543d7', '2026-11-11 19:06:58.608646+00'),
	('cron/fires/0002-tenants/1-column', 'a10374f2cd6af37b57c88ae0ff1ea5422013fa20967981e306ae2fbaf8877949', '2026-11-11 19:06:58.610918+00'),
	('cron/fires/0002-tenants/0-stamp-column', '0596d59fe519ddf6e3bdec0fd1fc26c52a4b9cf073078375ec89ba9e0f10ea88', '2026-11-11 19:06:58.610918+00'),
	('cron/fires/0002-tenants/2-keys', '12661fd78074ee0d3d321b59233a38097d4a144d279f1a222bd0faa2c23f06df', '2026-11-11 19:06:58.619588+00'),
	('cron/fires/0002-tenants/2-references', 'd323d729893bf937c6e6b443c3f31dc70a75ee1d5bb3c1955857f7d927218d8e', '2026-11-11 19:06:58.620609+00'),
	('cron/fires/0002-tenants/3-policy', 'c52b5a14056520eeddb50df202781d0084cfc87cbb141d7b52115117fa493e21', '2026-11-11 19:06:58.622525+00'),
	('cron/fires/0002-tenants/2-tenant-policy', '05884e402c4acd7c6188e2cd048def39893f6517cbc54f339b1acbd84d5f9a03', '2026-11-11 19:06:58.622525+00'),
	('cron/fires/0003-claims', '9bae5a95ea4708656a69dba3be0ce116914a9cab09bba58745568d94500b3bb2', '2026-11-11 19:06:58.625819+00'),
	('cron/fires/0004-copy-history', 'a052bd9b80203a35995d454994babeed47ec24d377e115a8174b4999292d93ee', '2026-11-11 19:06:58.628842+00'),
	('cron/fires/0004-drop-legacy-sync', 'e8a5d25daa6b34cbded1a4aa6dbad1eacbf6be4bb5fb8e01fd27e4446157a6a6', '2026-11-11 19:06:58.63114+00'),
	('cron/fires/0005-drop-fire-log', '762e0cd4037f7facfea19c27957ca6279b1f198ac93ad8680a314c9843689be9', '2026-11-11 19:06:58.632562+00'),
	('decisions/0002-tenants/0-column', '3ce72f60ab9894d801b89173604eb42a0f3fe81d85373ede7ff968645729a489', '2026-11-11 19:06:58.633997+00'),
	('decisions/0002-tenants/1-column', 'ce4b18b1a494e971327fd0c3a16633582eae991aaaa8cd200c2ae95cc21a598b', '2026-11-11 19:06:58.636634+00'),
	('decisions/0002-tenants/0-stamp-column', '9f34e5ea3a9419317666d6e4cda8ec8ad860fe5a14bdb7360f774a14fe449a12', '2026-11-11 19:06:58.636634+00'),
	('decisions/0002-tenants/2-keys', '0ab5d5b77e9077aa53c676eab0b2cf6f1acfdf70a9ee26e6e9cd35b7f365205d', '2026-11-11 19:06:58.649627+00'),
	('decisions/0002-tenants/2-references', '4b276fb6928ee54ef07d682b0c8abc561b169f9183b3c0427686048700d3ee6e', '2026-11-11 19:06:58.650462+00'),
	('decisions/0002-tenants/3-policy', '4176ee339463beaa5e0bc72ab50697ef8652ee1de78c5bfa21be4ba1223de579', '2026-11-11 19:06:58.653925+00'),
	('decisions/0002-tenants/2-tenant-policy', 'de77308bfacc75d597c1978766a38cd4e9dfc46d8dbf738dcef7db8af8362225', '2026-11-11 19:06:58.653925+00'),
	('delivery/store/0007', 'e22b36237580107662c4bf5541b223f47e7bcec09722f8e224803c1f29f5135e', '2026-11-11 19:06:58.658715+00'),
	('delivery/store/0008-tenants/0-column', '0cbb9f194153d607a04b2728a697734f8c3093d36a12a08e445a7aca7ba38040', '2026-11-11 19:06:58.65983+00'),
	('delivery/store/0008-tenants/1-column', '298bedb7aa4b971f3396c19fa1fb6f783adc88f256caa4616b17afc8b8c3ad4d', '2026-11-11 19:06:58.661833+00'),
	('delivery/store/0008-tenants/0-stamp-column', '77e8fc36f0dd55788c03fc0fbc2447055fd25bf2fc88f3720cc8ac1a75da392d', '2026-11-11 19:06:58.661833+00'),
	('delivery/store/0008-tenants/2-keys', '5df002f00edb8912bf7e2eab51b56c1d53c235c79b4422713ff6a9c2d8a23e8e', '2026-11-11 19:06:58.670767+00'),
	('delivery/store/0008-tenants/2-references', '6be494b498a920b4f1a9f8de15fa2270f4a66fadef45316c838933651a133fc8', '2026-11-11 19:06:58.671579+00'),
	('delivery/store/0008-tenants/3-policy', '57b76353086dac522328e31a1025548851b1059cce0198fef19d0bce6daf5e4a', '2026-11-11 19:06:58.673379+00'),
	('delivery/store/0008-tenants/2-tenant-policy', 'bc5c88dd9a91deb31db8cc7037d3c656518a171b488d2e923b0d08015c54610b', '2026-11-11 19:06:58.673379+00'),
	('delivery/store/0009-claims', '60e30b29a0e03e72760e3b6017f413af8d4f7d79735e0dd5802fedfede354ac3', '2026-11-11 19:06:58.677216+00'),
	('delivery/store/0010-undelivered-claims', '117986e5ac2ce624e00fe6ae942ecb96c80b0f05d123f54effc0620c9dcdb7ff', '2026-11-11 19:06:58.682057+00'),
	('delivery/store/0011-undelivered-uncapped', '0ca80f89e0a916c6b6bbf7218899cdbedf77b38a8e3e963abcf5bebde6ffdf43', '2026-11-11 19:06:58.683389+00'),
	('delivery/store/0012-undelivered-tenants', '473a7717f1f0db2c16e471206952248f840476dd5779b5fbb24fd0ccd968514b', '2026-11-11 19:06:58.684571+00'),
	('deploy/app-page-views/0001', '1a96f651d496b094c41604bedb25f1f5ae4542827668ef7a9a278d5024b38fd1', '2026-11-11 19:06:58.685688+00'),
	('directory/store/0006-base-schema', 'e8dcd5c2a3a8fcba7b1c14db1d1aceb57ca7ef6e1c7366ace6df65043f731198', '2026-11-11 19:06:58.692923+00'),
	('directory/store/0007-tenants/0-column', '04255d47b78c34b3cc104950195a2d958043caecc208e14f85ea1f4f2f2e5f36', '2026-11-11 19:06:58.694087+00'),
	('directory/store/0007-tenants/1-column', 'ef8a20685ad4639fb36b08ffac77f8d448c0e1261bd7d452e8a54a6ad1b0448b', '2026-11-11 19:06:58.700072+00'),
	('directory/store/0007-tenants/0-stamp-column', 'd7b4eb42bd1c5d0d12343d7c399cc4d9cc953cb0a96be36594a24df6fe273f89', '2026-11-11 19:06:58.700072+00'),
	('directory/store/0007-tenants/2-keys', '06bbd9d8e0f2393ac863082a0b74ab958d8152b9f1981522b46d39bad62f4db1', '2026-11-11 19:06:58.729563+00'),
	('directory/store/0007-tenants/2-references', 'f73dab5bc4783305eb2ed520c8dca1946c57eccc4389c1ee2ba21f95dd11bdea', '2026-11-11 19:06:58.7306+00'),
	('directory/store/0007-tenants/3-policy', '1e390b75e3417e5cb5990e2dd6d0247321cd23649007319de100a7299b7ffd1d', '2026-11-11 19:06:58.737335+00'),
	('directory/store/0007-tenants/2-tenant-policy', '36539f51f3e1c9efd19c3d12e29cfcef507198cd1f7d7ab6348eac7515bafb3c', '2026-11-11 19:06:58.737335+00'),
	('directory/store/0008-tenants-for-email', 'b8622cf26e327e06aca5783545c042ae348bc8d994abbfbac546178beac3a07d', '2026-11-11 19:06:58.744697+00'),
	('directory/store/0009-tenants-for-email-admins', 'ae78bff01d6f69ec05d294779483cda6edaf15b58bb03cda81d8c6f9144b488d', '2026-11-11 19:06:58.746269+00'),
	('directory/store/0010-tenants-for-email-users', 'b893453f8daa168dee111b7045cc7cd2646b352b66916c3f4c9e10ff605ebe4c', '2026-11-11 19:06:58.74789+00'),
	('durable-map/ack_emoji/0010-tenants/0-column', '630ef862df9cbcb52421482b607e0eba74b23c78782a40fb50fcff193dda46f0', '2026-11-11 19:06:58.74967+00'),
	('durable-map/ack_emoji/0010-tenants/1-column', 'f94fa5be396a68eeadf1fa932938e51f9d060a8d02c05ce64d62b28cebd62d97', '2026-11-11 19:06:58.75205+00'),
	('durable-map/ack_emoji/0010-tenants/0-stamp-column', 'c8be5ad22c59b6f8c6746b23f273624c937df2c04974a777cf0094f9016116c1', '2026-11-11 19:06:58.75205+00'),
	('durable-map/ack_emoji/0010-tenants/2-keys', 'a12df4cadf1a6c1772fe15d6cabc1c2739de4627885ec82c0f4d6ecaa060e82e', '2026-11-11 19:06:58.757805+00'),
	('durable-map/ack_emoji/0010-tenants/2-references', '8be528f27b0cb06312469370b6f46d37fb7df6bdfabdf2efb68ba7634dddd5f4', '2026-11-11 19:06:58.758652+00'),
	('durable-map/ack_emoji/0010-tenants/3-policy', 'f95b752223f536e7798dfba54a7d150d102f58801eb93cdb1dedd3b8890c7224', '2026-11-11 19:06:58.760453+00'),
	('durable-map/ack_emoji/0010-tenants/2-tenant-policy', '1945f13af473951a9cba45e60c2b2543a0a37271700a77a28b8acbcaab38aac9', '2026-11-11 19:06:58.760453+00'),
	('durable-map/ack_emoji/0020-claim-ids', 'fa021e6a1bf8472bc0ad65add2391d410c2aebbf3f6a10f6f9bb294e926d2afb', '2026-11-11 19:06:58.763165+00'),
	('durable-map/ack_emoji/0021-claim-tenants', '1a393d958802b8b25fe89805a085db3f688db4c4b896521d34f24953e5436d19', '2026-11-11 19:06:58.764352+00'),
	('durable-map/ambient_cursors/0010-tenants/0-column', 'f20917d483d4903bfc4c88adffded16e8bcd7eae3b63d5914c683d4dd1fd7603', '2026-11-11 19:06:58.765361+00'),
	('durable-map/ambient_cursors/0010-tenants/1-column', '607224eb94d87c375ce842c3e7024c79c07f98f65dd1ce9977242034dbe3a029', '2026-11-11 19:06:58.766817+00'),
	('durable-map/ambient_cursors/0010-tenants/0-stamp-column', 'a3044c5a8e05d6ffd55b6258624adea7c68be1fa8e29de0d2cd6ce3a9bc262d0', '2026-11-11 19:06:58.766817+00'),
	('durable-map/ambient_cursors/0010-tenants/2-keys', '9dc9b351dca4a276f592222d50d34a9aaf23cfba272a4eafa987f6a902037188', '2026-11-11 19:06:58.771534+00'),
	('durable-map/ambient_cursors/0010-tenants/2-references', '78e8c670bf31ea7c4c99d47f99792ed6b870dca34547f5cde67b85b406110ded', '2026-11-11 19:06:58.772382+00'),
	('durable-map/ambient_cursors/0010-tenants/3-policy', '62c48ec0565811f9bd3210f51a508077ff155b463442c9337570dcb178260084', '2026-11-11 19:06:58.774567+00'),
	('durable-map/ambient_cursors/0010-tenants/2-tenant-policy', '38c0f2a91319e7a1ab501d43e3c7f13ae6720fc8bd5dc63a17d888c7217d6c1c', '2026-11-11 19:06:58.774567+00'),
	('durable-map/ambient_cursors/0020-claim-ids', '0739cfecb8869262c8357334d0c8e1f99980cb062312e7f6772cf7440ab144f4', '2026-11-11 19:06:58.777315+00'),
	('durable-map/ambient_cursors/0021-claim-tenants', 'cc9cbd10ade9463e591df465e45aebfddec0dd43e6b3eb8ba65c691c326cbc57', '2026-11-11 19:06:58.778607+00'),
	('durable-map/approval_grant_modes/0010-tenants/0-column', '583207443187f53e1c1fb58c9098065c841e45ad647154638d93bf1f7ab80442', '2026-11-11 19:06:58.779904+00'),
	('durable-map/approval_grant_modes/0010-tenants/1-column', '8ab389c8bc194eae0ccbab5105082a5ae517b5415f856e548438443819a27870', '2026-11-11 19:06:58.781717+00'),
	('durable-map/approval_grant_modes/0010-tenants/0-stamp-column', '8b8f7f4b3fcd506d2bdb0f0b0a8d4821978c13d0457c47e025d4553fa3eb6e30', '2026-11-11 19:06:58.781717+00'),
	('durable-map/approval_grant_modes/0010-tenants/2-keys', 'd96669cf7f198251fa459e092a9ed59100948de81578647474433481eb0fec95', '2026-11-11 19:06:58.78698+00'),
	('durable-map/approval_grant_modes/0010-tenants/2-references', '577cd905f40072a4f148e4dd449d2cc31b3b9ca3e6ddbb03c6252b276a0c5ba1', '2026-11-11 19:06:58.787889+00'),
	('durable-map/approval_grant_modes/0010-tenants/3-policy', '571a4fe0d2aac7f83fa487b7a0b2259f132f0ec4fed1b6e7afaea628aa095a68', '2026-11-11 19:06:58.790281+00'),
	('durable-map/approval_grant_modes/0010-tenants/2-tenant-policy', '7b5f4ee6bea0571e9f0a78859178f2b8bc418e5cbae26025ea9d4622913f2c7d', '2026-11-11 19:06:58.790281+00'),
	('durable-map/approval_grant_modes/0020-claim-ids', '91890091deb57080ab7bc924aca7475385659af4cc3c52db916d1496e6bc3101', '2026-11-11 19:06:58.793877+00'),
	('durable-map/approval_grant_modes/0021-claim-tenants', 'e805c0e0859e1afa9396139ee71feaa22b2c338fbb83e458747dc3b13e8c644b', '2026-11-11 19:06:58.795409+00'),
	('durable-map/approval_grants/0010-tenants/0-column', '13d2834489de08c8ca3915a86e805028c7841c9fe3c6d9f4972b17d6fcba4594', '2026-11-11 19:06:58.797334+00'),
	('durable-map/approval_grants/0010-tenants/1-column', '0c95b06bacf1f51ef814eaa36dd3c9724e96c7cc86f59f26101b5849caa55b67', '2026-11-11 19:06:58.799121+00'),
	('durable-map/approval_grants/0010-tenants/0-stamp-column', '1b38f6bea64df4ae9086917943b92a4901f6d9c81ec7542286209c9104273506', '2026-11-11 19:06:58.799121+00'),
	('durable-map/approval_grants/0010-tenants/2-keys', '4d06c48a7abb7e96507e7f938ec114e96896827c70256222a8094a90ff665a9b', '2026-11-11 19:06:58.803705+00'),
	('durable-map/approval_grants/0010-tenants/2-references', 'af8a35b9687ec1315ae5e07e3ec339c54cc34036655bf90e3bafb8bcf24605e0', '2026-11-11 19:06:58.804591+00'),
	('durable-map/approval_grants/0010-tenants/3-policy', '1e1d194b150b042b7bf66cba0bb63b94c1fa6a0660fe7378cf441b6920700d99', '2026-11-11 19:06:58.806414+00'),
	('durable-map/approval_grants/0010-tenants/2-tenant-policy', '2178ed365f8a56fbf8232f80699bbbb674f1866809d26b9510bb109c3711539a', '2026-11-11 19:06:58.806414+00'),
	('durable-map/approval_grants/0020-claim-ids', '35746d22f142ff75ce7432a28683306999ae377eb8b3405747cd66bac2dd0ca2', '2026-11-11 19:06:58.809313+00'),
	('durable-map/approval_grants/0021-claim-tenants', '1e48ea9f56154af0ec9562bffc502fb3b39a5dc6e7e828c69be92c7f0255e0f2', '2026-11-11 19:06:58.81057+00'),
	('durable-map/approval_grants/claim-actorid', '84125816f58be8fb90f8ee87d1f819b19893dd8fc171343d8f45a6d95cea4fde', '2026-11-11 19:06:58.81156+00'),
	('durable-map/approval_grants/claim-tenants-actorid', 'f8c3f51c7943c530d1c3034bf05a73e0aaf45760afea0645128dac1d73f05fc4', '2026-11-11 19:06:58.812776+00'),
	('durable-map/approval_grants/lookup-actorid-drop', '0abca61411d1721d89d636d82f15cae23eedbdcc6956596a03aeb31de9535cde', '2026-11-11 19:06:58.813847+00'),
	('durable-map/approval_grants/lookup-actorid-hash', 'c63fc8546cf1a5358a6ad03c02cf00161e03d0e9bb0deda9a1c0a47bdaa53491', '2026-11-11 19:06:58.817493+00'),
	('durable-map/approval_grants/select-actorid', '6d3272c2deba8f75029adb10eb79356e82c57bc127abc0523ade328443047550', '2026-11-11 19:06:58.823547+00'),
	('durable-map/approval_grants/stats-actorid', 'a13b17482a5e4c6d7ee277a046ad358b82de05619c73cb3adf198e8de03c2a88', '2026-11-11 19:06:58.824521+00'),
	('durable-map/approvals/0010-tenants/0-column', '36bcb87257415bad0774e090a803832dc6938307274872a0516f0cde58595df0', '2026-11-11 19:06:58.826631+00'),
	('durable-map/approvals/0010-tenants/1-column', '3783d744ab0eaff2a89d0fbd0ae9142b16bb761adb125e9cf2312430ee126202', '2026-11-11 19:06:58.828449+00'),
	('durable-map/approvals/0010-tenants/0-stamp-column', '390c64f33757bd7bcbcf8858a9f99dccc3210dfdff73b7808e66ea7884eb250b', '2026-11-11 19:06:58.828449+00'),
	('durable-map/approvals/0010-tenants/2-keys', '4dd0a2e75b00247017b94d172c0b1a2c1eb766791df1d16e467419b8b0e5a4a3', '2026-11-11 19:06:58.832888+00'),
	('durable-map/approvals/0010-tenants/2-references', 'eaf2fd6e604265b53f9d228e8efcdce02fcf691a367901ed79f3d7323c0e3031', '2026-11-11 19:06:58.833642+00'),
	('durable-map/approvals/0010-tenants/3-policy', '79e4a8d00522db75404daa3c8dae62f1f4e9951ef7da647c2b2578721e8f0b92', '2026-11-11 19:06:58.83531+00'),
	('durable-map/approvals/0010-tenants/2-tenant-policy', '5c77020065fd6b26ced403ab7d37be8bc92643d3923362d9173b6f3f32389cc6', '2026-11-11 19:06:58.83531+00'),
	('durable-map/approvals/0020-claim-ids', 'd915cd635482ed099014e6a4da69c7a4f2ee15a8d39d8a50d796141d213ac7e1', '2026-11-11 19:06:58.838588+00'),
	('durable-map/approvals/0021-claim-tenants', '1b7c902a2cd16bf538260148a5cc4942968f6e16cc3ff7e3c59701c5b78b79dd', '2026-11-11 19:06:58.840458+00'),
	('durable-map/approvals/claim-sessionid', 'bf09c3f4eca7c2292bc5a6e65748c29bf729f1c73d9ea0131f6871cbe3dc0e88', '2026-11-11 19:06:58.842243+00'),
	('durable-map/approvals/claim-tenants-sessionid', 'd14338ed0a351e48cd4ce216968bf17113abccb77eb24c20b2c7a8f8797933c9', '2026-11-11 19:06:58.843579+00'),
	('durable-map/aws_deploy_bodies/0001', '7f458e3f79f0566522f6c4b34644602342c068a51a63683a15b8dc9dc4107def', '2026-11-11 19:06:58.845259+00'),
	('durable-map/aws_deploy_bodies/0010-tenants/0-column', '3d8161db02ae900e66b45b0311ad0bc8275050d2f1cdb09fc0c7136d03e93b7e', '2026-11-11 19:06:58.849576+00'),
	('durable-map/aws_deploy_bodies/0010-tenants/1-column', '2ec50d3ed13557da5da597d1c1d1e7d1906bc9712d9edce514e997a28b352bd5', '2026-11-11 19:06:58.851026+00'),
	('durable-map/aws_deploy_bodies/0010-tenants/0-stamp-column', '19c96b2d90a61ed198e41faa8ba761e142de1738729c670f7828686881ecdeeb', '2026-11-11 19:06:58.851026+00'),
	('durable-map/aws_deploy_bodies/0010-tenants/2-keys', '6478649b1b555aed85990cb62d81e0492cf405e36c1a8e931ed5717c4148e3ff', '2026-11-11 19:06:58.855342+00'),
	('durable-map/aws_deploy_bodies/0010-tenants/2-references', '44795d3075e4ea0dbf9e875d47db1dd5df456e133cb42f5438cdb71a75c5df6e', '2026-11-11 19:06:58.856155+00'),
	('durable-map/aws_deploy_bodies/0010-tenants/3-policy', '149e833200b1680d6220b26407ecc082765f81c3dc32c0aae1ac4ae389618072', '2026-11-11 19:06:58.857819+00'),
	('durable-map/aws_deploy_bodies/0010-tenants/2-tenant-policy', '3d2894164f6a95f09c8b8033b192b8e0fc84baa96d39b5f5ffec3060ab79906b', '2026-11-11 19:06:58.857819+00'),
	('durable-map/aws_deploy_bodies/0020-claim-ids', '7b2ac0daab70437456e57bc9e978fab2c3853f6b8ba6f305115c1d68de25f62b', '2026-11-11 19:06:58.860625+00'),
	('durable-map/aws_deploy_bodies/0021-claim-tenants', 'e2d43fdd20cb275402916b17cc00184ea4f6c8e2aff6d02e242827ca12142fbd', '2026-11-11 19:06:58.861594+00'),
	('durable-map/aws_sandbox_bodies/0010-tenants/0-column', '5de4be6b1b9d48fddd4d27bfb306c6925bd28470b95f3effd232b4c57b637345', '2026-11-11 19:06:58.862562+00'),
	('durable-map/aws_sandbox_bodies/0010-tenants/1-column', 'e0afdc8a13c4deaf1e9c12abcf46e60e67194a90a54348067ff07f29f90a7dfd', '2026-11-11 19:06:58.864166+00'),
	('durable-map/aws_sandbox_bodies/0010-tenants/0-stamp-column', '34763c41b8f6c5a428ac03a3779f365fe0bfaa827819b47b2d8f4e62a4ee420d', '2026-11-11 19:06:58.864166+00'),
	('durable-map/aws_sandbox_bodies/0010-tenants/2-keys', '1ae5ea1ca218320b47af69eedafb578e6d2bce58fa795d0bbbdd0b407fe2f498', '2026-11-11 19:06:58.86829+00'),
	('durable-map/aws_sandbox_bodies/0010-tenants/2-references', '1c83f0d165939cdd59f79f6d6aa2d32a3e530f4ddb6f92298597977d15346a22', '2026-11-11 19:06:58.86911+00'),
	('durable-map/aws_sandbox_bodies/0010-tenants/3-policy', 'a0675d566bba378fceabc691f8f4949445971465748af2b40c1c98187f51d00b', '2026-11-11 19:06:58.870993+00'),
	('durable-map/aws_sandbox_bodies/0010-tenants/2-tenant-policy', 'e2d1a3915687a6a4ee914410ece6d7e180895d6d1534803bbf815aee9b6beb36', '2026-11-11 19:06:58.870993+00'),
	('durable-map/aws_sandbox_bodies/0020-claim-ids', 'bc3c9b72f2196654697ffc94279c27ee74a0f810209103ae109e35b8558a5641', '2026-11-11 19:06:58.873339+00'),
	('durable-map/aws_sandbox_bodies/0021-claim-tenants', '1b69b0818128e608ea38d1a56deb9b97e4065b32e65294fabfc5d5f4afccd384', '2026-11-11 19:06:58.874598+00'),
	('durable-map/base_model_configs/0010-tenants/0-column', 'd9e290003d97fca3c3060dc1e5e1bb6c1efe702b2728aec5e0a8f0e792ed3f1a', '2026-11-11 19:06:58.875701+00'),
	('durable-map/base_model_configs/0010-tenants/1-column', 'f3c7960a0c50f547da8de47a9f04d7b31adb4acef62f7cc70426bd108c822adf', '2026-11-11 19:06:58.87702+00'),
	('durable-map/base_model_configs/0010-tenants/0-stamp-column', '5fcc140d24ae6d91a39a0717db61b849112fb02a6e3dce8fcaf30075133f4f5d', '2026-11-11 19:06:58.87702+00'),
	('durable-map/base_model_configs/0010-tenants/2-keys', 'd5591001788603f53ba61904731bf3299cb11618e5b4cdf97b9081b49ee6b5af', '2026-11-11 19:06:58.881374+00'),
	('durable-map/base_model_configs/0010-tenants/2-references', '0c0e47c96bdb6b419f0de24c11a7a5bd95a800724a417f4289fe09fdbd7cbba5', '2026-11-11 19:06:58.882164+00'),
	('durable-map/base_model_configs/0010-tenants/3-policy', '6936082e9da53c1e424ecb916ad0414760b422ac7d78325baaf2ddba672a8ae1', '2026-11-11 19:06:58.883783+00'),
	('durable-map/base_model_configs/0010-tenants/2-tenant-policy', '8efd675dc381a30312e6a5bb4b3dd3748e7af725d8dfa3c5ff8af45e69c7594d', '2026-11-11 19:06:58.883783+00'),
	('durable-map/base_model_configs/0020-claim-ids', '8f010d8396b1428f31e8e06dcc03ada5a843d58ee6c168e6eb798baf02374260', '2026-11-11 19:06:58.886452+00'),
	('durable-map/base_model_configs/0021-claim-tenants', '1f396402984be6ae2ddccdb5bbaf29a3fc681a603a258b5b95a21a5519872738', '2026-11-11 19:06:58.887764+00'),
	('durable-map/branding_configs/0010-tenants/0-column', '129af8dd6acd92ef2353d42cd85a8c97094bda5e1f6a77dbce9b206055d65959', '2026-11-11 19:06:58.889119+00'),
	('durable-map/branding_configs/0010-tenants/1-column', '2087c8bd2ac0b35500de566d8aac958a62abccc5e515415791f8afa75e75882d', '2026-11-11 19:06:58.890545+00'),
	('durable-map/branding_configs/0010-tenants/0-stamp-column', 'cf8c163d2ec5a7a4b528e195b85647eb156b25b01d76c0f6e06831d22d79b9af', '2026-11-11 19:06:58.890545+00'),
	('durable-map/branding_configs/0010-tenants/2-keys', 'a203f02b9f49d60927c0ca2bb95bb496d658639f55bf9530a59cd6680ce45212', '2026-11-11 19:06:58.895321+00'),
	('durable-map/branding_configs/0010-tenants/2-references', 'ba9225a59c3e95930952f0af842b3c50ac0f86ff73970de5c63d92671ebe181c', '2026-11-11 19:06:58.896007+00'),
	('durable-map/branding_configs/0010-tenants/3-policy', '31a87b9a8fd4e9240e9bde6382d0762f9090aa152a870fe28bb2d69c0827bbed', '2026-11-11 19:06:58.897836+00'),
	('durable-map/branding_configs/0010-tenants/2-tenant-policy', '73874c1018bec9171e7df034f605da0aaa513a133cb013b141637c93fa26c2ef', '2026-11-11 19:06:58.897836+00'),
	('durable-map/branding_configs/0020-claim-ids', '46136946a24ddb85a3c7c4053cf13378d291da7af722075c1181684d6ff3d331', '2026-11-11 19:06:58.901321+00'),
	('durable-map/branding_configs/0021-claim-tenants', 'aa1d73c1ca7ed79f6481dcd084e73babce58fa7105792ee11ad700f2a49d71e4', '2026-11-11 19:06:58.903399+00'),
	('durable-map/browse_max_steps_configs/0010-tenants/0-column', '2132d65d5098c475bcf337721613368415889ea14de6d1c947ffbae8daaac8e0', '2026-11-11 19:06:58.904896+00'),
	('durable-map/browse_max_steps_configs/0010-tenants/1-column', 'c6a81c5e9df4712230df731a63b0eb04d299a39aa637434082c0c056f7378264', '2026-11-11 19:06:58.906336+00'),
	('durable-map/browse_max_steps_configs/0010-tenants/0-stamp-column', 'cbb0081040dfa4cced7a1f8de5e9a58545bcfcf46dc2946bc1e6e1f16ac1cb22', '2026-11-11 19:06:58.906336+00'),
	('durable-map/browse_max_steps_configs/0010-tenants/2-keys', '85056bcebb027e1fbf7f1352da6ac4253aca5759afbe54ada11ac000fc69c78e', '2026-11-11 19:06:58.91048+00'),
	('durable-map/browse_max_steps_configs/0010-tenants/2-references', '12108b6e1ca80d24a0df80a96104f2b1b3ee8c15375ec02563b7e8d921005157', '2026-11-11 19:06:58.91106+00'),
	('durable-map/browse_max_steps_configs/0010-tenants/3-policy', '2b751419ca9e47a118a9f4ff610af763f5b5e70ee2bea49728527aff27f8d480', '2026-11-11 19:06:58.9125+00'),
	('durable-map/browse_max_steps_configs/0010-tenants/2-tenant-policy', 'd035d44f660787d0fb8e5adad185b6e1a9acc557a4844b22c4161f95a05a296d', '2026-11-11 19:06:58.9125+00'),
	('durable-map/browse_max_steps_configs/0020-claim-ids', '8fe85450bd7bf7002d64fa620f2e1ba2a5596719546e8348beed1f032665c61b', '2026-11-11 19:06:58.915164+00'),
	('durable-map/browse_max_steps_configs/0021-claim-tenants', 'ee9ff661a46a1e54e51d2c62d3a8a2303b4012faf17f0d63f4d2faa8dea9193c', '2026-11-11 19:06:58.91631+00'),
	('durable-map/browser_sessions/0010-tenants/0-column', '47f1e642163300ac458d95d6e99a07e5b3b5a5a473b92413d6aff3ad3d391b3f', '2026-11-11 19:06:58.917248+00'),
	('durable-map/browser_sessions/0010-tenants/1-column', '3037c7727aef2fa2e4290d99431ab160c0a167c4af26dda4cc82d553ea6de412', '2026-11-11 19:06:58.918669+00'),
	('durable-map/browser_sessions/0010-tenants/0-stamp-column', 'f98c0ea155de28bc5a21eaa8c99d268eb005d7828fa35e2b679f9fab8d4efc53', '2026-11-11 19:06:58.918669+00'),
	('durable-map/browser_sessions/0010-tenants/2-keys', '38cdd50c8d5a3b41b8f38e4eb44a5383a1fa064785d2a3aea899486d10139a0d', '2026-11-11 19:06:58.923426+00'),
	('durable-map/browser_sessions/0010-tenants/2-references', '96bbe9a1d3b0534d80a9aa68ad89bdf29985490609661c9ec1c57800611ee958', '2026-11-11 19:06:58.924216+00'),
	('durable-map/browser_sessions/0010-tenants/3-policy', '33aa93971e888608c211205841571547baaf637360f4e0359b9a511e51e92821', '2026-11-11 19:06:58.925806+00'),
	('durable-map/browser_sessions/0010-tenants/2-tenant-policy', '17d06e5daa495daa01b345f4f1a3880c4dc924c6be492a252a70251cf80faba0', '2026-11-11 19:06:58.925806+00'),
	('durable-map/browser_sessions/0020-claim-ids', '266d3738157aa366a46974dba48d091c97e6c34059b9f8d37997597923b5f532', '2026-11-11 19:06:58.928179+00'),
	('durable-map/browser_sessions/0021-claim-tenants', '575a427a3c69d2246dd5557098b9351452eea9730f4ffec24540eda15ccdbcf7', '2026-11-11 19:06:58.929521+00'),
	('durable-map/channel_header_pin_flag/0010-tenants/0-column', '9259754a5bc23dbc755a22a1016f9b6980545880d5ce1a6a64e23fbab79e2bc5', '2026-11-11 19:06:58.931078+00'),
	('durable-map/channel_header_pin_flag/0010-tenants/1-column', 'ae469e294189e47de637e6734758667a854db81fc8a9592f0440964202671e3e', '2026-11-11 19:06:58.933324+00'),
	('durable-map/channel_header_pin_flag/0010-tenants/0-stamp-column', '51f3ecf942baca957df53d568a4df763eaed0346ecfc46d71fcfa4a8749fc0a1', '2026-11-11 19:06:58.933324+00'),
	('durable-map/channel_header_pin_flag/0010-tenants/2-keys', '106c3d6e0b8e8e2d2491eaa4ae1902d7d3ce616b321af2ce6b85714b1ed989e0', '2026-11-11 19:06:58.938136+00'),
	('durable-map/channel_header_pin_flag/0010-tenants/2-references', '05ac9d8e3cb1af6bc416011fa71ab1d88a8e94c2deeeb8b65c72f831417b1d09', '2026-11-11 19:06:58.938862+00'),
	('durable-map/channel_header_pin_flag/0010-tenants/3-policy', '748ca2aabe196b9f5ae161eb1be80331ad018189e1ba620a2479124ad09b6c1c', '2026-11-11 19:06:58.940751+00'),
	('durable-map/channel_header_pin_flag/0010-tenants/2-tenant-policy', '2a5544550001cf8684ceaa06e7d8cf244b159e652b62c5c1240da7e6e2542774', '2026-11-11 19:06:58.940751+00'),
	('durable-map/channel_header_pin_flag/0020-claim-ids', '779387f74a90c2d49ebfc8fb9892c8ff79d7976ee69d46c5734c7a0f9d828801', '2026-11-11 19:06:58.943351+00'),
	('durable-map/channel_header_pin_flag/0021-claim-tenants', '6c26ad62717828f7ea570e9998cd2357beb6f4108d1d6fa736450dc86606c528', '2026-11-11 19:06:58.944509+00'),
	('durable-map/command_policies/0010-tenants/0-column', 'ee169a5bcbd55493a4ad1b6ab32a125e0f5165cd770604e0a76cd78190d09fbe', '2026-11-11 19:06:58.945523+00'),
	('durable-map/command_policies/0010-tenants/1-column', '3dcc271cd727f7bc5fb146f60ecec8c8d0f8ef1ceed506cade43ebb044a053cf', '2026-11-11 19:06:58.947247+00'),
	('durable-map/command_policies/0010-tenants/0-stamp-column', '32911ba3cef7ae8b99bb7d139b0eabc7b02d91ab5ca9cad175bff3fe2353b4ce', '2026-11-11 19:06:58.947247+00'),
	('durable-map/command_policies/0010-tenants/2-keys', '36b708efedf3d777af2bc4cd3f7fc83e1b7e893601c7ff2ec515bf46b059fefd', '2026-11-11 19:06:58.952294+00'),
	('durable-map/command_policies/0010-tenants/2-references', 'de2f7e39f0d2a20c21740d5307b2ad6e333d177c777026e604ef4db5b4c7de6c', '2026-11-11 19:06:58.952903+00'),
	('durable-map/command_policies/0010-tenants/3-policy', 'd1bb2dd1bf808ac252da6e23eebd7db85526a09d8231336ec5e0597b52a6a5d9', '2026-11-11 19:06:58.954778+00'),
	('durable-map/command_policies/0010-tenants/2-tenant-policy', '8ea5e301ea3bebcfc27d8b90c923c73c0a771082325a87c0b8ef557ab216cde8', '2026-11-11 19:06:58.954778+00'),
	('durable-map/command_policies/0020-claim-ids', '1dc3b4f827a45fb7dd15eeec793587258dbd45c5262d78c5188c59d9498bc297', '2026-11-11 19:06:58.957741+00'),
	('durable-map/command_policies/0021-claim-tenants', '1aaad2156f9c6cd542814c9d0199191d1de217878b3102e691319fceda6ea4e8', '2026-11-11 19:06:58.959087+00'),
	('durable-map/composio_returns/0010-tenants/0-column', 'b3921557624a25dc22b0d52c337668b5a85a7062a4471db410e55f141a5aca14', '2026-11-11 19:06:58.96006+00'),
	('durable-map/composio_returns/0010-tenants/1-column', '0abd47f6ce4c8f8e640c799a87a37c1c027d09d1035606c87af0f7f40bc91355', '2026-11-11 19:06:58.961598+00'),
	('durable-map/composio_returns/0010-tenants/0-stamp-column', '0f52c41dcec56b21686350b02578696c9a36fcde47075edb63ec64c713f5fa0d', '2026-11-11 19:06:58.961598+00'),
	('durable-map/composio_returns/0010-tenants/2-keys', '48b0dca9c27fdb251ce70e8ed7824487746cbcd8c7c0525b7232ed955388ce39', '2026-11-11 19:06:58.965931+00'),
	('durable-map/composio_returns/0010-tenants/2-references', 'ae2c5e01b87fd5b773e7bbf299afdffb64c04296433f460cd6b78a2327ee7b76', '2026-11-11 19:06:58.966698+00'),
	('durable-map/composio_returns/0010-tenants/3-policy', '758149ed8e4de22c90de08b0d48b95713cbc86c2696289f58e6d845952b19720', '2026-11-11 19:06:58.968734+00'),
	('durable-map/composio_returns/0010-tenants/2-tenant-policy', '8a8503a000623fd2586c01b4b08fc43af7e9750918948417bc671b10f9d7774d', '2026-11-11 19:06:58.968734+00'),
	('durable-map/composio_returns/0020-claim-ids', 'd624a056c155acdf3700e90b0d0b6fa3f432f1f6be0afb95f7e3c973e71cf8ab', '2026-11-11 19:06:58.971292+00'),
	('durable-map/composio_returns/0021-claim-tenants', 'fb1ecf8212a4f6c08c69563b2bc5d49c883808bb36ca9fa79e22586db7136195', '2026-11-11 19:06:58.972285+00'),
	('durable-map/connector_clients/0010-tenants/0-column', '875687d7485bff1768da61f248381a01108b0235a7ec61003321a30dda70580e', '2026-11-11 19:06:58.973596+00'),
	('durable-map/connector_clients/0010-tenants/1-column', 'b4c13dc57c87e888dbb0023bfb8bed6484238b87686c382d21a4d66dbe7ca782', '2026-11-11 19:06:58.9752+00'),
	('durable-map/connector_clients/0010-tenants/0-stamp-column', 'b7a26fabc5d521089127957f76f3c1963f6de35e2b4cd60b8bf44b99fc59c991', '2026-11-11 19:06:58.9752+00'),
	('durable-map/connector_clients/0010-tenants/2-keys', 'dc382f4a28ac154b11ddb9b450e69617d221ffcbefa26b9e1ffa07689ada717b', '2026-11-11 19:06:58.980064+00'),
	('durable-map/connector_clients/0010-tenants/2-references', '31d977eade492b3100bcbb86bc4b8ec51cb0dd97f272d6011fd04352e5821b08', '2026-11-11 19:06:58.980566+00'),
	('durable-map/connector_clients/0010-tenants/3-policy', '8ab38ebc9519a3a87b3180dbf04ff46058587eb5c0ade4bb317cf486df941e5e', '2026-11-11 19:06:58.9826+00'),
	('durable-map/connector_clients/0010-tenants/2-tenant-policy', '7b766545bf64e81f528b676fcefb0059ab4579d5dde1d0795990209ce5142463', '2026-11-11 19:06:58.9826+00'),
	('durable-map/connector_clients/0020-claim-ids', '7bb0ffce6e130251d28ef57feca1255ad30c66b3d397bbfd8983c6972bfb1f0e', '2026-11-11 19:06:58.985467+00'),
	('durable-map/connector_clients/0021-claim-tenants', '0f81b15b180f167063e91851acd01f6bb5439a87b82da54d9dd50c53e233849a', '2026-11-11 19:06:58.986344+00'),
	('durable-map/consent_links/0010-tenants/0-column', 'd6405ac7b799c86e41c45c1e22e566b7034a83662dc5e26f18c355fce3ab052c', '2026-11-11 19:06:58.987255+00'),
	('durable-map/consent_links/0010-tenants/1-column', 'cbda3b70bd1515412df5622e7115b340c3a1b07cba20d308d8cbdebaf910cf66', '2026-11-11 19:06:58.988733+00'),
	('durable-map/consent_links/0010-tenants/0-stamp-column', '7fcb616c93998370f70aa2eb10cc3f8bbc8d6d3d844af4468fee20ca8a4c9fb9', '2026-11-11 19:06:58.988733+00'),
	('durable-map/consent_links/0010-tenants/2-keys', 'c4f7e1d5ccfefa1b1cdbe13f7bbad6b90afbfa9b43991d4d045c2c9ec522a1f6', '2026-11-11 19:06:58.994122+00'),
	('durable-map/consent_links/0010-tenants/2-references', '6751d6286f272d680b9f8ef191cd5ce93ea1bcea2af24192c001ddd80b14fd6b', '2026-11-11 19:06:58.994717+00'),
	('durable-map/consent_links/0010-tenants/3-policy', '208adbfe50e990c45f3bc580d3270ee1da6f9e9073e36fc20af6f1cf8dcd2944', '2026-11-11 19:06:58.996737+00'),
	('durable-map/consent_links/0010-tenants/2-tenant-policy', 'aeea38d1eff9a2a573cbfe269ab4ef46fc53110b8f3bc5f2b3a3cae69e715d01', '2026-11-11 19:06:58.996737+00'),
	('durable-map/consent_links/0020-claim-ids', 'ec52221290e32451673fc228252a76531cc901f77909b1f31c0be4138eaf4249', '2026-11-11 19:06:58.999214+00'),
	('durable-map/consent_links/0021-claim-tenants', '68652d47bb0981dcb6d9b7e0287488d547fd2d61ff6103e671b9cb7c2b34885d', '2026-11-11 19:06:59.000224+00'),
	('durable-map/context_requests/0010-tenants/0-column', '5c65eec3c4ce30d41e75b9969ac42906f31ccb281d79e990bde05f5e3f47d177', '2026-11-11 19:06:59.001104+00'),
	('durable-map/context_requests/0010-tenants/1-column', 'c4ce734d20d90accb28d90b834a7b23ed7a909eb37dd2cbf350e483d5ea426ce', '2026-11-11 19:06:59.002649+00'),
	('durable-map/context_requests/0010-tenants/0-stamp-column', '60894dfcdc53d5d3d1290b47d1c45b8b05a9720e46306152e93ad4f9f2247e54', '2026-11-11 19:06:59.002649+00'),
	('durable-map/context_requests/0010-tenants/2-keys', 'd8b783ca21cf621e976d18f54e8657847eb7ede907b54e03436dad2a110299bc', '2026-11-11 19:06:59.007168+00'),
	('durable-map/context_requests/0010-tenants/2-references', '08c4e61292fc89bd28f9d120b5a4dfd97461d9904237a40319b572eb65861fb6', '2026-11-11 19:06:59.007766+00'),
	('durable-map/context_requests/0010-tenants/3-policy', 'fb95f483d8bec71ae6ecd77bf6f9fe5365e576b94ca1d1d2531c2046ed924d22', '2026-11-11 19:06:59.009638+00'),
	('durable-map/context_requests/0010-tenants/2-tenant-policy', '017ec649748bbba610b5f8df27af01b2047877006e284d5b64c6eccbf3cbcadd', '2026-11-11 19:06:59.009638+00'),
	('durable-map/context_requests/0020-claim-ids', 'd4a59b6c661d5907d9d2ace1523fd8639c1367d7970eff67d54e38c6f05915cd', '2026-11-11 19:06:59.012472+00'),
	('durable-map/context_requests/0021-claim-tenants', '33693d8b80082f590e5d59bea351f1fe03949cd378a6e92143116de2c0553a14', '2026-11-11 19:06:59.0137+00'),
	('durable-map/crons/0002-drop-fire-log', 'e5c71115a606ee26802f5865e9c040b8f83f59701444b8ee453eb579a974ffa1', '2026-11-11 19:06:59.014884+00'),
	('durable-map/crons/0010-tenants/0-column', 'd64481458c8229e6f3a6533538375aa07c5f03cd54fbfbbb076dfa845ab2f80c', '2026-11-11 19:06:59.016051+00'),
	('durable-map/crons/0010-tenants/1-column', '4088ec1bca9f563eb84a50ce3ac6e5d3849dbedf5373fff238407d974dd5fc37', '2026-11-11 19:06:59.017507+00'),
	('durable-map/crons/0010-tenants/0-stamp-column', 'f7eeddd6a82bb270195d855d7bb355894570d9b38bde0ef096c8ebfa4ad09cb4', '2026-11-11 19:06:59.017507+00'),
	('durable-map/crons/0010-tenants/2-keys', 'cd8a37b7e7c26cddace54a59f44c805ac33a1be6e59beeeae31408a613a4c584', '2026-11-11 19:06:59.021981+00'),
	('durable-map/crons/0010-tenants/2-references', 'a0cd2d803bdbc1d9ed8f52c3daf111f1dec3be82dfdff879496df129549985c3', '2026-11-11 19:06:59.022631+00'),
	('durable-map/crons/0010-tenants/3-policy', 'a4b6f2308f4030dce63504d3d3d2a25aaf13cd4bedbfa17a3ad62a3d024adfa1', '2026-11-11 19:06:59.024614+00'),
	('durable-map/crons/0010-tenants/2-tenant-policy', '2cfb36defc5d81439ed94b4b60a2894b0f171ad350b48d9dc3b37a877bcc2756', '2026-11-11 19:06:59.024614+00'),
	('durable-map/crons/0020-claim-ids', '248f0956a7ccff4831d870cc3b892cf38cdfece63a9d45cae0d3f479e6e35a7b', '2026-11-11 19:06:59.027746+00'),
	('durable-map/crons/0021-claim-tenants', '36cf9d539a48ac31e2d32ecb585681a5e40d331ea968ba79e9d399727288c874', '2026-11-11 19:06:59.028982+00'),
	('durable-map/crons/claim-ownerscopeid', '25bffaf38b8049c846e4120c2e751009c7681f2615bdfcad78d2c41cf5a5d85d', '2026-11-11 19:06:59.029916+00'),
	('durable-map/crons/claim-tenants-ownerscopeid', 'ee4bfe9fae4151b9ad21b70c357e8883549a047b9aa03b5da14fae6c1ba3b2ae', '2026-11-11 19:06:59.03072+00'),
	('durable-map/crons/lookup-ownerscopeid-drop', '1cc2c2306effba05aea7faedf703cdeb164606db17e419e2e49d561864ac31ca', '2026-11-11 19:06:59.031502+00'),
	('durable-map/crons/lookup-ownerscopeid-hash', '433e85de066799d6cd416cd286f95e6257b6067fc91f011fc549f6df43963c9f', '2026-11-11 19:06:59.03479+00'),
	('durable-map/crons/select-ownerscopeid', '7bc92ad7c73d1eddf8b18aee5bff5081aeb0447b5153ea5a90fdd7e78a239628', '2026-11-11 19:06:59.041155+00'),
	('durable-map/crons/stats-ownerscopeid', '190a91573ba35b1fd34091eddf47ca1dd38420b59f14bd594233ff76f5afba49', '2026-11-11 19:06:59.041931+00'),
	('durable-map/custom_model_providers/0010-tenants/0-column', 'ab3c3a62b9f67a00fb216e611f038b161afc72033e2e66f17064066ced90a3a7', '2026-11-11 19:06:59.043656+00'),
	('durable-map/custom_model_providers/0010-tenants/1-column', 'f383a5fe5403a74f0447ed8d905f3bee04220ea8b20466119833a7cc2957d787', '2026-11-11 19:06:59.045458+00'),
	('durable-map/custom_model_providers/0010-tenants/0-stamp-column', 'b6a3905947476655e7fd325aca79b27c1ad82218ba6f0d32e8f90669bf7fb453', '2026-11-11 19:06:59.045458+00'),
	('durable-map/custom_model_providers/0010-tenants/2-keys', '72137a943cfc8755ad12eff423eda3fa55e49cb58a255d2d219e5c2c0bf837e3', '2026-11-11 19:06:59.049849+00'),
	('durable-map/custom_model_providers/0010-tenants/2-references', 'b4e75c43cb72aed7a015227abbc6b1e69af992f3cf83d667ddd2dc47189f8809', '2026-11-11 19:06:59.050375+00'),
	('durable-map/custom_model_providers/0010-tenants/3-policy', '5668cb70458d9cc28a0ddbce21309e65f70b17d438a723185552469f49dc66df', '2026-11-11 19:06:59.052007+00'),
	('durable-map/custom_model_providers/0010-tenants/2-tenant-policy', 'ef0d37c5e0bb3eb42484d72503d2ac741b738b89617467f775c0b2c9c4bd3fb4', '2026-11-11 19:06:59.052007+00'),
	('durable-map/custom_model_providers/0020-claim-ids', 'e8a0c444e388c584df7922f7cb9b4060ba62d06a6a55a16c437510919c319c7a', '2026-11-11 19:06:59.05476+00'),
	('durable-map/custom_model_providers/0021-claim-tenants', '1f5bf4083e24ad1eeb764feb8a29ef1b34d24e2fb2a242f38ac29ad4e121d14a', '2026-11-11 19:06:59.055837+00'),
	('durable-map/deactivated_principals/0010-tenants/0-column', '1efc9d8db166b632aae2b7bdac92fe7db0015f0448034f24f5b24151279bba09', '2026-11-11 19:06:59.056862+00'),
	('durable-map/deactivated_principals/0010-tenants/1-column', '7ffdfc1fb93c8571c447338d118a991bf8df0a0c29c39f34a77722a2cf141dce', '2026-11-11 19:06:59.058555+00'),
	('durable-map/deactivated_principals/0010-tenants/0-stamp-column', '9ea0f710d5f935619c0ce9c46b1109f9453cd8934807b617ba245a1b4a15cab1', '2026-11-11 19:06:59.058555+00'),
	('durable-map/deactivated_principals/0010-tenants/2-keys', 'f88c250d484dbd5b0c01fd4a29efdc16576c3083c74ef26498e9e3dabbb873ba', '2026-11-11 19:06:59.063378+00'),
	('durable-map/deactivated_principals/0010-tenants/2-references', '80a6e738d13ec8675066760cccb81f1c84f4e9f70047ef7b218d33e58735cdc7', '2026-11-11 19:06:59.063873+00'),
	('durable-map/deactivated_principals/0010-tenants/3-policy', 'dbda525e68ffc3458a3a2faacdd8b4d5cde41a353aa95ea7afb02df944df01ce', '2026-11-11 19:06:59.065403+00'),
	('durable-map/deactivated_principals/0010-tenants/2-tenant-policy', '4dfd6c97abf4983b83be134ca32e326bca4a09608efdd5270cf6472a0d675e23', '2026-11-11 19:06:59.065403+00'),
	('durable-map/deactivated_principals/0020-claim-ids', 'f421615c30ea28edec203f05ee58745e21f3d39251b558eddbed8c00232fe51c', '2026-11-11 19:06:59.067984+00'),
	('durable-map/deactivated_principals/0021-claim-tenants', '9d0f30e8b6c28e01c56d22026076430162b1f325cff15ef88e774237ebbe25ea', '2026-11-11 19:06:59.068831+00'),
	('durable-map/deploy_git_repos/0010-tenants/0-column', '80cca26cfc184b58b7645450d0a197455a7bc194d72d79d80196f88fa41a2814', '2026-11-11 19:06:59.069687+00'),
	('durable-map/deploy_git_repos/0010-tenants/1-column', '3a35fd4ace44a7e90799ac8a713f27a6a9bae063444fa7af5a6dbecbb7b9f5b4', '2026-11-11 19:06:59.071068+00'),
	('durable-map/deploy_git_repos/0010-tenants/0-stamp-column', '67c8107219625fc491705eb723a8e344fc40e81976ea0270f0e0ec4f29dee36c', '2026-11-11 19:06:59.071068+00'),
	('durable-map/deploy_git_repos/0010-tenants/2-keys', '50046923872d36a7e73cb3a02350529ecc6c881f7e50864e379eb91295e87d0c', '2026-11-11 19:06:59.075433+00'),
	('durable-map/deploy_git_repos/0010-tenants/2-references', '5f04808f0b1952df37c7d35a5e9bce42f10747c4449a5a64bedebcb738a8412e', '2026-11-11 19:06:59.075984+00'),
	('durable-map/deploy_git_repos/0010-tenants/3-policy', 'e22c0ffad526c2747574170935d30b6ed68b051011b193652be19f4679f12821', '2026-11-11 19:06:59.077514+00'),
	('durable-map/deploy_git_repos/0010-tenants/2-tenant-policy', '7309859c881c29c5bcaa072644a46d4f60134f5f85572298c0fabf3319d2ab13', '2026-11-11 19:06:59.077514+00'),
	('durable-map/deploy_git_repos/0020-claim-ids', '67187b0f086137c466a5ec65af4ed8e12f42dc3f1707fe651cc0ff3690aaadc0', '2026-11-11 19:06:59.079765+00'),
	('durable-map/deploy_git_repos/0021-claim-tenants', '5f8228e9fd63d796e3056eb3f9b492125e8d5c3f92ef31a8c8c5db1bbf9a755a', '2026-11-11 19:06:59.080709+00'),
	('durable-map/deployment_identity/0010-tenants/0-column', '799c23dd38d6ef9e186051834a6f7f68faae772bd98ba9cfbacd4444cace72f1', '2026-11-11 19:06:59.081739+00'),
	('durable-map/deployment_identity/0010-tenants/1-column', '22cad043f3fd460957e7d39eda905fff429f28e92df5c4bdc85969c1dbbe9bd0', '2026-11-11 19:06:59.083008+00'),
	('durable-map/deployment_identity/0010-tenants/0-stamp-column', '5cbfdca18f26b695f458cb05a7716f05825791962eee1221a16b2c9b65dd1777', '2026-11-11 19:06:59.083008+00'),
	('durable-map/deployment_identity/0010-tenants/2-keys', '956d14e072816a025483d68c001a490964ba6a0323a5be3b0629cadccc4cfed5', '2026-11-11 19:06:59.087355+00'),
	('durable-map/deployment_identity/0010-tenants/2-references', '1ab413cd916478ec2784cce76a0f89adb5bcdb8c065a16fc8f23bc095e6cec13', '2026-11-11 19:06:59.088144+00'),
	('durable-map/deployment_identity/0010-tenants/3-policy', 'db397656b9f7e2f006fa7b8026c373ee53e123389be8e29a36143d38a002a0a9', '2026-11-11 19:06:59.08973+00'),
	('durable-map/deployment_identity/0010-tenants/2-tenant-policy', 'b9c02bff933ced9e398a9550a14b837988f81d164002819f2c0a64cd8bc45973', '2026-11-11 19:06:59.08973+00'),
	('durable-map/deployment_identity/0020-claim-ids', '0becbc58987144c08481b23dc1d6dd31cda8daa101ec902110d5bd2edd4c8dcf', '2026-11-11 19:06:59.092042+00'),
	('durable-map/deployment_identity/0021-claim-tenants', '3ee4164687d9b8aee4d61416211635430a3e9190d4cbadc884e10eec449d74b4', '2026-11-11 19:06:59.092908+00'),
	('durable-map/deployment_layer/0030-process-level', 'bf5b074bca31f04f6a1db4e8c2b3ff0c258f4eb87602aadd2ae572df87a836e8', '2026-11-11 19:06:59.093705+00'),
	('durable-map/deployments/0010-tenants/0-column', 'f4344bfb413a052d4b273aecd3edbe8217b77df012a4fd925dfddb49b189bef3', '2026-11-11 19:06:59.094907+00'),
	('durable-map/deployments/0010-tenants/1-column', '340593d1dcdcc545e83a711c2231f3366d3a598d7427accc83a84521d367f54c', '2026-11-11 19:06:59.097234+00'),
	('durable-map/deployments/0010-tenants/0-stamp-column', '59371c29d8377ff8ad47f03a8c23155d4facbb5bf3fc2757505d346fecbc2b6c', '2026-11-11 19:06:59.097234+00'),
	('durable-map/deployments/0010-tenants/2-keys', '6eca7b946aa5657832d6198c5c3c4f8d60c4258e16fed301d4681c133d4b04b7', '2026-11-11 19:06:59.109262+00'),
	('durable-map/deployments/0010-tenants/2-references', 'ab01aca3bbaf7bcc2b2b72ae29a5807403ebd574b07c26449ba157da0646f90d', '2026-11-11 19:06:59.110164+00'),
	('durable-map/deployments/0010-tenants/3-policy', '9ea7c03d0223a6b68ce9859567ae514b1da24c372f35c526c6a8744ae47ab382', '2026-11-11 19:06:59.115303+00'),
	('durable-map/deployments/0010-tenants/2-tenant-policy', '35c54d0b3fccb7e8f3c25ae3282e166c8540ac04382a6e03514cea89ddb05970', '2026-11-11 19:06:59.115303+00'),
	('durable-map/deployments/0020-claim-ids', '0d0726be6dcfbb31995b02f9888e8c372c8655af631fdd14ad5adacae310bd95', '2026-11-11 19:06:59.120187+00'),
	('durable-map/deployments/0020-name-index', '9ef9035f02d53d5cead3b5f0320c865efdbd63d931b38820de4bcbabf036233a', '2026-11-11 19:06:59.121193+00'),
	('durable-map/deployments/0021-claim-tenants', '713cda233c4c62124db10344d80510c8115a6511746abe84c7e6c2b957dba089', '2026-11-11 19:06:59.12327+00'),
	('durable-map/do_managed_agents_sandbox_bodies/0010-tenants/0-column', 'a8d7866d10321890c800bde0cf38c78dde989a46e39fa409b5d28a1c8013c25f', '2026-11-11 19:06:59.124394+00'),
	('durable-map/do_managed_agents_sandbox_bodies/0010-tenants/1-column', '43c9620b620a260b6e40e82f69d12195e2a446ac9d31733b4a6f1d70086c92a3', '2026-11-11 19:06:59.125871+00'),
	('durable-map/do_managed_agents_sandbox_bodies/0010-tenants/0-stamp-column', '2e9db4e0a3edf153b304dc1d2a6cd1bbd80caabb04aac96678fd9f2ccfec2a79', '2026-11-11 19:06:59.125871+00'),
	('durable-map/do_managed_agents_sandbox_bodies/0010-tenants/2-keys', 'c2aef6148f266e293a1b262967a2fff6c6336097a63d646d4016fc3e98e1cf4a', '2026-11-11 19:06:59.130318+00'),
	('durable-map/do_managed_agents_sandbox_bodies/0010-tenants/2-references', 'af2718878f116bb797f758f595ca5e2003821feb4724c6af5160e424c186a289', '2026-11-11 19:06:59.130901+00'),
	('durable-map/do_managed_agents_sandbox_bodies/0010-tenants/3-policy', '2192bfead0ffe29ba78824b1740eac1ec6d5f4844bac70f28c3a046ae505dc03', '2026-11-11 19:06:59.132363+00'),
	('durable-map/do_managed_agents_sandbox_bodies/0010-tenants/2-tenant-policy', '1828fe48a8d41ab80b00f2f14f5e35bdfe9ccaf41ad1a8053a84dd029330f6b1', '2026-11-11 19:06:59.132363+00'),
	('durable-map/do_managed_agents_sandbox_bodies/0020-claim-ids', 'fe798c3218284fcba19ab87d069456212275083a4f2895905c072bbbe408904a', '2026-11-11 19:06:59.134767+00'),
	('durable-map/do_managed_agents_sandbox_bodies/0021-claim-tenants', 'c3f458b3052a61d586b039e8c6165ae4e5aad914ba8ccd0e49c6e1816921dd88', '2026-11-11 19:06:59.135935+00'),
	('durable-map/durable_map_versions/0010-tenants/0-column', '166e4b448555bf192dd405716b23d1292a865eb3aa3997aca91226614e70c8d5', '2026-11-11 19:06:59.136912+00'),
	('durable-map/durable_map_versions/0010-tenants/1-column', 'ef449b091307ab1f308082286196c348ec7d3d4700241b2e3849f348b6f52707', '2026-11-11 19:06:59.138104+00'),
	('durable-map/durable_map_versions/0010-tenants/0-stamp-column', '19188fe0b31a36e064a7f88bf4b04e1e00cc631863e4833f8cab36f2cc328a17', '2026-11-11 19:06:59.138104+00'),
	('durable-map/durable_map_versions/0010-tenants/2-keys', '869d35c7a51809c25ee131c832d174d388b978d2fe99f834dbbf3350d9337694', '2026-11-11 19:06:59.1428+00'),
	('durable-map/durable_map_versions/0010-tenants/2-references', '9bac066e806cc2eb1698fecb1ce50906ca9f5bd189c221921d218787b34a2c85', '2026-11-11 19:06:59.143423+00'),
	('durable-map/durable_map_versions/0010-tenants/3-policy', '0dfa4e5e48d4dbd6830f277ca8b0eea01231c6aa8b0fcd63124a67296be9ab02', '2026-11-11 19:06:59.14532+00'),
	('durable-map/durable_map_versions/0010-tenants/2-tenant-policy', '43fd81f33b075778c60fd4430c8e45694a9ce09127ac9d1581017330b9763cc4', '2026-11-11 19:06:59.14532+00'),
	('durable-map/e2b_sandbox_bodies/0010-tenants/0-column', '6627170b93a60467ed94407dba9bc5aa134755be2c305a3dfca9033ef8d4808f', '2026-11-11 19:06:59.148535+00'),
	('durable-map/e2b_sandbox_bodies/0010-tenants/1-column', '280063c4bae16b12a699d6dc774fe7547179ff2b1c4793653e5ac8867ade442e', '2026-11-11 19:06:59.150269+00'),
	('durable-map/e2b_sandbox_bodies/0010-tenants/0-stamp-column', '1cdfe1b225adf285c5d062f4c3759d54c1696d59d8b65614b3489e16957966eb', '2026-11-11 19:06:59.150269+00'),
	('durable-map/e2b_sandbox_bodies/0010-tenants/2-keys', 'c8285688b7f01d8471944ee41ee7f0a523ab22c694028649932e37f85a692af6', '2026-11-11 19:06:59.155392+00'),
	('durable-map/e2b_sandbox_bodies/0010-tenants/2-references', '688bdf3ecbab5aadb6e5bc0e8bc36a57dcf62cf9b3f7233512e152c5560d6c7b', '2026-11-11 19:06:59.156061+00'),
	('durable-map/e2b_sandbox_bodies/0010-tenants/3-policy', '2f73ada6d67019e3152b277a0b3335e957ba4c746a1b3d432614433eed6f91af', '2026-11-11 19:06:59.157782+00'),
	('durable-map/e2b_sandbox_bodies/0010-tenants/2-tenant-policy', 'faae24f2b8ff6e402b5b4f7bd2c7a27992c06dc1de8189a66558ce4e67454da7', '2026-11-11 19:06:59.157782+00'),
	('durable-map/e2b_sandbox_bodies/0020-claim-ids', '9d76f444396660ee202c7da965f94afde55cdcd354afdd42103acd09577a3046', '2026-11-11 19:06:59.160246+00'),
	('durable-map/e2b_sandbox_bodies/0021-claim-tenants', '1f05990dc09bf4fe0c55c95d290fda9e525b3eb5c748f8b809900dd4ba6c5575', '2026-11-11 19:06:59.161443+00'),
	('durable-map/egress_policies/0010-tenants/0-column', '572ed6bd2669f7d6a63d42e164ad2cab7c5ba51d6f1e5ffa28a0f9495e1e780b', '2026-11-11 19:06:59.162778+00'),
	('durable-map/egress_policies/0010-tenants/1-column', '3af600ae6bf5f786c28d5bd919f3d091f9bf7531c1f19769498e28ab68794e9f', '2026-11-11 19:06:59.16428+00'),
	('durable-map/egress_policies/0010-tenants/0-stamp-column', 'f791730bd0ea809a0640fdb5fe9bc3ccc0fe26af36f717976e74a57d82eef567', '2026-11-11 19:06:59.16428+00'),
	('durable-map/egress_policies/0010-tenants/2-keys', '226f10c8d6e50234a744cf90d6d9721ffa4b56a8a6709fe8ee839b651d90adaa', '2026-11-11 19:06:59.169315+00'),
	('durable-map/egress_policies/0010-tenants/2-references', 'd843e0b3d20fab3e0d29aa47fcdd0e0ba718c0434eee2e8909c1a00738d134bf', '2026-11-11 19:06:59.17018+00'),
	('durable-map/egress_policies/0010-tenants/3-policy', 'bdcae0565905a3a47a07f5b5579f232055bd7b734f0a4bbd3d2911dd132dfe1b', '2026-11-11 19:06:59.172095+00'),
	('durable-map/egress_policies/0010-tenants/2-tenant-policy', '21ac15ee967b8215a7a802337d611d6b08eb253557d492912336e0a8d4aa18d3', '2026-11-11 19:06:59.172095+00'),
	('durable-map/egress_policies/0020-claim-ids', 'b4086d4bb59834c03d67506ca45215b25c03f5dcb4a8b0370edfb6af34a8c339', '2026-11-11 19:06:59.17448+00'),
	('durable-map/egress_policies/0021-claim-tenants', '8a8d7debdb72c39f87608ac5c9cba5e391c43b4361ef752df55a327a5e131eff', '2026-11-11 19:06:59.175577+00'),
	('durable-map/external_members/0010-tenants/0-column', '99a8348c9e696e713425a1cec8568eecd1390ccf6c505d9b2de74dc1d69d2c74', '2026-11-11 19:06:59.177024+00'),
	('durable-map/external_members/0010-tenants/1-column', '7cebc91a732a1ba420a736591cfb76cf4c118d59e7c9c71bde10fbf8b0bc0f1f', '2026-11-11 19:06:59.179064+00'),
	('durable-map/external_members/0010-tenants/0-stamp-column', '76ced0bd47f48157288be19054572ba480d1668ef1731467038145a6435da285', '2026-11-11 19:06:59.179064+00'),
	('durable-map/external_members/0010-tenants/2-keys', '776d502e6807bf9d9b0fb7acca8a6ab2ca40e2dfbc5083e0b788db6ab51a9405', '2026-11-11 19:06:59.183755+00'),
	('durable-map/external_members/0010-tenants/2-references', 'a55def95e2ae8008fd21f250baaec9e3d993ea3aafdab26579542a62a76152f1', '2026-11-11 19:06:59.184527+00'),
	('durable-map/external_members/0010-tenants/3-policy', 'ffc11ef1a7b04819e55ba1cdfa251f8ef34d3640cfbd85e29357db9448617940', '2026-11-11 19:06:59.186218+00'),
	('durable-map/external_members/0010-tenants/2-tenant-policy', 'e3f577c82e05dad8fe91fefd2dcba303905da24ccc06a802900c613369e31193', '2026-11-11 19:06:59.186218+00'),
	('durable-map/external_members/0020-claim-ids', 'a18746ef22089c36dab387abc6c99827d3b1aed40c100b58ed89dc82817f1b78', '2026-11-11 19:06:59.188705+00'),
	('durable-map/external_members/0021-claim-tenants', '163c2678a24642fb2b7370ac1903856a25d4bedf76897c87cd87e7b405c70e37', '2026-11-11 19:06:59.190095+00'),
	('durable-map/external_slack_participants_flag/0010-tenants/0-column', 'ca98d9b28bb75c71e1273bfc0e7c762ec6f44bef7fcf4098347d0aafbe001a0c', '2026-11-11 19:06:59.191587+00'),
	('durable-map/external_slack_participants_flag/0010-tenants/1-column', 'e4581c2b9291c1b2151097624e74b9582b633744fa33b5024e384d5b261b0355', '2026-11-11 19:06:59.193193+00'),
	('durable-map/external_slack_participants_flag/0010-tenants/0-stamp-column', 'a15fd8f966690aa2b33a5fe846dec4b812e62e3c7d3285c346867f41d12aeacf', '2026-11-11 19:06:59.193193+00'),
	('durable-map/external_slack_participants_flag/0010-tenants/2-keys', '6cbce59c90e9f8a764fa6ab40060b3cd753be876fb7a788944653e3ee7d78d12', '2026-11-11 19:06:59.199292+00'),
	('durable-map/external_slack_participants_flag/0010-tenants/2-references', '70b706ccfa0dfd87ac6efdbf48bc5e15dae18dd22333a234ad4373dd886b5d9a', '2026-11-11 19:06:59.200138+00'),
	('durable-map/external_slack_participants_flag/0010-tenants/3-policy', 'dedd110c245a5b02e2267728fd0a68080189e93dace856bba1dee0fc68f047bf', '2026-11-11 19:06:59.202077+00'),
	('durable-map/external_slack_participants_flag/0010-tenants/2-tenant-policy', '0db2a703da9f7546e0ea7086d0ca7c878fe37e3ac26dd7f8d4bab73168b9ee64', '2026-11-11 19:06:59.202077+00'),
	('durable-map/external_slack_participants_flag/0020-claim-ids', '661d9046807a66f66ee218d9dc41e8c21ef964bd2f98a9b1730732138c1780a7', '2026-11-11 19:06:59.204939+00'),
	('durable-map/external_slack_participants_flag/0021-claim-tenants', '3b9b7a539a74894a607e6fb8f4c77693458d2fc66023798fe7b8b13c634e1080', '2026-11-11 19:06:59.206218+00'),
	('durable-map/feature_flags/0010-tenants/0-column', '7c87e1a2a844395498566c044d589396792d018d677c2412c34c4020273aad61', '2026-11-11 19:06:59.207411+00'),
	('durable-map/feature_flags/0010-tenants/1-column', '72f3dbc47f5ef06589a45fc4d0cae6c41df4a9b5be22a87a189ad61edc0bbef0', '2026-11-11 19:06:59.209205+00'),
	('durable-map/feature_flags/0010-tenants/0-stamp-column', 'ad29d3fb50c5b632875cb9df790ded722073bd14ba49cf2b5cfa5181fd28f83a', '2026-11-11 19:06:59.209205+00'),
	('durable-map/feature_flags/0010-tenants/2-keys', '7694a9f3ad1b49212c92fe340dee34fb458579c9ede38b94a4f211e9dc4cd6d0', '2026-11-11 19:06:59.213695+00'),
	('durable-map/feature_flags/0010-tenants/2-references', '71a12202057eb79e90dd4311a5cded2cbf3aedbdf2b97d9f66b1ea9aad09ffdd', '2026-11-11 19:06:59.214641+00'),
	('durable-map/feature_flags/0010-tenants/3-policy', '1c1ef2cd0af32b11fa5293e215a197b574e57aa90656d12566e8642641c4ad2e', '2026-11-11 19:06:59.216412+00'),
	('durable-map/feature_flags/0010-tenants/2-tenant-policy', '270dc605b78440eeba314593368f4399a9dbf2875f2572889a5df013a89bf37c', '2026-11-11 19:06:59.216412+00'),
	('durable-map/feature_flags/0020-claim-ids', 'e107bc6efc973875da2fa2e0455d32f77900762415ef225ee696714e3183a5c3', '2026-11-11 19:06:59.219823+00'),
	('durable-map/feature_flags/0021-claim-tenants', '29e680ad8ea7abeeaed298b53c5aefa4bbc6814c38e92dfb3d9f6397c271321c', '2026-11-11 19:06:59.221017+00'),
	('durable-map/fly_deploy_configs/0001', 'f6699096d3377c79be5ae0c38db9a87791c4dc0c0aa9a9baaa1a6cbaba783d7e', '2026-11-11 19:06:59.222407+00'),
	('durable-map/fly_deploy_configs/0010-tenants/0-column', '4642a70fa5a4d31c2e6f2a522a482d37bc9c3d809b96161e1feda311f9912bf1', '2026-11-11 19:06:59.227453+00'),
	('durable-map/fly_deploy_configs/0010-tenants/1-column', '65e03cd2ce1a8847ef0052a89aebadb09f6cc976c441119c0910c269fc301f6d', '2026-11-11 19:06:59.229088+00'),
	('durable-map/fly_deploy_configs/0010-tenants/0-stamp-column', 'fc525f7fa263df282e380b1c6594fdbd18813b3977b51c259012ea7274717d04', '2026-11-11 19:06:59.229088+00'),
	('durable-map/fly_deploy_configs/0010-tenants/2-keys', 'a1d03c0f5059f7358260cf786ab9de48dc26a1a4dfc3a2d4d0defa3e8abd131e', '2026-11-11 19:06:59.235005+00'),
	('durable-map/fly_deploy_configs/0010-tenants/2-references', '2f1f29a94628f52b34f7bdfb7ef8aa461f8cc9c35f4a992d4ad2c45ef9ac8ecf', '2026-11-11 19:06:59.235875+00'),
	('durable-map/fly_deploy_configs/0010-tenants/3-policy', '89eb4cc06ca6fe5db7d4397b114ce6de77d6f61a458c986961353e64e4efb3ba', '2026-11-11 19:06:59.237976+00'),
	('durable-map/fly_deploy_configs/0010-tenants/2-tenant-policy', '3da123fb3ec8d3be3d6475c1ff82e2d7b15fd3adaa63949b24bcf8cc02e12c94', '2026-11-11 19:06:59.237976+00'),
	('durable-map/fly_deploy_configs/0020-claim-ids', '1c134e7f03453a5062e4b409a28fcc2622253cac1ba07a1fa873ca53acc7318b', '2026-11-11 19:06:59.241707+00'),
	('durable-map/fly_deploy_configs/0021-claim-tenants', '596a1489ad7f227ed4f8d7bfd8f98176d153b5181981d45773497664f40bf98e', '2026-11-11 19:06:59.243551+00'),
	('durable-map/fly_deploy_ports/0001', '3f182c0cb8b1de816666fe1721abc072c6df77770ee382887f2456e7a9542bf6', '2026-11-11 19:06:59.244634+00'),
	('durable-map/fly_deploy_ports/0030-process-level', '148000a365850d9b51f0d145b620c6554892acd41f3dd9e348fee9bbf2cd87ed', '2026-11-11 19:06:59.250114+00'),
	('durable-map/fly_peer_claims/0001', '3ee15b6e7069fbc0c977232eca1b3ce161eca06a50970f17d52d456134b6ecf8', '2026-11-11 19:06:59.251735+00'),
	('durable-map/fly_peer_claims/0030-process-level', '7af8c2b41d719d7430ab6a6bc625223fd4610eb87abfee217323971321c176ef', '2026-11-11 19:06:59.25745+00'),
	('durable-map/idempotency/0010-tenants/0-column', 'c6fd6aaa80189ab8d93b8e5bf2fc346185a832796c8139449a762abec994962e', '2026-11-11 19:06:59.259293+00'),
	('durable-map/idempotency/0010-tenants/1-column', '03a9c7d5d430d0ce97d8d8d0dd92b26c46dc2866eb98837bbfd72134f4ffa9bd', '2026-11-11 19:06:59.261152+00'),
	('durable-map/idempotency/0010-tenants/0-stamp-column', '46a4b0275e0ffa9a5b4767b6632a7710f1b100094edd6b92387f0d8b14f97860', '2026-11-11 19:06:59.261152+00'),
	('durable-map/idempotency/0010-tenants/2-keys', '32b7ab599b12e9f9a6e537a36e4cfe17a594ebb8f83ad30ee777839070143970', '2026-11-11 19:06:59.266724+00'),
	('durable-map/idempotency/0010-tenants/2-references', '3aa02710373da1e1df63acffb258a5a104cb538065424c7e3c3c44666791e85c', '2026-11-11 19:06:59.267443+00'),
	('durable-map/idempotency/0010-tenants/3-policy', '8fa61780a50d5c09779c9c3527a131fd08d247deb7fdfc0a2d95d6feec19b950', '2026-11-11 19:06:59.268936+00'),
	('durable-map/idempotency/0010-tenants/2-tenant-policy', 'bd46faa8ef03cdd9f6fe6dacd6010e6bd3c3756f1bdc67b394d9a16c630a5594', '2026-11-11 19:06:59.268936+00'),
	('durable-map/idempotency/0020-claim-ids', 'f4cd0ba693059ae03584a1157858203b239ad9a760868ee08dcf6219464d941d', '2026-11-11 19:06:59.271604+00'),
	('durable-map/idempotency/0021-claim-tenants', 'c7898a1488bf48d92bf23107e426654cba7e685c39c3360851c8976bc2839e42', '2026-11-11 19:06:59.273059+00'),
	('durable-map/individual_model_auth_flag/0010-tenants/0-column', 'e941be6d1d270aec2d0d05f621754f92c3b9a26eaa1275cbc28c14c9ddf55cf9', '2026-11-11 19:06:59.274209+00'),
	('durable-map/individual_model_auth_flag/0010-tenants/1-column', 'd8ef8af391f6bdf2b80d051ec9152a06af67277655686d9b597aac88ba92c083', '2026-11-11 19:06:59.275878+00'),
	('durable-map/individual_model_auth_flag/0010-tenants/0-stamp-column', '0febc0fed7058f2cf9f56c59284a79824acbf3160dff824cc2e64d108cbb6631', '2026-11-11 19:06:59.275878+00'),
	('durable-map/individual_model_auth_flag/0010-tenants/2-keys', '78211f7282adf77d8db30dede35b4223ff7ec61b6f5b364e6c07eaa6a9156410', '2026-11-11 19:06:59.280844+00'),
	('durable-map/individual_model_auth_flag/0010-tenants/2-references', '05447cd2fb832c374a33ae55be57b8fa6041d6021d7bf0064f202e5e512129da', '2026-11-11 19:06:59.281596+00'),
	('durable-map/individual_model_auth_flag/0010-tenants/3-policy', '88b5ed9b43a5cafcffd1a99a76a8d7f8d76925b625030493e118e962c1406a8f', '2026-11-11 19:06:59.283434+00'),
	('durable-map/individual_model_auth_flag/0010-tenants/2-tenant-policy', 'c7e681ea15299410a30d1febad919339ab4d69b4f5dfc230ec86230c5addb123', '2026-11-11 19:06:59.283434+00'),
	('durable-map/individual_model_auth_flag/0020-claim-ids', 'd5895938fe116d54a6f5c45c6d44798f38ea6abedbab0742186e166a2be6a95f', '2026-11-11 19:06:59.286099+00'),
	('durable-map/individual_model_auth_flag/0021-claim-tenants', '793413ffff65adf72bfd5262815598bb13357a48c56b445f2a52e417860144a9', '2026-11-11 19:06:59.287117+00'),
	('durable-map/interactive_fast_mode_flag/0010-tenants/0-column', '36e12e857a6bf651ff06b4c24b23f60c124f0c9a1a267c2aee577f981687c191', '2026-11-11 19:06:59.288021+00'),
	('durable-map/interactive_fast_mode_flag/0010-tenants/1-column', '8a96b2b23f4b4b113c3f449a127324063b79d38450cc0f58b67866f69f256f92', '2026-11-11 19:06:59.289399+00'),
	('durable-map/interactive_fast_mode_flag/0010-tenants/0-stamp-column', '06414e23650e3a4803e6771e49bb9866bff70b65d012e331414b54031d132663', '2026-11-11 19:06:59.289399+00'),
	('durable-map/interactive_fast_mode_flag/0010-tenants/2-keys', '87b83f2e74b96d93366db04ad5ffec78d8e5e8c1d35bccb9f2788cc4ebc1dac3', '2026-11-11 19:06:59.293983+00'),
	('durable-map/interactive_fast_mode_flag/0010-tenants/2-references', '1dcd8c85bc05637284d54a77d65cfd0343e3b85e3e3130bd67ee0a50d12c40aa', '2026-11-11 19:06:59.294587+00'),
	('durable-map/interactive_fast_mode_flag/0010-tenants/3-policy', 'e6335438baac158f4df22b0ebcf904ae300dcdfdc45e14bac937584022c895e5', '2026-11-11 19:06:59.296373+00'),
	('durable-map/interactive_fast_mode_flag/0010-tenants/2-tenant-policy', 'f4fa6e526ba5862adbe54f5e25d50c57d083aaf9b12340aa98fb2220e6c55290', '2026-11-11 19:06:59.296373+00'),
	('durable-map/interactive_fast_mode_flag/0020-claim-ids', 'a7f8edc9a085e3e40f15e0a5d4ec72a78e2017d06051d161d09093034a929898', '2026-11-11 19:06:59.298883+00'),
	('durable-map/interactive_fast_mode_flag/0021-claim-tenants', '1acf91b02a36fac526604165fbb5412ab72713875041aab02b055730ef33e76a', '2026-11-11 19:06:59.299982+00'),
	('durable-map/keychain_asks/0010-tenants/0-column', 'f9747ad3177a59caab78ebece4ac6d5329273120eca9450c10f9828c18b09fca', '2026-11-11 19:06:59.30107+00'),
	('durable-map/keychain_asks/0010-tenants/1-column', '3c6283f99a3aff647a7b1e8061536b6ca9ad40246570dd3fdda0cec25b59db5f', '2026-11-11 19:06:59.302553+00'),
	('durable-map/keychain_asks/0010-tenants/0-stamp-column', '0b2702e01d62b569ba5aa5abaeb7ce9ff9af27a24e1e2103e6a4dfeb1352ee94', '2026-11-11 19:06:59.302553+00'),
	('durable-map/keychain_asks/0010-tenants/2-keys', '54028f2c988663b33b69c3b3c89d5f79943689bca7ecd84cfdf1bbbf7a97506e', '2026-11-11 19:06:59.308332+00'),
	('durable-map/keychain_asks/0010-tenants/2-references', '3b68878dc6d7bc1373ee740027d134bd9f7e65d532e827ce375c5adf545eb00c', '2026-11-11 19:06:59.308916+00'),
	('durable-map/keychain_asks/0010-tenants/3-policy', 'f05dff4176385a29c6ffa38e2f88a035f0b35e032750483edef4a06e02dd73d2', '2026-11-11 19:06:59.310687+00'),
	('durable-map/keychain_asks/0010-tenants/2-tenant-policy', '200c5b5e79c205c27c0fd3af6e64913c0b5f0084fbf0f37908702e970b0e1737', '2026-11-11 19:06:59.310687+00'),
	('durable-map/keychain_asks/0020-claim-ids', '4c089b6c12e89635b7d353a3c4cd13cf37196462366d13f4fd511b9c2d4a2a42', '2026-11-11 19:06:59.313023+00'),
	('durable-map/keychain_asks/0021-claim-tenants', '9b10f0aa55ddea5741c6d419f6884f0c782c84d29fb1b2a67ca5cb83293950f2', '2026-11-11 19:06:59.313994+00'),
	('durable-map/keychain_credentials/0010-tenants/0-column', '2750e6de713c9bb8c361b894573e88c3d0e0d0ad52eb23f26b4cc2dc24954feb', '2026-11-11 19:06:59.315234+00'),
	('durable-map/keychain_credentials/0010-tenants/1-column', '1e22c68a07e4a4a784c812dae25f2b81257b4f7ff222c68d60b1f65caa4781b7', '2026-11-11 19:06:59.316979+00'),
	('durable-map/keychain_credentials/0010-tenants/0-stamp-column', '06a3e84f478b68414965f8e45c9edfbaec767fc04a83fdea188e32a47a678662', '2026-11-11 19:06:59.316979+00'),
	('durable-map/keychain_credentials/0010-tenants/2-keys', '63e86bbb18a4789409be0c77a52e4893f9d7dbb6a79c87e4a922db86851af628', '2026-11-11 19:06:59.322162+00'),
	('durable-map/keychain_credentials/0010-tenants/2-references', 'a56a60d958a1abad662e11a48f5eaceba660480ed49df5242cc6d3aa6426c30a', '2026-11-11 19:06:59.322872+00'),
	('durable-map/keychain_credentials/0010-tenants/3-policy', 'a8fb75a721873091d028ca81181def19d2c0b5c76eab5e0aca4bf1e4e04dd354', '2026-11-11 19:06:59.324775+00'),
	('durable-map/keychain_credentials/0010-tenants/2-tenant-policy', 'f3ac76964da82b29736fb56dfd05bf9a85a3bd4553493b142d46a9e1a3047d31', '2026-11-11 19:06:59.324775+00'),
	('durable-map/keychain_credentials/0020-claim-ids', '2a69a134c9370fd37f6cc2d39251fe2c7465ed9dad4f77068a185bc2ad664bba', '2026-11-11 19:06:59.328048+00'),
	('durable-map/keychain_credentials/0021-claim-tenants', '5b4f6469518c27dfa61d84404b99745730b81b2bf62654bef96b5805d7d7e3e6', '2026-11-11 19:06:59.329263+00'),
	('durable-map/keychain_credentials/claim-ownerid', 'd27dbd443b99a2a6461ad63d27ca6e760a72bccab665f424a338e6fa9d1ed81d', '2026-11-11 19:06:59.330204+00'),
	('durable-map/keychain_credentials/claim-tenants-ownerid', '9b2574d3d31dabf63ed03852a9ae3ded3e5b333935ec10a1e3819243ab5d910e', '2026-11-11 19:06:59.331081+00'),
	('durable-map/keychain_grants/0010-tenants/0-column', '7353a32bb82f8e82ababec35c72e48d8f03804e6ebb53073ff19f995ff57b5f4', '2026-11-11 19:06:59.332672+00'),
	('durable-map/keychain_grants/0010-tenants/1-column', '4d663aac942dfa7e8877dea2b1b8c1494a09984903669aded659d7a27dec4380', '2026-11-11 19:06:59.334388+00'),
	('durable-map/keychain_grants/0010-tenants/0-stamp-column', 'c5e7d9c8715d71f0b085fdb0eedb3a6e06f1dc9469502e2d3f8c525de6dcbe28', '2026-11-11 19:06:59.334388+00'),
	('durable-map/keychain_grants/0010-tenants/2-keys', '363aac52f5e94abc6f466c478df3cda3a573416449528d1e4be79bb7e38ea29a', '2026-11-11 19:06:59.339652+00'),
	('durable-map/keychain_grants/0010-tenants/2-references', 'fb5fd44e8120dac6011d4bff1e0a09ad09410f3c6c8c594bcdba8dc2b7bd4579', '2026-11-11 19:06:59.340471+00'),
	('durable-map/keychain_grants/0010-tenants/3-policy', '5bcda960113ba7718cc84ee86b2191551eeb6abf8ef2a550ee86381205837093', '2026-11-11 19:06:59.342517+00'),
	('durable-map/keychain_grants/0010-tenants/2-tenant-policy', '99d0087b07313c4a9286ce0b6feb4efc00a1107a04bbedd751e9c077ae160f51', '2026-11-11 19:06:59.342517+00'),
	('durable-map/keychain_grants/0020-claim-ids', '5610b7617dbda1e54134661440f8279d0220b7597d7cc49c55ae2554b6b44b83', '2026-11-11 19:06:59.345664+00'),
	('durable-map/keychain_grants/0021-claim-tenants', 'f263610dc3f9b76c143d5be62778f571f08210f97cfddc86a28865ba658ef8e7', '2026-11-11 19:06:59.346978+00'),
	('durable-map/keychain_grants/claim-ownerid', '414f3e6b854d36b2f77f605f80e4f7cfdc02622e3536951b4dd07f51683ce411', '2026-11-11 19:06:59.348096+00'),
	('durable-map/keychain_grants/claim-tenants-ownerid', '8976d3df25b7fd6b5134af23b6b1d820ee0a25e276ffffd1ed459632c2ec4247', '2026-11-11 19:06:59.349169+00'),
	('durable-map/loop_ingress_deliveries/0010-tenants/0-column', '373aef79c0d1602c1e3ad6da51737b7db2e021103b6e81af5b229d3bd8401856', '2026-11-11 19:06:59.35114+00'),
	('durable-map/loop_ingress_deliveries/0010-tenants/1-column', '0b358b985c9284c93b0398385f4573cd3c7149608a4d75446b104be527135f14', '2026-11-11 19:06:59.353024+00'),
	('durable-map/loop_ingress_deliveries/0010-tenants/0-stamp-column', '268659675d0525305ce1a6a5e348b1022a48ac40adf44c3b778aaccb666ad8c9', '2026-11-11 19:06:59.353024+00'),
	('durable-map/loop_ingress_deliveries/0010-tenants/2-keys', 'aa4c52ceae5a5b40c29bf59f497541b9e974a45a7c6827b26f9b976a5621ccbd', '2026-11-11 19:06:59.358401+00'),
	('durable-map/loop_ingress_deliveries/0010-tenants/2-references', 'fbfb724818554d02ea379052b714c7a19dbe00edb3c8f932d85cd1aac2168038', '2026-11-11 19:06:59.359141+00'),
	('durable-map/loop_ingress_deliveries/0010-tenants/3-policy', 'f9f444b6ae5411c5f45efdea6d7b5d83135ea441da8812bd8ea9f596cc4cd0bb', '2026-11-11 19:06:59.361544+00'),
	('durable-map/loop_ingress_deliveries/0010-tenants/2-tenant-policy', 'e02e7d8206afc164a60a3397ea35f90fcc27658a73a9f6ed08aa2d0639c6739c', '2026-11-11 19:06:59.361544+00'),
	('durable-map/loop_ingress_deliveries/0020-claim-ids', '07ecf2facf766e6e676c74371c843d4774a178f9504c3a3592d4cb1a5c1e7fc3', '2026-11-11 19:06:59.364399+00'),
	('durable-map/loop_ingress_deliveries/0021-claim-tenants', '84022089e11a89f8e24d073f66b20d59300b6017e49e0e04d9c7b7df2a62c903', '2026-11-11 19:06:59.365315+00'),
	('durable-map/loop_ingress_deliveries/claim-queuekey', 'ab6dfe11e4c532bba537b302c68f63b0fcb319bca70a69969f10edb8c86b0b4b', '2026-11-11 19:06:59.366208+00'),
	('durable-map/loop_ingress_deliveries/claim-tenants-queuekey', 'dcbb9d23fff25862b6bf5135441d9214bf8634e87909aaafe37c95dcdaccb0b8', '2026-11-11 19:06:59.367057+00'),
	('durable-map/loop_ingress/0010-tenants/0-column', '5f73564f37638b10e8a427a3b396a221e6b02a73d0621d7f04298b3d7d5d5903', '2026-11-11 19:06:59.368409+00'),
	('durable-map/loop_ingress/0010-tenants/1-column', '1b31c824aecf32b132247ef67ebe0c3f84693e5c194cb779c343ebd0c2d9f5c3', '2026-11-11 19:06:59.370238+00'),
	('durable-map/loop_ingress/0010-tenants/0-stamp-column', 'be705848d74931afb8fb2228835c1b9cf3033620b1896e54542c62f27b55b280', '2026-11-11 19:06:59.370238+00'),
	('durable-map/loop_ingress/0010-tenants/2-keys', '7b266f906ed902f3e6a1f228f5180a8c4966b5481048629a2cff36b268db82c9', '2026-11-11 19:06:59.374933+00'),
	('durable-map/loop_ingress/0010-tenants/2-references', '2977df7a5e18a378b81bf1e125f01c9f5e5890923a1f2abc8d8389baf57210ba', '2026-11-11 19:06:59.375619+00'),
	('durable-map/loop_ingress/0010-tenants/3-policy', '668e186ea808b0685237f0aa1ba280074ddc737309246f2809f20716a48738ef', '2026-11-11 19:06:59.37774+00'),
	('durable-map/loop_ingress/0010-tenants/2-tenant-policy', '2d3d52d525ab558925dbf0eb5885647fc740c00f45615649d2a19a668f15d787', '2026-11-11 19:06:59.37774+00'),
	('durable-map/loop_ingress/0020-claim-ids', 'c66425d97d9469a785999cf18ee60b5f26990d650e76ee1de8fc826210ca4c6f', '2026-11-11 19:06:59.381384+00'),
	('durable-map/loop_ingress/0021-claim-tenants', 'd1e21fa31233ee95d11af461dc730590400ce813360e467f7d2effc3f09e03e1', '2026-11-11 19:06:59.382587+00'),
	('durable-map/loop_ingress/claim-loopid', '9a78421833d6b52e27979ef9ea3e6f189fbe78825ff313eeadb5f309ab4e1ac8', '2026-11-11 19:06:59.383449+00'),
	('durable-map/loop_ingress/claim-tenants-loopid', 'ffcc05b7665e3acdf7633be918626480b331c01d411f434c98b81201f7e05613', '2026-11-11 19:06:59.384429+00'),
	('durable-map/loop_items/0010-tenants/0-column', '636b77fddf414636c19ae4bf238155fe2f7ac47f4124a42c0a0034485911abd2', '2026-11-11 19:06:59.386384+00'),
	('durable-map/loop_items/0010-tenants/1-column', '3d7f9cb9a206326c825d522baef5f7427fbd78ebda17d1bd2c6a3c7f4e01d3e2', '2026-11-11 19:06:59.388097+00'),
	('durable-map/loop_items/0010-tenants/0-stamp-column', '74b6324efd63948bc0762d4b83c2300f215bf6ea73bbe4ab2c2c6e2590ec2280', '2026-11-11 19:06:59.388097+00'),
	('durable-map/loop_items/0010-tenants/2-keys', '60fa4cf2f7d8f1a92654b5e3eca00ef5145bd9f47b0dc5d9f73b61a1fd51de41', '2026-11-11 19:06:59.392662+00'),
	('durable-map/loop_items/0010-tenants/2-references', 'f38107ad41571e57fd2a99be5fec34c09e1260303e23a3fe00302222dea25bd3', '2026-11-11 19:06:59.393393+00'),
	('durable-map/loop_items/0010-tenants/3-policy', 'c3be172590b4add04e93acd92692ac3b64e9a37b806e24f6146fffc7a8e52427', '2026-11-11 19:06:59.395592+00'),
	('durable-map/loop_items/0010-tenants/2-tenant-policy', 'a20d75adce0d361d3eadbdf6d422efec964ef55ba46af9acb34f1f1999732f98', '2026-11-11 19:06:59.395592+00'),
	('durable-map/loop_items/0020-claim-ids', '114b64ea220a78d19b865f22702e8615f60110947a708793caa6d9fe021bf2ed', '2026-11-11 19:06:59.398433+00'),
	('durable-map/loop_items/0021-claim-tenants', '06b3c015500e415051f40de4ee5b457a4fb2f85e0694ad036042c41cdd040aef', '2026-11-11 19:06:59.399555+00'),
	('durable-map/loop_items/claim-loopid', '3e306c1ec930abc85156fa05998698415063231c610f6df798031e46d36a0455', '2026-11-11 19:06:59.400492+00'),
	('durable-map/loop_items/claim-tenants-loopid', 'b092213371056acb643d7fed533ad94e47c8cd38d855b362412cd89ac70c52d3', '2026-11-11 19:06:59.401603+00'),
	('durable-map/loop_outputs/0010-tenants/0-column', 'f96d09a020797f275965a056cdd54a2b55763083db57a4ac518fd7c5053815c5', '2026-11-11 19:06:59.403658+00'),
	('durable-map/loop_outputs/0010-tenants/1-column', '85ddbefa97692674a040379ad79fc08602ea9596eca553010d3a716243eb2ffc', '2026-11-11 19:06:59.405153+00'),
	('durable-map/loop_outputs/0010-tenants/0-stamp-column', '68b99216601b74aaac13e7aa2147acacc68f837d050450aced46e8a417c4bfbd', '2026-11-11 19:06:59.405153+00'),
	('durable-map/loop_outputs/0010-tenants/2-keys', '1cb389d67307b601f767aca41f5ec6be1e4c9a34b19c6b9eafd6928e1474f4b8', '2026-11-11 19:06:59.409533+00'),
	('durable-map/loop_outputs/0010-tenants/2-references', '511ff12c7059ad16db5418123aada5e923bb21d403de7dff49a118b96a4332b9', '2026-11-11 19:06:59.41023+00'),
	('durable-map/loop_outputs/0010-tenants/3-policy', 'b4e4a88a5e0099bf2e17ed89af77a749077743960aec4410525d729ffe4994b7', '2026-11-11 19:06:59.411906+00'),
	('durable-map/loop_outputs/0010-tenants/2-tenant-policy', '5e0c5c5e18efc51dba23e417ae1f24dc4f1689e60b02f4b41b2b09afa5df1467', '2026-11-11 19:06:59.411906+00'),
	('durable-map/loop_outputs/0020-claim-ids', 'f523b9b57899f839ae6b4592f9d92f1d021c99dd7775b90236a7c4c8c68db11e', '2026-11-11 19:06:59.415214+00'),
	('durable-map/loop_outputs/0021-claim-tenants', '975627150cc421b75a2f0cdd7611526be2c6ad57c4d492769ef0fb9f28c679b0', '2026-11-11 19:06:59.416425+00'),
	('durable-map/loop_outputs/claim-itemid', '7cb959682c16dcf8ae913781492e5e38908ae371c55652a270aa8d525cbb90fb', '2026-11-11 19:06:59.417726+00'),
	('durable-map/loop_outputs/claim-tenants-itemid', '87054226955776216affdf25105fdc8a203cedc7d5ca3f1edaba0cce1ee6cb6c', '2026-11-11 19:06:59.418985+00'),
	('durable-map/loop_ship_grants/0010-tenants/0-column', 'e410c6a2dab2ba7a49c411058fe04fd76ff2de4bdd3ac92b345b03904451555b', '2026-11-11 19:06:59.42091+00'),
	('durable-map/loop_ship_grants/0010-tenants/1-column', 'd917294ef4080c19e7db9a7961cb8d8a47343fd1753ac049812ed0e823e97652', '2026-11-11 19:06:59.422266+00'),
	('durable-map/loop_ship_grants/0010-tenants/0-stamp-column', 'ec11353af881b8aa4ee7db91230bbedf0847e3486e3696fb8017dc97aad85333', '2026-11-11 19:06:59.422266+00'),
	('durable-map/loop_ship_grants/0010-tenants/2-keys', 'a9c98cdfbe6170c4e5b0f5c589c189b1677ed73c418084f8b08b20020d207c41', '2026-11-11 19:06:59.426666+00'),
	('durable-map/loop_ship_grants/0010-tenants/2-references', '2273e910c8c998518c908ed3f705b795a041874744bfb7a8d6400c7b28a5a41d', '2026-11-11 19:06:59.427189+00'),
	('durable-map/loop_ship_grants/0010-tenants/3-policy', '5e8720e650cda5a612f5dbd44d95c96565ca2bcfaf5ace9768d17b66fc9eefb7', '2026-11-11 19:06:59.428657+00'),
	('durable-map/loop_ship_grants/0010-tenants/2-tenant-policy', '674d33acdb98cc61de54bb47f16d549dc82ddda8e4d4c65f7ec2b5a362068069', '2026-11-11 19:06:59.428657+00'),
	('durable-map/loop_ship_grants/0020-claim-ids', 'e2aa42a20845a221da45c99b3180b1152bd179dfa6fedc503a5c224cb161b97b', '2026-11-11 19:06:59.431637+00'),
	('durable-map/loop_ship_grants/0021-claim-tenants', '86e31f5e79436934cc530d2b038d50b8ea71ec9dd32e527f93c1b39e55c65786', '2026-11-11 19:06:59.432899+00'),
	('durable-map/loops/0010-tenants/0-column', '8fc2020c0c951ef628a287e05551cd33b9e30d5f4e1ab3740dbf74488cf34213', '2026-11-11 19:06:59.434313+00'),
	('durable-map/loops/0010-tenants/1-column', '6e9906709437537d3ef772a6319694a7961740a866b1fd04f77d0e49841877e2', '2026-11-11 19:06:59.435664+00'),
	('durable-map/loops/0010-tenants/0-stamp-column', '7833b0eff8f64a94adc1b53a63921dfab980bd02c5c19a07111a5210211199be', '2026-11-11 19:06:59.435664+00'),
	('durable-map/loops/0010-tenants/2-keys', 'f798cfeac6d7ab57ef53afd8908dd94efd1cc1fb1d3b35b4702237bf814e28a2', '2026-11-11 19:06:59.440784+00'),
	('durable-map/loops/0010-tenants/2-references', 'd9fcfad87e451928a0e3eaab4fdb69e8a0db30b91248365fe2b7904b96ba0d28', '2026-11-11 19:06:59.441342+00'),
	('durable-map/loops/0010-tenants/3-policy', '534a29d94e24ee1c15baa9f24168b44931e4f4b1ff19c5e076f6d10af312037d', '2026-11-11 19:06:59.443271+00'),
	('durable-map/loops/0010-tenants/2-tenant-policy', '571f2a3cae57af20f28734d116a16bae34fcac336f9a267723a96808e2d40927', '2026-11-11 19:06:59.443271+00'),
	('durable-map/loops/0020-claim-ids', '978ebbbd69f150f8bb903ded6451fd1daa92ec5cf30a2d3bf14b83c3700ef727', '2026-11-11 19:06:59.446167+00'),
	('durable-map/loops/0021-claim-tenants', 'a015a33cd03867df66f03dbad36e39d08229f95bdcbee42d30ab0d3a979412a0', '2026-11-11 19:06:59.447699+00'),
	('durable-map/mcp_servers/0010-tenants/0-column', 'e16b0a73241a9f2272ce2c5754b6460063caf50b682b3b1b6b4be4d090651b0b', '2026-11-11 19:06:59.449554+00'),
	('durable-map/mcp_servers/0010-tenants/1-column', 'f8326ff7f8e8fe0b57affad5e6d8b3d330b8f80c320055884eb02d77710cbeba', '2026-11-11 19:06:59.45138+00'),
	('durable-map/mcp_servers/0010-tenants/0-stamp-column', 'c319674473e3c4f1a8957465c29bf28eadb387aba51efbca4b06b526bda88c97', '2026-11-11 19:06:59.45138+00'),
	('durable-map/mcp_servers/0010-tenants/2-keys', 'd0c31606854e16562b5b3a1f9454dca4f97944e1615d049f670a06d28a12666d', '2026-11-11 19:06:59.456389+00'),
	('durable-map/mcp_servers/0010-tenants/2-references', '500b392d3d20f0e86071fcfe52f64468a7f31b73ebda67f9a52807661d39020f', '2026-11-11 19:06:59.45708+00'),
	('durable-map/mcp_servers/0010-tenants/3-policy', '6af8fa2bc4d679bdafbb73ac080ecd1ec01d2eac84d89ec4d56f0826ef1b88f3', '2026-11-11 19:06:59.459074+00'),
	('durable-map/mcp_servers/0010-tenants/2-tenant-policy', 'f0fd0031e60e3542e31e98ab10d127f7115df1f5aaa79bfb7367096fa321eac7', '2026-11-11 19:06:59.459074+00'),
	('durable-map/mcp_servers/0020-claim-ids', 'b13eba5bf23860a64358194dd340701cc4d1a53921a8ee2e55e595a241eb2d37', '2026-11-11 19:06:59.461716+00'),
	('durable-map/mcp_servers/0021-claim-tenants', '90debeff24886eeba7861f22ab8e781b95f143c8b8c98c7244caa2c82e7ef68b', '2026-11-11 19:06:59.462987+00'),
	('durable-map/memory_registry/0001', '0ad0bce1417cfc0bda6ac3d35f1ea5052954611f4cb4a77713d530c9468ed54c', '2026-11-11 19:06:59.46399+00'),
	('durable-map/memory_registry/0010-tenants/0-column', 'ff7a611d4a378c86a72d4ded2e142058c63ba2afa65528ca49cac76cdf877b01', '2026-11-11 19:06:59.467887+00'),
	('durable-map/memory_registry/0010-tenants/1-column', '0981acfd4785d8c5ea3ce054d50e0ad77d976999313b22434e76f60b12ef2d6d', '2026-11-11 19:06:59.469359+00'),
	('durable-map/memory_registry/0010-tenants/0-stamp-column', '3d856c2313b8f78ec9fb33e302a88cb3e1872c9ac62917dcb304bf50b687cfc7', '2026-11-11 19:06:59.469359+00'),
	('durable-map/memory_registry/0010-tenants/2-keys', '2c8b51a86aa553e2d237caa83728fb972a9e302cfdd787e88836a926bbb9dd14', '2026-11-11 19:06:59.473445+00'),
	('durable-map/memory_registry/0010-tenants/2-references', 'ac3d465024328dba8d6ef759d0a63d8dddfe0a909d4dccc9f2010aff270d8640', '2026-11-11 19:06:59.473994+00'),
	('durable-map/memory_registry/0010-tenants/3-policy', 'a6dddb4b40902b540beb301beb72e44d4d95cff1002c8eafafd39f6e92c14835', '2026-11-11 19:06:59.475779+00'),
	('durable-map/memory_registry/0010-tenants/2-tenant-policy', '04555a5cc4ca7bc0f23ebaf80f73d010237e6bfefed2834b1e0fabf28ebb2f44', '2026-11-11 19:06:59.475779+00'),
	('durable-map/memory_registry/0020-claim-ids', '454ea7372bf7853ef69770c24428eab91cfbbc4314ae86cd9f7fc67ad3571b8a', '2026-11-11 19:06:59.478456+00'),
	('durable-map/memory_registry/0021-claim-tenants', '9f37434417bb73989fdb9097e735d8970a4ec60a5d13ffeb4490bac5f1548ae9', '2026-11-11 19:06:59.479656+00'),
	('durable-map/memory_tidy_profiles/0010-tenants/0-column', '57bee6021f5abd494485fe5bdc146735e1f00e6f0ec08107ae0400e0f25a4c83', '2026-11-11 19:06:59.480857+00'),
	('durable-map/memory_tidy_profiles/0010-tenants/1-column', '173017c467c31bcaa249c25e08a7f9818be46ea66dd5c8368c2b6911d59025e4', '2026-11-11 19:06:59.482806+00'),
	('durable-map/memory_tidy_profiles/0010-tenants/0-stamp-column', 'ef909a887a30ea72201013ce607764af326c8bbed73c35ab199cceb583a1c164', '2026-11-11 19:06:59.482806+00'),
	('durable-map/memory_tidy_profiles/0010-tenants/2-keys', '2db32f33a8528a688f2b1ca06ee95a8f9e9e84bce7453170de82e313a139b2af', '2026-11-11 19:06:59.487467+00'),
	('durable-map/memory_tidy_profiles/0010-tenants/2-references', '40adddcefefe31a54bd13e58928280abfbe21cb999fe096ef8518baf917f5945', '2026-11-11 19:06:59.488153+00'),
	('durable-map/memory_tidy_profiles/0010-tenants/3-policy', '0fe0f829725ee54875092f5a6189a8a6af3bb252a43ea8b08af453eb0891d65d', '2026-11-11 19:06:59.489913+00'),
	('durable-map/memory_tidy_profiles/0010-tenants/2-tenant-policy', '719f75d81094ae09c6720ea1931b9f211c5ffba238cd5f97077b75d7794226f7', '2026-11-11 19:06:59.489913+00'),
	('durable-map/memory_tidy_profiles/0020-claim-ids', '442f89570c54ea808a3399529af178f5dc73695f4ba407ac78dca5d4c40337d0', '2026-11-11 19:06:59.492394+00'),
	('durable-map/memory_tidy_profiles/0021-claim-tenants', 'bcaa926903c6091b094caabdc22ff84414920dc5e6aa5ec6bec7be1c9466f290', '2026-11-11 19:06:59.493638+00'),
	('durable-map/modal_sandbox_bodies/0010-tenants/0-column', 'c8ee754fd6cfc3862d8f3e5f66169b172393075d5dec79416d579cd8a06b6839', '2026-11-11 19:06:59.49489+00'),
	('durable-map/modal_sandbox_bodies/0010-tenants/1-column', '4f43c7cba257c475ad9da50ff1b647c126dbe67aad835a3a859c4e7c5815589c', '2026-11-11 19:06:59.496299+00'),
	('durable-map/modal_sandbox_bodies/0010-tenants/0-stamp-column', '701a38c7313b8621bf3f59505aa440bb8937690602be4cfd4dec7af74a44fef9', '2026-11-11 19:06:59.496299+00'),
	('durable-map/modal_sandbox_bodies/0010-tenants/2-keys', '7a2f50ec42bcc3f78b5256a13fb14b4bc5eecdc8cdfeafe34bff0be61c8881c4', '2026-11-11 19:06:59.500874+00'),
	('durable-map/modal_sandbox_bodies/0010-tenants/2-references', 'f848c62f8085bb8bf5badd477b3a48ce4fcfeb5eab5e2e9498faee6c784b6301', '2026-11-11 19:06:59.50151+00'),
	('durable-map/modal_sandbox_bodies/0010-tenants/3-policy', '5c41efe0f618e05cc28f9d5efdcd0ce3a82ae43602116b9222fc918028c351d3', '2026-11-11 19:06:59.504191+00'),
	('durable-map/modal_sandbox_bodies/0010-tenants/2-tenant-policy', '8120192ff20e6bd4ce0cfaa993939f71f400336c9fe0f5bfc1fd3192d1830b6f', '2026-11-11 19:06:59.504191+00'),
	('durable-map/modal_sandbox_bodies/0020-claim-ids', '5f7b1caeba9245c3cdf1707f8c01ac8dc9b5f4b0c7fac9b0a5b2419804f5b0c0', '2026-11-11 19:06:59.507559+00'),
	('durable-map/modal_sandbox_bodies/0021-claim-tenants', '774e4093d2ff7644e6e19f5e538949a625abb92a742fe396a7d824c88c2030d6', '2026-11-11 19:06:59.508661+00'),
	('durable-map/model_credentials/0010-tenants/0-column', '20b3c69fa813c621b352510ece2423d71fb1ae2558882c4bba52ee60e088f1f4', '2026-11-11 19:06:59.509715+00'),
	('durable-map/model_credentials/0010-tenants/1-column', '93b7ae7d53c92194f596d2f1b2950085e3da7c6e61a5ced700b9246fc9991bae', '2026-11-11 19:06:59.516052+00'),
	('durable-map/model_credentials/0010-tenants/0-stamp-column', '0a7ef5a16f3f427fb6dd1787cd603cbc163ae083f3bce3d05eb5e51f673f8786', '2026-11-11 19:06:59.516052+00'),
	('durable-map/model_credentials/0010-tenants/2-keys', '67b8c33b42a75ef68eaf5f5c32bc69383a71aec3c251c6be4c0318c99fefcbb9', '2026-11-11 19:06:59.522118+00'),
	('durable-map/model_credentials/0010-tenants/2-references', '7a7ab7506639a79199ab4001b3061996d6ab6ea0f0f3cc2c4d3c7e1078b9c94d', '2026-11-11 19:06:59.522795+00'),
	('durable-map/model_credentials/0010-tenants/3-policy', 'd3df1217e468e4d3d35b09425cf3467f6f98e7cd1e99a2b80f745313f592930b', '2026-11-11 19:06:59.525307+00'),
	('durable-map/model_credentials/0010-tenants/2-tenant-policy', 'd991e45b1336c6e3c7d5c80e11ce0edcccf926679045054244eaa5a62912f3ad', '2026-11-11 19:06:59.525307+00'),
	('durable-map/model_credentials/0020-claim-ids', 'd56e181d49726496cac18adb07462cb9253d90ee1a1731d0af4279d44eb39af7', '2026-11-11 19:06:59.528148+00'),
	('durable-map/model_credentials/0021-claim-tenants', '8154699aaff060bc75fb266624f362b63f2f8b71c04f611680eb929ff37063ec', '2026-11-11 19:06:59.529392+00'),
	('durable-map/model_registry/0010-tenants/0-column', '2f3426a157152983626c398bf78bdfa0c6a2968beb5491ac8f8d2358b861b4cd', '2026-11-11 19:06:59.530842+00'),
	('durable-map/model_registry/0010-tenants/1-column', '7d5a7c60b15395b78872072c49047b7468ebd36e8e784ca9d0d5fa8aa3f06143', '2026-11-11 19:06:59.532356+00'),
	('durable-map/model_registry/0010-tenants/0-stamp-column', '2efffeff9bcd547d33497e4e94d270c0c805884486eb74c6a379dec15fdfe57e', '2026-11-11 19:06:59.532356+00'),
	('durable-map/model_registry/0010-tenants/2-keys', '1f10240787932ec0618525ce7ddd5581ef94cbc0d1b504dd3638bb0f52644774', '2026-11-11 19:06:59.537715+00'),
	('durable-map/model_registry/0010-tenants/2-references', '4b054c82942ba7dea99ffce1f029869b97f3aa19c1bedc870a81dd3818ecfcc0', '2026-11-11 19:06:59.538426+00'),
	('durable-map/model_registry/0010-tenants/3-policy', '608cbf449e0ae5a7b244dc1b4f3477b3eb6a88eb68cc16cda5a9c4caea9cb256', '2026-11-11 19:06:59.540743+00'),
	('durable-map/model_registry/0010-tenants/2-tenant-policy', '8758557cd4f4caecc13acc996f70ce99cab72023b1c5bcfc9a4c4464d331ef56', '2026-11-11 19:06:59.540743+00'),
	('durable-map/model_registry/0020-claim-ids', '7db8473d5fbe9ecccf31cfae0dfc5114e444aa00fb397a514a33dc45d727561a', '2026-11-11 19:06:59.543749+00'),
	('durable-map/model_registry/0021-claim-tenants', '3fca48d08c4542586475454333a772aac2c3bb93d72a3939bdee09855e22e0cf', '2026-11-11 19:06:59.544935+00'),
	('durable-map/monitors/0010-tenants/0-column', '5e7166990bbacdcb9ded39ec8d2ba1fd30880b9456cc9c86be90ad83166ce4be', '2026-11-11 19:06:59.546566+00'),
	('durable-map/monitors/0010-tenants/1-column', 'bf7c2161b9749f92b326ddc3ace1413a98596c7e974d26ff224516edbc033c92', '2026-11-11 19:06:59.548328+00'),
	('durable-map/monitors/0010-tenants/0-stamp-column', 'c5d2f95673826cfff8a5a0eb78046361cd718642eb5b6a976069dab4c7c9bfb8', '2026-11-11 19:06:59.548328+00'),
	('durable-map/monitors/0010-tenants/2-keys', '2f980a7345b59dc3453f453b0a1421ff1387404fa897fb4929c49bb1f9d0f432', '2026-11-11 19:06:59.554321+00'),
	('durable-map/monitors/0010-tenants/2-references', '24d077335588718f03b92ddc688b572647cdb14a81e1aa0020a27b200a9cd561', '2026-11-11 19:06:59.555061+00'),
	('durable-map/monitors/0010-tenants/3-policy', '99a3429c147a6d77b0eb79f2b3a7f100ae1070c9685f43845d238f8bb152a0da', '2026-11-11 19:06:59.557144+00'),
	('durable-map/monitors/0010-tenants/2-tenant-policy', '5d4bfcb442d1677505c694ffacdd670553c42718281451a17c5738792b262415', '2026-11-11 19:06:59.557144+00'),
	('durable-map/monitors/0020-claim-ids', '0fd81396b4a1a9c26a9ef9c9677331d81393f82928cc158f5536779c8aa0ab1f', '2026-11-11 19:06:59.559691+00'),
	('durable-map/monitors/0021-claim-tenants', 'b41b5d44220daf53e4ac23205c821040b5aaab7c01d8f452a05936b6e7281ff0', '2026-11-11 19:06:59.560814+00'),
	('durable-map/monitors/claim-ownerscopeid', '7f9ff25dbaf2de9edeed680cd98c0010ea99c4ab2c183331190bfb284a2fe09d', '2026-11-11 19:06:59.562637+00'),
	('durable-map/monitors/claim-tenants-ownerscopeid', 'bf515e8621e495a6d54b042c46e3d0989b2ef5c81051e086f685136f2ab77ad2', '2026-11-11 19:06:59.563577+00'),
	('durable-map/monitors/lookup-ownerscopeid-drop', 'da0e6fa54100837c47e88fea27c5f3ed807eb3b026473bbf1f6b64d7ea3d264d', '2026-11-11 19:06:59.564552+00'),
	('durable-map/monitors/lookup-ownerscopeid-hash', '309d0a292b6c04131a97c4b0e047cc4dc4b95aa6b327327fc28a7d0f1cc1b015', '2026-11-11 19:06:59.568418+00'),
	('durable-map/monitors/select-ownerscopeid', 'ae9b16dfa3c0a31ac987e28a043ddc08c55f0328b76a999d8319ed61dbce8907', '2026-11-11 19:06:59.574401+00'),
	('durable-map/monitors/stats-ownerscopeid', '52d4260bb2c2e6d7e3c32a9c50e5395ecfd98b5a83b1f03f649e5b0b804a2c17', '2026-11-11 19:06:59.575352+00'),
	('durable-map/oauth_flows/0010-tenants/0-column', '26d4c2b9756666cfb883672a2d02323014495bfa59cca3e4d1c2bd929532a859', '2026-11-11 19:06:59.577358+00'),
	('durable-map/oauth_flows/0010-tenants/1-column', '3553be8521677517c2feec515957fc5cf8b6cbcb81fa4f79330ca1aaae6562bf', '2026-11-11 19:06:59.578801+00'),
	('durable-map/oauth_flows/0010-tenants/0-stamp-column', 'd47385c183bdd0b41215b6fe3494b0ce4b5baf8aebe6ef74d048a1b48616c5be', '2026-11-11 19:06:59.578801+00'),
	('durable-map/oauth_flows/0010-tenants/2-keys', '56f1e3ee0c3b51058da2a0548264b1bd9185c668f5e0cf92ccdabbe8b8001c74', '2026-11-11 19:06:59.583409+00'),
	('durable-map/oauth_flows/0010-tenants/2-references', '663cb1d51a10d19b915624f0316a6bdcfbd8755c3ef647812ecf9a64658c26a0', '2026-11-11 19:06:59.584032+00'),
	('durable-map/oauth_flows/0010-tenants/3-policy', '0f253dfe97b8027ee752cde02ad289ca15f7b855fa574690c0be5197fdb5aaff', '2026-11-11 19:06:59.586029+00'),
	('durable-map/oauth_flows/0010-tenants/2-tenant-policy', '2656906c55deef7d1135ed7fece149c9643a9f9fe563af0fa1f04bfc322efb71', '2026-11-11 19:06:59.586029+00'),
	('durable-map/oauth_flows/0020-claim-ids', '2354fb0fcff96c27894e2e44e52bba6b71c62aa8d8015e789ded6e5478dd6009', '2026-11-11 19:06:59.588648+00'),
	('durable-map/oauth_flows/0021-claim-tenants', 'ab0d3035b58e33e38bb71529ad49a50aa29e1c9dc3f1a4e68cf31db15818f0db', '2026-11-11 19:06:59.589704+00'),
	('durable-map/org_ambient_flag/0010-tenants/0-column', '0d17183ed2117681e6b9be2d4cf7db7b53e4ae27265c830b18da7effee541549', '2026-11-11 19:06:59.590857+00'),
	('durable-map/org_ambient_flag/0010-tenants/1-column', 'b5a934cfaebc26f6a7d3c5c789d83bccd422694b5014f3bd6e7e374d7fa6a8f1', '2026-11-11 19:06:59.592165+00'),
	('durable-map/org_ambient_flag/0010-tenants/0-stamp-column', '2854839a00d9644a0a877c15e6982295ab0f89869cdf12cd46a9cea4ae657f87', '2026-11-11 19:06:59.592165+00'),
	('durable-map/org_ambient_flag/0010-tenants/2-keys', '10da8949b0390a1f31da718ad2edd8938185735746a0a695a2c91bad6c19d8ce', '2026-11-11 19:06:59.597311+00'),
	('durable-map/org_ambient_flag/0010-tenants/2-references', 'c5dfc0f48b7e14764cc870d1001b0d142020746abf929cbd144a8515729f4db6', '2026-11-11 19:06:59.598227+00'),
	('durable-map/org_ambient_flag/0010-tenants/3-policy', '47d95ac3138b020b23c324a7547f37dc22521e01fe92ed0991bb9dd17c8f78cf', '2026-11-11 19:06:59.599773+00'),
	('durable-map/org_ambient_flag/0010-tenants/2-tenant-policy', '0a01006d13a379cb9cee6c2cd3e882ec9ee390814e7cef215e5fd860f5230cba', '2026-11-11 19:06:59.599773+00'),
	('durable-map/org_ambient_flag/0020-claim-ids', '884797c0f2b4884e59ee9ae7f55d6dcfd55198f284dcd975f357da7f35d4f147', '2026-11-11 19:06:59.60227+00'),
	('durable-map/org_ambient_flag/0021-claim-tenants', 'c7976751aeb4da76618cef43bd577ccd02b7a3cb819b20923cad28dcdbd1ffb7', '2026-11-11 19:06:59.603564+00'),
	('durable-map/porter_deploy_bodies/0001', '08dfd8e5e80e05d55c3bb2d9c51d7d14de8b0adb2450fd5cd0bd588552506a25', '2026-11-11 19:06:59.604856+00'),
	('durable-map/porter_deploy_bodies/0010-tenants/0-column', '7e7fc3cf92913d82398c7c18262c285dcc22da6a184cf851c939aa5422c2830d', '2026-11-11 19:06:59.608436+00'),
	('durable-map/porter_deploy_bodies/0010-tenants/1-column', '121ce5c9124550d6fe7b60ef1b34f022977afaf590d010ccb1c53392f3861871', '2026-11-11 19:06:59.609771+00'),
	('durable-map/porter_deploy_bodies/0010-tenants/0-stamp-column', 'e4608f90eec64797d23ae9e3705afa19595880e8f5aa710f340ceb9b4fe7c4fb', '2026-11-11 19:06:59.609771+00'),
	('durable-map/porter_deploy_bodies/0010-tenants/2-keys', 'ae2ce7c25fc73216d69fadc94734e52ff333c941c159f83b739a806ac0d06e0a', '2026-11-11 19:06:59.614524+00'),
	('durable-map/porter_deploy_bodies/0010-tenants/2-references', 'a2edd32af0791d25d75d28c6e4e448308a376643efd535d42a7c425b46d26f3b', '2026-11-11 19:06:59.615484+00'),
	('durable-map/porter_deploy_bodies/0010-tenants/3-policy', '1b533d481c237d3a31b4960763130b08d37eda4014317f11e1d0692cb944d372', '2026-11-11 19:06:59.617394+00'),
	('durable-map/porter_deploy_bodies/0010-tenants/2-tenant-policy', 'ebf7089d47bde4302a2b6481a45bd56a4e1688c3c78ec77b3bae3614d88eac49', '2026-11-11 19:06:59.617394+00'),
	('durable-map/porter_deploy_bodies/0020-claim-ids', '3bbbf02e7f0663f9e7fd824ba9bd0adb3bc1640be407849b7a7bc901457fd018', '2026-11-11 19:06:59.620195+00'),
	('durable-map/porter_deploy_bodies/0021-claim-tenants', '991c271c07b62041c271378c892f77a6a44ce6d00dd7e70c3b948c4f1705b6cc', '2026-11-11 19:06:59.621638+00'),
	('durable-map/projects/0010-tenants/0-column', '3d726c13f07d928611607026f7782d86a717b550e7ec89920ddd32eae30a7b5b', '2026-11-11 19:06:59.622705+00'),
	('durable-map/projects/0010-tenants/1-column', 'b4126f80a2d024dc0346c85884cb3a3e962f4e649398c0f91527c45626966e81', '2026-11-11 19:06:59.624148+00'),
	('durable-map/projects/0010-tenants/0-stamp-column', '1db742830593abcb692d40f36172bc2dc92d04acfa538a0c9a1ac1b54c329f2d', '2026-11-11 19:06:59.624148+00'),
	('durable-map/projects/0010-tenants/2-keys', '2d0ddb87c59cd71b439cb5d113939b36eeb07d7324db675ff139cfc07cd7e32a', '2026-11-11 19:06:59.629241+00'),
	('durable-map/projects/0010-tenants/2-references', '23e326ae19c95cb7b85fc506bad9ce5f0e0d41fd5a99fe33e5defa37adba60a4', '2026-11-11 19:06:59.630142+00'),
	('durable-map/projects/0010-tenants/3-policy', 'e79fcb90b93b2f189562692d791a6fb17877795c9ea17922bbd89cd91a0b3333', '2026-11-11 19:06:59.632183+00'),
	('durable-map/projects/0010-tenants/2-tenant-policy', 'fbce9af43e7af2a5ce8881bdbd4e7c4fc521bb9beee66adac4d64185f0d54461', '2026-11-11 19:06:59.632183+00'),
	('durable-map/projects/0020-claim-ids', '583e55d673fb90aa38cc68a940c24a5592cc83253fb31846c0a388ad1f74a391', '2026-11-11 19:06:59.634759+00'),
	('durable-map/projects/0021-claim-tenants', '7b455d56fe226a9ffcee7f5cc6378ae2bd764aff9bba3e19800864e9b85dc115', '2026-11-11 19:06:59.635848+00'),
	('durable-map/render_app_storage/0001', 'c399f0fd0ae7e27ffe754fb60a7f94cfe69abcb4802126c8ba312ea4dd110270', '2026-11-11 19:06:59.637135+00'),
	('durable-map/render_app_storage/0010-tenants/0-column', 'fe7f9140abe13706b158943ce9f68e22b33b0face6950c39fcadb952fa272d40', '2026-11-11 19:06:59.641592+00'),
	('durable-map/render_app_storage/0010-tenants/1-column', '27a5b89bcf615dbed8fec7bf611bc81bce471af792f58ee7280b20807698d38f', '2026-11-11 19:06:59.643175+00'),
	('durable-map/render_app_storage/0010-tenants/0-stamp-column', 'e61686a302c062f5ef991a33dfdbb1953c681d755dc2205ca39f6f504c6f36c9', '2026-11-11 19:06:59.643175+00'),
	('durable-map/render_app_storage/0010-tenants/2-keys', '6c7a1649262de38c249edb6a1945efddc3a80c4a36d7497ac4ffbab717d1f84b', '2026-11-11 19:06:59.647032+00'),
	('durable-map/render_app_storage/0010-tenants/2-references', '4762d7dd08f6544275300ede3f6a5c81df981eb548f7a5b456bc90599668a6ef', '2026-11-11 19:06:59.647468+00'),
	('durable-map/render_app_storage/0010-tenants/3-policy', '1126474da29fbf198c8f9344e1777b43d1cefe648f80aee82d0457d344680c62', '2026-11-11 19:06:59.648778+00'),
	('durable-map/render_app_storage/0010-tenants/2-tenant-policy', '8ef825573b7cf08a0bdfb9a59ae980077ca1f7efe9f6a603f60632b42193215b', '2026-11-11 19:06:59.648778+00'),
	('durable-map/render_app_storage/0020-claim-ids', '18aba2d4745615fd007056fab93de54892de0ac8e011798ce7c506d019633dde', '2026-11-11 19:06:59.6515+00'),
	('durable-map/render_app_storage/0021-claim-tenants', '2332cef31773c4572af0c501281d905d750f3c83eea22b27c0beed328cf76829', '2026-11-11 19:06:59.652633+00'),
	('durable-map/render_deploy_bodies/0001', '90bfc2a877940993dc12dd46b717da6a91b4f1fce5f1316d374289b3967b44ca', '2026-11-11 19:06:59.653879+00'),
	('durable-map/render_deploy_bodies/0010-tenants/0-column', '997c2795e1c940ed8a81630a6b00dac50e56b0923f452dd1537fae404c50138c', '2026-11-11 19:06:59.658269+00'),
	('durable-map/render_deploy_bodies/0010-tenants/1-column', 'bfd270ab4be7ce075b663448821f9decb119e9912a45e2daafeb6ee1f3d5a309', '2026-11-11 19:06:59.659493+00'),
	('durable-map/render_deploy_bodies/0010-tenants/0-stamp-column', '3ffe478b7e0764d8b6348e62096d4fe34df860ca452cc2b98df8054cad644aee', '2026-11-11 19:06:59.659493+00'),
	('durable-map/render_deploy_bodies/0010-tenants/2-keys', '413f0d12de24aef26b2e0851f044f5ccb95c76d33e38d88b25a93738ce1a7e36', '2026-11-11 19:06:59.663556+00'),
	('durable-map/render_deploy_bodies/0010-tenants/2-references', '53f52fd21c2a2fa218852e9a0557eb5fc26440f3ca56c0249ae12ca472a5a99a', '2026-11-11 19:06:59.664222+00'),
	('durable-map/render_deploy_bodies/0010-tenants/3-policy', 'e989c5bc48fd711d5e842acc745230ac80343632f09e0882d6f57b8f962c13c4', '2026-11-11 19:06:59.666008+00'),
	('durable-map/render_deploy_bodies/0010-tenants/2-tenant-policy', '350f29746ce5a8b8c843e8373394bab2003a159a7c715fbc74340164eefc50b1', '2026-11-11 19:06:59.666008+00'),
	('durable-map/render_deploy_bodies/0020-claim-ids', '65ab6c6f904f2627aa08c10ead49715ff82bb155cc78a99c753ea9ce318713d2', '2026-11-11 19:06:59.668698+00'),
	('durable-map/render_deploy_bodies/0021-claim-tenants', '728d25568527a5893e75b40b7008ed8d9852e044766442e7462a4f70e8010b98', '2026-11-11 19:06:59.670155+00'),
	('durable-map/render_deploy_credentials/0001', 'e5ff9bfeaf39b06aca08e3d62bf8f4e1c3a7514923009f045630ed48d594e2f5', '2026-11-11 19:06:59.671119+00'),
	('durable-map/render_deploy_credentials/0010-tenants/0-column', '2917477ebc20f3aa41b1bec7307bcf4144c5c8d50cbd95005830b6395dd32fbc', '2026-11-11 19:06:59.67438+00'),
	('durable-map/render_deploy_credentials/0010-tenants/1-column', '2a03209e2a8c298af1b47aae9790efc490740752a07a138f1483baae82747438', '2026-11-11 19:06:59.675398+00'),
	('durable-map/render_deploy_credentials/0010-tenants/0-stamp-column', '01058a57b77f303456f26caebd172d084a44f36ac564c12351e8414f1633ea2b', '2026-11-11 19:06:59.675398+00'),
	('durable-map/render_deploy_credentials/0010-tenants/2-keys', 'ff3b25872f08d9749ca5b998b0252d2ca192c66962616f6f5a7e6e90ea9d99fb', '2026-11-11 19:06:59.679043+00'),
	('durable-map/render_deploy_credentials/0010-tenants/2-references', 'd722e02960a105c942ea095f335c0c056c58f88036b85a1d3e1611ef78d91b93', '2026-11-11 19:06:59.679534+00'),
	('durable-map/render_deploy_credentials/0010-tenants/3-policy', 'f894d9763efb8da01e7d1cf56d0f49990224754d03999c84cb9c89e2064a41d1', '2026-11-11 19:06:59.681226+00'),
	('durable-map/render_deploy_credentials/0010-tenants/2-tenant-policy', 'e16bc61fa15b29aa4624dfff4340d8f4368781f74b2f24aeb015d0c9e01c563f', '2026-11-11 19:06:59.681226+00'),
	('durable-map/render_deploy_credentials/0020-claim-ids', '51c5e45b8bd36bfe86962ab5003ec5b859760291b5bf35b100a91e712f4652d5', '2026-11-11 19:06:59.683965+00'),
	('durable-map/render_deploy_credentials/0021-claim-tenants', 'e77d34430a3e773f49dcf472c4d7004731b3cd42819414fddd620705f3fa9028', '2026-11-11 19:06:59.685029+00'),
	('durable-map/render_sandbox_bases/0001', 'cc0511ba517e9cbeba8acd9777a73a04aa0acda9163e2a59ec73037f9dd99a9e', '2026-11-11 19:06:59.686054+00'),
	('durable-map/render_sandbox_bases/0030-process-level', '8f49345e53057e58fa791c84ff173b2b0b8185652aa71c87605e14c03324a22f', '2026-11-11 19:06:59.690168+00'),
	('durable-map/render_sandbox_bodies/0001', 'e64c614383cd6163c1ab1a59d7fa81e08a5edaf94439489382ca4edf288b515b', '2026-11-11 19:06:59.691774+00'),
	('durable-map/render_sandbox_bodies/0010-tenants/0-column', '74b6cfb43a522c08f9e507c359f1fb0195ad7a87c9bfc7aa9ed4d8985a977c14', '2026-11-11 19:06:59.69626+00'),
	('durable-map/render_sandbox_bodies/0010-tenants/1-column', '046277a112173d9dc38ec37d2be1aca4f923caa396860b9cebc022da9ecb5c1a', '2026-11-11 19:06:59.697531+00'),
	('durable-map/render_sandbox_bodies/0010-tenants/0-stamp-column', 'f96e5cde411ce697dcbd71309a017e646ce225b355078bca1cc51516ecdd56fe', '2026-11-11 19:06:59.697531+00'),
	('durable-map/render_sandbox_bodies/0010-tenants/2-keys', '8a9ec92d9a5984d79e28f144baced02315959981e920ab42f93e25762b9f1d76', '2026-11-11 19:06:59.701995+00'),
	('durable-map/render_sandbox_bodies/0010-tenants/2-references', '18180b4470aca7fe7a4735e4d737e5eb7b758c156d105b0ac4966454211d773e', '2026-11-11 19:06:59.702641+00'),
	('durable-map/render_sandbox_bodies/0010-tenants/3-policy', 'dbfc9322001e37dac4ab3bb2ef1e2953d1b21a494e3130ae2881578de0a13892', '2026-11-11 19:06:59.70455+00'),
	('durable-map/render_sandbox_bodies/0010-tenants/2-tenant-policy', '066382a56d82f72dab79bcccd915e32588287c3c43c64fd287bc0f95a76b3d91', '2026-11-11 19:06:59.70455+00'),
	('durable-map/render_sandbox_bodies/0020-claim-ids', 'c76839c2c06354e11ce88a491ad7d761b63b907cdb66506d6da5cf68e4f227d1', '2026-11-11 19:06:59.707145+00'),
	('durable-map/render_sandbox_bodies/0021-claim-tenants', '9dc75ce629dedad40836bc3d0378072bc9a261476c0f23687a1545e86a5c86b2', '2026-11-11 19:06:59.708295+00'),
	('durable-map/render_sandbox_cleanup/0001', '91c90f81a8878869dd6936ad8c0b5f5a70d25dd6989a9792987a856e8c048523', '2026-11-11 19:06:59.70921+00'),
	('durable-map/render_sandbox_cleanup/0010-tenants/0-column', 'be372279729d4eedc4197798fb811256f4a221fc5aa4d0f9a4fc0c85150e852d', '2026-11-11 19:06:59.71344+00'),
	('durable-map/render_sandbox_cleanup/0010-tenants/1-column', '4f6a17109e20a0b66bcdf2ef8406fbee2ab920a3053c29c2b916cf979fdc62f3', '2026-11-11 19:06:59.715087+00'),
	('durable-map/render_sandbox_cleanup/0010-tenants/0-stamp-column', 'a86228c7c74cf7d741fd5d9ef5e2aadf21d83b44941c18cc1f30eb10a21a6c0b', '2026-11-11 19:06:59.715087+00'),
	('durable-map/render_sandbox_cleanup/0010-tenants/2-keys', 'fc59db39026b8e68ce1c9085199e2dd10db49191e2b854001359bd72315b6b60', '2026-11-11 19:06:59.719775+00'),
	('durable-map/render_sandbox_cleanup/0010-tenants/2-references', '2563204dbd822128471f9d99edcc1a06bd9bc3bdab2efb13e1b0a2b519b57d93', '2026-11-11 19:06:59.720283+00'),
	('durable-map/render_sandbox_cleanup/0010-tenants/3-policy', '3bb32fb3be11b908884cdeb1c6eb7b42269f50af2378806ebf0ffe5b667c0d1e', '2026-11-11 19:06:59.721928+00'),
	('durable-map/render_sandbox_cleanup/0010-tenants/2-tenant-policy', '1da06efc0bfbae95b379e223452fad60545a862d53b7cb27a71f49adc6cceeb5', '2026-11-11 19:06:59.721928+00'),
	('durable-map/render_sandbox_cleanup/0020-claim-ids', 'd8927a84e5295d818c3bbe1eade3c2d51792f118b7ff548a79268e009fa204fb', '2026-11-11 19:06:59.724228+00'),
	('durable-map/render_sandbox_cleanup/0021-claim-tenants', '09e25db25b072a8b2b2f6d1ef8dd17ee44971fbb08067ab5c3d5a33eb7809b61', '2026-11-11 19:06:59.725216+00'),
	('durable-map/render_scratch_bodies/0001', '090542aeaa44e14aa2f7f8e1d9371b5e1251fcdbb31746edd0a39c6843eb69db', '2026-11-11 19:06:59.726001+00'),
	('durable-map/render_scratch_bodies/0010-tenants/0-column', '54083a0feb29c388ec92d72969206a85b6e696926cf7d8922ff96ab01f7c6f92', '2026-11-11 19:06:59.72983+00'),
	('durable-map/render_scratch_bodies/0010-tenants/1-column', '6465c0339af78636dfa804528eeed5af64131546efbf7c8a6e15083d5837bb79', '2026-11-11 19:06:59.731283+00'),
	('durable-map/render_scratch_bodies/0010-tenants/0-stamp-column', 'b8a32bd28e7f4397c9dc97d2c0e8067982a83f9f9c9d2cd6355a68118d1d6bd4', '2026-11-11 19:06:59.731283+00'),
	('durable-map/render_scratch_bodies/0010-tenants/2-keys', '3abdd931693e675e3e7a16940d5baa5768163d6817439835a31c4c86a522fe28', '2026-11-11 19:06:59.736134+00'),
	('durable-map/render_scratch_bodies/0010-tenants/2-references', 'c4ed20da29b7517a232e318644f5e3d050d4acc87daa4458d2d9eaaa2120c65d', '2026-11-11 19:06:59.736865+00'),
	('durable-map/render_scratch_bodies/0010-tenants/3-policy', 'ea1fd62c1b65079af91341c779f6b7739bcb61fec73c5bfca762799bb5257ce5', '2026-11-11 19:06:59.739142+00'),
	('durable-map/render_scratch_bodies/0010-tenants/2-tenant-policy', 'dd55991390549525c5c3b5fffa34058882ee80a7248f2b6ab2bedf740fb59cbe', '2026-11-11 19:06:59.739142+00'),
	('durable-map/render_scratch_bodies/0020-claim-ids', '9f06a5b2256ee6cbb259f170354d04c3ec7c9647bb984f7b08fbde23c6cfaeca', '2026-11-11 19:06:59.742712+00'),
	('durable-map/render_scratch_bodies/0021-claim-tenants', '6ee7654c3cb2da83d5fdd33977345666e75d7d46741ebdb1db057386b3a3732c', '2026-11-11 19:06:59.74387+00'),
	('durable-map/retired-tables/0001-drop', '7dea85967ce04a37a73458498a11df8da2aca63f36b1d18dd79545452622723e', '2026-11-11 19:06:59.745225+00'),
	('durable-map/sandbox_defaults/0010-tenants/0-column', '8583132b6e6b32d5a8b6cb3b6117438299786fa56d92f981242d4323cff683e0', '2026-11-11 19:06:59.750924+00'),
	('durable-map/sandbox_defaults/0010-tenants/1-column', '751c780a6ecf156208726bc20b711e53a265dde8d92ea22faa25d3c0daea1475', '2026-11-11 19:06:59.752432+00'),
	('durable-map/sandbox_defaults/0010-tenants/0-stamp-column', '28a53ea25d959a48151a74878d73dd65bbc091137a7a9cb28b74ef36f0ecd2db', '2026-11-11 19:06:59.752432+00'),
	('durable-map/sandbox_defaults/0010-tenants/2-keys', '755a67bfe5b1ebafd63743097bebfd5bb50166e79df03bfe19f01b56d59d7b73', '2026-11-11 19:06:59.757866+00'),
	('durable-map/sandbox_defaults/0010-tenants/2-references', '968f1c1c881e5bce5574f2445188d421cbd9c089cb8a565c62c38b3a4ff8dcf2', '2026-11-11 19:06:59.7586+00'),
	('durable-map/sandbox_defaults/0010-tenants/3-policy', '919ddeb78a8dc5e1c02ffd819f00f293e811205e8256c0dbced2ec038e3cc652', '2026-11-11 19:06:59.760659+00'),
	('durable-map/sandbox_defaults/0010-tenants/2-tenant-policy', '69d087a3223d40eaa4d2fee6b056178d36d6187df2ff7cd149153a9a37973263', '2026-11-11 19:06:59.760659+00'),
	('durable-map/sandbox_defaults/0020-claim-ids', '57e24b4c1a5978d611d9fc4e794efdb3a86e6c341155d32096e9095626575af4', '2026-11-11 19:06:59.763044+00'),
	('durable-map/sandbox_defaults/0021-claim-tenants', 'abb999471f6cb9d2396551b52fbdfbaf0a869b4fda640475e7a45a37945e56fc', '2026-11-11 19:06:59.763837+00'),
	('durable-map/sandbox_resource_rollout/0001', 'dcd22153628d543510d7b0354f04f44e5ced4caace605e4d11fc5d2a23e4951a', '2026-11-11 19:06:59.764835+00'),
	('durable-map/sandbox_resource_rollout/0010-tenants/0-column', '0adfa044aa9a0017e84f1dca6908a34e97ea76b97236807247ff22e4a167bb41', '2026-11-11 19:06:59.768115+00'),
	('durable-map/sandbox_resource_rollout/0010-tenants/1-column', '5767d74b113d75cbf6645a3a85c6ef0f43775b51b2345c03ae4422e2a2a36610', '2026-11-11 19:06:59.769391+00'),
	('durable-map/sandbox_resource_rollout/0010-tenants/0-stamp-column', '16daacd8bbaf24d2f5795e7fe4b319130d2a47bc8660f13681247d5649597d20', '2026-11-11 19:06:59.769391+00'),
	('durable-map/sandbox_resource_rollout/0010-tenants/2-keys', 'b3280c3082fd743e6942ba39ae461be7c18013898bd6b67e8f8deaf6da963df6', '2026-11-11 19:06:59.77364+00'),
	('durable-map/sandbox_resource_rollout/0010-tenants/2-references', 'e45fb149c923549df5b184aafa9a0ce8c1fdc668bd0a265872dde0be8edd03ed', '2026-11-11 19:06:59.774566+00'),
	('durable-map/sandbox_resource_rollout/0010-tenants/3-policy', 'cb6c90fd18148c6b68e042c274e83fda6432614bac2a10ca55fa4f9dd83adaa9', '2026-11-11 19:06:59.776437+00'),
	('durable-map/sandbox_resource_rollout/0010-tenants/2-tenant-policy', 'a857953ab61a972c2209149476c9b50e4bb44c6ada09fc514c711e16bc6ed932', '2026-11-11 19:06:59.776437+00'),
	('durable-map/sandbox_resource_rollout/0020-claim-ids', 'e9b4f99187c8dca705b1b8f0c8e525ce3d9c14c4c798e1c471e65be2de8d49a7', '2026-11-11 19:06:59.779026+00'),
	('durable-map/sandbox_resource_rollout/0021-claim-tenants', '7766f84d3f48f463287af5490347dd0d90acda1235ebd4aa0443cd81bcf55c91', '2026-11-11 19:06:59.7799+00'),
	('durable-map/sandbox_resources/0010-tenants/0-column', 'bffcc361553c526095e8a23453ca46c7366c6bfe3e5b3dc6b7a691e0ec4184a9', '2026-11-11 19:06:59.780697+00'),
	('durable-map/sandbox_resources/0010-tenants/1-column', '9992e0f40e308e3dd0454b776a0906446d67f729122870402efe0b6e7e396a50', '2026-11-11 19:06:59.782+00'),
	('durable-map/sandbox_resources/0010-tenants/0-stamp-column', '1ec882ca0467a4c98d4db1d8d9949cef73dc72eee0748d7482e1ff8c30d3b237', '2026-11-11 19:06:59.782+00'),
	('durable-map/sandbox_resources/0010-tenants/2-keys', 'fc9eed44152e1da4cfaebf9ebbfe4da47a771283c7b770772c9b8d19d6608172', '2026-11-11 19:06:59.786342+00'),
	('durable-map/sandbox_resources/0010-tenants/2-references', '066cd0aab6dfc692ac16e39483deddfc10e52555d45bd637f039d46c020631dd', '2026-11-11 19:06:59.787202+00'),
	('durable-map/sandbox_resources/0010-tenants/3-policy', '8e298be42ce379adcb5486fcf810b956731a0304456f3ab869f01fef4bc6c291', '2026-11-11 19:06:59.788815+00'),
	('durable-map/sandbox_resources/0010-tenants/2-tenant-policy', 'f5efd324c972da2daadfafca8452b5f2ec1cee1ff1fb25996ce1608b73fbc4c4', '2026-11-11 19:06:59.788815+00'),
	('durable-map/sandbox_resources/0020-claim-ids', 'af5e7d43ce9cc44e7e6f1a6331b0bf81315de7b7cc56d194b4edacdfcce18edc', '2026-11-11 19:06:59.791574+00'),
	('durable-map/sandbox_resources/0021-claim-tenants', 'e780be685f7a724421f95ef9816e8ad678ced4ff1fa55e4369f6d3ca275fbac0', '2026-11-11 19:06:59.792464+00'),
	('durable-map/sandbox_routing/0001', '87419da3caad64f369b0b2fab335aba22d336730b4a11abf8bddf24300a49448', '2026-11-11 19:06:59.793274+00'),
	('durable-map/sandbox_routing/0010-tenants/0-column', 'f9ba77a556dac614adc20e5aa8b6cfa56b74093ce8cef85d2b57d243325d7c2d', '2026-11-11 19:06:59.796935+00'),
	('durable-map/sandbox_routing/0010-tenants/1-column', '1c6d0e26220387ed7aff4f2b0f868338cad740ddb66b07383f2df3c79c34211c', '2026-11-11 19:06:59.798331+00'),
	('durable-map/sandbox_routing/0010-tenants/0-stamp-column', '5c31d065df17af5485255dd715a803600082744f080f7daff056e2c5e0981f31', '2026-11-11 19:06:59.798331+00'),
	('durable-map/sandbox_routing/0010-tenants/2-keys', '7f7bbc1270e17fad6f675b2f6adf396bbf72657aaf3488f731e88357047cc9b4', '2026-11-11 19:06:59.802791+00'),
	('durable-map/sandbox_routing/0010-tenants/2-references', 'c91ec57e9dac4228094ca7bb9706e32400c9a327fd0f11c299ae2e3cd5118456', '2026-11-11 19:06:59.803446+00'),
	('durable-map/sandbox_routing/0010-tenants/3-policy', 'a5b160948fbbd3b84c04d5166b20a09c92a7b92444f5fd06e46f7cc4a2ca4541', '2026-11-11 19:06:59.805062+00'),
	('durable-map/sandbox_routing/0010-tenants/2-tenant-policy', 'd62a3ae9eab9c95459b4fee80d0c92c8948712978c12c09ba7c9c5fc5fc3f16d', '2026-11-11 19:06:59.805062+00'),
	('durable-map/sandbox_routing/0020-claim-ids', 'ad518f92f12e72603722ed9bd86151cd594d557216b3b82f4ba46099ac3db0bd', '2026-11-11 19:06:59.807425+00'),
	('durable-map/sandbox_routing/0021-claim-tenants', '6028fb276ef57900b366ac66b1ec43634df83ab4ea761ba820eb49630c8a8f08', '2026-11-11 19:06:59.808317+00'),
	('durable-map/secret_drops/0010-tenants/0-column', 'ade75c0473979b26fe4f67ccfb9b48d7a866b904efeac7502ac50fb93461101b', '2026-11-11 19:06:59.809423+00'),
	('durable-map/secret_drops/0010-tenants/1-column', 'd95afa2b906ab6b4c56babc241adff6c0ab855ed2474fc384e9175bc78afbf95', '2026-11-11 19:06:59.811022+00'),
	('durable-map/secret_drops/0010-tenants/0-stamp-column', 'c565c1690e0d39a43fc35c1d0911f4a7a5366448d51bfc7ee0e3b794fb636b86', '2026-11-11 19:06:59.811022+00'),
	('durable-map/secret_drops/0010-tenants/2-keys', '881d7b7e41299d3421a9afedf836ed78d5cf711194349a42fb74d141767984c3', '2026-11-11 19:06:59.817346+00'),
	('durable-map/secret_drops/0010-tenants/2-references', '3401fed0ee29e863aa02d6b41e131c7c62deade8582943930444c6acb371cf72', '2026-11-11 19:06:59.818198+00'),
	('durable-map/secret_drops/0010-tenants/3-policy', '7da719f737636fe34b8a974119fec38066383346c963f15c4506026e7eb6f222', '2026-11-11 19:06:59.820469+00'),
	('durable-map/secret_drops/0010-tenants/2-tenant-policy', '1cb5ba390933ebdd81932419dd7aef8234872356d6c2224415fe24524c168028', '2026-11-11 19:06:59.820469+00'),
	('durable-map/secret_drops/0020-claim-ids', '2702edce1baa3a3261995cba65de5708b3188370de4882ebcefe0519364d5782', '2026-11-11 19:06:59.82372+00'),
	('durable-map/secret_drops/0021-claim-tenants', 'd00339184617a5cb354b0a63ff7caa3ee90220a229db62f73237c447c8a4c208', '2026-11-11 19:06:59.825207+00'),
	('durable-map/security_postures/0010-tenants/0-column', '54974a9041b611230ae07bd1084f2f104ca20b99c22725d00a072f631ba3901f', '2026-11-11 19:06:59.826258+00'),
	('durable-map/security_postures/0010-tenants/1-column', '42693d83c060ad60ce069517a73bec88329c40dfb8d26a530186eb88ab743168', '2026-11-11 19:06:59.827622+00'),
	('durable-map/security_postures/0010-tenants/0-stamp-column', '7d0e88e3e377fe47aeb5b32056373acf62e3e1bf18a9d35194823250e36e2e57', '2026-11-11 19:06:59.827622+00'),
	('durable-map/security_postures/0010-tenants/2-keys', '1db2728e918aec8c4b275159baf938b7f9848951234dfd59ac744ae848cb93af', '2026-11-11 19:06:59.832035+00'),
	('durable-map/security_postures/0010-tenants/2-references', '18e8b23e0e40f43d9dea7506d717357ba28a1de3f0e302ae70ee6e1c675bb695', '2026-11-11 19:06:59.83274+00'),
	('durable-map/security_postures/0010-tenants/3-policy', '7e7722dce965f4ca4a1ecf474c3aa856a8c5cd0156e3efa0d6b2e2637221e43a', '2026-11-11 19:06:59.834373+00'),
	('durable-map/security_postures/0010-tenants/2-tenant-policy', '77aabff45be5b6e7cb362b2410f80a73aeac81a696d181160dd102ac327f377c', '2026-11-11 19:06:59.834373+00'),
	('durable-map/security_postures/0020-claim-ids', '48364f6bbf9c32a343e1207b3f58feb44d6a95e321990848926f60c1515a8cc4', '2026-11-11 19:06:59.836817+00'),
	('durable-map/security_postures/0021-claim-tenants', '572928c7cd909ab1a88815c78212750b1d9471b52391eb9fdd403b9f8f71cb05', '2026-11-11 19:06:59.83767+00'),
	('durable-map/session_mailbox/0010-tenants/0-column', '310a0f6ab875418cb6f09b6d0e50bef2991f24297546614a18860e9b1f49b23d', '2026-11-11 19:06:59.840006+00'),
	('durable-map/session_mailbox/0010-tenants/1-column', '7f64c3dfc3d4642c84ec3a64dec4412b1cfa12e2eeb5ca85cdc3a4628b9d95f4', '2026-11-11 19:06:59.841425+00'),
	('durable-map/session_mailbox/0010-tenants/0-stamp-column', 'f788c80ebb6b063ee276e6ad2d57afbdca1ed7056aaa012bd781a094e26746ed', '2026-11-11 19:06:59.841425+00'),
	('durable-map/session_mailbox/0010-tenants/2-keys', '121d9d602e445f11a8ab36a09fa6287a85080c12c107038a0e83147843b9802d', '2026-11-11 19:06:59.84539+00'),
	('durable-map/session_mailbox/0010-tenants/2-references', 'f441cfa988d18a1146f62ef184ec7b57ec730eab7298672414cbeb112cb784dd', '2026-11-11 19:06:59.846143+00'),
	('durable-map/session_mailbox/0010-tenants/3-policy', '28da0477deae5250fbbc93adda22b395c65da4c1612c2b9c76ab6ce9795b1c0f', '2026-11-11 19:06:59.848124+00'),
	('durable-map/session_mailbox/0010-tenants/2-tenant-policy', '35bcb1a45a65c037f67b224c19c65bb423a17d317c7196563409a0977941091f', '2026-11-11 19:06:59.848124+00'),
	('durable-map/session_mailbox/0020-claim-ids', '12d794b1defafe4372e5c0a019ad3ce3ecae48e1f8c955e834ab1b42b5b7e06e', '2026-11-11 19:06:59.850835+00'),
	('durable-map/session_mailbox/0021-claim-tenants', '2ded6486f4923fc74eb562417c39c5aeb1f9f55b9e5fa8a17334757d0de604d3', '2026-11-11 19:06:59.851838+00'),
	('durable-map/session_mailbox/claim-recipientid', 'd9c29b5987adc8211f7a31b1deaf58386270fa32d6fc590f7f7ce425110fce59', '2026-11-11 19:06:59.852871+00'),
	('durable-map/session_mailbox/claim-tenants-recipientid', 'd6bc12814a24026df1f3fc1517133e3ffb96d70802e67f4762c1b2827b97be1c', '2026-11-11 19:06:59.854004+00'),
	('durable-map/session_mailbox/claim-tenants-wake', '6a336c4dfb3bd9e8d9872563780f2357e42dacf4f4fdaf82cf49e107aaeeeeaf', '2026-11-11 19:06:59.855288+00'),
	('durable-map/session_mailbox/claim-wake', '43c0c27fcb022cdb37a26cd4436d36ab7f993bed56dfc779b67c1b71ecb2675e', '2026-11-11 19:06:59.856628+00'),
	('durable-map/session_mailbox/lookup-wake-drop', '36d1fa0fbb2878177fd89fd272128d1c24a6d03b19cffe8c2277390c5c9631dc', '2026-11-11 19:06:59.85802+00'),
	('durable-map/session_mailbox/lookup-wake-hash', '412fef1862afd33ab9c235988829aab134ae9e02e2c562cdb9707e6d04a95c8d', '2026-11-11 19:06:59.862716+00'),
	('durable-map/session_mailbox/select-wake', 'ef6f6f3c44e7d900032bc507e5ff2f2d1b2aa64daafc25d3c348b5fa08d10510', '2026-11-11 19:06:59.868687+00'),
	('durable-map/session_mailbox/stats-wake', 'd7c3abe7148b7cadd8d2414418b3fcd177af27fed1d4fb95c04f209a194fd56d', '2026-11-11 19:06:59.869654+00'),
	('durable-map/session_shares/0010-tenants/0-column', '29daf80d093d929027761f0e3f3a39e81d4a0d15a0143a5edbad7d0507214cfc', '2026-11-11 19:06:59.871569+00'),
	('durable-map/session_shares/0010-tenants/1-column', 'b38d670e08385455aaec7adaa110ca6afc71d36851b2248ee4030904af134e1c', '2026-11-11 19:06:59.873135+00'),
	('durable-map/session_shares/0010-tenants/0-stamp-column', '0a517e35cfc617422a5e73ecec0899af81b56bfea2663a8ff5773eeaeec740cf', '2026-11-11 19:06:59.873135+00'),
	('durable-map/session_shares/0010-tenants/2-keys', '4e2d70ae10b6474bf2f220fffb5005d21c4583829c67ed622f9c0ac5ce9e8a71', '2026-11-11 19:06:59.877704+00'),
	('durable-map/session_shares/0010-tenants/2-references', 'bb5f3f86e1b247e838e740ef4572921841934ba0c87b5dd5e2382d8b6291d085', '2026-11-11 19:06:59.878293+00'),
	('durable-map/session_shares/0010-tenants/3-policy', '43cfa2069c9fb70b3f049379ecf53b53320f4786f72481cf0162c1101bcc4f7e', '2026-11-11 19:06:59.880089+00'),
	('durable-map/session_shares/0010-tenants/2-tenant-policy', '866f9b5fa8b08e90d3caf85db435e8ad99422e60d2e7e74bd1ad72e08d2b52be', '2026-11-11 19:06:59.880089+00'),
	('durable-map/session_shares/0020-claim-ids', '0adb9e73e9e27b3bb883fd82e3bae7ff28765cc8f1741cb13d73e3ea7e6d28a6', '2026-11-11 19:06:59.883088+00'),
	('durable-map/session_shares/0021-claim-tenants', '1c66c43ce73d7767034e86271aae989cfde6b18545d96bf9fbc83cd6cfd098b3', '2026-11-11 19:06:59.884533+00'),
	('durable-map/sharing_postures/0010-tenants/0-column', 'e73bb3198f8be6c293318e117158f2589a7e01574c8f7ec074db9b0966337acf', '2026-11-11 19:06:59.885822+00'),
	('durable-map/sharing_postures/0010-tenants/1-column', '9e55922a2937b26e2ad094e150e636fb4c1e31d5a086fbd628a27490d44904b2', '2026-11-11 19:06:59.888572+00'),
	('durable-map/sharing_postures/0010-tenants/0-stamp-column', '57b44200ba3bb5872b00298402532a609be1289ba35ea6795edc1e35175c465d', '2026-11-11 19:06:59.888572+00'),
	('durable-map/sharing_postures/0010-tenants/2-keys', 'a1bdc58597ac5b2db7d31a28b9b7c8a78d6f3ddcda00404e02f3fbb0e189e1e2', '2026-11-11 19:06:59.895425+00'),
	('durable-map/sharing_postures/0010-tenants/2-references', '5bbc5c6bf1885b4a4f7ac4880769e6f83f949c04dc0e44b1a943507f1c882597', '2026-11-11 19:06:59.896599+00'),
	('durable-map/sharing_postures/0010-tenants/3-policy', 'c46f40878a93f8ce5879651a87e5bfd833545710d3291d5953c0eb746fb71558', '2026-11-11 19:06:59.899409+00'),
	('durable-map/sharing_postures/0010-tenants/2-tenant-policy', '76be33414ac1cb92f79ac27c57f9a63b291ccf3719e3a575cb085d85ba364708', '2026-11-11 19:06:59.899409+00'),
	('durable-map/sharing_postures/0020-claim-ids', '0e159661cd581fbe1cc9a11d17e45439b3300f1eb7f036bbe9cb56dc569aea01', '2026-11-11 19:06:59.903072+00'),
	('durable-map/sharing_postures/0021-claim-tenants', '55375153f34769396cad62a00cc14fd353b7deb179393d83ad057400603dade0', '2026-11-11 19:06:59.904238+00'),
	('durable-map/skill_bundles/0010-tenants/0-column', '1700432e674b9938b9929b0897990b62997cec36b8cbddd0c2196e33fbeb8fe9', '2026-11-11 19:06:59.905634+00'),
	('durable-map/skill_bundles/0010-tenants/1-column', '58258c2683df6065c748b95fb3236401f780d8f37e5060d034c7b01df6bb4bd6', '2026-11-11 19:06:59.907302+00'),
	('durable-map/skill_bundles/0010-tenants/0-stamp-column', '0f50136203f4f59ac577fb6b58caa8e52b106709321e6bcfebd71bc34dca1ff5', '2026-11-11 19:06:59.907302+00'),
	('durable-map/skill_bundles/0010-tenants/2-keys', '81272a1f6d125eee45ab4615ef787658a391b689483c9113df5fc52fa712dedf', '2026-11-11 19:06:59.912186+00'),
	('durable-map/skill_bundles/0010-tenants/2-references', '1b576589e7b2b30a696e3f43c97835708f4ef0bc8d1180c5e534dfdbd9474c9d', '2026-11-11 19:06:59.913196+00'),
	('durable-map/skill_bundles/0010-tenants/3-policy', 'c6588f0c7691e75b607cae8f651aafeef4515c8cb6a5bd51851f4b9e2a57e4ec', '2026-11-11 19:06:59.915223+00'),
	('durable-map/skill_bundles/0010-tenants/2-tenant-policy', 'f4c09f5a7867701132d4d2f6051b72b489216f078e7dcaf0eb391bbb382d8370', '2026-11-11 19:06:59.915223+00'),
	('durable-map/skill_bundles/0020-claim-ids', '884ddac39ae542c55caf1682b7695d1a6b1ad1ea9a5a4fb0e783421705ed4b62', '2026-11-11 19:06:59.917841+00'),
	('durable-map/skill_bundles/0021-claim-tenants', '4eec1d80cff0ac4d4a81c4a96aca30a69a60716b1ab197e3e9913aaeed806b87', '2026-11-11 19:06:59.918973+00'),
	('durable-map/skill_packs/0010-tenants/0-column', '8f49566cee769899cdbe5c581793ce621f48cfcdd1b85d612e9e66e62d59c997', '2026-11-11 19:06:59.920457+00'),
	('durable-map/skill_packs/0010-tenants/1-column', 'e260022f906ffb245e305cedd092b32138fb453da676b597cfbe4457d62b7829', '2026-11-11 19:06:59.922112+00'),
	('durable-map/skill_packs/0010-tenants/0-stamp-column', '595deae7eef5d59afda70d65d0ea1da56e93ac11d041ff761bd6dd7255547002', '2026-11-11 19:06:59.922112+00'),
	('durable-map/skill_packs/0010-tenants/2-keys', 'cecef985e8ebcf52802367bf4551bd4b9206bf20a31ae324d2445cf6eb7fd308', '2026-11-11 19:06:59.927288+00'),
	('durable-map/skill_packs/0010-tenants/2-references', 'b810091efca0f206727bcbdd3b8f4c8c7f84771c9642eb05d01907effe6b1940', '2026-11-11 19:06:59.928258+00'),
	('durable-map/skill_packs/0010-tenants/3-policy', 'a3743e660f9ae6150bdc7b31d8348f5d13348a5ec36268a68fe40bbeebce2ad3', '2026-11-11 19:06:59.930484+00'),
	('durable-map/skill_packs/0010-tenants/2-tenant-policy', '90d65784866c96ea936540e7abdb085bbf846c2d3ec344a106f17f8d5db198e7', '2026-11-11 19:06:59.930484+00'),
	('durable-map/skill_packs/0020-claim-ids', 'f2b1baee1a3a414eb2a294c3c8703ae3c619526763f10c40f1f0bac0ae0d8303', '2026-11-11 19:06:59.933298+00'),
	('durable-map/skill_packs/0021-claim-tenants', '11ba1f1612a28cca6d7b3c8b00cb66c4d7a4c92c24fa0471c716b74ff0b5a15e', '2026-11-11 19:06:59.934474+00'),
	('durable-map/skills/0010-tenants/0-column', '2c3186811f500f350a355d9e239e13aa49eb7b1acb4edb76b28ae119eff650ac', '2026-11-11 19:06:59.935446+00'),
	('durable-map/skills/0010-tenants/1-column', '5ab890c5c2c44fb69be6de35d62cd84fd0fd8b734207b834b1f7ddbd9df0c3ad', '2026-11-11 19:06:59.937183+00'),
	('durable-map/skills/0010-tenants/0-stamp-column', 'de4ddee2623ad532ac490d397b9dbb7d4a7727e63bf967d84653da754a5bb754', '2026-11-11 19:06:59.937183+00'),
	('durable-map/skills/0010-tenants/2-keys', 'acd272d22322a9ad64a3823ba55ac255fddc0d5c6276a7703809bbed1efc870f', '2026-11-11 19:06:59.943021+00'),
	('durable-map/skills/0010-tenants/2-references', '540c03afdd96501103a0f1a2922ff1e9756e289a14f1b6a5779130f27455dd79', '2026-11-11 19:06:59.944042+00'),
	('durable-map/skills/0010-tenants/3-policy', '64b08a24100bf3420d24932e41ac045a56aae0b1901f65c8a469d1f74ac00f91', '2026-11-11 19:06:59.946266+00'),
	('durable-map/skills/0010-tenants/2-tenant-policy', 'b57b299200d9f9c038f49112c38d6cf2a3f2995b29a126ff1f3fade6b6392175', '2026-11-11 19:06:59.946266+00'),
	('durable-map/skills/0020-claim-ids', 'e3456a0aa49d179872d870a8b880f9fd32e76f28614a3f7c26b9b60f6a54cac2', '2026-11-11 19:06:59.949409+00'),
	('durable-map/skills/0021-claim-tenants', '7d2e3d793fb3e7c54b948a712a8d3535f6921114303df8502466454c1e3889b8', '2026-11-11 19:06:59.950551+00'),
	('durable-map/skills/claim-scopeid', '7a241aa627b5f53f34ca909792c32904d27689459e20787e5e2bea4c62bf3411', '2026-11-11 19:06:59.95165+00'),
	('durable-map/skills/claim-tenants-scopeid', '949757a460fb5d2c50bdfa5bfd9b787925d28590930733aed9633004d2ab396f', '2026-11-11 19:06:59.952541+00'),
	('durable-map/skills/lookup-scopeid-drop', '9d6c67dba12d614f52f0699708744290fe34ce3a3c809af0e384c73e8204a50b', '2026-11-11 19:06:59.953535+00'),
	('durable-map/skills/lookup-scopeid-hash', '4ad1cb3e06ff90c35c53e28a20b4299e868b76486dfc561d79724eedfb198fbf', '2026-11-11 19:06:59.957478+00'),
	('durable-map/skills/select-scopeid', 'b010072d152a8c28d5a831ed0fcf75539cb1347f0684a621ff84939a8e0d6017', '2026-11-11 19:06:59.964402+00'),
	('durable-map/skills/stats-scopeid', 'bafceb5216672202808bc727023c3ae8e048a947030742dc82e973571777043c', '2026-11-11 19:06:59.965304+00'),
	('durable-map/slack_accounts/0010-tenants/0-column', 'e7b7e370549f0d97ad347c57856f43c80a14976d026cf40816d171089144e17e', '2026-11-11 19:06:59.968242+00');
INSERT INTO public.qm_schema_migrations (id, checksum, applied_at) VALUES
	('durable-map/slack_accounts/0010-tenants/1-column', '87e7f7d30f00287e0b059ab55642a25edd79f5470031be7d31fe4dcc9abe082f', '2026-11-11 19:06:59.969866+00'),
	('durable-map/slack_accounts/0010-tenants/0-stamp-column', '2cf301d8d41d6ec20fc8a001acf18f179a4388762330fb75fd8fa83e36823fad', '2026-11-11 19:06:59.969866+00'),
	('durable-map/slack_accounts/0010-tenants/2-keys', 'fae134a495ae53688def166ed1dd73e786f939b7defcb9e7d7ae2fed74d78ed4', '2026-11-11 19:06:59.974811+00'),
	('durable-map/slack_accounts/0010-tenants/2-references', '2a0b78ddc3014ae2202f0546ddbe7b7718600ee271c6495b633c21ffe8207da5', '2026-11-11 19:06:59.975403+00'),
	('durable-map/slack_accounts/0010-tenants/3-policy', '7ccea104923a8111bcdac4199b614f5c821f4ae376952050c8aa08b474a9a07d', '2026-11-11 19:06:59.977152+00'),
	('durable-map/slack_accounts/0010-tenants/2-tenant-policy', 'ed06c117cf2c8077a3285f3ba1120d5a5b76ae2c785f31245b5dfa8bdaf43d9c', '2026-11-11 19:06:59.977152+00'),
	('durable-map/slack_accounts/0020-claim-ids', '55befaed0b9076410ba6144458f10915f0979acb00257ff6ba97cc3f68e263cc', '2026-11-11 19:06:59.979901+00'),
	('durable-map/slack_accounts/0021-claim-tenants', '237ec501d60d1a19d5943a5277bfb2a689c146a06f0d2a4678c1855713ef1f8c', '2026-11-11 19:06:59.981107+00'),
	('durable-map/slack_emoji_catalog/0010-tenants/0-column', '3dab331514ee21b5a317ecafc88fc541f1d50f8550eb64992cb28215066cd506', '2026-11-11 19:06:59.982906+00'),
	('durable-map/slack_emoji_catalog/0010-tenants/1-column', '69eb1067518c5baf53f7f7359d03c8aad386069271b5307389ed938fdda19c8b', '2026-11-11 19:06:59.984528+00'),
	('durable-map/slack_emoji_catalog/0010-tenants/0-stamp-column', '1b4484ebb68adeeee2ee132bc38f10bf175760de3b8a26b1c23b44e33b3d7bc6', '2026-11-11 19:06:59.984528+00'),
	('durable-map/slack_emoji_catalog/0010-tenants/2-keys', '58d9931bed21506a912e7866ec56bf73d95b6feadae0ee484a78b8cc1ccc12b4', '2026-11-11 19:06:59.98919+00'),
	('durable-map/slack_emoji_catalog/0010-tenants/2-references', 'a5018fb6b6c7e5883b13718cecc850a8670f3b7800f46cf77bd4e42f4265ea80', '2026-11-11 19:06:59.989741+00'),
	('durable-map/slack_emoji_catalog/0010-tenants/3-policy', '4b5953a12e16f5e2d1a9b73a1953872b64c8589cbb1dfe7949c7e295792eb160', '2026-11-11 19:06:59.991627+00'),
	('durable-map/slack_emoji_catalog/0010-tenants/2-tenant-policy', 'd5b6983bd935e01a3d3b8e3a6ba40282b76ba05af248df219f71d71c45771a92', '2026-11-11 19:06:59.991627+00'),
	('durable-map/slack_emoji_catalog/0020-claim-ids', '00deb34b6a89f8dfaef9c056ec769b249893334ea1f019fce70cc0b3e6117488', '2026-11-11 19:06:59.994148+00'),
	('durable-map/slack_emoji_catalog/0021-claim-tenants', 'e478114ba395785cf3a6f698698ac015b7529d88c38cbc171664c5b8884775f2', '2026-11-11 19:06:59.995428+00'),
	('durable-map/slack_installation/0010-tenants/0-column', '0d1bce4deb3e556be551338e6b66f006bf5cc4929f058a0efcdd9dbe644b7222', '2026-11-11 19:06:59.996828+00'),
	('durable-map/slack_installation/0010-tenants/1-column', '3d75b669e4fcdcdf5b259155e8d2340acd3965d2fb90557a5fb63dd905d928f3', '2026-11-11 19:06:59.998542+00'),
	('durable-map/slack_installation/0010-tenants/0-stamp-column', '7b05822ea31194cc1075bb0bcdc57d89b3c1987fab5bd0ef530395a9a5ae61ed', '2026-11-11 19:06:59.998542+00'),
	('durable-map/slack_installation/0010-tenants/2-keys', '841ddfa242da046a4596ceaa0b1bdcf5e7526eac086f4faad77bf59fdc698238', '2026-11-11 19:07:00.003468+00'),
	('durable-map/slack_installation/0010-tenants/2-references', 'e0e543346c2968342cf95b911f7926f4844b31cbc4c3c3d57772872d9e9f2f89', '2026-11-11 19:07:00.004077+00'),
	('durable-map/slack_installation/0010-tenants/3-policy', 'cd50a304277b7a99f2d965b1bb7792ac8a097370462c09b4011775131fb1bc6e', '2026-11-11 19:07:00.005726+00'),
	('durable-map/slack_installation/0010-tenants/2-tenant-policy', 'acbcd501d820405a22d7213194fb8f9ebd2d70ac5c721fe0884eb3967b727afd', '2026-11-11 19:07:00.005726+00'),
	('durable-map/slack_installation/0020-claim-ids', '138773d9cb57fe6f95fa274684886b53f0f2809645a1e9398654c97e02ec67a8', '2026-11-11 19:07:00.00851+00'),
	('durable-map/slack_installation/0021-claim-tenants', '15e344b32fdd2039be66124a9ecb85b35cfc91680dc61a47f6659c68a5a0c2ca', '2026-11-11 19:07:00.009877+00'),
	('durable-map/slack_session_status/0010-tenants/0-column', '23f649a78297c49a2a3cf9c062b417e5e0d21223e51ffd56e6151edea03f9d25', '2026-11-11 19:07:00.010996+00'),
	('durable-map/slack_session_status/0010-tenants/1-column', 'b290eaa6c5989d45217a4a23a21cd6b147700faa18c95f176aedc3a3b3e5ad39', '2026-11-11 19:07:00.012996+00'),
	('durable-map/slack_session_status/0010-tenants/0-stamp-column', '726ffe5da2251f35e7b4bd865b82b4f394685720a4bdcb536dea3771785d0b35', '2026-11-11 19:07:00.012996+00'),
	('durable-map/slack_session_status/0010-tenants/2-keys', 'c9d78a04cfa3ae7689ebb432e095fd13cd6f028ca1f37b188de3e23634fa6ba9', '2026-11-11 19:07:00.018438+00'),
	('durable-map/slack_session_status/0010-tenants/2-references', 'f57a383e71d65dc717575c5e083fef3954d888dbb770993e404f9150dae5f10b', '2026-11-11 19:07:00.019095+00'),
	('durable-map/slack_session_status/0010-tenants/3-policy', '4691a3049e6d63bfcfa5ee4b9449a7b67587e75bda4207245514f8f785c1da11', '2026-11-11 19:07:00.021275+00'),
	('durable-map/slack_session_status/0010-tenants/2-tenant-policy', '84fe83a867180078a346878c45a5f82caf14971b1835205597284e22cbf5a006', '2026-11-11 19:07:00.021275+00'),
	('durable-map/slack_session_status/0020-claim-ids', '418c618117a4962171fa6a8c35b48a41eb2e7f2086bd8bb9a794b8195f90fd76', '2026-11-11 19:07:00.024198+00'),
	('durable-map/slack_session_status/0021-claim-tenants', '49640a62b34a66f7aadf17ca21f5c4f19468124220f5dfc158753910a1d5cec4', '2026-11-11 19:07:00.025715+00'),
	('durable-map/slack_staged_envelopes/0010-tenants/0-column', '44fd1367c596bf4ab946930a17fca6076a2591ebab6c9ea16c465510db855a6d', '2026-11-11 19:07:00.026853+00'),
	('durable-map/slack_staged_envelopes/0010-tenants/1-column', '7234aa65ea159015656e3b4ed51fb6cbcf4794f25c39f09d63c61a16d5b69d12', '2026-11-11 19:07:00.028538+00'),
	('durable-map/slack_staged_envelopes/0010-tenants/0-stamp-column', '1dc0160f3aab7ab8a14adec363fc18295d85e91fb5c69b421594c6b502327796', '2026-11-11 19:07:00.028538+00'),
	('durable-map/slack_staged_envelopes/0010-tenants/2-keys', '026165451282419ab7f3648cf75a6c1c267a071ff23b6455cc33b7b1a77c324a', '2026-11-11 19:07:00.033936+00'),
	('durable-map/slack_staged_envelopes/0010-tenants/2-references', '326fff69e810e203138a61f873e44fb0c7a2fa4c0517fe452ab07a4f4a64bdca', '2026-11-11 19:07:00.034707+00'),
	('durable-map/slack_staged_envelopes/0010-tenants/3-policy', 'b57c15b930a6dc0e457e7b102ffbdeece5db71dea498b11206c25df3148579cf', '2026-11-11 19:07:00.036801+00'),
	('durable-map/slack_staged_envelopes/0010-tenants/2-tenant-policy', '9c721ca3ed44b9c2cd72048cbbd1845af1878724cfee5d48c4e40a37ccbd7543', '2026-11-11 19:07:00.036801+00'),
	('durable-map/slack_staged_envelopes/0020-claim-ids', '5a9809482a9f511854609e464cba721fe0d3ce43d9be6bd9c0b38a5b814a488a', '2026-11-11 19:07:00.039646+00'),
	('durable-map/slack_staged_envelopes/0021-claim-tenants', 'db95d5c24c87cd08eb0b33b047c6a09ae7d56626e1dd011a7ceec490fbbe19cf', '2026-11-11 19:07:00.040777+00'),
	('durable-map/slack_task_acknowledgements/0010-tenants/0-column', 'cbcc1d6c70276b285ef409dc57eb24e625c93a6ccc680c0dd9c46e17005687cc', '2026-11-11 19:07:00.041931+00'),
	('durable-map/slack_task_acknowledgements/0010-tenants/1-column', '877aee46a74722bdf51a6379463dce9c13ab3738b43daad6802e6b044ec07762', '2026-11-11 19:07:00.043561+00'),
	('durable-map/slack_task_acknowledgements/0010-tenants/0-stamp-column', 'be801aa6a1b23b1c9af4b298efddf72866d9f665837468bb771951adf0ef9994', '2026-11-11 19:07:00.043561+00'),
	('durable-map/slack_task_acknowledgements/0010-tenants/2-keys', '644f98c2b144ecb43fe3f6cc6ab6060cf2ec1c8ce13520a2d9c78b15197ee9dc', '2026-11-11 19:07:00.04864+00'),
	('durable-map/slack_task_acknowledgements/0010-tenants/2-references', 'd9f58d11b1ae5464952ef2b22a58e18010f204f802dc63f571b90009904527ed', '2026-11-11 19:07:00.049202+00'),
	('durable-map/slack_task_acknowledgements/0010-tenants/3-policy', '1d29ad89e708e63262f69f349193fc8c11ddf28da62d3b75bb89463088e03076', '2026-11-11 19:07:00.05102+00'),
	('durable-map/slack_task_acknowledgements/0010-tenants/2-tenant-policy', '1c9ef2db8a19d8ac3a5a0172fd8169e25b9095245276b85c369359897e79e50a', '2026-11-11 19:07:00.05102+00'),
	('durable-map/slack_task_acknowledgements/0020-claim-ids', '0552b327a3ab6df8cd60881e2a61e48cda486948a41d987367f90b68dd1712c1', '2026-11-11 19:07:00.053486+00'),
	('durable-map/slack_task_acknowledgements/0021-claim-tenants', 'a21b01e8c6d2bf9f59bef59ee0e385966ef58ae8dbb574cbcb822346d4df7d9d', '2026-11-11 19:07:00.054519+00'),
	('durable-map/smolmachines_sandbox_bodies/0010-tenants/0-column', 'b7a934294ad591230a1ca6116bcd7a9d056ce95781e15c072eb39b6c28831c8b', '2026-11-11 19:07:00.055555+00'),
	('durable-map/smolmachines_sandbox_bodies/0010-tenants/1-column', '573ab9c90cf83ba031319d608604d7b335de8efb7983f5b4ab57d72814187b60', '2026-11-11 19:07:00.057187+00'),
	('durable-map/smolmachines_sandbox_bodies/0010-tenants/0-stamp-column', '655af21986a63f2c29a623154707d048835c329a9147b98395a638d9c21ae20a', '2026-11-11 19:07:00.057187+00'),
	('durable-map/smolmachines_sandbox_bodies/0010-tenants/2-keys', '22da85c2c68d8ee3e6b3b4fc270566f21deaa76f3488915b4391c6266e07ccf1', '2026-11-11 19:07:00.062512+00'),
	('durable-map/smolmachines_sandbox_bodies/0010-tenants/2-references', 'd877e906843ac393e5cf15837566514cfd1da21f9d327a11617aaa59e5fa8fd6', '2026-11-11 19:07:00.063288+00'),
	('durable-map/smolmachines_sandbox_bodies/0010-tenants/3-policy', 'b6e1694b72e2719594884b7019db50c2fe5b24fd3e6eb908386ace9449c6ba92', '2026-11-11 19:07:00.065372+00'),
	('durable-map/smolmachines_sandbox_bodies/0010-tenants/2-tenant-policy', '1f4b03b881de845de637fb2ed930080cfe07f5a3bc67266c77fbbf28ad47fe77', '2026-11-11 19:07:00.065372+00'),
	('durable-map/smolmachines_sandbox_bodies/0020-claim-ids', '3150d375eb1ad2d8b2f569560e503ff4fb05f5440d960f82ba7a37573cda8be5', '2026-11-11 19:07:00.068558+00'),
	('durable-map/smolmachines_sandbox_bodies/0021-claim-tenants', 'ac18b09c35b86305e220b1ba23270ba292df6723eba4c083aeb5c07dcb7cc1b4', '2026-11-11 19:07:00.070492+00'),
	('durable-map/soul_configs/0010-tenants/0-column', '470665fd03d58a7d95ea9c573d41d905b5d6b393ac9004b927d46bc4fd69d032', '2026-11-11 19:07:00.072043+00'),
	('durable-map/soul_configs/0010-tenants/1-column', '7ad97fc603ac69977847e012aed6c7542d8512ae5e858f5c2b272a9e67568135', '2026-11-11 19:07:00.073986+00'),
	('durable-map/soul_configs/0010-tenants/0-stamp-column', 'c3e0138b05316fd3835b20ff5cd0568703de967695c3fdedc42d8fa1091f8d57', '2026-11-11 19:07:00.073986+00'),
	('durable-map/soul_configs/0010-tenants/2-keys', '7043ea776b881e2eac9e7b3ae79d0a27aa332eafa87a0e9157d18b89e787756a', '2026-11-11 19:07:00.079357+00'),
	('durable-map/soul_configs/0010-tenants/2-references', 'a15e5c490f214035f66c946a3fde9fc6c13b11a27846a4a8eabc9267cf611d06', '2026-11-11 19:07:00.07991+00'),
	('durable-map/soul_configs/0010-tenants/3-policy', '63e1f2fd5015e56ed01b123da8592391cbe8e15d7c607fa5754aee41cc38f954', '2026-11-11 19:07:00.081855+00'),
	('durable-map/soul_configs/0010-tenants/2-tenant-policy', '4f200c2b331d9aeab1e51a58a2bb8bc54dfe64c2961c4bfe5086d2c5e11b8927', '2026-11-11 19:07:00.081855+00'),
	('durable-map/soul_configs/0020-claim-ids', 'e0b2df08c11293b14a4a72984fc86f947ffe59fed78ee9888a98a311e3c5c773', '2026-11-11 19:07:00.084238+00'),
	('durable-map/soul_configs/0021-claim-tenants', 'c7b667330f8013bf897a13f2d22a701d7913a0c4ece25fe4cb258b52d58caa5a', '2026-11-11 19:07:00.085151+00'),
	('durable-map/soul_history/0010-tenants/0-column', 'aeed5df84eb30aab57e7be65ae6c464f9aaec688fc458ab81c204923475983ca', '2026-11-11 19:07:00.086206+00'),
	('durable-map/soul_history/0010-tenants/1-column', '204f9cd9abab198c8d41c07694d52150113a7058a4d2bfb634bc01ce7b9ce99e', '2026-11-11 19:07:00.087902+00'),
	('durable-map/soul_history/0010-tenants/0-stamp-column', 'cb0203e7aee3d72725363dcdfee28b04e800ba259b95914f0414669bdbb8b63f', '2026-11-11 19:07:00.087902+00'),
	('durable-map/soul_history/0010-tenants/2-keys', 'c8cc5ae18157cff2746b822d62df69748b5905e0740201bb4f582016bd0e2fd6', '2026-11-11 19:07:00.093387+00'),
	('durable-map/soul_history/0010-tenants/2-references', '1673f3f72f3523eac3dcc978edeef99eaf270ed12f6751b917055b66afc9d624', '2026-11-11 19:07:00.094109+00'),
	('durable-map/soul_history/0010-tenants/3-policy', 'c3febf4e1aedf271b36372b18889e0ad41272a0811739f72855ee08cf9279609', '2026-11-11 19:07:00.096544+00'),
	('durable-map/soul_history/0010-tenants/2-tenant-policy', '4c25a99635db6c5a23815aa3c51fcafec20e13ea345fffae753e76b9068813ee', '2026-11-11 19:07:00.096544+00'),
	('durable-map/soul_history/0020-claim-ids', '9ba83f6d65e2446deec2360abb1de60b519725f5eaa91da7faa742867ae3345c', '2026-11-11 19:07:00.10041+00'),
	('durable-map/soul_history/0021-claim-tenants', 'cd7cfec4717730fdd61c1aa35b9a7aa006a590bbdb346c5e3a3ec808d18dba9d', '2026-11-11 19:07:00.10202+00'),
	('durable-map/spend_limit_configs/0001', '526dfb125254549e65e5b02045cd8e165ce0267a1497ec210b8d541df749b558', '2026-11-11 19:07:00.103231+00'),
	('durable-map/spend_limit_configs/0010-tenants/0-column', 'c3dfdb545f9a6d6420d1c2c817f9902b8e016e459edb59ffeca3d75a4124a10c', '2026-11-11 19:07:00.107802+00'),
	('durable-map/spend_limit_configs/0010-tenants/1-column', 'cfcdbf1de9fd878f1e13dd6b87ebfefed36ad5d716b649f517b43cbae4dfc4ba', '2026-11-11 19:07:00.109336+00'),
	('durable-map/spend_limit_configs/0010-tenants/0-stamp-column', 'c8e39dab094d8e09c3bdd5da52c0f0e2b7dd68108a0b9d44e09b9fc24aba5b99', '2026-11-11 19:07:00.109336+00'),
	('durable-map/spend_limit_configs/0010-tenants/2-keys', '33814b7f424f7b6257fd757f36b839833ee95e7a13916adefdadb699604cae36', '2026-11-11 19:07:00.114611+00'),
	('durable-map/spend_limit_configs/0010-tenants/2-references', 'fee57eb4ad5f7c07f9b37f43c5f8c4c0e82a26acca9ade0b1bf5ac63e551ff02', '2026-11-11 19:07:00.115158+00'),
	('durable-map/spend_limit_configs/0010-tenants/3-policy', 'e0826e29a58d4b8b37e1663cf16ce67c38f8f062d93ebb576181b7b6f6614a1d', '2026-11-11 19:07:00.116983+00'),
	('durable-map/spend_limit_configs/0010-tenants/2-tenant-policy', '332b8167a8de18e8f357ed62ea5a0a01ff012844e75c864169b73ab93ce841ba', '2026-11-11 19:07:00.116983+00'),
	('durable-map/spend_limit_configs/0020-claim-ids', '00b3e7c2e1dc5b12e273e20665d943fefea45fb7dd912a41837802adcac9d382', '2026-11-11 19:07:00.119394+00'),
	('durable-map/spend_limit_configs/0021-claim-tenants', 'fd34022459608f3339ba480c643b84afe070911c19618a5045e767b54b4cfb76', '2026-11-11 19:07:00.120337+00'),
	('durable-map/sprites_initialization/0001', 'e987bfe4bd5996dcee71ab6963e051d5192325c6d06a71f4e9da7621df4a50a0', '2026-11-11 19:07:00.121275+00'),
	('durable-map/sprites_initialization/0010-tenants/0-column', '321805f8b44a8671a4dbd402cd0227130f7c6e798d9289dde7a112a0b1c7e553', '2026-11-11 19:07:00.125107+00'),
	('durable-map/sprites_initialization/0010-tenants/1-column', '6a4d36f951eecb941c336413ea99b4685e50b0ef0308612c3a1c3b6bc58a5e2f', '2026-11-11 19:07:00.126454+00'),
	('durable-map/sprites_initialization/0010-tenants/0-stamp-column', '1d8278d2df80c5c30c39084f0f5eb288c2e5046179bf05ac6e3f9b1fd6f465df', '2026-11-11 19:07:00.126454+00'),
	('durable-map/sprites_initialization/0010-tenants/2-keys', 'b8580cbdd8325f67a1b631e9d85d74b720d1f06a8bf2e5fa3966bc9799610da0', '2026-11-11 19:07:00.130827+00'),
	('durable-map/sprites_initialization/0010-tenants/2-references', '4c0805559e14a0ac5b1df497a2105ae9fed1e066935ba0f78232934003fc0de3', '2026-11-11 19:07:00.131548+00'),
	('durable-map/sprites_initialization/0010-tenants/3-policy', 'ca1e253bd670cb7b7bdcec3806d8ce89db061f382d947f52ad6fb0805cd8824e', '2026-11-11 19:07:00.133362+00'),
	('durable-map/sprites_initialization/0010-tenants/2-tenant-policy', 'f9d391471f8a688ccd5549fa1eabce785d0398b9d3e46754969943db2f504873', '2026-11-11 19:07:00.133362+00'),
	('durable-map/sprites_initialization/0020-claim-ids', 'e6899e3164b4271e03b02cc01ee6188fe2762ebb6d7296512815f626febfd5ce', '2026-11-11 19:07:00.136452+00'),
	('durable-map/sprites_initialization/0021-claim-tenants', 'dd8a1d3991c9e9c84d72557347518370c9042d2a857edec949683ac3066f93d1', '2026-11-11 19:07:00.137563+00'),
	('durable-map/suggested_activity_profiles/0010-tenants/0-column', 'd76e40682f920e29a9d0c401d39b30f47e7513df51dbbd16f2e5157fd312704c', '2026-11-11 19:07:00.13854+00'),
	('durable-map/suggested_activity_profiles/0010-tenants/1-column', '88bc48a7f34472f8d31d0ee6a0fe7141506bd8fa11e33e69f294a45d5ca2550a', '2026-11-11 19:07:00.139903+00'),
	('durable-map/suggested_activity_profiles/0010-tenants/0-stamp-column', '5322dd5fb89b254ada0dbf0e99d86c6588cfe96d0a20b240f303c858f37c6c63', '2026-11-11 19:07:00.139903+00'),
	('durable-map/suggested_activity_profiles/0010-tenants/2-keys', '1765e0af2a8d133afe6dfa59e887a995ab3e81a2d9045e5b4c329a48e278c227', '2026-11-11 19:07:00.144559+00'),
	('durable-map/suggested_activity_profiles/0010-tenants/2-references', 'bf8b234e5474779d532d984a2ec6d332b4afed8a615c2e042b17cfb03007c9d3', '2026-11-11 19:07:00.145209+00'),
	('durable-map/suggested_activity_profiles/0010-tenants/3-policy', '33c9698206d85b5969bde1b234e06d3df45358858bba6af33945af8f625eb68b', '2026-11-11 19:07:00.146763+00'),
	('durable-map/suggested_activity_profiles/0010-tenants/2-tenant-policy', 'ab43c62df7f92ae95b337bffb7d6ba61eacfea3ec5e857fa11471718ea7c3051', '2026-11-11 19:07:00.146763+00'),
	('durable-map/suggested_activity_profiles/0020-claim-ids', '5bcd81e780e6039608b004a39d75e37ba6af1907b60ad756b5393e09a043d44c', '2026-11-11 19:07:00.149193+00'),
	('durable-map/suggested_activity_profiles/0021-claim-tenants', 'c20539ec0ba8573b10cac7cc177494f7340105d0a3909fbe0c4476a83297fe06', '2026-11-11 19:07:00.15018+00'),
	('durable-map/superserve_config_epochs/0030-process-level', '3cdc38ac6b3dfff5222a54f6fd28cd7a49782afeae68df91a1cbc8e51bd92931', '2026-11-11 19:07:00.151131+00'),
	('durable-map/superserve_sandbox_bodies/0010-tenants/0-column', 'a3a645c5b5dd57bac0933e65943768e0555f65a8858bc17445fc8e8ec5d8f86d', '2026-11-11 19:07:00.152269+00'),
	('durable-map/superserve_sandbox_bodies/0010-tenants/1-column', '38798b366f9b582693d0013fb1b902f43e3f55bab8898506f0966aef8ed128c1', '2026-11-11 19:07:00.153547+00'),
	('durable-map/superserve_sandbox_bodies/0010-tenants/0-stamp-column', 'e6b904b8b932c4f1e0343fa03a882f663564aa07b66729497c0d3e1299584da4', '2026-11-11 19:07:00.153547+00'),
	('durable-map/superserve_sandbox_bodies/0010-tenants/2-keys', '46595e6bd7a9e499c2538af655c17bb97fb6e33d3852dd344029d375ff88f1b6', '2026-11-11 19:07:00.15843+00'),
	('durable-map/superserve_sandbox_bodies/0010-tenants/2-references', '4124032a2feeb1ef2c8266a4b0aacdaa089b360ac5fd4079b16de9a03eaa6fef', '2026-11-11 19:07:00.159253+00'),
	('durable-map/superserve_sandbox_bodies/0010-tenants/3-policy', '6dad005428ca05d6a168f13a2028b63e94bbb0dffbd5413c8018c7bfd32487bc', '2026-11-11 19:07:00.161615+00'),
	('durable-map/superserve_sandbox_bodies/0010-tenants/2-tenant-policy', '31f5845509073a26654b3a4d197828f91f25e44879f4566ec044087279330176', '2026-11-11 19:07:00.161615+00'),
	('durable-map/superserve_sandbox_bodies/0020-claim-ids', '9b213911585f21688f869d35716e18c5dc4f54ce513c83c38ddd2051f5a3e219', '2026-11-11 19:07:00.165094+00'),
	('durable-map/superserve_sandbox_bodies/0021-claim-tenants', 'f7ce8c2f88023201e480482037eb40e29109986ddcf65a7078ed314285037dd3', '2026-11-11 19:07:00.167105+00'),
	('durable-map/swarms/0001', '06c668b8a0fe2334046b16835e71facb31ef6324bab697acfd0f2a428cf8babe', '2026-11-11 19:07:00.16869+00'),
	('durable-map/swarms/0010-tenants/0-column', '89eb30819f9ccd84abac6e6445daf763c927040e815eeae99c3968c0ad0dfc65', '2026-11-11 19:07:00.174447+00'),
	('durable-map/swarms/0010-tenants/1-column', 'bc63a6f33ee486d5f3946dd054cfa25f83f4c1679fe2a44f86b991e12709de80', '2026-11-11 19:07:00.176254+00'),
	('durable-map/swarms/0010-tenants/0-stamp-column', '13b43cafff796978e1c773263a1e31a589c4272954c87fe03d5977e506981efa', '2026-11-11 19:07:00.176254+00'),
	('durable-map/swarms/0010-tenants/2-keys', '25e02990be8e640501ac3b52e7788d353b681de0231ccaae2dcd1255823cd467', '2026-11-11 19:07:00.18324+00'),
	('durable-map/swarms/0010-tenants/2-references', '3403f0a8e0301ff29550866e2dfe1ed7d9a435491e9c2d3611a873864efb07d8', '2026-11-11 19:07:00.184474+00'),
	('durable-map/swarms/0010-tenants/3-policy', '9d688301b50f4c2d36bfb4eee516d4966e449d4c9c05f9c7843f3af4dba4843b', '2026-11-11 19:07:00.186579+00'),
	('durable-map/swarms/0010-tenants/2-tenant-policy', '487056ad9f6dc1a2f6aa311bae306a69314d227ba721eaed58062c15e5ce20cd', '2026-11-11 19:07:00.186579+00'),
	('durable-map/swarms/0020-claim-ids', 'adc0e2d9f13290887bca14f356ad6396622710c90f22018cb6c353589a80af5d', '2026-11-11 19:07:00.189834+00'),
	('durable-map/swarms/0021-claim-tenants', '74782b63d290b40292eba1704c34e9079baaaf6785e7c1297b9bbd9f659bd8d2', '2026-11-11 19:07:00.191194+00'),
	('durable-map/swarms/claim-pending', '754e21e8e05dddf06fb60ef7a74d024d1acba2f3d44ca0f4734bde6e2f52b2b3', '2026-11-11 19:07:00.192299+00'),
	('durable-map/swarms/claim-tenants-pending', 'bd34d50d9ebfd5d9d600b5c6e9e18816c0a0d4e970c9da52b05f5eff35ab24b7', '2026-11-11 19:07:00.19331+00'),
	('durable-map/swarms/lookup-pending-drop', '73b853b6b1f937076c35ccc041a7d0b9677f93078402956b2fe85cb07eb4edcb', '2026-11-11 19:07:00.194512+00'),
	('durable-map/swarms/lookup-pending-hash', '2ef7efc86dbe12da3a19fc4b7016155a964bf364b28c907489287456919ff422', '2026-11-11 19:07:00.197974+00'),
	('durable-map/swarms/select-pending', '2fc4854407c8b8a0f0fc8d8982508164b03ee36a545beece349c379549e84d84', '2026-11-11 19:07:00.204265+00'),
	('durable-map/swarms/stats-pending', 'bc2f52d2abd272e95fc41a0ea3649aa5758bd7dfcbc9de666a3b7d097aa9377c', '2026-11-11 19:07:00.204805+00'),
	('durable-map/triggers/0001-drop-recipient-consent', '690a465b166e66765bd18fc38375020f8b9adbc3d503e384e307d2e02c00c320', '2026-11-11 19:07:00.206856+00'),
	('durable-map/web_ui_state/0010-tenants/0-column', '15c557213fec3feb4fc532215058b52a4b1fee8d866a56336512a8da3fef5ef3', '2026-11-11 19:07:00.208928+00'),
	('durable-map/web_ui_state/0010-tenants/1-column', '7d8847f473af5ef33480cf1f6d9615d0a017f311a73047693d52df139b805ef5', '2026-11-11 19:07:00.210788+00'),
	('durable-map/web_ui_state/0010-tenants/0-stamp-column', 'e83a89069a9b36f9037b36c4479c5bc6cb4d9783a7f1877a2e9f96d3227fb5e1', '2026-11-11 19:07:00.210788+00'),
	('durable-map/web_ui_state/0010-tenants/2-keys', '5deb1474f4929e7b59292caabf5171675d147b5c76a0f04883f077a688552b9e', '2026-11-11 19:07:00.215715+00'),
	('durable-map/web_ui_state/0010-tenants/2-references', '84d3092ca8ba6c1730f8705e1cd2fe86606e9e3b202e02f1c6b961125470e07c', '2026-11-11 19:07:00.216426+00'),
	('durable-map/web_ui_state/0010-tenants/3-policy', 'dbff9684c76f30dc63572a41854d2bb304481bb4ea015218db994a2f5ba71359', '2026-11-11 19:07:00.218563+00'),
	('durable-map/web_ui_state/0010-tenants/2-tenant-policy', '68732b2bf80624ecc313ae609a520280203b244a447559c7103f72f664fc7444', '2026-11-11 19:07:00.218563+00'),
	('durable-map/web_ui_state/0020-claim-ids', '41ef3188fc5b915d1cebb99a06e567c25ce8022ecb632e094373919464ee21fc', '2026-11-11 19:07:00.221585+00'),
	('durable-map/web_ui_state/0021-claim-tenants', 'd592e5652822e477625736da598e8748f28cfce0271d37f3250574cae0e7e6ff', '2026-11-11 19:07:00.222652+00'),
	('durable-map/webhook_history/0010-tenants/0-column', '8742854bf3476ce0ddd0aac04e1972670539f026622a0d85fc2f7298b2d552d4', '2026-11-11 19:07:00.224298+00'),
	('durable-map/webhook_history/0010-tenants/1-column', '518a455e0dce75725eb946de759db73cd40634ef048c720a4d3804d30c9b00a0', '2026-11-11 19:07:00.225854+00'),
	('durable-map/webhook_history/0010-tenants/0-stamp-column', 'a28e8a862f32eaac1c0a93522fd79b101f8f730551019780b0b12a8496de6fe9', '2026-11-11 19:07:00.225854+00'),
	('durable-map/webhook_history/0010-tenants/2-keys', '38297ad75f9dccdcb3b918b461ea3772c2f6b6913cd0a53aafe89059de2cc77f', '2026-11-11 19:07:00.231182+00'),
	('durable-map/webhook_history/0010-tenants/2-references', '0fc79d7a3848b98a70464da27317b0094cf595bd8533690ce3efebedff98789f', '2026-11-11 19:07:00.231861+00'),
	('durable-map/webhook_history/0010-tenants/3-policy', 'd7f6533824f64c68cefd412ae585ffd3e5bbd1e821d64324164d8dfa0a1e870f', '2026-11-11 19:07:00.234327+00'),
	('durable-map/webhook_history/0010-tenants/2-tenant-policy', 'd86e3d90025f8fe1dcafb405a7509fa74abab37009ae3309ae1ad9c264b20bb6', '2026-11-11 19:07:00.234327+00'),
	('durable-map/webhook_history/0020-claim-ids', '5f401b25f729b09bb4a5d5ced35715f05b28216ec9d31fa05662a21561711a2f', '2026-11-11 19:07:00.237628+00'),
	('durable-map/webhook_history/0021-claim-tenants', '2e4ef364e042668a4f334bda6c3dd7a4444ad70ed857f7c6318a20127df74190', '2026-11-11 19:07:00.239625+00'),
	('durable-map/webhooks/0010-tenants/0-column', '79c9e6d442cae78683f6521287c750e2c4f678e3ae608574839c73f3d30dabae', '2026-11-11 19:07:00.241076+00'),
	('durable-map/webhooks/0010-tenants/1-column', '9513ccb541c37f90380eb9f967a69247474f9ce77e655f07e194b06527361f22', '2026-11-11 19:07:00.242448+00'),
	('durable-map/webhooks/0010-tenants/0-stamp-column', 'd9443a0e1855917cf7e55dedaa93e670c469235872492db4652b57ed87598e4e', '2026-11-11 19:07:00.242448+00'),
	('durable-map/webhooks/0010-tenants/2-keys', '80a9d592b39c3d363b01fa7ecfc84f3aa1e8753950dc10cbeb2dae91c0e88669', '2026-11-11 19:07:00.247189+00'),
	('durable-map/webhooks/0010-tenants/2-references', '5523807929fef5491e22830172e90d4e096109f32d147dfe7be99a178f79017a', '2026-11-11 19:07:00.247883+00'),
	('durable-map/webhooks/0010-tenants/3-policy', 'ff5bdfc112dbc1846dd0bd23c6d4e8f084a42063e258e4b232629dc71992c671', '2026-11-11 19:07:00.250498+00'),
	('durable-map/webhooks/0010-tenants/2-tenant-policy', 'f25a53567c25510e4b7dd3d7cf09978b2fb22a5ece619bd7d9c90620d0bfd6d8', '2026-11-11 19:07:00.250498+00'),
	('durable-map/webhooks/0020-claim-ids', '586bb5d7c1a8622cf0f75cd0f24dcf29e073c2f7278a686570bec0486bd337f5', '2026-11-11 19:07:00.253401+00'),
	('durable-map/webhooks/0021-claim-tenants', '08f5c91e819b5d82b22e61ca1b2448c14f329b1a98ee570dc1ce84114a0bfd38', '2026-11-11 19:07:00.254474+00'),
	('durable-map/webhooks/claim-ownerscopeid', '1325a1b391004f0f57292352a9eb9bb75bc53b23527b64ddb6149079028c0555', '2026-11-11 19:07:00.255322+00'),
	('durable-map/webhooks/claim-tenants-ownerscopeid', 'b4ab61169e632f8584175e0a83199ee054cfb7f2884604d0a4bea97c4779b57c', '2026-11-11 19:07:00.256127+00'),
	('durable-map/webhooks/lookup-ownerscopeid-drop', '1661691fa2024faa4bc1c713d6ef00b9285d84fa36ed0a6427843dfa6ce22927', '2026-11-11 19:07:00.257122+00'),
	('durable-map/webhooks/lookup-ownerscopeid-hash', '0f72885639dbc0ea755bc4f42a4edb0fb2fe34ae486bba6b1f68965a5305c539', '2026-11-11 19:07:00.260559+00'),
	('durable-map/webhooks/select-ownerscopeid', '8a21c4276fc53492b23562c5eb76db6b91527a0acaae648d1e112727dd048c47', '2026-11-11 19:07:00.267052+00'),
	('durable-map/webhooks/stats-ownerscopeid', '71e358b93e8e66ccb60553c8ad576dc97d11bf2e73e6eab99bb47c42870200d4', '2026-11-11 19:07:00.268153+00'),
	('durable-map/webui_model_configs/0010-tenants/0-column', 'ab97f87fcdd04079c08fd463534cfe50429e07c0d83f463e38e47cfae0d85f0e', '2026-11-11 19:07:00.27015+00'),
	('durable-map/webui_model_configs/0010-tenants/1-column', 'c28db4e46a8054c0bcf95c7014639c1f5472a4e945fbe776d518cd3c3c8e86f0', '2026-11-11 19:07:00.271761+00'),
	('durable-map/webui_model_configs/0010-tenants/0-stamp-column', 'dfa2e1a093fc230310b3c0ce71b3c07db4cccc523d8541452253e51cb5057a47', '2026-11-11 19:07:00.271761+00'),
	('durable-map/webui_model_configs/0010-tenants/2-keys', 'a6338ddd7759d0253f6f59882463bddd1f62332952ad51843b68fd11c311ebf6', '2026-11-11 19:07:00.276698+00'),
	('durable-map/webui_model_configs/0010-tenants/2-references', 'fd7b444bd6c4e10a5ba8f9f63ce51aa935fb8b52bb17372f3893401ac412975d', '2026-11-11 19:07:00.277384+00'),
	('durable-map/webui_model_configs/0010-tenants/3-policy', 'c5fbbb50b3250b4cb9b5c5c51251fb4a15f9b715fd00124d3ee864f9dc91371a', '2026-11-11 19:07:00.279317+00'),
	('durable-map/webui_model_configs/0010-tenants/2-tenant-policy', '170ec8731aaf082200354b34ad51a0703f17bb881b3222d924979db1be50b4b3', '2026-11-11 19:07:00.279317+00'),
	('durable-map/webui_model_configs/0020-claim-ids', 'd71357625f793fa1e9543307dd1a7856d08de66535c54533b4d229b2e29b2608', '2026-11-11 19:07:00.282418+00'),
	('durable-map/webui_model_configs/0021-claim-tenants', '0b37aa5d6393916e09179c40430c126d09fcd7c3502551e69c9bf68220d5338e', '2026-11-11 19:07:00.283914+00'),
	('environments/store/0002-tenants/0-column', '634a7d4e93c2b5616c73d57f1b92c935c61e74b72678766a2d9ac2cfa90d6f74', '2026-11-11 19:07:00.285245+00'),
	('environments/store/0002-tenants/1-column', '7f4e34bde1dbbe8e1ccbaa9f97dc2688de742b60cc22630209839e8b0531c9f6', '2026-11-11 19:07:00.28774+00'),
	('environments/store/0002-tenants/0-stamp-column', '8818ed1c25c029898b96338dc70517db42d4c7a9f8e5ef819e7124fa73cc6481', '2026-11-11 19:07:00.28774+00'),
	('environments/store/0002-tenants/2-keys', '24baf25a85fa67c9cf8377d91e3fa006a8d3f7b28bf33962edf09f326094097f', '2026-11-11 19:07:00.296782+00'),
	('environments/store/0002-tenants/2-references', 'ee19029cb9262e28912af6e25f00be6263cd3a0a14a5ad0b0b1789d39d8a4d7f', '2026-11-11 19:07:00.297439+00'),
	('environments/store/0002-tenants/3-policy', '140ef672a4417b54bec4585acd0552c3312d30a3ac0d62ec672b9896fa06b9a9', '2026-11-11 19:07:00.301233+00'),
	('environments/store/0002-tenants/2-tenant-policy', '2c33d0fe0baaab70fddc39fa25a0be400b4342b484751ad381abec6acb365439', '2026-11-11 19:07:00.301233+00'),
	('files/artifacts/0003-tenants/0-column', 'b09922cc046ff6504f92bd72749626be31037b373c3f046ec8efbd895a4144e3', '2026-11-11 19:07:00.306714+00'),
	('files/artifacts/0003-tenants/1-column', 'c53e242c5861bafe759f7cd26a65201fbb32220807adf836c3f5fd1e322b1caf', '2026-11-11 19:07:00.309661+00'),
	('files/artifacts/0003-tenants/0-stamp-column', 'ec4a9122e412f006b275b89f06962b803aa8db081b40b2dc7ead9bf8994afc4a', '2026-11-11 19:07:00.309661+00'),
	('files/artifacts/0003-tenants/2-keys', 'a0da8389e92d63f821e731758ed2a224328f7df6d8a1003a1b03b5108a1a3e78', '2026-11-11 19:07:00.32061+00'),
	('files/artifacts/0003-tenants/2-references', '7600f51bf2763217afdc608ea492d1f1ae25bd1ecceed01e3b294b7f81125f19', '2026-11-11 19:07:00.32123+00'),
	('files/artifacts/0003-tenants/3-policy', 'c98ea4a4b0e9590299592efe62dd9ac2e4fe2a6bb42ab57184770ccc36f1500c', '2026-11-11 19:07:00.324201+00'),
	('files/artifacts/0003-tenants/2-tenant-policy', '68680f805c5a53f598a95f86892ec3f63181b4989e7bf95c39fdd618efda21d3', '2026-11-11 19:07:00.324201+00'),
	('files/uploads/0001', 'f3d699810703e9323f42978510407cd0023c8dc164600a5f5ccd8c339f0841c0', '2026-11-11 19:07:00.328132+00'),
	('files/uploads/0002', 'c9a204a21fc0f2a978dd90bbdb5d72497383c82956fd171da66af62ca8a40b42', '2026-11-11 19:07:00.335796+00'),
	('files/uploads/0003-tenants/0-column', 'a435c9eda71c22ef8903760cf3024294e7a79663800fa0ad457606931a8f3e0b', '2026-11-11 19:07:00.338445+00'),
	('files/uploads/0003-tenants/1-column', 'a02c8533f09dd9da09f7fb901eca1175e5820ef5bae9e3699a0b35316b1ebf4c', '2026-11-11 19:07:00.339915+00'),
	('files/uploads/0003-tenants/0-stamp-column', 'd0abb1de90175c01b2f58637d44201e33eeda5d15824dd9b09d0c311cdcae302', '2026-11-11 19:07:00.339915+00'),
	('files/uploads/0003-tenants/2-keys', 'ed046c6bfa25f0c222895c0d98ab62ed222509a311643011ed42d540af0687b3', '2026-11-11 19:07:00.344354+00'),
	('files/uploads/0003-tenants/2-references', 'c71a430aab30a54f45f8ce26f45552ce510bf7289f7567479a15ef2dbcf3be68', '2026-11-11 19:07:00.345035+00'),
	('files/uploads/0003-tenants/3-policy', '00ae5d0c52acf2533d42112fb4f99869ada79eedc081f60f63de2eedf39d5a2c', '2026-11-11 19:07:00.347178+00'),
	('files/uploads/0003-tenants/2-tenant-policy', '067ae01cac8fa10685cd6c73f162040e3be811c154a2b6c24f42424faaa7c84d', '2026-11-11 19:07:00.347178+00'),
	('files/uploads/0004-claims', 'ca8c6edb18bd9d8628958c9d705f617fdcae8309d8f94c5de81abe840ff9280d', '2026-11-11 19:07:00.349879+00'),
	('memory/facts/0002-text-hash', 'c7ca6a779272265e9201ccf0430ec1ca98836701b2eff508b08af22e008aadb5', '2026-11-11 19:07:00.351481+00'),
	('memory/facts/0003-tenants/0-column', 'c05c1cc686de223438acea786ff29a3354aaafe6c5647aa3fed80ea6e013f3d0', '2026-11-11 19:07:00.353236+00'),
	('memory/facts/0003-tenants/1-column', '07348aef73d67dfb05768ebcd72988c655edeb3f968c017e406a6be8fd1a9271', '2026-11-11 19:07:00.354823+00'),
	('memory/facts/0003-tenants/0-stamp-column', '35fae1375a42a043ce55ced487f5f9ee69e65c13e79fbb4f6591d87e0ed13de8', '2026-11-11 19:07:00.354823+00'),
	('memory/facts/0003-tenants/2-keys', 'a9df904ce1766c73740275be058c493cbf498cb31c5f8cd826fff0cbdecf8b18', '2026-11-11 19:07:00.360747+00'),
	('memory/facts/0003-tenants/2-references', '212f01180a88ffb8e3a3981278e653472329a3922d6f178c3f79bc943c5e9577', '2026-11-11 19:07:00.361365+00'),
	('memory/facts/0003-tenants/3-policy', '7e086d2bad9c881134b4a83d9950b08447070d75d2ed80308e0b665dd975cb40', '2026-11-11 19:07:00.363101+00'),
	('memory/facts/0003-tenants/2-tenant-policy', '8f8f0afca41cafb58258f625d472ab22c0b0b340d6128505c5c8929226d192a4', '2026-11-11 19:07:00.363101+00'),
	('memory/vectors/0001-vector-extension', '6621ce857a7dd926227687333cd49723df73909c42a9c0b76c5dce6840e03d3c', '2026-11-11 19:07:00.366004+00'),
	('memory/vectors/0002', '9ac35a0030e6d7d272fc8b0f52416c9d5ccb7e9f8224e166ff01b115aebe6801', '2026-11-11 19:07:00.37211+00'),
	('memory/vectors/0003-sketch', 'd704d8691a365ffac4d4e67d764fadfaaaf2d9486432cdd8a86838ac8a4b30a8', '2026-11-11 19:07:00.376741+00'),
	('memory/vectors/0003-tenants/0-column', '6dfec4b9507e5c002163821c012e0cb4f15962a83320876b086f6a66103e7d09', '2026-11-11 19:07:00.378457+00'),
	('memory/vectors/0003-tenants/1-column', '397523caa64d911c3a563a1ea6eeb9768429f7af41ae5ed54189e791ac0b8aa5', '2026-11-11 19:07:00.379643+00'),
	('memory/vectors/0003-tenants/0-stamp-column', 'c835322de9ad9c6f1b857ea5b7b6cb5afc871f92a855d4102895b03b09f69a95', '2026-11-11 19:07:00.379643+00'),
	('memory/vectors/0003-tenants/2-keys', '5df499bfa977de9d105e30e2c3659be1f21f82251e5544713449ce14a330a1bc', '2026-11-11 19:07:00.384408+00'),
	('memory/vectors/0003-tenants/2-references', '583168acfde2ac0498954f6a26b5455fa3aacf4ccf00ebe3b52c35285f854134', '2026-11-11 19:07:00.385188+00'),
	('memory/vectors/0003-tenants/3-policy', 'dcff5bf793b07a6537cb2122145d8169b447281d0169d34994d05ff86981f9da', '2026-11-11 19:07:00.387158+00'),
	('memory/vectors/0003-tenants/2-tenant-policy', 'd36872c07e638d0385c607bde6381c2c7103fa2dd08d1b0b381f749f6ee54f21', '2026-11-11 19:07:00.387158+00'),
	('memory/vectors/0004-claims', 'fe36c342d2e27a752a6ffde3c73a1916d5f837e2592c2e836999dd2ae2a3546a', '2026-11-11 19:07:00.389892+00'),
	('memory/vectors/0004-sketch-backfill', '8bbeac5d366c45cb69452e753f9b82b3c6f9762413a906879e55aa02de6f7627', '2026-11-11 19:07:00.39192+00'),
	('memory/vectors/0005-claim-tenants', '5e358e723c6ccad025bf6f915d2d8224d59c559f2dd11715b9f376e03b30d29b', '2026-11-11 19:07:00.392442+00'),
	('processes/registry/0005-tenants/0-column', '052e6ca48bcc946c98be76cb54804a9f22719e094d522a9b831fd517de6fcf6a', '2026-11-11 19:07:00.39388+00'),
	('processes/registry/0005-tenants/1-column', '1916b1aeca3251c583b476acc5a6a00e27aced4c50b65e27a9850aed300bdb8f', '2026-11-11 19:07:00.395289+00'),
	('processes/registry/0005-tenants/0-stamp-column', '27ec5839dba7501e4a44580a4a6ab4ca8072484f47e172f9c546c6f2e0bb3f63', '2026-11-11 19:07:00.395289+00'),
	('processes/registry/0005-tenants/2-keys', '6f3bf01382b77b1d3204761999c5c47790a83fbcaf96b5199e99bbb0f0eee7eb', '2026-11-11 19:07:00.399584+00'),
	('processes/registry/0005-tenants/2-references', '40b3c4df609aec1997e13edf34199942e78faa045a83ec3fc6c0ac8d70656e8d', '2026-11-11 19:07:00.400128+00'),
	('processes/registry/0005-tenants/3-policy', 'c93e9b7d9ad5348888c459ade911bc79038f23d5eaa93d7e347038d3a0980574', '2026-11-11 19:07:00.401916+00'),
	('processes/registry/0005-tenants/2-tenant-policy', '7ccd2d5b33606a1d7ced564a1f3d234b8d933e1c9b7e83c85d853cffba04757a', '2026-11-11 19:07:00.401916+00'),
	('processes/registry/0006-claim-expired', '3ba2a9d92a6031d242b6d31000489f41a0d81987e8b1e5a68bbc7638e025da13', '2026-11-11 19:07:00.404632+00'),
	('ratelimit/budget/0001', '0186484b961f396532706137612082ed9c052f476e79b243d7b89897a0ec4880', '2026-11-11 19:07:00.405733+00'),
	('ratelimit/budget/0002-tenants/0-column', 'c486804fb372cfd8f657eeb4b9905dcafc12ff9475f2d93736969ac48bb93489', '2026-11-11 19:07:00.411663+00'),
	('ratelimit/budget/0002-tenants/1-column', 'bab20f9e81468f08788f91e4e3808f2c9870b6d7fb36f3bda2db91137ccc3912', '2026-11-11 19:07:00.413341+00'),
	('ratelimit/budget/0002-tenants/0-stamp-column', '48649402a01917e40068d3596e61ebe671776fba920fc34ee7e24cd4ea1b7fdf', '2026-11-11 19:07:00.413341+00'),
	('ratelimit/budget/0002-tenants/2-keys', '79897723df7fd293612db8bdcf6882d714a58e93668614727fd16789ffa3085c', '2026-11-11 19:07:00.418369+00'),
	('ratelimit/budget/0002-tenants/2-references', 'd57bae59cc658a9a8d96cde5ddd54801a2482768f335bde683452d7399c455ce', '2026-11-11 19:07:00.419212+00'),
	('ratelimit/budget/0002-tenants/3-policy', 'd37e8cd6ea5af1531e1b5981d6a4e8db0f20eacb63362e548d3f3d2f3d1571bc', '2026-11-11 19:07:00.421027+00'),
	('ratelimit/budget/0002-tenants/2-tenant-policy', '81c0a6c18051c7098c1d8912d6d106fa815a8caa8842c934a941be5190e33195', '2026-11-11 19:07:00.421027+00'),
	('runs/activity/0001', '985e4430016c037b986909566aceb68f53870fc50a71158dbaf73c1c5a15c509', '2026-11-11 19:07:00.424735+00'),
	('runs/activity/0002-tenants/0-column', '496efd706f1756a2184955c31439c8c04a52660d73195b8c9a2e1572b265e27d', '2026-11-11 19:07:00.433241+00'),
	('runs/activity/0002-tenants/1-column', '5106a498c90ff8fa699b63192ec4025c9fcfdcd30b69bce4c81a1707c8499da8', '2026-11-11 19:07:00.43444+00'),
	('runs/activity/0002-tenants/0-stamp-column', '397b17c893b803a74ff35a964aa9cdfe8456ca4e06567b8cfdd4cf9697088434', '2026-11-11 19:07:00.43444+00'),
	('runs/activity/0002-tenants/2-keys', '5a6ad003f4d06204db9365cee1360d88a252952c56b9c3fd6b8794d95fb85567', '2026-11-11 19:07:00.439061+00'),
	('runs/activity/0002-tenants/2-references', '4ef9a2c5817eeec7148a622e65d57a17cb859215d8ff879274462605861d4a0d', '2026-11-11 19:07:00.439707+00'),
	('runs/activity/0002-tenants/3-policy', '12e9d69ac8aff17fa3149c6a49a16da7209da341b9695d05ab749bd0253e2438', '2026-11-11 19:07:00.441655+00'),
	('runs/activity/0002-tenants/2-tenant-policy', 'e4191fe1a97106bba5c112e61b5798519d0d6eefe16532afb3dc11f68c0a9857', '2026-11-11 19:07:00.441655+00'),
	('runs/instance-heartbeats/0001', 'b66b27fd44eaea464c1a3e28331dcc37909ecca00322b6ed75cb925af3503cbf', '2026-11-11 19:07:00.444801+00'),
	('runs/instance-heartbeats/0002', 'f885cc622eab13f06dd6728196420698a399751875323d79c2a6207f9daeb807', '2026-11-11 19:07:00.449335+00'),
	('runs/signals/0001', 'f94f67b5c878383af0026a0a44b1f252f83585dec0e12b79b9db6e8de841cacf', '2026-11-11 19:07:00.450432+00'),
	('runs/signals/0002', '5eaf490533f72a518bd27d4846b052532a7715976e2e5b3b3432b16d1416bb59', '2026-11-11 19:07:00.456356+00'),
	('runs/signals/0003-tenants/0-column', '1b33c2c98ff8c8daa0e3ee6697820bea00d00bb2e756a7a2d299b0ab79a90260', '2026-11-11 19:07:00.458633+00'),
	('runs/signals/0003-tenants/1-column', 'bf7eb3441401f9cff8323cc1bd8eb5a10ee0df85a07b8e49790857445f79b84f', '2026-11-11 19:07:00.459845+00'),
	('runs/signals/0003-tenants/0-stamp-column', 'c7219a9091a73ae5831768c021689ded2b0f86c7833d2a60a8acbd92461c559c', '2026-11-11 19:07:00.459845+00'),
	('runs/signals/0003-tenants/2-keys', '102164f672557f2847051f8e1d7b1a5bed92934729ef98522f390ec912e0bed2', '2026-11-11 19:07:00.468801+00'),
	('runs/signals/0003-tenants/2-references', '1d6c174a718b6f0fa33ea7238beb0f3f5fb63f01a8e8fecc25fcf5b09acc72aa', '2026-11-11 19:07:00.46954+00'),
	('runs/signals/0003-tenants/3-policy', '9f142dc6c335340d6a3e6bac9cd769dd37f3f11c009fe6ab185595d8cccbd522', '2026-11-11 19:07:00.471238+00'),
	('runs/signals/0003-tenants/2-tenant-policy', '5d1c03469fbbcfcf8fec16b9a4be7624970d7c0f196843dcc84dbd8e5bfc6887', '2026-11-11 19:07:00.471238+00'),
	('runs/signals/0004-claims', '77f27c4ae99ed0c4d6b1145a0e0f03dd5cba5da50153f30d73d3e023156b0d24', '2026-11-11 19:07:00.500378+00'),
	('runs/store/0011-base-schema', '77ca2d1c3ec5253374c0eadbf47d91d53c6d2c3fc7232079b33006bc9233a24e', '2026-11-11 19:07:00.502533+00'),
	('runs/store/0012-tenants/0-column', '6d7bc8900e1fb8b4abc060c5dc569594c483f8e2cfdda9dad13b6d2d94f2ea37', '2026-11-11 19:07:00.518065+00'),
	('runs/store/0012-tenants/1-column', 'd6fc0402cc0d05c4ce375d0c5b81dbf0a524d317ce301d1aca0acb98896bbbd1', '2026-11-11 19:07:00.520029+00'),
	('runs/store/0012-tenants/0-stamp-column', '0ac13596802e4349174ba3f773e6d0a9395ad21ac30947619b285e232d4c9f5e', '2026-11-11 19:07:00.520029+00'),
	('runs/store/0012-tenants/2-keys', 'a6b630b3223d15e5754e6f36a97c0b795af82934f2567b8d46d4409847ed67aa', '2026-11-11 19:07:00.532163+00'),
	('runs/store/0012-tenants/2-references', 'bf7d845bec9272dcad2d6fa4c9a75e6255eaee3e7fab18f1478e23c16db3d538', '2026-11-11 19:07:00.53313+00'),
	('runs/store/0012-tenants/3-policy', 'c12052c273d2373441789d96a41c5931b5fde8ebddc00abea257f06c1cdaf2d7', '2026-11-11 19:07:00.53548+00'),
	('runs/store/0012-tenants/2-tenant-policy', 'afb968ac6257c1b69f52c61f52387282ed6efae5c3fde3c15935ba9174dd7359', '2026-11-11 19:07:00.53548+00'),
	('runs/store/0013-claims', 'ee68429db1cf91c4045d3ae1deb3d5f8c4c13b7232f1dc16caa2925c7b6bdcfb', '2026-11-11 19:07:00.538836+00'),
	('runtime/0002-drop-harness-choice', '2e7a8523090c84d00b557197f2e3038b5b2fd418e6b3b4b08c10ef0cf596a792', '2026-11-11 19:07:00.542209+00'),
	('sessions/store/0047-base-schema', '09cc3da1e893709927f3a18d593d543289d9d92dc416c56f426e3a5d69957099', '2026-11-11 19:07:00.547077+00'),
	('sessions/store/0048-message-search-index', 'f1996db3a8774e9c0b1e7dc35ecc70b2cfb1d64e8923225e40cdfc351a0b9cf4', '2026-11-11 19:07:00.635555+00'),
	('sessions/store/0049-drop-items-search', '0d987ff91662ce4509dfe4a31b7d3400ae5369ae3e3fbae1a31e30d223483c66', '2026-11-11 19:07:00.636122+00'),
	('sessions/store/0050-tenant-backfill', '73f0b5440a2bccaefe16bbdc2d826e95bcf8da2e8af937c6c911c9f48e75a18e', '2026-11-11 19:07:00.63738+00'),
	('sessions/store/0051-spend-recovery-index', '4afb2779caa4de04dbd6210f1bf1fda4ae52e6e3158294ce42ef1f9821f89c41', '2026-11-11 19:07:00.642353+00'),
	('sessions/store/0052-session-facts', 'cc6b8210d1fb814301e48e051fb225e96e67a09827241f78d5ef31b5524d4784', '2026-11-11 19:07:00.643081+00'),
	('sessions/store/0054-session-facts-copy', '233524866d2259689e40a9d9e95dfdc514981fe8e8dc3f3919293506e382b637', '2026-11-11 19:07:00.647027+00'),
	('sessions/store/0055-participant-membership', '3432fb84aca3eb8b5dcd9856cb8b8151428f5ccf7b1e5bf80fb75045f6841fc0', '2026-11-11 19:07:00.647655+00'),
	('sessions/store/0056-persona', 'bc744e1e17bc8c0b73e0d6e60079d8db1977e5088693a9282f80027f7ca485c8', '2026-11-11 19:07:00.652458+00'),
	('sessions/store/0056-tenants/0-column', '1634d0d450aa88d181fe6cab73116360a13b0bf058b9a8eb3bfd930de9170974', '2026-11-11 19:07:00.654737+00'),
	('sessions/store/0056-tenants/1-column', '3ac83c1935c43dd0a51567cfe8686fe89e7fa9e290e508910b6a300bb45b2498', '2026-11-11 19:07:00.675818+00'),
	('sessions/store/0056-tenants/0-stamp-column', '1b3e9177d869f478ff66cddab222102c20b52d5617c7e9d8a72621cd8c898582', '2026-11-11 19:07:00.675818+00'),
	('sessions/store/0056-tenants/2-keys', 'c84e8c937b39a123ba68bc4f987f8f6f82eba8a7205d70c5dee2805e50ab3747', '2026-11-11 19:07:00.719472+00'),
	('sessions/store/0056-tenants/2-references', '34e92a18c70932d4793c3d5c4be4f8492879e15ea64dbe93671131b470a09dd5', '2026-11-11 19:07:00.720048+00');


--
-- Data for Name: qm_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: qm_tenant; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_tenant (id) VALUES
	('7e938598-79c1-46e2-89db-b446e13d0599');


--
-- Data for Name: rate_limit_windows; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.rate_limit_windows (principal_id, window_start, count) VALUES
	('upgrade-check', 1, 1);


--
-- Data for Name: render_app_storage; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: render_deploy_bodies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: render_deploy_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: render_sandbox_bases; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: render_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: render_sandbox_cleanup; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: render_scratch_bodies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: retired_tenant_hosts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_activity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_signals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sandbox_defaults; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sandbox_defaults (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: sandbox_resource_rollout; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sandbox_resources; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sandbox_resources (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: sandbox_routing; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: secret_drops; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.secret_drops (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: security_postures; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.security_postures (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: session_goals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_leases; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_llm_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_mailbox; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.session_mailbox (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: session_pins; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_shares; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.session_shares (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: session_spend_days; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_spend_dirty; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sharing_postures; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sharing_postures (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: skill_bundles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.skill_bundles (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: skill_packs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.skill_packs (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.skills (id, json, tenant_id) VALUES
	('48c2b992-29d8-49ba-9f06-e1c3d9ccc2fb', '{"id": "48c2b992-29d8-49ba-9f06-e1c3d9ccc2fb", "status": "published", "scopeId": "org:default-org", "version": 1, "manifest": {"body": "# admin — act for an org admin, from chat\n\nUse the native `admin` tool for the operations below. Its fixed actions call the same\n`/v1/admin/*` handlers and accept the same values; configuration and provider value\nobjects are validated by those existing handlers. Binary and full captured-prompt downloads, raw-secret setters, connector configuration,\nand service-credential configuration still use the self-API, never native tool arguments. You are acting **as them**: authorization is re-checked against the live grant\nstore on every call; existing admin audit events remain attributed to them. Two standing rules:\n**confirm before any mutation** (state exactly what you''ll change and where), and report\nafterwards exactly what changed. Reads are fine to just do.\n\n## System administration\n\nSystem administration is not limited to this API. A verified admin may use independently\nauthorized infrastructure or provider access to diagnose, repair, and manage the instance,\nincluding resources owned by other users. Ordinary resource-owner restrictions do not\nrequire the owner to do that work. An owner-only API denial does not revoke separately\nauthorized administrative access; verify it before taking another route. Acting under the\nadmin''s own authority is not impersonation or circumvention.\n\nPreserve credential grants, provider permissions, explicit restrictions, and mutation approvals.\nAdmin status alone supplies no provider credentials. Do not borrow another user''s identity,\nuse ungranted credentials, or bypass the portal-only actions below. Check the provider\naccount and target, keep changes attributed to the admin, and disclose only what this\nconversation''s audience may see. For cloud operations, also load cloud-cli.\n\n## Admin API limits\n\nLimits the API enforces (don''t offer what it will refuse):\n\n- Your token elevates only on turns the admin **started themselves** — on autonomous\n  runs (crons, webhooks) the admin plane refuses it, whoever owns the run.\n- Reads that return private content — transcripts, files, notebooks, logs, another\n  scope''s config — work from a **DM** with the admin, or from an **Open** conversation\n  on a live admin turn. Organization, personal, and conversation sharing restrictions\n  all apply; any Isolated setting keeps the DM requirement. The request uses the\n  authenticated speaker''s live admin grant, not another participant''s authority.\n  Open reads can expose private data to everyone in the conversation: retrieve and\n  report only what the request needs. Two other exceptions: org-targeted\n  memory/config reads work anywhere (org content is ambient to every conversation), and\n  a cron can carry **unattended read grants** (`unattendedGrants` on the cron:\n  `admin.sessions.read`, `admin.audit.read`, `admin.metrics.read`, `admin.egress.read`,\n  `admin.files.read`) — set only on a live turn by the cron''s owner, who must be a\n  current org admin, on a personal-scope cron running as its owner. Each grant opens\n  exactly its own GET routes to that cron''s autonomous fires, audited as the owner\n  (re-checked live — revoking their admin grant closes it). Other mutations work\n  anywhere; the room sees what changed, by design.\n- **Grant changes (promote/revoke) and impersonation are portal-only** through you.\n- Bulk configuration import is not supported. Use the individual configuration resources instead.\n\nAll calls share one shape — only method/path/body vary:\n\n```bash\ncurl -fsS -H \"x-agent-capability: $AGENT_API_TOKEN\" \"$AGENT_API_URL/v1/admin/...\"\n```\n\nAnyone can check admin status (this is also how you answer \"am I an admin?\"):\n\n```bash\nGET /v1/admin/whoami        → {\"isAdmin\":true,\"role\":\"org_admin\",\"scopeId\":\"org:…\"} or {\"isAdmin\":false}\n```\n\n## Check connector sources\n\nDuring admin onboarding, check this silently before offering Slack bot setup or personal\nconnections. A source is either Composio or the org''s own OAuth apps. Never inspect\ndeployment secrets.\n\n**Composio.** It is available when `GET /v1/composio/toolkits` succeeds. A\n`composio_unavailable` error only means it is not available to this person; the org may\nstill have a key they are not granted. To check the org, read\n`GET /v1/admin/scopes/<org scope>?view=credentials`: a `serviceCredentials` entry with\n`enabled: true`, `hasSecret: true`, `delivery: \"env\"` and `envKey: \"COMPOSIO_API_KEY\"`\nmeans Composio is configured.\n\n**Own OAuth apps.** The live Connected apps block reflects the providers configured with\nclient credentials, from Admin → Connectors or deployment secrets. The line \"No direct\nOAuth app connections are configured\" means none are, even if MCP apps appear under\n\"Connected\". Without that line, at least one provider is configured.\n`GET /v1/admin/scopes/<org scope>?view=connectors` shows only apps added in Admin →\nConnectors, not ones set by deployment secrets, so it cannot prove absence.\n\nComposio is absent only when the toolkits read fails and the org check finds no such\ncredential. If either source exists, skip silently. If the block is missing or a read\nfails, treat it as unknown, not absent, and do not offer setup. Only when both are\nconfirmed absent, send one short message:\n\n- Composio (recommended): one project key covers most apps. Add it in Admin → Credentials\n  as an org service credential with env key `COMPOSIO_API_KEY`, and set up callback\n  verification as described in QM''s `docs/composio.md`. If they would rather paste the\n  key now, mint a one-time link with the `secret-drop` skill (service `composio`, envKey\n  `COMPOSIO_API_KEY`) and share its `url`.\n  A dropped key enables Composio only for them; teammates need the org credential.\n- Own OAuth apps: add each provider in Admin → Connectors. Each one needs the callback URL\n  `<web origin>/v1/connectors/oauth/<provider>/callback`, which the Connectors page also\n  shows.\n\nLinks: the web origin is the origin of the Connection page URL in the Connected apps\nblock (`<web origin>/keychain`). Link `<web origin>/admin/credentials` and\n`<web origin>/admin/connectors`. If that line is absent, name the pages without links and\noffer the drop link. Never invent URLs or ask for keys or client secrets in chat. Never\nask regular users to configure a source.\n\n## Guide Slack installation\n\nCheck this silently before offering Slack bot setup during admin onboarding. It is\nseparate from personal account connections. Verify admin status first. On a\nhuman-started admin turn, read `GET /v1/admin/slack-installation`; it returns setup\nmetadata, not tokens. A failed read means unknown, not absent. Never inspect\ndeployment secrets to infer status.\n\n- `configured: true`: skip silently during onboarding, including environment-backed\n  installs. Do not add a setup heading, say \"already connected\", or ask for a test DM.\n  Configuration is not a live connectivity check; troubleshoot only if asked.\n- `managed: true`, `configured: false`: leave disabled setup alone unless the admin\n  asks to resume or re-enable it. Do not advertise it during onboarding.\n- `source: \"invalid_environment\"`: this is incomplete setup, not an absent app. Do\n  not create a duplicate; offer to finish the existing setup using its secure page.\n- Only a successful read confirming an absent bot warrants a new setup offer.\n  Respect a prior deferral and continue with personal connections.\n\nFor company-owned provisioning, the status response supplies `setup.tokenUrl`,\n`setup.submitUrl`, and `setup.installUrl`. They are stable authenticated QM entry\nlinks, not expiring tickets. Never invent URLs or mint launch tickets in the shell.\n\nOn the web surface, post **[Set up Slack](setup.submitUrl)** once, using the returned\nURL. The conversation renders one live checklist with all three links together in one message:\n**Create token**, **Submit token**, and **Add to Slack**, plus the instructional GIF.\nIt checks progress in place without another assistant reply. Do not duplicate that\nchecklist in prose. On other surfaces, present all three returned links together:\n\n1. Create token: open `setup.tokenUrl`. Under **App Configuration Tokens**, choose\n   **Generate Token**, select the intended workspace, and copy the **access token**,\n   not the refresh token.\n2. Submit token: open `setup.submitUrl`, the secure provisioning form. This is\n   not a generic keychain token-drop. The token can manage other apps they own in\n   that workspace. QM creates/configures its app, then discards the token.\n   Never paste it in chat, memory, files, or the keychain.\n3. Add to Slack: open `setup.installUrl` after submitting the token, review the\n   workspace, and choose **Allow**. The company owns the app.\n\n`setup.appReady` means the app exists; it does not mean it is installed.\nOnly verified `setup.connected` together with `configured` warrants **Connected**.\nRequire a real reply before claiming the bot works, not as an onboarding prerequisite.\nA failed status read or `setupUnavailable` means unknown, not absent. Do not restart\nprovisioning or create a duplicate. Retry the existing links or follow recovery guidance.\n\nOlder services may return `installAvailable: true` without `setup`. That only promises\nthe authenticated dashboard **Add to Slack** action. Give its known entry link and\ninstructions together instead of promising a checklist or fabricating a token-drop.\n\nWithout managed installation, use the returned `createUrl` and the known dashboard''s\nworkspace app guide. Do not ask for a configuration token this flow cannot consume.\nHave them enter credentials only in its secure form. Do not guess scopes, callback\nURLs, or credential requirements. Setup is optional; continue onboarding if deferred.\n\n## Finding the scope\n\nMost endpoints take `?scope=<scopeId>` (`org:<org>`, `personal:<user>`, `channel:<id>`).\nDon''t guess ids — list them:\n\n```bash\nGET /v1/admin/scopes        → every scope with display labels (#channel names, people) and what lives there\n```\n\n## Read & govern a scope''s config\n\n```bash\nGET /v1/admin/scopes/<scopeId>                → resolved config: commandPolicy, soul (+version), egress, flags, connectors, serviceCredentials\nPUT /v1/admin/scopes/<scopeId>/<resource>     → resource ∈ soul | command-policy | egress |\n                                                connectors | service-credentials |\n                                                base-model (org-wide LLM; body { modelId } — e.g. gpt-5.5; empty string clears)\n```\n\nGET first, then PUT the corrected value (`soul` takes `{content}`, `egress` takes\n`{allowedHosts,deniedHosts}`, the toggles take `{on}`). Changes apply next turn.\n\n## Read & fix any scope''s memory\n\n```bash\nGET /v1/admin/memory?scope=<scopeId>          → that scope''s whole notebook\nPUT /v1/admin/memory?scope=<scopeId>          {\"content\":\"…full replacement…\"}\n```\n\n(For \"remember this org-wide\" you don''t need the admin plane at all — `\"scope\":\"org\"`\non the memory self-API is the lighter path; see the memory skill.)\n\n## Inspect activity & content\n\n```bash\nGET /v1/admin/sessions?scope=&limit=&cursor=  → conversation listing (turns, last activity); pass nextCursor for older rows\nGET /v1/admin/sessions/<id>?scope=            → a transcript\nGET /v1/admin/sessions/<id>/llm?scope=        → captured provider requests — what the model actually saw (debugging \"why did it do X\")\nGET /v1/admin/runs?scope=                     → queued/in-flight/recent runs\nGET /v1/admin/files?scope=                    → document store; read?id= / download?id= for content\nGET /v1/admin/volumes?scope=                  → a scope''s computer/backup contents (sizes only)\nGET /v1/admin/crons|deployments|skills?scope= → artifacts by owner\n```\n\n## Observability\n\n```bash\nGET /v1/admin/audit?scope=     GET /v1/admin/errors?scope=    GET /v1/admin/metrics?scope=\nGET /v1/admin/egress?scope=    GET /v1/admin/retention\nGET /v1/admin/users            → roster + admin status (org-wide)\n```\n\n## External users\n\nOutside collaborators, admitted by email with a role and an expiry; they sign in at the\nportal with that address until it lapses. Listed alongside the roster:\n\n```bash\nGET /v1/admin/users                          → externalUsers: [{email, role, expiresAt, invitedBy, status: active|expired}]\nPOST /v1/admin/external-users                {\"email\":\"ana@partner.com\",\"expiresAt\":\"2026-12-31\"}   role defaults to member; expiresAt required (a bare date means end of that day UTC; ISO date-time or epoch ms also work)\nDELETE /v1/admin/external-users/<email>      → revokes access now; the row stays listed as expired (a DELETE a day after expiry removes it)\n```\n\nConfirm with the admin before inviting or revoking — say who, which role, and until\nwhen. The invitation email needs Resend configured on core (`RESEND_API_KEY` +\n`AUTH_EMAIL_FROM`); without it the user is still added. When the response has\n`emailSent:false`, tell the admin why (`emailProblem`) and hand them `signInUrl` to pass\nalong themselves. The `org_admin` role for externals is portal-only, like every other\ngrant change — don''t offer it.\n\n## Admin grants (promote / revoke)\n\nNot available through you: who governs the org changes only in the admin dashboard,\nwhere the admin acts directly. If asked, point them there — don''t try the API\n(`POST/DELETE /v1/admin/grants` refuses agent tokens).\n\n## Failure modes\n\n- `403 admin grant required for this scope` — the user isn''t an org admin (or was just\n  revoked). Say so; don''t retry or work around it.\n- `403 … require a turn the admin started themselves` — this is an autonomous run\n  (cron/webhook); admin actions only ride turns the admin personally initiated. Say so.\n- `403 … returns private content — ask the agent in a DM` — the shared room does not have effective Open access for this live admin turn;\n  tell the admin to ask again in a DM with you (or, for reads they want recurring\n  on a schedule, to put an unattended read grant on a personal-scope cron — from\n  their DM, never from here).\n- `403 … grant changes (promote/revoke) are portal-only` — point them at the dashboard.\n- `403 granting or removing org admin for an external user is portal-only …` — same\n  answer: the dashboard.\n- `409 that address already belongs to a member of the org …` — org email domain, Slack\n  directory, sign-in allow-list, or someone who has already used the agent. They are not\n  external; to promote them, point the admin at Grant org admin in the dashboard and\n  tell them to enter the email as the principal ID. The person need not appear in Users first.\n- `409 that address holds an org admin grant of its own …` — the admin manages that grant\n  under Admins in the dashboard first.\n- `403 capability token not valid for this route` — this core predates agent admin\n  access; the user must use the admin dashboard.\n", "name": "admin", "files": [], "description": "Act for an org admin — the admin API (scope directory, per-scope config & SOUL, any scope''s memory, transcripts & captured prompts, files, user roster & external users, audit/errors/metrics/egress) accepts your token when the user you''re talking to is an org admin and started this turn themselves. Use when an admin asks you to inspect or change anything org-wide or in another scope, or anyone asks whether they''re an admin.", "requiredCapabilities": []}, "approvals": ["system:skills-reviewer"], "createdAt": 1794423914790, "createdBy": "system:skills-seed", "signature": "d1c1dfe8e6ffb68b3f9c09701d6e1c190c1969f63da033891009a7ffae04f645", "updatedAt": 1794423914798, "grantedCapabilities": []}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: slack_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_accounts (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: slack_emoji_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_emoji_catalog (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: slack_installation; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_installation (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: slack_session_status; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_session_status (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: slack_staged_envelopes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_staged_envelopes (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: slack_task_acknowledgements; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_task_acknowledgements (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: smolmachines_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.smolmachines_sandbox_bodies (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: soul_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.soul_configs (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: soul_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.soul_history (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: source_auth_replay; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.source_auth_replay (event_id, expires_at) VALUES
	('upgrade-check', '2026-11-11 19:05:25.475767+00');


--
-- Data for Name: spend_limit_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sprites_initialization; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: suggested_activity_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.suggested_activity_profiles (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: superserve_config_epochs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.superserve_config_epochs (id, json) VALUES
	('upgrade-check', '{}');


--
-- Data for Name: superserve_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.superserve_sandbox_bodies (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: swarms; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_rooms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.team_rooms (team_id, scope_id) VALUES
	('upgrade-check', 'upgrade-check');


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.teams (team_id, name, isolated_in_open, created_by, created_at) VALUES
	('upgrade-check', 'upgrade-check', false, 'upgrade-check', 1);


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.tenants (id, created_at, settings) VALUES
	('ee4a3194-8db6-4173-9d32-006834a7795e', '2026-11-11 19:06:58.488247+00', '{}'),
	('7e938598-79c1-46e2-89db-b446e13d0599', '2026-11-11 19:07:00.63738+00', '{}');


--
-- Data for Name: turn_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.turn_metrics (id, ts, scope_label, session_id, turn_seq, run_id, status, total_ms, ttft_ms, intake_preamble_ms, dispatch_ms, provisioned, cold_start, model_calls, tool_calls, provision_ms, materialize_ms, creds_ms, layers_ms, compile_ms, recall_ms, exec_ms, stream_ms, lease_ms, capture_ms, ingress_ms, detect_ms, compact_ms, queue_ms, deliver_ms, slack_inflight_ms, resumed_from_seq, cache_read, cache_write, uncached_input, lease_wait_ms) VALUES
	(1, 1, 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 1, 1, 1, 1, false, false, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);


--
-- Data for Name: unfulfilled_insights_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.unfulfilled_insights_flag (id, json) VALUES
	('upgrade-check', '{}');


--
-- Data for Name: web_ui_state; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.web_ui_state (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: webhook_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.webhook_history (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.webhooks (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Data for Name: webui_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.webui_model_configs (id, json, tenant_id) VALUES
	('upgrade-check', '{}', 'ee4a3194-8db6-4173-9d32-006834a7795e');


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ack_emoji_picks_id_seq', 1, true);


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ambient_judgments_id_seq', 1, true);


--
-- Name: app_page_views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.app_page_views_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, true);


--
-- Name: budget_spend_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_spend_id_seq', 1, false);


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.channel_policy_history_id_seq', 1, true);


--
-- Name: credential_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credential_usage_id_seq', 1, true);


--
-- Name: egress_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.egress_events_id_seq', 1, true);


--
-- Name: error_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.error_events_id_seq', 1, true);


--
-- Name: memory_facts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.memory_facts_id_seq', 1, true);


--
-- Name: run_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.run_activity_id_seq', 1, false);


--
-- Name: run_signals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.run_signals_id_seq', 1, false);


--
-- Name: runs_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.runs_seq_seq', 1, false);


--
-- Name: turn_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.turn_metrics_id_seq', 1, true);


--
-- Name: ack_emoji_picks ack_emoji_picks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks
    ADD CONSTRAINT ack_emoji_picks_pkey PRIMARY KEY (id);


--
-- Name: ack_emoji ack_emoji_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji
    ADD CONSTRAINT ack_emoji_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: acl_grants acl_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants
    ADD CONSTRAINT acl_grants_pkey PRIMARY KEY (tenant_id, owner_scope_id, path, grantee_scope_id, permission);


--
-- Name: acl_grants_version acl_grants_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants_version
    ADD CONSTRAINT acl_grants_version_pkey PRIMARY KEY (tenant_id, only_row);


--
-- Name: admin_grants admin_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_grants
    ADD CONSTRAINT admin_grants_pkey PRIMARY KEY (tenant_id, principal_id, scope_id, role);


--
-- Name: ambient_cursors ambient_cursors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_cursors
    ADD CONSTRAINT ambient_cursors_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: ambient_judgments ambient_judgments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments
    ADD CONSTRAINT ambient_judgments_pkey PRIMARY KEY (id);


--
-- Name: app_page_views app_page_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_page_views
    ADD CONSTRAINT app_page_views_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approval_grant_modes approval_grant_modes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grant_modes
    ADD CONSTRAINT approval_grant_modes_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approval_grants approval_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grants
    ADD CONSTRAINT approval_grants_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: auth_broker_sessions auth_broker_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_broker_sessions
    ADD CONSTRAINT auth_broker_sessions_pkey PRIMARY KEY (token_hash);


--
-- Name: auto_flagger_configs auto_flagger_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_flagger_configs
    ADD CONSTRAINT auto_flagger_configs_pkey PRIMARY KEY (id);


--
-- Name: aws_deploy_bodies aws_deploy_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_deploy_bodies
    ADD CONSTRAINT aws_deploy_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: aws_sandbox_bodies aws_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_sandbox_bodies
    ADD CONSTRAINT aws_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: base_model_configs base_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.base_model_configs
    ADD CONSTRAINT base_model_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: blobs blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blobs
    ADD CONSTRAINT blobs_pkey PRIMARY KEY (tenant_id, sha256);


--
-- Name: branding_configs branding_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_configs
    ADD CONSTRAINT branding_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: browse_max_steps_configs browse_max_steps_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_max_steps_configs
    ADD CONSTRAINT browse_max_steps_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: browse_model_configs browse_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_model_configs
    ADD CONSTRAINT browse_model_configs_pkey PRIMARY KEY (id);


--
-- Name: browser_sessions browser_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browser_sessions
    ADD CONSTRAINT browser_sessions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: budget_spend budget_spend_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_spend
    ADD CONSTRAINT budget_spend_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_files channel_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_files
    ADD CONSTRAINT channel_files_pkey PRIMARY KEY (org_id, container, ts, file_id);


--
-- Name: channel_header_pin_flag channel_header_pin_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_header_pin_flag
    ADD CONSTRAINT channel_header_pin_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_messages channel_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_messages
    ADD CONSTRAINT channel_messages_pkey PRIMARY KEY (org_id, container, ts);


--
-- Name: channel_policy_history channel_policy_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history
    ADD CONSTRAINT channel_policy_history_pkey PRIMARY KEY (id);


--
-- Name: channel_policy channel_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy
    ADD CONSTRAINT channel_policy_pkey PRIMARY KEY (org_id, container);


--
-- Name: channel_state channel_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_state
    ADD CONSTRAINT channel_state_pkey PRIMARY KEY (org_id, container);


--
-- Name: command_policies command_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_policies
    ADD CONSTRAINT command_policies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: composio_returns composio_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composio_returns
    ADD CONSTRAINT composio_returns_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: connector_clients connector_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_clients
    ADD CONSTRAINT connector_clients_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: consent_links consent_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_links
    ADD CONSTRAINT consent_links_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: context_requests context_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.context_requests
    ADD CONSTRAINT context_requests_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: credential_daily_calls credential_daily_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_daily_calls
    ADD CONSTRAINT credential_daily_calls_pkey PRIMARY KEY (tenant_id, slug, day);


--
-- Name: credential_usage credential_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage
    ADD CONSTRAINT credential_usage_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: cron_fires cron_fires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_fires
    ADD CONSTRAINT cron_fires_pkey PRIMARY KEY (tenant_id, cron_id, fire_key);


--
-- Name: crons crons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crons
    ADD CONSTRAINT crons_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: custom_model_providers custom_model_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_model_providers
    ADD CONSTRAINT custom_model_providers_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deactivated_principals deactivated_principals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deactivated_principals
    ADD CONSTRAINT deactivated_principals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: decision_providers decision_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_providers
    ADD CONSTRAINT decision_providers_pkey PRIMARY KEY (tenant_id, provider_id);


--
-- Name: decision_rules decision_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_pkey PRIMARY KEY (tenant_id, rule_id);


--
-- Name: deliveries deliveries_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_idempotency_key_key UNIQUE (tenant_id, idempotency_key);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deploy_git_repos deploy_git_repos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_git_repos
    ADD CONSTRAINT deploy_git_repos_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_access deployment_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_identity deployment_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_identity
    ADD CONSTRAINT deployment_identity_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_layer deployment_layer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_layer
    ADD CONSTRAINT deployment_layer_pkey PRIMARY KEY (id);


--
-- Name: deployments deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: directory_channel_members directory_channel_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channel_members
    ADD CONSTRAINT directory_channel_members_pkey PRIMARY KEY (tenant_id, org_id, channel_id, principal_id);


--
-- Name: directory_channels directory_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channels
    ADD CONSTRAINT directory_channels_pkey PRIMARY KEY (tenant_id, org_id, channel_id);


--
-- Name: directory_group_members directory_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_group_members
    ADD CONSTRAINT directory_group_members_pkey PRIMARY KEY (tenant_id, org_id, group_id, principal_id);


--
-- Name: directory_groups directory_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_groups
    ADD CONSTRAINT directory_groups_pkey PRIMARY KEY (tenant_id, org_id, group_id);


--
-- Name: directory_members directory_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_members
    ADD CONSTRAINT directory_members_pkey PRIMARY KEY (tenant_id, org_id, principal_id);


--
-- Name: directory_meta directory_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_meta
    ADD CONSTRAINT directory_meta_pkey PRIMARY KEY (tenant_id, org_id);


--
-- Name: directory_sync directory_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_sync
    ADD CONSTRAINT directory_sync_pkey PRIMARY KEY (tenant_id, org_id);


--
-- Name: do_managed_agents_sandbox_bodies do_managed_agents_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.do_managed_agents_sandbox_bodies
    ADD CONSTRAINT do_managed_agents_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: durable_map_versions durable_map_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.durable_map_versions
    ADD CONSTRAINT durable_map_versions_pkey PRIMARY KEY (tenant_id, tbl);


--
-- Name: e2b_sandbox_bodies e2b_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2b_sandbox_bodies
    ADD CONSTRAINT e2b_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: egress_events egress_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events
    ADD CONSTRAINT egress_events_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: egress_policies egress_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_policies
    ADD CONSTRAINT egress_policies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: environment_attachments environment_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_pkey PRIMARY KEY (tenant_id, scope_id);


--
-- Name: environments environments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: error_events error_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events
    ADD CONSTRAINT error_events_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: external_members external_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_members
    ADD CONSTRAINT external_members_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: external_slack_participants_flag external_slack_participants_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_slack_participants_flag
    ADD CONSTRAINT external_slack_participants_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: file_artifact_deletions file_artifact_deletions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifact_deletions
    ADD CONSTRAINT file_artifact_deletions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: file_artifacts file_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifacts
    ADD CONSTRAINT file_artifacts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: file_uploads file_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_uploads
    ADD CONSTRAINT file_uploads_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: fly_deploy_configs fly_deploy_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fly_deploy_configs
    ADD CONSTRAINT fly_deploy_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: fly_deploy_ports fly_deploy_ports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fly_deploy_ports
    ADD CONSTRAINT fly_deploy_ports_pkey PRIMARY KEY (id);


--
-- Name: fly_peer_claims fly_peer_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fly_peer_claims
    ADD CONSTRAINT fly_peer_claims_pkey PRIMARY KEY (id);


--
-- Name: idempotency idempotency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency
    ADD CONSTRAINT idempotency_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: individual_model_auth_flag individual_model_auth_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.individual_model_auth_flag
    ADD CONSTRAINT individual_model_auth_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: instance_heartbeats instance_heartbeats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instance_heartbeats
    ADD CONSTRAINT instance_heartbeats_pkey PRIMARY KEY (instance_id);


--
-- Name: interactive_fast_mode_flag interactive_fast_mode_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interactive_fast_mode_flag
    ADD CONSTRAINT interactive_fast_mode_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (tenant_id, session_id, seq);


--
-- Name: keychain_asks keychain_asks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_asks
    ADD CONSTRAINT keychain_asks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: keychain_credentials keychain_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_credentials
    ADD CONSTRAINT keychain_credentials_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: keychain_grants keychain_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_grants
    ADD CONSTRAINT keychain_grants_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: llm_prompt_envelopes llm_prompt_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_prompt_envelopes
    ADD CONSTRAINT llm_prompt_envelopes_pkey PRIMARY KEY (hash);


--
-- Name: loop_ingress_deliveries loop_ingress_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ingress_deliveries
    ADD CONSTRAINT loop_ingress_deliveries_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loop_ingress loop_ingress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ingress
    ADD CONSTRAINT loop_ingress_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loop_items loop_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_items
    ADD CONSTRAINT loop_items_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loop_outputs loop_outputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_outputs
    ADD CONSTRAINT loop_outputs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loop_ship_grants loop_ship_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ship_grants
    ADD CONSTRAINT loop_ship_grants_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loops loops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loops
    ADD CONSTRAINT loops_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: memory_fact_vectors memory_fact_vectors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_fact_vectors
    ADD CONSTRAINT memory_fact_vectors_pkey PRIMARY KEY (tenant_id, scope_id, model, fact_id);


--
-- Name: memory_facts memory_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: memory_registry memory_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_registry
    ADD CONSTRAINT memory_registry_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: memory_tidy_profiles memory_tidy_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_tidy_profiles
    ADD CONSTRAINT memory_tidy_profiles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: modal_sandbox_bodies modal_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modal_sandbox_bodies
    ADD CONSTRAINT modal_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: model_credentials model_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_credentials
    ADD CONSTRAINT model_credentials_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: model_registry model_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: monitors monitors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: oauth_flows oauth_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_flows
    ADD CONSTRAINT oauth_flows_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: org_ambient_flag org_ambient_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_ambient_flag
    ADD CONSTRAINT org_ambient_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: participants participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_pkey PRIMARY KEY (session_id, principal_id);


--
-- Name: people_directory_urls people_directory_urls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.people_directory_urls
    ADD CONSTRAINT people_directory_urls_pkey PRIMARY KEY (id);


--
-- Name: porter_deploy_bodies porter_deploy_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.porter_deploy_bodies
    ADD CONSTRAINT porter_deploy_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: principal_links principal_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.principal_links
    ADD CONSTRAINT principal_links_pkey PRIMARY KEY (id);


--
-- Name: process_sessions process_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_sessions
    ADD CONSTRAINT process_sessions_pkey PRIMARY KEY (tenant_id, process_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: qm_schema_migrations qm_schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_schema_migrations
    ADD CONSTRAINT qm_schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: qm_settings qm_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_settings
    ADD CONSTRAINT qm_settings_pkey PRIMARY KEY (key);


--
-- Name: qm_tenant qm_tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_tenant
    ADD CONSTRAINT qm_tenant_pkey PRIMARY KEY (id);


--
-- Name: rate_limit_windows rate_limit_windows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit_windows
    ADD CONSTRAINT rate_limit_windows_pkey PRIMARY KEY (principal_id);


--
-- Name: render_app_storage render_app_storage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_app_storage
    ADD CONSTRAINT render_app_storage_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: render_deploy_bodies render_deploy_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_deploy_bodies
    ADD CONSTRAINT render_deploy_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: render_deploy_credentials render_deploy_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_deploy_credentials
    ADD CONSTRAINT render_deploy_credentials_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: render_sandbox_bases render_sandbox_bases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_sandbox_bases
    ADD CONSTRAINT render_sandbox_bases_pkey PRIMARY KEY (id);


--
-- Name: render_sandbox_bodies render_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_sandbox_bodies
    ADD CONSTRAINT render_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: render_sandbox_cleanup render_sandbox_cleanup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_sandbox_cleanup
    ADD CONSTRAINT render_sandbox_cleanup_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: render_scratch_bodies render_scratch_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_scratch_bodies
    ADD CONSTRAINT render_scratch_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: retired_tenant_hosts retired_tenant_hosts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retired_tenant_hosts
    ADD CONSTRAINT retired_tenant_hosts_pkey PRIMARY KEY (host);


--
-- Name: run_activity run_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity
    ADD CONSTRAINT run_activity_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: run_signals run_signals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals
    ADD CONSTRAINT run_signals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: runs runs_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_idempotency_key_key UNIQUE (tenant_id, idempotency_key);


--
-- Name: runs runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_defaults sandbox_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_defaults
    ADD CONSTRAINT sandbox_defaults_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_resource_rollout sandbox_resource_rollout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resource_rollout
    ADD CONSTRAINT sandbox_resource_rollout_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_resources sandbox_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resources
    ADD CONSTRAINT sandbox_resources_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_routing sandbox_routing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_routing
    ADD CONSTRAINT sandbox_routing_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: secret_drops secret_drops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_drops
    ADD CONSTRAINT secret_drops_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: security_postures security_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_postures
    ADD CONSTRAINT security_postures_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_goals session_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_pkey PRIMARY KEY (session_id);


--
-- Name: session_leases session_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_leases
    ADD CONSTRAINT session_leases_pkey PRIMARY KEY (session_id);


--
-- Name: session_llm_requests session_llm_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_llm_requests
    ADD CONSTRAINT session_llm_requests_pkey PRIMARY KEY (id);


--
-- Name: session_mailbox session_mailbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_mailbox
    ADD CONSTRAINT session_mailbox_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_pins session_pins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_pins
    ADD CONSTRAINT session_pins_pkey PRIMARY KEY (id);


--
-- Name: session_shares session_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_shares
    ADD CONSTRAINT session_shares_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_spend_days session_spend_days_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_days
    ADD CONSTRAINT session_spend_days_pkey PRIMARY KEY (day);


--
-- Name: session_spend_dirty session_spend_dirty_day_writer_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_dirty
    ADD CONSTRAINT session_spend_dirty_day_writer_key UNIQUE (day, writer);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_thread_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_thread_ref_key UNIQUE (thread_ref);


--
-- Name: sharing_postures sharing_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sharing_postures
    ADD CONSTRAINT sharing_postures_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skill_bundles skill_bundles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_bundles
    ADD CONSTRAINT skill_bundles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skill_packs skill_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_packs
    ADD CONSTRAINT skill_packs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_accounts slack_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_accounts
    ADD CONSTRAINT slack_accounts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_emoji_catalog slack_emoji_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_emoji_catalog
    ADD CONSTRAINT slack_emoji_catalog_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_installation slack_installation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_installation
    ADD CONSTRAINT slack_installation_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_session_status slack_session_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_session_status
    ADD CONSTRAINT slack_session_status_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_staged_envelopes slack_staged_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_staged_envelopes
    ADD CONSTRAINT slack_staged_envelopes_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_task_acknowledgements slack_task_acknowledgements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_task_acknowledgements
    ADD CONSTRAINT slack_task_acknowledgements_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: smolmachines_sandbox_bodies smolmachines_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smolmachines_sandbox_bodies
    ADD CONSTRAINT smolmachines_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: soul_configs soul_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_configs
    ADD CONSTRAINT soul_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: soul_history soul_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_history
    ADD CONSTRAINT soul_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: source_auth_replay source_auth_replay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_auth_replay
    ADD CONSTRAINT source_auth_replay_pkey PRIMARY KEY (event_id);


--
-- Name: spend_limit_configs spend_limit_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend_limit_configs
    ADD CONSTRAINT spend_limit_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sprites_initialization sprites_initialization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprites_initialization
    ADD CONSTRAINT sprites_initialization_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: suggested_activity_profiles suggested_activity_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggested_activity_profiles
    ADD CONSTRAINT suggested_activity_profiles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: superserve_config_epochs superserve_config_epochs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_config_epochs
    ADD CONSTRAINT superserve_config_epochs_pkey PRIMARY KEY (id);


--
-- Name: superserve_sandbox_bodies superserve_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_sandbox_bodies
    ADD CONSTRAINT superserve_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: swarms swarms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swarms
    ADD CONSTRAINT swarms_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (team_id, principal_id);


--
-- Name: team_rooms team_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_pkey PRIMARY KEY (team_id, scope_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (team_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: turn_metrics turn_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.turn_metrics
    ADD CONSTRAINT turn_metrics_pkey PRIMARY KEY (id);


--
-- Name: unfulfilled_insights_flag unfulfilled_insights_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unfulfilled_insights_flag
    ADD CONSTRAINT unfulfilled_insights_flag_pkey PRIMARY KEY (id);


--
-- Name: web_ui_state web_ui_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_ui_state
    ADD CONSTRAINT web_ui_state_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webhook_history webhook_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_history
    ADD CONSTRAINT webhook_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webui_model_configs webui_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webui_model_configs
    ADD CONSTRAINT webui_model_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: ack_emoji_picks_org_channel_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_channel_created ON public.ack_emoji_picks USING btree (org_id, channel, created_at DESC);


--
-- Name: ack_emoji_picks_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_created ON public.ack_emoji_picks USING btree (org_id, created_at DESC, id DESC);


--
-- Name: ack_emoji_picks_org_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_outcome ON public.ack_emoji_picks USING btree (org_id, outcome);


--
-- Name: acl_grants_by_grantee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX acl_grants_by_grantee ON public.acl_grants USING btree (grantee_scope_id, path text_pattern_ops);


--
-- Name: ambient_judgments_org_container_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_container_created ON public.ambient_judgments USING btree (org_id, container, created_at DESC);


--
-- Name: ambient_judgments_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_created ON public.ambient_judgments USING btree (org_id, created_at DESC, id DESC);


--
-- Name: ambient_judgments_org_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_decision ON public.ambient_judgments USING btree (org_id, decision);


--
-- Name: app_page_views_by_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX app_page_views_by_at ON public.app_page_views USING btree (at);


--
-- Name: app_page_views_by_deployment_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX app_page_views_by_deployment_at ON public.app_page_views USING btree (deployment_id, at DESC);


--
-- Name: approval_grants_actorid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_grants_actorid_fold ON public.approval_grants USING hash (lower((json ->> 'actorId'::text)));


--
-- Name: approval_grants_actorid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_grants_actorid_unicode ON public.approval_grants USING btree (id) WHERE ((json ->> 'actorId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: approvals_sessionid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_sessionid_fold ON public.approvals USING hash (lower((json ->> 'sessionId'::text)));


--
-- Name: approvals_sessionid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_sessionid_unicode ON public.approvals USING btree (id) WHERE ((json ->> 'sessionId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: audit_log_by_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_action ON public.audit_log USING btree (action, at DESC);


--
-- Name: audit_log_by_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_at ON public.audit_log USING btree (at DESC);


--
-- Name: audit_log_by_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX audit_log_by_idempotency_key ON public.audit_log USING btree (tenant_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: audit_log_by_scope_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_scope_at ON public.audit_log USING btree (scope_label, at DESC);


--
-- Name: auth_broker_sessions_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_email ON public.auth_broker_sessions USING btree (email);


--
-- Name: auth_broker_sessions_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_expiry ON public.auth_broker_sessions USING btree (expires_at);


--
-- Name: budget_spend_by_principal_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_spend_by_principal_at ON public.budget_spend USING btree (principal_id, at);


--
-- Name: channel_messages_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_by_container ON public.channel_messages USING btree (org_id, container, ts);


--
-- Name: channel_messages_by_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_by_sub ON public.channel_messages USING btree (org_id, container, sub, ts);


--
-- Name: channel_messages_deleted_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_deleted_by_container ON public.channel_messages USING btree (org_id, container, deleted_at) WHERE (deleted_at > 0);


--
-- Name: channel_messages_edited_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_edited_by_container ON public.channel_messages USING btree (org_id, container, edited_at) WHERE (edited_at > 0);


--
-- Name: channel_messages_live_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_live_by_container ON public.channel_messages USING btree (org_id, container) WHERE (deleted = false);


--
-- Name: channel_messages_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_tsv ON public.channel_messages USING gin (tsv);


--
-- Name: channel_policy_history_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_policy_history_container ON public.channel_policy_history USING btree (org_id, container, id DESC);


--
-- Name: credential_usage_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_scope_ts ON public.credential_usage USING btree (scope_label, ts DESC);


--
-- Name: credential_usage_by_slug_ts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_slug_ts_id ON public.credential_usage USING btree (slug, ts DESC, id DESC);


--
-- Name: credential_usage_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_ts ON public.credential_usage USING btree (ts DESC);


--
-- Name: crons_ownerscopeid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_ownerscopeid_fold ON public.crons USING hash (lower((json ->> 'ownerScopeId'::text)));


--
-- Name: crons_ownerscopeid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_ownerscopeid_unicode ON public.crons USING btree (id) WHERE ((json ->> 'ownerScopeId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: crons_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_resource_search_gin ON public.crons USING gin (to_tsvector('simple'::regconfig, ((((COALESCE((json ->> 'title'::text), ''::text) || ' '::text) || COALESCE((json ->> 'action'::text), ''::text)) || ' '::text) || COALESCE((json ->> 'message'::text), ''::text))));


--
-- Name: decision_rules_hook; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX decision_rules_hook ON public.decision_rules USING btree (hook) WHERE (mode <> 'off'::text);


--
-- Name: deployments_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX deployments_name_unique ON public.deployments USING btree (tenant_id, ((json ->> 'name'::text))) WHERE ((json ->> 'name'::text) IS NOT NULL);


--
-- Name: deployments_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deployments_resource_search_gin ON public.deployments USING gin (to_tsvector('simple'::regconfig, ((COALESCE((json ->> 'displayName'::text), (json ->> 'name'::text), ''::text) || ' '::text) || COALESCE((json ->> 'name'::text), ''::text))));


--
-- Name: directory_channels_lower_cid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_lower_cid ON public.directory_channels USING btree (org_id, lower(channel_id));


--
-- Name: directory_channels_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_name ON public.directory_channels USING btree (org_id, name_lc);


--
-- Name: directory_group_members_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_group_members_principal ON public.directory_group_members USING btree (org_id, principal_id, group_id);


--
-- Name: directory_members_lower_pid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_lower_pid ON public.directory_members USING btree (org_id, lower(principal_id));


--
-- Name: directory_members_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_name ON public.directory_members USING btree (org_id, display_name_lc);


--
-- Name: egress_events_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_by_scope_ts ON public.egress_events USING btree (scope_label, ts DESC);


--
-- Name: egress_events_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_by_ts ON public.egress_events USING btree (ts DESC);


--
-- Name: environment_attachments_by_env; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_attachments_by_env ON public.environment_attachments USING btree (environment_id);


--
-- Name: error_events_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_scope_ts ON public.error_events USING btree (scope_label, ts DESC);


--
-- Name: error_events_by_session_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_session_ts ON public.error_events USING btree (session_id, ts DESC);


--
-- Name: error_events_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_ts ON public.error_events USING btree (ts DESC);


--
-- Name: file_artifacts_owner_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_owner_created ON public.file_artifacts USING btree (owner_scope_id, created_at DESC, id DESC);


--
-- Name: file_artifacts_owner_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_owner_path ON public.file_artifacts USING btree (owner_scope_id, path);


--
-- Name: file_artifacts_scope_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_scope_created ON public.file_artifacts USING btree (created_in_scope, created_at DESC, id DESC) WHERE (enabled = true);


--
-- Name: file_uploads_actor_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_uploads_actor_state ON public.file_uploads USING btree (actor_id, state);


--
-- Name: file_uploads_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_uploads_expiry ON public.file_uploads USING btree (expires_at) WHERE (state <> ALL (ARRAY['complete'::text, 'aborted'::text]));


--
-- Name: file_uploads_retry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_uploads_retry ON public.file_uploads USING btree (next_attempt_at, expires_at) WHERE (state <> ALL (ARRAY['complete'::text, 'aborted'::text, 'failed'::text]));


--
-- Name: idx_cron_fires_cron_fired_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cron_fires_cron_fired_at ON public.cron_fires USING btree (cron_id, fired_at DESC);


--
-- Name: idx_cron_fires_thread_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cron_fires_thread_ref ON public.cron_fires USING btree (thread_ref);


--
-- Name: idx_deliveries_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_pending ON public.deliveries USING btree (((destination ->> 'type'::text)), created_at) WHERE (delivered_at IS NULL);


--
-- Name: idx_deliveries_pending_live; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_pending_live ON public.deliveries USING btree (((destination ->> 'type'::text)), created_at) WHERE ((delivered_at IS NULL) AND (expired_at IS NULL));


--
-- Name: idx_deliveries_recipient_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_recipient_thread ON public.deliveries USING btree (recipient_thread_ref, created_at) WHERE (recipient_thread_ref IS NOT NULL);


--
-- Name: idx_deliveries_shadow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_shadow ON public.deliveries USING btree (created_at) WHERE (shadow AND (delivered_at IS NULL));


--
-- Name: idx_deliveries_source_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_source_session ON public.deliveries USING btree (((provenance ->> 'sourceSessionId'::text)), created_at) WHERE (provenance IS NOT NULL);


--
-- Name: idx_deliveries_source_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_source_thread ON public.deliveries USING btree (((provenance ->> 'sourceThreadRef'::text)), created_at) WHERE (provenance IS NOT NULL);


--
-- Name: idx_proc_scope_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proc_scope_status ON public.process_sessions USING btree (scope_id, status);


--
-- Name: idx_run_activity_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_activity_created ON public.run_activity USING btree (created_at);


--
-- Name: idx_run_activity_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_activity_run ON public.run_activity USING btree (run_id, id);


--
-- Name: idx_run_signals_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_signals_pending ON public.run_signals USING btree (run_id) WHERE (consumed_at IS NULL);


--
-- Name: idx_runs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_created ON public.runs USING btree (created_at DESC);


--
-- Name: idx_runs_one_running_per_session; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_runs_one_running_per_session ON public.runs USING btree (tenant_id, session_id) WHERE (status = 'running'::text);


--
-- Name: idx_runs_pending_child_returns; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_pending_child_returns ON public.runs USING btree (id) WHERE ((status = ANY (ARRAY['done'::text, 'failed'::text])) AND (returned_at IS NULL) AND (session_id ~~ 'agent:main:subagent:%'::text));


--
-- Name: idx_runs_pending_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_pending_priority ON public.runs USING btree (claim_priority, created_at, seq) WHERE (status = 'pending'::text);


--
-- Name: idx_runs_session_active_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_active_created ON public.runs USING btree (session_id, created_at DESC) WHERE (status = ANY (ARRAY['pending'::text, 'running'::text]));


--
-- Name: idx_runs_session_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_created_seq ON public.runs USING btree (session_id, created_at DESC, seq DESC);


--
-- Name: idx_runs_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created ON public.runs USING btree (status, created_at);


--
-- Name: idx_runs_status_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created_seq ON public.runs USING btree (status, created_at, seq);


--
-- Name: idx_runs_terminal_finished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_terminal_finished ON public.runs USING btree (finished_at, id) WHERE (status = ANY (ARRAY['done'::text, 'failed'::text]));


--
-- Name: idx_sessions_parent_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_parent_session_id ON public.sessions USING btree (parent_session_id) WHERE (parent_session_id IS NOT NULL);


--
-- Name: items_by_elicit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_elicit ON public.items USING btree (tenant_id, session_id, elicit_id) WHERE (elicit_id IS NOT NULL);


--
-- Name: items_by_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_external_id ON public.items USING btree (tenant_id, session_id, external_id) WHERE (external_id IS NOT NULL);


--
-- Name: items_by_turn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_turn ON public.items USING btree (tenant_id, turn_id, seq) WHERE (turn_id IS NOT NULL);


--
-- Name: items_message_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_message_search ON public.items USING gin (tenant_id, search) WHERE ((kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'AgentMessage'::public.item_kind])) AND (variant IS DISTINCT FROM 'files_delivered'::text) AND (text IS NOT NULL));


--
-- Name: items_one_call_per_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX items_one_call_per_kind ON public.items USING btree (tenant_id, session_id, kind, md5(call_id)) WHERE (call_id IS NOT NULL);


--
-- Name: items_session_kind_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_session_kind_created ON public.items USING btree (tenant_id, session_id, kind, created_at);


--
-- Name: keychain_credentials_ownerid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_credentials_ownerid_fold ON public.keychain_credentials USING hash (lower((json ->> 'ownerId'::text)));


--
-- Name: keychain_credentials_ownerid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_credentials_ownerid_unicode ON public.keychain_credentials USING btree (id) WHERE ((json ->> 'ownerId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: keychain_grants_ownerid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_ownerid_fold ON public.keychain_grants USING hash (lower((json ->> 'ownerId'::text)));


--
-- Name: keychain_grants_ownerid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_ownerid_unicode ON public.keychain_grants USING btree (id) WHERE ((json ->> 'ownerId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: llm_prompt_envelopes_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX llm_prompt_envelopes_created_at ON public.llm_prompt_envelopes USING btree (created_at);


--
-- Name: llm_prompt_envelopes_tenant_pkey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX llm_prompt_envelopes_tenant_pkey ON public.llm_prompt_envelopes USING btree (tenant_id, hash);


--
-- Name: loop_ingress_deliveries_queuekey_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_deliveries_queuekey_fold ON public.loop_ingress_deliveries USING hash (lower((json ->> 'queueKey'::text)));


--
-- Name: loop_ingress_deliveries_queuekey_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_deliveries_queuekey_unicode ON public.loop_ingress_deliveries USING btree (id) WHERE ((json ->> 'queueKey'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: loop_ingress_loopid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_loopid_fold ON public.loop_ingress USING hash (lower((json ->> 'loopId'::text)));


--
-- Name: loop_ingress_loopid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_loopid_unicode ON public.loop_ingress USING btree (id) WHERE ((json ->> 'loopId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: loop_items_loopid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_items_loopid_fold ON public.loop_items USING hash (lower((json ->> 'loopId'::text)));


--
-- Name: loop_items_loopid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_items_loopid_unicode ON public.loop_items USING btree (id) WHERE ((json ->> 'loopId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: loop_outputs_itemid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_outputs_itemid_fold ON public.loop_outputs USING hash (lower((json ->> 'itemId'::text)));


--
-- Name: loop_outputs_itemid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_outputs_itemid_unicode ON public.loop_outputs USING btree (id) WHERE ((json ->> 'itemId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: memory_facts_live; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX memory_facts_live ON public.memory_facts USING btree (scope_id, id) WHERE (deleted_at IS NULL);


--
-- Name: monitors_ownerscopeid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX monitors_ownerscopeid_fold ON public.monitors USING hash (lower((json ->> 'ownerScopeId'::text)));


--
-- Name: monitors_ownerscopeid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX monitors_ownerscopeid_unicode ON public.monitors USING btree (id) WHERE ((json ->> 'ownerScopeId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: participants_by_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX participants_by_principal ON public.participants USING btree (principal_id, session_id);


--
-- Name: participants_tenant_pkey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX participants_tenant_pkey ON public.participants USING btree (tenant_id, session_id, principal_id);


--
-- Name: qm_tenant_singleton; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX qm_tenant_singleton ON public.qm_tenant USING btree ((true));


--
-- Name: run_signals_by_dedupe_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX run_signals_by_dedupe_key ON public.run_signals USING btree (tenant_id, dedupe_key) WHERE (dedupe_key IS NOT NULL);


--
-- Name: session_goals_tenant_pkey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX session_goals_tenant_pkey ON public.session_goals USING btree (tenant_id, session_id);


--
-- Name: session_leases_tenant_pkey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX session_leases_tenant_pkey ON public.session_leases USING btree (tenant_id, session_id);


--
-- Name: session_llm_requests_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_by_session ON public.session_llm_requests USING btree (session_id, created_at, step);


--
-- Name: session_llm_requests_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_created_at ON public.session_llm_requests USING btree (created_at);


--
-- Name: session_llm_requests_screens; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_screens ON public.session_llm_requests USING btree (created_at DESC) WHERE (step = '-1'::integer);


--
-- Name: session_llm_requests_session_spend_recovery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_session_spend_recovery ON public.session_llm_requests USING btree (session_id, created_at) WHERE (usage_json IS NOT NULL);


--
-- Name: session_llm_requests_spend; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_spend ON public.session_llm_requests USING btree (created_at, (((public.spend_usage_json(usage_json) ->> 'costUsd'::text))::double precision), (((public.spend_usage_json(usage_json) ->> 'input'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'output'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'cacheRead'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'cacheWrite'::text))::bigint)) INCLUDE (session_id, model, usage_json) WHERE ((usage_json IS NOT NULL) AND ((public.spend_usage_json(usage_json) IS NOT NULL) AND (((octet_length(session_id) + octet_length(model)) + octet_length(usage_json)) <= 2000)));


--
-- Name: session_llm_requests_spend_wide; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_spend_wide ON public.session_llm_requests USING btree (created_at) WHERE ((usage_json IS NOT NULL) AND (NOT ((public.spend_usage_json(usage_json) IS NOT NULL) AND (((octet_length(session_id) + octet_length(model)) + octet_length(usage_json)) <= 2000))));


--
-- Name: session_llm_requests_tenant_pkey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX session_llm_requests_tenant_pkey ON public.session_llm_requests USING btree (tenant_id, id);


--
-- Name: session_mailbox_recipientid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_recipientid_fold ON public.session_mailbox USING hash (lower((json ->> 'recipientId'::text)));


--
-- Name: session_mailbox_recipientid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_recipientid_unicode ON public.session_mailbox USING btree (id) WHERE ((json ->> 'recipientId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: session_mailbox_wake_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_wake_fold ON public.session_mailbox USING hash (lower((json ->> 'wake'::text)));


--
-- Name: session_mailbox_wake_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_wake_unicode ON public.session_mailbox USING btree (id) WHERE ((json ->> 'wake'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: session_pins_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_pins_by_session ON public.session_pins USING btree (session_id, created_at);


--
-- Name: session_pins_tenant_pkey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX session_pins_tenant_pkey ON public.session_pins USING btree (tenant_id, id);


--
-- Name: session_spend_days_tenant_pkey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX session_spend_days_tenant_pkey ON public.session_spend_days USING btree (tenant_id, day);


--
-- Name: session_spend_dirty_day_writer_key_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX session_spend_dirty_day_writer_key_tenant ON public.session_spend_dirty USING btree (tenant_id, day, writer);


--
-- Name: sessions_by_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_activity ON public.sessions USING btree (COALESCE(last_activity, created_at) DESC, id DESC);


--
-- Name: sessions_by_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_scope ON public.sessions USING btree (scope_id, created_at DESC);


--
-- Name: sessions_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC);


--
-- Name: sessions_conversations_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_conversations_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC) WHERE (origin = 'conversation'::text);


--
-- Name: sessions_other_background_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_other_background_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC) WHERE (origin <> ALL (ARRAY['conversation'::text, 'cron'::text]));


--
-- Name: sessions_side_chat_origin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_side_chat_origin ON public.sessions USING btree (forked_from_session_id) WHERE (side_chat IS NOT NULL);


--
-- Name: sessions_tenant_pkey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sessions_tenant_pkey ON public.sessions USING btree (tenant_id, id);


--
-- Name: sessions_thread_ref_key_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sessions_thread_ref_key_tenant ON public.sessions USING btree (tenant_id, thread_ref);


--
-- Name: skills_resource_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_resource_name_idx ON public.skills USING btree ((((json -> 'manifest'::text) ->> 'name'::text)));


--
-- Name: skills_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_resource_search_gin ON public.skills USING gin (to_tsvector('simple'::regconfig, ((COALESCE(((json -> 'manifest'::text) ->> 'name'::text), ''::text) || ' '::text) || COALESCE(((json -> 'manifest'::text) ->> 'description'::text), ''::text))));


--
-- Name: skills_scopeid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_scopeid_fold ON public.skills USING hash (lower((json ->> 'scopeId'::text)));


--
-- Name: skills_scopeid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_scopeid_unicode ON public.skills USING btree (id) WHERE ((json ->> 'scopeId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: source_auth_replay_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_auth_replay_expires_at ON public.source_auth_replay USING btree (expires_at);


--
-- Name: swarms_pending_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX swarms_pending_fold ON public.swarms USING hash (lower((json ->> 'pending'::text)));


--
-- Name: swarms_pending_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX swarms_pending_unicode ON public.swarms USING btree (id) WHERE ((json ->> 'pending'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: team_members_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_members_principal ON public.team_members USING btree (principal_id);


--
-- Name: team_rooms_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_rooms_scope ON public.team_rooms USING btree (scope_id);


--
-- Name: tenants_app_handle; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tenants_app_handle ON public.tenants USING btree (public.qm_tenant_handle(settings));


--
-- Name: turn_metrics_by_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX turn_metrics_by_run ON public.turn_metrics USING btree (run_id);


--
-- Name: turn_metrics_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX turn_metrics_by_scope_ts ON public.turn_metrics USING btree (scope_label, ts DESC);


--
-- Name: turn_metrics_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX turn_metrics_by_session ON public.turn_metrics USING btree (session_id, ts DESC);


--
-- Name: turn_metrics_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX turn_metrics_by_ts ON public.turn_metrics USING btree (ts DESC);


--
-- Name: webhooks_ownerscopeid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_ownerscopeid_fold ON public.webhooks USING hash (lower((json ->> 'ownerScopeId'::text)));


--
-- Name: webhooks_ownerscopeid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_ownerscopeid_unicode ON public.webhooks USING btree (id) WHERE ((json ->> 'ownerScopeId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: webhooks_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_resource_search_gin ON public.webhooks USING gin (to_tsvector('simple'::regconfig, ((COALESCE((json ->> 'action'::text), ''::text) || ' '::text) || COALESCE(((json -> 'verification'::text) ->> 'scheme'::text), ''::text))));


--
-- Name: approval_grants_actorid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.approval_grants_actorid_stats ON (json ->> 'actorId'::text) FROM public.approval_grants;


--
-- Name: approvals_sessionid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.approvals_sessionid_stats ON (json ->> 'sessionId'::text) FROM public.approvals;


--
-- Name: crons_ownerscopeid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.crons_ownerscopeid_stats ON (json ->> 'ownerScopeId'::text) FROM public.crons;


--
-- Name: keychain_credentials_ownerid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.keychain_credentials_ownerid_stats ON (json ->> 'ownerId'::text) FROM public.keychain_credentials;


--
-- Name: keychain_grants_ownerid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.keychain_grants_ownerid_stats ON (json ->> 'ownerId'::text) FROM public.keychain_grants;


--
-- Name: loop_ingress_deliveries_queuekey_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_ingress_deliveries_queuekey_stats ON (json ->> 'queueKey'::text) FROM public.loop_ingress_deliveries;


--
-- Name: loop_ingress_loopid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_ingress_loopid_stats ON (json ->> 'loopId'::text) FROM public.loop_ingress;


--
-- Name: loop_items_loopid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_items_loopid_stats ON (json ->> 'loopId'::text) FROM public.loop_items;


--
-- Name: loop_outputs_itemid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_outputs_itemid_stats ON (json ->> 'itemId'::text) FROM public.loop_outputs;


--
-- Name: monitors_ownerscopeid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.monitors_ownerscopeid_stats ON (json ->> 'ownerScopeId'::text) FROM public.monitors;


--
-- Name: session_mailbox_recipientid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.session_mailbox_recipientid_stats ON (json ->> 'recipientId'::text) FROM public.session_mailbox;


--
-- Name: session_mailbox_wake_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.session_mailbox_wake_stats ON (json ->> 'wake'::text) FROM public.session_mailbox;


--
-- Name: skills_scopeid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.skills_scopeid_stats ON (json ->> 'scopeId'::text) FROM public.skills;


--
-- Name: swarms_pending_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.swarms_pending_stats ON (json ->> 'pending'::text) FROM public.swarms;


--
-- Name: webhooks_ownerscopeid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.webhooks_ownerscopeid_stats ON (json ->> 'ownerScopeId'::text) FROM public.webhooks;


--
-- Name: acl_grants acl_grants_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER acl_grants_bump AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.acl_grants FOR EACH STATEMENT EXECUTE FUNCTION public.acl_grants_bump_version();


--
-- Name: blobs blobs_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER blobs_immutable BEFORE DELETE OR UPDATE ON public.blobs FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: blobs blobs_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER blobs_no_truncate BEFORE TRUNCATE ON public.blobs FOR EACH STATEMENT EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: items items_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_append_only BEFORE UPDATE ON public.items FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: items items_delete_through_session; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_delete_through_session BEFORE DELETE ON public.items FOR EACH ROW EXECUTE FUNCTION public.forbid_direct_delete();


--
-- Name: items items_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_no_truncate BEFORE TRUNCATE ON public.items FOR EACH STATEMENT EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: memory_fact_vectors memory_fact_vectors_bits; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER memory_fact_vectors_bits BEFORE INSERT OR UPDATE OF embedding ON public.memory_fact_vectors FOR EACH ROW EXECUTE FUNCTION public.memory_fact_vectors_bits();


--
-- Name: memory_facts memory_facts_text_hash; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER memory_facts_text_hash BEFORE INSERT OR UPDATE OF text ON public.memory_facts FOR EACH ROW EXECUTE FUNCTION public.memory_facts_text_hash();


--
-- Name: session_llm_requests session_llm_requests_spend_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER session_llm_requests_spend_dirty AFTER INSERT OR DELETE OR UPDATE OF created_at, session_id, model, usage_json ON public.session_llm_requests FOR EACH ROW EXECUTE FUNCTION public.invalidate_request_spend();


--
-- Name: sessions sessions_spend_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sessions_spend_dirty AFTER INSERT OR DELETE OR UPDATE OF id, scope_id, origin, thread_ref, parent_session_id ON public.sessions FOR EACH ROW EXECUTE FUNCTION public.invalidate_session_spend();


--
-- Name: tenants tenants_retire_hosts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tenants_retire_hosts BEFORE DELETE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.qm_retire_tenant_hosts();


--
-- Name: ack_emoji ack_emoji_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji
    ADD CONSTRAINT ack_emoji_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: acl_grants acl_grants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants
    ADD CONSTRAINT acl_grants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: acl_grants_version acl_grants_version_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants_version
    ADD CONSTRAINT acl_grants_version_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: admin_grants admin_grants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_grants
    ADD CONSTRAINT admin_grants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: ambient_cursors ambient_cursors_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_cursors
    ADD CONSTRAINT ambient_cursors_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: app_page_views app_page_views_deployment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_page_views
    ADD CONSTRAINT app_page_views_deployment_id_fkey FOREIGN KEY (tenant_id, deployment_id) REFERENCES public.deployments(tenant_id, id);


--
-- Name: app_page_views app_page_views_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_page_views
    ADD CONSTRAINT app_page_views_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: approval_grant_modes approval_grant_modes_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grant_modes
    ADD CONSTRAINT approval_grant_modes_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: approval_grants approval_grants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grants
    ADD CONSTRAINT approval_grants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: approvals approvals_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: audit_log audit_log_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: aws_deploy_bodies aws_deploy_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_deploy_bodies
    ADD CONSTRAINT aws_deploy_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: aws_sandbox_bodies aws_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_sandbox_bodies
    ADD CONSTRAINT aws_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: base_model_configs base_model_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.base_model_configs
    ADD CONSTRAINT base_model_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: blobs blobs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blobs
    ADD CONSTRAINT blobs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: branding_configs branding_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_configs
    ADD CONSTRAINT branding_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: browse_max_steps_configs browse_max_steps_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_max_steps_configs
    ADD CONSTRAINT browse_max_steps_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: browser_sessions browser_sessions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browser_sessions
    ADD CONSTRAINT browser_sessions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: budget_spend budget_spend_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_spend
    ADD CONSTRAINT budget_spend_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: channel_header_pin_flag channel_header_pin_flag_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_header_pin_flag
    ADD CONSTRAINT channel_header_pin_flag_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: command_policies command_policies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_policies
    ADD CONSTRAINT command_policies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: composio_returns composio_returns_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composio_returns
    ADD CONSTRAINT composio_returns_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: connector_clients connector_clients_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_clients
    ADD CONSTRAINT connector_clients_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: consent_links consent_links_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_links
    ADD CONSTRAINT consent_links_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: context_requests context_requests_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.context_requests
    ADD CONSTRAINT context_requests_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: credential_daily_calls credential_daily_calls_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_daily_calls
    ADD CONSTRAINT credential_daily_calls_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: credential_usage credential_usage_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage
    ADD CONSTRAINT credential_usage_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: cron_fires cron_fires_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_fires
    ADD CONSTRAINT cron_fires_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: crons crons_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crons
    ADD CONSTRAINT crons_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: custom_model_providers custom_model_providers_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_model_providers
    ADD CONSTRAINT custom_model_providers_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: deactivated_principals deactivated_principals_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deactivated_principals
    ADD CONSTRAINT deactivated_principals_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: decision_providers decision_providers_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_providers
    ADD CONSTRAINT decision_providers_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: decision_rules decision_rules_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_provider_id_fkey FOREIGN KEY (tenant_id, provider_id) REFERENCES public.decision_providers(tenant_id, provider_id);


--
-- Name: decision_rules decision_rules_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: deliveries deliveries_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: deploy_git_repos deploy_git_repos_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_git_repos
    ADD CONSTRAINT deploy_git_repos_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: deployment_access deployment_access_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_id_fkey FOREIGN KEY (tenant_id, id) REFERENCES public.deployments(tenant_id, id) ON DELETE CASCADE;


--
-- Name: deployment_access deployment_access_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: deployment_identity deployment_identity_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_identity
    ADD CONSTRAINT deployment_identity_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: deployments deployments_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: directory_channel_members directory_channel_members_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channel_members
    ADD CONSTRAINT directory_channel_members_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: directory_channels directory_channels_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channels
    ADD CONSTRAINT directory_channels_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: directory_group_members directory_group_members_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_group_members
    ADD CONSTRAINT directory_group_members_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: directory_groups directory_groups_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_groups
    ADD CONSTRAINT directory_groups_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: directory_members directory_members_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_members
    ADD CONSTRAINT directory_members_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: directory_meta directory_meta_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_meta
    ADD CONSTRAINT directory_meta_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: directory_sync directory_sync_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_sync
    ADD CONSTRAINT directory_sync_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: do_managed_agents_sandbox_bodies do_managed_agents_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.do_managed_agents_sandbox_bodies
    ADD CONSTRAINT do_managed_agents_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: durable_map_versions durable_map_versions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.durable_map_versions
    ADD CONSTRAINT durable_map_versions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: e2b_sandbox_bodies e2b_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2b_sandbox_bodies
    ADD CONSTRAINT e2b_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: egress_events egress_events_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events
    ADD CONSTRAINT egress_events_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: egress_policies egress_policies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_policies
    ADD CONSTRAINT egress_policies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: environment_attachments environment_attachments_environment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_environment_id_fkey FOREIGN KEY (tenant_id, environment_id) REFERENCES public.environments(tenant_id, id);


--
-- Name: environment_attachments environment_attachments_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: environments environments_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: error_events error_events_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events
    ADD CONSTRAINT error_events_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: external_members external_members_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_members
    ADD CONSTRAINT external_members_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: external_slack_participants_flag external_slack_participants_flag_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_slack_participants_flag
    ADD CONSTRAINT external_slack_participants_flag_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: feature_flags feature_flags_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: file_artifact_deletions file_artifact_deletions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifact_deletions
    ADD CONSTRAINT file_artifact_deletions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: file_artifacts file_artifacts_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifacts
    ADD CONSTRAINT file_artifacts_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: file_uploads file_uploads_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_uploads
    ADD CONSTRAINT file_uploads_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: fly_deploy_configs fly_deploy_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fly_deploy_configs
    ADD CONSTRAINT fly_deploy_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: idempotency idempotency_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency
    ADD CONSTRAINT idempotency_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: individual_model_auth_flag individual_model_auth_flag_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.individual_model_auth_flag
    ADD CONSTRAINT individual_model_auth_flag_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: interactive_fast_mode_flag interactive_fast_mode_flag_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interactive_fast_mode_flag
    ADD CONSTRAINT interactive_fast_mode_flag_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: items items_blob; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_blob FOREIGN KEY (tenant_id, blob_sha) REFERENCES public.blobs(tenant_id, sha256);


--
-- Name: items items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: items items_session_id_fkey_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_session_id_fkey_tenant FOREIGN KEY (tenant_id, session_id) REFERENCES public.sessions(tenant_id, id) ON DELETE CASCADE NOT VALID;


--
-- Name: items items_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: keychain_asks keychain_asks_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_asks
    ADD CONSTRAINT keychain_asks_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: keychain_credentials keychain_credentials_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_credentials
    ADD CONSTRAINT keychain_credentials_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: keychain_grants keychain_grants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_grants
    ADD CONSTRAINT keychain_grants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: llm_prompt_envelopes llm_prompt_envelopes_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_prompt_envelopes
    ADD CONSTRAINT llm_prompt_envelopes_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: loop_ingress_deliveries loop_ingress_deliveries_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ingress_deliveries
    ADD CONSTRAINT loop_ingress_deliveries_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: loop_ingress loop_ingress_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ingress
    ADD CONSTRAINT loop_ingress_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: loop_items loop_items_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_items
    ADD CONSTRAINT loop_items_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: loop_outputs loop_outputs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_outputs
    ADD CONSTRAINT loop_outputs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: loop_ship_grants loop_ship_grants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ship_grants
    ADD CONSTRAINT loop_ship_grants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: loops loops_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loops
    ADD CONSTRAINT loops_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: mcp_servers mcp_servers_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: memory_fact_vectors memory_fact_vectors_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_fact_vectors
    ADD CONSTRAINT memory_fact_vectors_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: memory_facts memory_facts_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: memory_registry memory_registry_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_registry
    ADD CONSTRAINT memory_registry_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: memory_tidy_profiles memory_tidy_profiles_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_tidy_profiles
    ADD CONSTRAINT memory_tidy_profiles_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: modal_sandbox_bodies modal_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modal_sandbox_bodies
    ADD CONSTRAINT modal_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: model_credentials model_credentials_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_credentials
    ADD CONSTRAINT model_credentials_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: model_registry model_registry_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: monitors monitors_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: oauth_flows oauth_flows_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_flows
    ADD CONSTRAINT oauth_flows_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: org_ambient_flag org_ambient_flag_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_ambient_flag
    ADD CONSTRAINT org_ambient_flag_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: participants participants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: porter_deploy_bodies porter_deploy_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.porter_deploy_bodies
    ADD CONSTRAINT porter_deploy_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: process_sessions process_sessions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_sessions
    ADD CONSTRAINT process_sessions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: projects projects_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: render_app_storage render_app_storage_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_app_storage
    ADD CONSTRAINT render_app_storage_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: render_deploy_bodies render_deploy_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_deploy_bodies
    ADD CONSTRAINT render_deploy_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: render_deploy_credentials render_deploy_credentials_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_deploy_credentials
    ADD CONSTRAINT render_deploy_credentials_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: render_sandbox_bodies render_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_sandbox_bodies
    ADD CONSTRAINT render_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: render_sandbox_cleanup render_sandbox_cleanup_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_sandbox_cleanup
    ADD CONSTRAINT render_sandbox_cleanup_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: render_scratch_bodies render_scratch_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_scratch_bodies
    ADD CONSTRAINT render_scratch_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: run_activity run_activity_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity
    ADD CONSTRAINT run_activity_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: run_signals run_signals_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals
    ADD CONSTRAINT run_signals_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: runs runs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: sandbox_defaults sandbox_defaults_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_defaults
    ADD CONSTRAINT sandbox_defaults_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: sandbox_resource_rollout sandbox_resource_rollout_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resource_rollout
    ADD CONSTRAINT sandbox_resource_rollout_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: sandbox_resources sandbox_resources_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resources
    ADD CONSTRAINT sandbox_resources_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: sandbox_routing sandbox_routing_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_routing
    ADD CONSTRAINT sandbox_routing_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: secret_drops secret_drops_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_drops
    ADD CONSTRAINT secret_drops_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: security_postures security_postures_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_postures
    ADD CONSTRAINT security_postures_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: session_goals session_goals_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: session_goals session_goals_session_id_fkey_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_session_id_fkey_tenant FOREIGN KEY (tenant_id, session_id) REFERENCES public.sessions(tenant_id, id) ON DELETE CASCADE NOT VALID;


--
-- Name: session_goals session_goals_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_leases session_leases_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_leases
    ADD CONSTRAINT session_leases_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_llm_requests session_llm_requests_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_llm_requests
    ADD CONSTRAINT session_llm_requests_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_mailbox session_mailbox_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_mailbox
    ADD CONSTRAINT session_mailbox_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: session_pins session_pins_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_pins
    ADD CONSTRAINT session_pins_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_shares session_shares_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_shares
    ADD CONSTRAINT session_shares_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: session_spend_days session_spend_days_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_days
    ADD CONSTRAINT session_spend_days_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_spend_dirty session_spend_dirty_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_dirty
    ADD CONSTRAINT session_spend_dirty_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: sessions sessions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: sharing_postures sharing_postures_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sharing_postures
    ADD CONSTRAINT sharing_postures_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: skill_bundles skill_bundles_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_bundles
    ADD CONSTRAINT skill_bundles_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: skill_packs skill_packs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_packs
    ADD CONSTRAINT skill_packs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: skills skills_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: slack_accounts slack_accounts_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_accounts
    ADD CONSTRAINT slack_accounts_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: slack_emoji_catalog slack_emoji_catalog_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_emoji_catalog
    ADD CONSTRAINT slack_emoji_catalog_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: slack_installation slack_installation_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_installation
    ADD CONSTRAINT slack_installation_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: slack_session_status slack_session_status_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_session_status
    ADD CONSTRAINT slack_session_status_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: slack_staged_envelopes slack_staged_envelopes_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_staged_envelopes
    ADD CONSTRAINT slack_staged_envelopes_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: slack_task_acknowledgements slack_task_acknowledgements_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_task_acknowledgements
    ADD CONSTRAINT slack_task_acknowledgements_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: smolmachines_sandbox_bodies smolmachines_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smolmachines_sandbox_bodies
    ADD CONSTRAINT smolmachines_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: soul_configs soul_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_configs
    ADD CONSTRAINT soul_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: soul_history soul_history_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_history
    ADD CONSTRAINT soul_history_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: spend_limit_configs spend_limit_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend_limit_configs
    ADD CONSTRAINT spend_limit_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: sprites_initialization sprites_initialization_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprites_initialization
    ADD CONSTRAINT sprites_initialization_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: suggested_activity_profiles suggested_activity_profiles_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggested_activity_profiles
    ADD CONSTRAINT suggested_activity_profiles_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: superserve_sandbox_bodies superserve_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_sandbox_bodies
    ADD CONSTRAINT superserve_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: swarms swarms_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swarms
    ADD CONSTRAINT swarms_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(team_id) ON DELETE CASCADE;


--
-- Name: team_rooms team_rooms_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(team_id) ON DELETE CASCADE;


--
-- Name: web_ui_state web_ui_state_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_ui_state
    ADD CONSTRAINT web_ui_state_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: webhook_history webhook_history_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_history
    ADD CONSTRAINT webhook_history_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: webhooks webhooks_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: webui_model_configs webui_model_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webui_model_configs
    ADD CONSTRAINT webui_model_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: ack_emoji; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ack_emoji ENABLE ROW LEVEL SECURITY;

--
-- Name: acl_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.acl_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: acl_grants_version; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.acl_grants_version ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: ambient_cursors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ambient_cursors ENABLE ROW LEVEL SECURITY;

--
-- Name: app_page_views; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.app_page_views ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_grant_modes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_grant_modes ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: approvals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approvals ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: aws_deploy_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.aws_deploy_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: aws_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.aws_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: base_model_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.base_model_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: branding_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.branding_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: browse_max_steps_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.browse_max_steps_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: browser_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.browser_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: budget_spend; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.budget_spend ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_header_pin_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_header_pin_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: command_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.command_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: composio_returns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.composio_returns ENABLE ROW LEVEL SECURITY;

--
-- Name: connector_clients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.connector_clients ENABLE ROW LEVEL SECURITY;

--
-- Name: consent_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.consent_links ENABLE ROW LEVEL SECURITY;

--
-- Name: context_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.context_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_daily_calls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credential_daily_calls ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_usage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credential_usage ENABLE ROW LEVEL SECURITY;

--
-- Name: cron_fires; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cron_fires ENABLE ROW LEVEL SECURITY;

--
-- Name: crons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.crons ENABLE ROW LEVEL SECURITY;

--
-- Name: custom_model_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.custom_model_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: deactivated_principals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deactivated_principals ENABLE ROW LEVEL SECURITY;

--
-- Name: decision_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decision_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: decision_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decision_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: deploy_git_repos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deploy_git_repos ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_access; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_access ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_identity; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_identity ENABLE ROW LEVEL SECURITY;

--
-- Name: deployments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployments ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_channel_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_channel_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_channels; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_channels ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_group_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_group_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_meta; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_meta ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_sync; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_sync ENABLE ROW LEVEL SECURITY;

--
-- Name: do_managed_agents_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.do_managed_agents_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: durable_map_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.durable_map_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: e2b_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.e2b_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: egress_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.egress_events ENABLE ROW LEVEL SECURITY;

--
-- Name: egress_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.egress_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: environment_attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.environment_attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: environments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.environments ENABLE ROW LEVEL SECURITY;

--
-- Name: error_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.error_events ENABLE ROW LEVEL SECURITY;

--
-- Name: external_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_members ENABLE ROW LEVEL SECURITY;

--
-- Name: external_slack_participants_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_slack_participants_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_flags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;

--
-- Name: file_artifact_deletions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_artifact_deletions ENABLE ROW LEVEL SECURITY;

--
-- Name: file_artifacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_artifacts ENABLE ROW LEVEL SECURITY;

--
-- Name: file_uploads; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: fly_deploy_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fly_deploy_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: idempotency; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.idempotency ENABLE ROW LEVEL SECURITY;

--
-- Name: individual_model_auth_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.individual_model_auth_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: interactive_fast_mode_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.interactive_fast_mode_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_asks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_asks ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_ingress; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_ingress ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_ingress_deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_ingress_deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_items ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_outputs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_outputs ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_ship_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_ship_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: loops; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loops ENABLE ROW LEVEL SECURITY;

--
-- Name: mcp_servers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mcp_servers ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_fact_vectors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_fact_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_facts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_facts ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_registry; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_registry ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_tidy_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_tidy_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: modal_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.modal_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: model_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.model_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: model_registry; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.model_registry ENABLE ROW LEVEL SECURITY;

--
-- Name: monitors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.monitors ENABLE ROW LEVEL SECURITY;

--
-- Name: oauth_flows; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.oauth_flows ENABLE ROW LEVEL SECURITY;

--
-- Name: org_ambient_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_ambient_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: porter_deploy_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.porter_deploy_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: process_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.process_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: projects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

--
-- Name: render_app_storage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.render_app_storage ENABLE ROW LEVEL SECURITY;

--
-- Name: render_deploy_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.render_deploy_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: render_deploy_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.render_deploy_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: render_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.render_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: render_sandbox_cleanup; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.render_sandbox_cleanup ENABLE ROW LEVEL SECURITY;

--
-- Name: render_scratch_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.render_scratch_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: retired_tenant_hosts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.retired_tenant_hosts ENABLE ROW LEVEL SECURITY;

--
-- Name: run_activity; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.run_activity ENABLE ROW LEVEL SECURITY;

--
-- Name: run_signals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.run_signals ENABLE ROW LEVEL SECURITY;

--
-- Name: runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runs ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_defaults; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_defaults ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_resource_rollout; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_resource_rollout ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_resources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_resources ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_routing; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_routing ENABLE ROW LEVEL SECURITY;

--
-- Name: secret_drops; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.secret_drops ENABLE ROW LEVEL SECURITY;

--
-- Name: security_postures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.security_postures ENABLE ROW LEVEL SECURITY;

--
-- Name: session_mailbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_mailbox ENABLE ROW LEVEL SECURITY;

--
-- Name: session_shares; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_shares ENABLE ROW LEVEL SECURITY;

--
-- Name: sharing_postures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sharing_postures ENABLE ROW LEVEL SECURITY;

--
-- Name: skill_bundles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skill_bundles ENABLE ROW LEVEL SECURITY;

--
-- Name: skill_packs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skill_packs ENABLE ROW LEVEL SECURITY;

--
-- Name: skills; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skills ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_emoji_catalog; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_emoji_catalog ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_installation; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_installation ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_session_status; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_session_status ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_staged_envelopes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_staged_envelopes ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_task_acknowledgements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_task_acknowledgements ENABLE ROW LEVEL SECURITY;

--
-- Name: smolmachines_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.smolmachines_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: soul_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.soul_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: soul_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.soul_history ENABLE ROW LEVEL SECURITY;

--
-- Name: spend_limit_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.spend_limit_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: sprites_initialization; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sprites_initialization ENABLE ROW LEVEL SECURITY;

--
-- Name: suggested_activity_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suggested_activity_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: superserve_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.superserve_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: swarms; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.swarms ENABLE ROW LEVEL SECURITY;

--
-- Name: ack_emoji tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.ack_emoji USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: acl_grants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.acl_grants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: acl_grants_version tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.acl_grants_version USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: admin_grants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.admin_grants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: ambient_cursors tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.ambient_cursors USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: app_page_views tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.app_page_views USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: approval_grant_modes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.approval_grant_modes USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: approval_grants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.approval_grants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: approvals tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.approvals USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: audit_log tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.audit_log USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: aws_deploy_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.aws_deploy_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: aws_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.aws_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: base_model_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.base_model_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: branding_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.branding_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: browse_max_steps_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.browse_max_steps_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: browser_sessions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.browser_sessions USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: budget_spend tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.budget_spend USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: channel_header_pin_flag tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.channel_header_pin_flag USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: command_policies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.command_policies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: composio_returns tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.composio_returns USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: connector_clients tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.connector_clients USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: consent_links tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.consent_links USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: context_requests tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.context_requests USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: credential_daily_calls tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.credential_daily_calls USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: credential_usage tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.credential_usage USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: cron_fires tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.cron_fires USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: crons tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.crons USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: custom_model_providers tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.custom_model_providers USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deactivated_principals tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deactivated_principals USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: decision_providers tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.decision_providers USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: decision_rules tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.decision_rules USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deliveries tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deliveries USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deploy_git_repos tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deploy_git_repos USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deployment_access tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deployment_access USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deployment_identity tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deployment_identity USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deployments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deployments USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_channel_members tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_channel_members USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_channels tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_channels USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_group_members tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_group_members USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_groups tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_groups USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_members tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_members USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_meta tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_meta USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_sync tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_sync USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: do_managed_agents_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.do_managed_agents_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: durable_map_versions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.durable_map_versions USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: e2b_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.e2b_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: egress_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.egress_events USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: egress_policies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.egress_policies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: environment_attachments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.environment_attachments USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: environments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.environments USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: error_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.error_events USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: external_members tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.external_members USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: external_slack_participants_flag tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.external_slack_participants_flag USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: feature_flags tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.feature_flags USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: file_artifact_deletions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.file_artifact_deletions USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: file_artifacts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.file_artifacts USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: file_uploads tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.file_uploads USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: fly_deploy_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.fly_deploy_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: idempotency tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.idempotency USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: individual_model_auth_flag tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.individual_model_auth_flag USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: interactive_fast_mode_flag tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.interactive_fast_mode_flag USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: keychain_asks tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.keychain_asks USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: keychain_credentials tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.keychain_credentials USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: keychain_grants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.keychain_grants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loop_ingress tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loop_ingress USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loop_ingress_deliveries tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loop_ingress_deliveries USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loop_items tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loop_items USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loop_outputs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loop_outputs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loop_ship_grants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loop_ship_grants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loops tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loops USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: mcp_servers tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.mcp_servers USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: memory_fact_vectors tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.memory_fact_vectors USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: memory_facts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.memory_facts USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: memory_registry tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.memory_registry USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: memory_tidy_profiles tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.memory_tidy_profiles USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: modal_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.modal_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: model_credentials tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.model_credentials USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: model_registry tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.model_registry USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: monitors tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.monitors USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: oauth_flows tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.oauth_flows USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: org_ambient_flag tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.org_ambient_flag USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: porter_deploy_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.porter_deploy_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: process_sessions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.process_sessions USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: projects tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.projects USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: render_app_storage tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.render_app_storage USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: render_deploy_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.render_deploy_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: render_deploy_credentials tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.render_deploy_credentials USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: render_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.render_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: render_sandbox_cleanup tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.render_sandbox_cleanup USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: render_scratch_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.render_scratch_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: run_activity tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.run_activity USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: run_signals tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.run_signals USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: runs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.runs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sandbox_defaults tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sandbox_defaults USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sandbox_resource_rollout tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sandbox_resource_rollout USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sandbox_resources tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sandbox_resources USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sandbox_routing tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sandbox_routing USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: secret_drops tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.secret_drops USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: security_postures tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.security_postures USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: session_mailbox tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_mailbox USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: session_shares tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_shares USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sharing_postures tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sharing_postures USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: skill_bundles tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.skill_bundles USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: skill_packs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.skill_packs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: skills tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.skills USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_accounts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_accounts USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_emoji_catalog tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_emoji_catalog USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_installation tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_installation USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_session_status tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_session_status USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_staged_envelopes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_staged_envelopes USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_task_acknowledgements tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_task_acknowledgements USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: smolmachines_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.smolmachines_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: soul_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.soul_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: soul_history tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.soul_history USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: spend_limit_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.spend_limit_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sprites_initialization tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sprites_initialization USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: suggested_activity_profiles tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.suggested_activity_profiles USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: superserve_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.superserve_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: swarms tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.swarms USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: tenants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.tenants FOR SELECT USING ((id = public.qm_bound_tenant()));


--
-- Name: web_ui_state tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.web_ui_state USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: webhook_history tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.webhook_history USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: webhooks tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.webhooks USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: webui_model_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.webui_model_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: web_ui_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.web_ui_state ENABLE ROW LEVEL SECURITY;

--
-- Name: webhook_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhook_history ENABLE ROW LEVEL SECURITY;

--
-- Name: webhooks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhooks ENABLE ROW LEVEL SECURITY;

--
-- Name: webui_model_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webui_model_configs ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--


