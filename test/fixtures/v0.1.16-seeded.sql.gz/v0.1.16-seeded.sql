--
-- PostgreSQL database dump
--


-- Dumped from database version 18.6 (Ubuntu 18.6-0ubuntu0.26.04.1)
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-0ubuntu0.26.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgboss; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgboss;


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: job_state; Type: TYPE; Schema: pgboss; Owner: -
--

CREATE TYPE pgboss.job_state AS ENUM (
    'created',
    'retry',
    'active',
    'completed',
    'cancelled',
    'failed'
);


--
-- Name: item_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.item_kind AS ENUM (
    'UserMessage',
    'SteeringMessage',
    'AgentMessage',
    'Reasoning',
    'ToolCall',
    'ToolResult',
    'Elicitation',
    'ElicitationResponse',
    'Wake',
    'Error',
    'ContextCompaction',
    'Retraction',
    'Stop',
    'RuntimeChange'
);


--
-- Name: wake_cause; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.wake_cause AS ENUM (
    'cron',
    'webhook',
    'child_done',
    'system'
);


--
-- Name: create_queue(text, jsonb); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.create_queue(queue_name text, options jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $_$
    DECLARE
      tablename varchar := CASE WHEN options->>'partition' = 'true'
                            THEN 'j' || encode(sha224(queue_name::bytea), 'hex')
                            ELSE 'job_common'
                            END;
      queue_created_on timestamptz;
    BEGIN

      WITH q as (
        INSERT INTO pgboss.queue (
          name,
          policy,
          retry_limit,
          retry_delay,
          retry_backoff,
          retry_delay_max,
          expire_seconds,
          retention_seconds,
          deletion_seconds,
          warning_queued,
          dead_letter,
          partition,
          table_name,
          heartbeat_seconds,
          notify
        )
        VALUES (
          queue_name,
          options->>'policy',
          COALESCE((options->>'retryLimit')::int, 2),
          COALESCE((options->>'retryDelay')::int, 0),
          COALESCE((options->>'retryBackoff')::bool, false),
          (options->>'retryDelayMax')::int,
          COALESCE((options->>'expireInSeconds')::int, 900),
          COALESCE((options->>'retentionSeconds')::int, 1209600),
          COALESCE((options->>'deleteAfterSeconds')::int, 604800),
          COALESCE((options->>'warningQueueSize')::int, 0),
          options->>'deadLetter',
          COALESCE((options->>'partition')::bool, false),
          tablename,
          (options->>'heartbeatSeconds')::int,
          COALESCE((options->>'notify')::bool, false)
        )
        ON CONFLICT DO NOTHING
        RETURNING created_on
      )
      SELECT created_on into queue_created_on from q;

      IF queue_created_on IS NULL OR options->>'partition' IS DISTINCT FROM 'true' THEN
        RETURN;
      END IF;

      EXECUTE format('CREATE TABLE pgboss.%I (LIKE pgboss.job INCLUDING DEFAULTS)', tablename);

      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD PRIMARY KEY (name, id)$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED$cmd$, tablename);

      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i5 ON pgboss.job (name, start_after) WHERE state < 'active' AND NOT blocked$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i4 ON pgboss.job (name, singleton_on, COALESCE(singleton_key, '')) WHERE state <> 'cancelled' AND singleton_on IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i7 ON pgboss.job (name, group_id) WHERE state = 'active' AND group_id IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i9 ON pgboss.job (name, id) WHERE blocking AND state = 'completed'$cmd$, tablename);

      IF options->>'policy' = 'short' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i1 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state = 'created' AND policy = 'short'$cmd$, tablename);
      ELSIF options->>'policy' = 'singleton' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i2 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state = 'active' AND policy = 'singleton'$cmd$, tablename);
      ELSIF options->>'policy' = 'stately' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i3 ON pgboss.job (name, state, COALESCE(singleton_key, '')) WHERE state <= 'active' AND policy = 'stately'$cmd$, tablename);
      ELSIF options->>'policy' = 'exclusive' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i6 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state <= 'active' AND policy = 'exclusive'$cmd$, tablename);
      ELSIF options->>'policy' = 'key_strict_fifo' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i8 ON pgboss.job (name, singleton_key) WHERE state IN ('active', 'retry', 'failed') AND policy = 'key_strict_fifo'$cmd$, tablename);
        EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT job_key_strict_fifo_singleton_key_check CHECK (NOT (policy = 'key_strict_fifo' AND singleton_key IS NULL))$cmd$, tablename);
      END IF;

      EXECUTE format('ALTER TABLE pgboss.%I ADD CONSTRAINT cjc CHECK (name=%L)', tablename, queue_name);
      EXECUTE format('ALTER TABLE pgboss.job ATTACH PARTITION pgboss.%I FOR VALUES IN (%L)', tablename, queue_name);
    END;
    $_$;


--
-- Name: delete_queue(text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.delete_queue(queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      v_table varchar;
      v_partition bool;
    BEGIN
      
      SELECT table_name, partition
      FROM pgboss.queue
      WHERE name = queue_name
      INTO v_table, v_partition;

      IF v_partition THEN
        EXECUTE format('DROP TABLE IF EXISTS pgboss.%I', v_table);
      ELSE
        EXECUTE format('DELETE FROM pgboss.%I WHERE name = %L', v_table, queue_name);
      END IF;
    
      DELETE FROM pgboss.queue WHERE name = queue_name;
    END;
    $$;


--
-- Name: job_table_format(text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_format(command text, table_name text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $_$
      SELECT format(
        regexp_replace(
          regexp_replace(command, '\.job\y', '.%1$I', 'g'),
          '\yjob_i(\d+)', '%1$s_i\1', 'g'
        ),
        table_name
      );
    $_$;


--
-- Name: job_table_run(text, text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_run(command text, tbl_name text DEFAULT NULL::text, queue_name text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      tbl RECORD;
    BEGIN
      IF queue_name IS NOT NULL THEN
        SELECT table_name INTO tbl_name FROM pgboss.queue WHERE name = queue_name;
      END IF;

      IF tbl_name IS NOT NULL THEN
        EXECUTE pgboss.job_table_format(command, tbl_name);
        RETURN;
      END IF;

      EXECUTE pgboss.job_table_format(command, 'job_common');

      FOR tbl IN SELECT table_name FROM pgboss.queue WHERE partition = true
      LOOP
        EXECUTE pgboss.job_table_format(command, tbl.table_name);
      END LOOP;
    END;
    $$;


--
-- Name: job_table_run_async(text, integer, text, text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_run_async(command_name text, version integer, command text, tbl_name text DEFAULT NULL::text, queue_name text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF queue_name IS NOT NULL THEN
        SELECT table_name INTO tbl_name FROM pgboss.queue WHERE name = queue_name;
      END IF;

      IF tbl_name IS NOT NULL THEN
        INSERT INTO pgboss.bam (name, version, status, queue, table_name, command)
        VALUES (
          command_name,
          version,
          'pending',
          queue_name,
          tbl_name,
          pgboss.job_table_format(command, tbl_name)
        );
        RETURN;
      END IF;

      INSERT INTO pgboss.bam (name, version, status, queue, table_name, command)
      SELECT
        command_name,
        version,
        'pending',
        NULL,
        'job_common',
        pgboss.job_table_format(command, 'job_common')
      UNION ALL
      SELECT
        command_name,
        version,
        'pending',
        queue.name,
        queue.table_name,
        pgboss.job_table_format(command, queue.table_name)
      FROM pgboss.queue
      WHERE partition = true;
    END;
    $$;


--
-- Name: acl_grants_bump_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.acl_grants_bump_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        IF TG_LEVEL = 'STATEMENT' THEN
          UPDATE acl_grants_version SET v = v + 1;
        ELSE
          INSERT INTO acl_grants_version(tenant_id, only_row, v)
          SELECT DISTINCT tenant, TRUE, 1
            FROM (VALUES (CASE WHEN TG_OP <> 'INSERT' THEN OLD.tenant_id END),
                         (CASE WHEN TG_OP <> 'DELETE' THEN NEW.tenant_id END)) changed(tenant)
           WHERE tenant IS NOT NULL
          ON CONFLICT (tenant_id, only_row) DO UPDATE SET v = acl_grants_version.v + 1;
        END IF;
        RETURN NULL;
      END
      $$;


--
-- Name: forbid_direct_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_direct_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     IF pg_trigger_depth() > 1 THEN RETURN OLD; END IF;
     RAISE EXCEPTION 'DELETE on % is only allowed through its session', TG_TABLE_NAME
       USING ERRCODE = 'integrity_constraint_violation';
   END $$;


--
-- Name: forbid_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     RAISE EXCEPTION '% on % is forbidden', TG_OP, TG_TABLE_NAME USING ERRCODE = 'integrity_constraint_violation';
   END $$;


--
-- Name: invalidate_request_spend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_request_spend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     INSERT INTO session_spend_dirty(tenant_id, day)
     SELECT DISTINCT tenant, floor(at::numeric / 86400000)::bigint
       FROM (VALUES
         (CASE WHEN TG_OP <> 'INSERT' AND OLD.usage_json IS NOT NULL THEN OLD.tenant_id END,
          CASE WHEN TG_OP <> 'INSERT' AND OLD.usage_json IS NOT NULL THEN OLD.created_at END),
         (CASE WHEN TG_OP <> 'DELETE' AND NEW.usage_json IS NOT NULL THEN NEW.tenant_id END,
          CASE WHEN TG_OP <> 'DELETE' AND NEW.usage_json IS NOT NULL THEN NEW.created_at END)
       ) changed(tenant, at) WHERE at IS NOT NULL
     ON CONFLICT DO NOTHING;
     RETURN NULL;
   END $$;


--
-- Name: invalidate_session_spend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_session_spend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     IF TG_OP = 'UPDATE' AND ROW(OLD.id, OLD.scope_id, OLD.origin, OLD.thread_ref, OLD.parent_session_id)
          IS NOT DISTINCT FROM ROW(NEW.id, NEW.scope_id, NEW.origin, NEW.thread_ref, NEW.parent_session_id) THEN
       RETURN NULL;
     END IF;
     INSERT INTO session_spend_dirty(tenant_id, session_id)
     SELECT DISTINCT tenant, id FROM (VALUES (OLD.tenant_id, OLD.id), (NEW.tenant_id, NEW.id)) changed(tenant, id)
      WHERE id IS NOT NULL;
     RETURN NULL;
   END $$;


--
-- Name: memory_facts_text_hash(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.memory_facts_text_hash() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        NEW.text_hash := encode(sha256(convert_to(NEW.text, 'UTF8')), 'hex');
        RETURN NEW;
      END $$;


--
-- Name: qm_bound_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_bound_tenant() RETURNS uuid
    LANGUAGE plpgsql STABLE PARALLEL SAFE
    AS $$
DECLARE
  bound text := current_setting('qm.tenant_id', true);
  sole uuid;
BEGIN
  IF bound IS NULL OR bound = '' THEN
    SELECT tenant.sole INTO sole FROM qm_sole_tenant() tenant;
    IF sole IS NULL THEN
      RAISE insufficient_privilege USING MESSAGE = 'No tenant is bound to this query';
    END IF;
    RETURN sole;
  END IF;
  RETURN bound::uuid;
END $$;


--
-- Name: qm_host_tenant(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_host_tenant(requested text) RETURNS TABLE(tenant_id uuid, multi boolean, retired boolean)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
      SELECT (SELECT h.tenant_id FROM tenant_hosts h WHERE h.host = lower(requested)),
        EXISTS (SELECT 1 FROM tenant_hosts) OR EXISTS (SELECT 1 FROM retired_tenant_hosts),
        EXISTS (SELECT 1 FROM retired_tenant_hosts r WHERE r.host = lower(requested))
    $$;


--
-- Name: qm_retire_tenant_hosts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_retire_tenant_hosts() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
      BEGIN
        INSERT INTO retired_tenant_hosts(host) SELECT h.host FROM tenant_hosts h WHERE h.tenant_id = OLD.id
          ON CONFLICT (host) DO NOTHING;
        RETURN OLD;
      END
    $$;


--
-- Name: qm_sole_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_sole_tenant(OUT sole uuid, OUT tenants bigint) RETURNS record
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
       SELECT CASE WHEN count(*) = 1 THEN min(id::text)::uuid END, count(*) FROM tenants
     $$;


--
-- Name: qm_tenant_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_id() RETURNS uuid
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$ SELECT id FROM qm_tenant $$;


--
-- Name: qm_tenant_settings(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_settings() RETURNS jsonb
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
      SELECT settings FROM tenants WHERE id = qm_bound_tenant()
    $$;


--
-- Name: spend_usage_json(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.spend_usage_json(t text) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE
    AS $$
             DECLARE j jsonb;
             BEGIN
               IF t IS NULL OR octet_length(t) > 2000 OR NOT pg_input_is_valid(t, 'jsonb') THEN
                 RETURN NULL;
               END IF;
               j := t::jsonb;
               IF pg_input_is_valid(j ->> 'costUsd', 'double precision') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'input', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'output', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheRead', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheWrite', 'bigint') IS NOT FALSE THEN
                 RETURN j;
               END IF;
               RETURN NULL;
             END
             $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bam; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.bam (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    version integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    queue text,
    table_name text NOT NULL,
    command text NOT NULL,
    error text,
    created_on timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone
);


--
-- Name: job; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    retry_delay_max integer,
    expire_seconds integer DEFAULT 900 NOT NULL,
    deletion_seconds integer DEFAULT 604800 NOT NULL,
    singleton_key text,
    singleton_on timestamp without time zone,
    group_id text,
    group_tier text,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '336:00:00'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    heartbeat_on timestamp with time zone,
    heartbeat_seconds integer,
    blocked boolean DEFAULT false NOT NULL,
    blocking boolean DEFAULT false NOT NULL,
    pending_dependencies integer DEFAULT 0 NOT NULL,
    source_name text,
    source_id uuid,
    source_created_on timestamp with time zone,
    source_retry_count integer
)
PARTITION BY LIST (name);


--
-- Name: job_common; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job_common (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    retry_delay_max integer,
    expire_seconds integer DEFAULT 900 NOT NULL,
    deletion_seconds integer DEFAULT 604800 NOT NULL,
    singleton_key text,
    singleton_on timestamp without time zone,
    group_id text,
    group_tier text,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '336:00:00'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    heartbeat_on timestamp with time zone,
    heartbeat_seconds integer,
    blocked boolean DEFAULT false NOT NULL,
    blocking boolean DEFAULT false NOT NULL,
    pending_dependencies integer DEFAULT 0 NOT NULL,
    source_name text,
    source_id uuid,
    source_created_on timestamp with time zone,
    source_retry_count integer,
    CONSTRAINT job_key_strict_fifo_singleton_key_check CHECK ((NOT ((policy = 'key_strict_fifo'::text) AND (singleton_key IS NULL))))
);


--
-- Name: job_dependency; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job_dependency (
    child_name text NOT NULL,
    child_id uuid NOT NULL,
    parent_name text NOT NULL,
    parent_id uuid NOT NULL
);


--
-- Name: queue; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue (
    name text NOT NULL,
    policy text NOT NULL,
    retry_limit integer NOT NULL,
    retry_delay integer NOT NULL,
    retry_backoff boolean NOT NULL,
    retry_delay_max integer,
    expire_seconds integer NOT NULL,
    retention_seconds integer NOT NULL,
    deletion_seconds integer NOT NULL,
    dead_letter text,
    partition boolean NOT NULL,
    table_name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    warning_queued integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    ready_history integer[] DEFAULT '{}'::integer[] NOT NULL,
    heartbeat_seconds integer,
    notify boolean DEFAULT false NOT NULL,
    singletons_active text[],
    monitor_on timestamp with time zone,
    maintain_on timestamp with time zone,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT queue_check CHECK ((dead_letter IS DISTINCT FROM name))
);


--
-- Name: queue_stats; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    captured_on timestamp with time zone DEFAULT now() NOT NULL
)
PARTITION BY RANGE (captured_on);


--
-- Name: queue_stats_20261109; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats_20261109 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    captured_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: queue_stats_20261110; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats_20261110 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    captured_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schedule; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.schedule (
    name text NOT NULL,
    key text DEFAULT ''::text NOT NULL,
    cron text NOT NULL,
    timezone text,
    data jsonb,
    options jsonb,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscription; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.subscription (
    event text NOT NULL,
    name text NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: version; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.version (
    version integer NOT NULL,
    cron_on timestamp with time zone,
    bam_on timestamp with time zone,
    flow_on timestamp with time zone
);


--
-- Name: warning; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.warning (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type text NOT NULL,
    message text NOT NULL,
    data jsonb,
    created_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ack_emoji; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: ack_emoji_picks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji_picks (
    id bigint NOT NULL,
    org_id text NOT NULL,
    surface text NOT NULL,
    channel text NOT NULL,
    ts text NOT NULL,
    outcome text NOT NULL,
    picked text,
    icon text,
    message text,
    candidates text,
    model text,
    latency_ms integer,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ack_emoji_picks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ack_emoji_picks_id_seq OWNED BY public.ack_emoji_picks.id;


--
-- Name: acl_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acl_grants (
    owner_scope_id text NOT NULL,
    path text NOT NULL,
    grantee_scope_id text NOT NULL,
    permission text NOT NULL,
    granted_by text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: acl_grants_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acl_grants_version (
    only_row boolean DEFAULT true NOT NULL,
    v bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    CONSTRAINT acl_grants_version_only_row_check CHECK (only_row)
);


--
-- Name: admin_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_grants (
    principal_id text NOT NULL,
    scope_id text NOT NULL,
    role text NOT NULL,
    granted_by text,
    created_at bigint,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: ambient_cursors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ambient_cursors (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: ambient_judgments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ambient_judgments (
    id bigint NOT NULL,
    org_id text NOT NULL,
    surface text NOT NULL,
    container text NOT NULL,
    decision text NOT NULL,
    reason text,
    asked_by text,
    prompt text,
    model text,
    latency_ms integer,
    ts_from text,
    ts_to text,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ambient_judgments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ambient_judgments_id_seq OWNED BY public.ambient_judgments.id;


--
-- Name: app_page_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_page_views (
    id bigint NOT NULL,
    deployment_id text NOT NULL,
    version integer,
    viewer text,
    auth_mode text NOT NULL,
    at bigint NOT NULL,
    path text NOT NULL,
    ip text,
    user_agent text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: app_page_views_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.app_page_views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: app_page_views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.app_page_views_id_seq OWNED BY public.app_page_views.id;


--
-- Name: approval_grant_modes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grant_modes (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: approval_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grants (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approvals (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    at bigint NOT NULL,
    principal_id text NOT NULL,
    action text NOT NULL,
    resource text NOT NULL,
    scope_label text NOT NULL,
    status text,
    detail text,
    idempotency_key text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: auth_broker_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_broker_sessions (
    token_hash text NOT NULL,
    email text NOT NULL,
    authenticated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    absolute_expires_at timestamp with time zone NOT NULL,
    idle_seconds integer NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: aws_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aws_sandbox_bodies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: base_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.base_model_configs (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blobs (
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    sha256 bytea NOT NULL,
    size bigint NOT NULL,
    mime text,
    storage_key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT blobs_sha256_check CHECK ((length(sha256) = 32)),
    CONSTRAINT blobs_size_check CHECK ((size >= 0)),
    CONSTRAINT blobs_storage_key_check CHECK ((storage_key <> ''::text))
);


--
-- Name: branding_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_configs (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: browse_max_steps_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_max_steps_configs (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: browser_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browser_sessions (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: budget_spend; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_spend (
    id bigint NOT NULL,
    principal_id text NOT NULL,
    at bigint NOT NULL,
    usd double precision NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: budget_spend_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budget_spend_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budget_spend_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budget_spend_id_seq OWNED BY public.budget_spend.id;


--
-- Name: channel_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_files (
    org_id text NOT NULL,
    container text NOT NULL,
    ts text NOT NULL,
    file_id text NOT NULL,
    name text,
    mimetype text,
    created_at bigint NOT NULL,
    title text,
    size bigint,
    surface text DEFAULT 'slack'::text NOT NULL,
    account text DEFAULT ''::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: channel_header_pin_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_header_pin_flag (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: channel_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_messages (
    org_id text NOT NULL,
    container text NOT NULL,
    ts text NOT NULL,
    sub text,
    author_id text,
    author_name text,
    text text DEFAULT ''::text NOT NULL,
    mentions jsonb,
    self boolean DEFAULT false NOT NULL,
    bot boolean DEFAULT false NOT NULL,
    mentions_self boolean DEFAULT false NOT NULL,
    edited_at bigint,
    deleted boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    handled boolean DEFAULT false NOT NULL,
    tsv tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(text, ''::text))) STORED,
    deleted_at bigint,
    broadcast boolean DEFAULT false NOT NULL,
    subtype text,
    bot_id text,
    raw jsonb,
    surface text DEFAULT 'slack'::text NOT NULL,
    account text DEFAULT ''::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: channel_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_policy (
    org_id text NOT NULL,
    container text NOT NULL,
    orders text DEFAULT ''::text NOT NULL,
    bots jsonb DEFAULT '{}'::jsonb NOT NULL,
    set_by text,
    updated_at bigint NOT NULL,
    ambient_enabled boolean,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: channel_policy_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_policy_history (
    id bigint NOT NULL,
    org_id text NOT NULL,
    container text NOT NULL,
    orders text NOT NULL,
    set_by text,
    session_id text,
    created_at bigint NOT NULL,
    bots jsonb,
    ambient_enabled boolean,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.channel_policy_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.channel_policy_history_id_seq OWNED BY public.channel_policy_history.id;


--
-- Name: channel_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_state (
    org_id text NOT NULL,
    container text NOT NULL,
    last_ts text,
    oldest_ts text,
    name text,
    kind text,
    members jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_at bigint NOT NULL,
    surface text DEFAULT 'slack'::text NOT NULL,
    account text DEFAULT ''::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: command_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.command_policies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: composio_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.composio_returns (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: connector_clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_clients (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: consent_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consent_links (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: context_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.context_requests (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: credential_daily_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_daily_calls (
    slug text NOT NULL,
    day bigint NOT NULL,
    sent integer NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: credential_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_usage (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    slug text NOT NULL,
    host text NOT NULL,
    status text NOT NULL,
    upstream_status integer,
    scope_label text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: credential_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credential_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credential_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credential_usage_id_seq OWNED BY public.credential_usage.id;


--
-- Name: cron_fires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cron_fires (
    cron_id text NOT NULL,
    fire_key text NOT NULL,
    thread_ref text NOT NULL,
    session_id text,
    fired_at bigint NOT NULL,
    scheduled_at bigint,
    ended_at bigint,
    status text,
    note text,
    reply text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: crons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crons (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: custom_model_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_model_providers (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deactivated_principals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deactivated_principals (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: decision_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_providers (
    provider_id text NOT NULL,
    protocol text NOT NULL,
    base_url text,
    credential text,
    updated_by text NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: decision_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_rules (
    rule_id text NOT NULL,
    hook text NOT NULL,
    question text NOT NULL,
    options json NOT NULL,
    provider_id text NOT NULL,
    model text NOT NULL,
    mode text NOT NULL,
    on_error text NOT NULL,
    updated_by text NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    CONSTRAINT decision_rules_mode_check CHECK ((mode = ANY (ARRAY['off'::text, 'observe'::text, 'enforce'::text])))
);


--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deliveries (
    id text NOT NULL,
    idempotency_key text NOT NULL,
    destination jsonb NOT NULL,
    text text NOT NULL,
    created_at bigint NOT NULL,
    delivered_at bigint,
    attachments jsonb,
    provenance jsonb,
    recipient_thread_ref text,
    shadow boolean DEFAULT false NOT NULL,
    deliver_latency_ms integer,
    slack_api_ms integer,
    claim_expires_at bigint,
    expired_at bigint,
    source_cron_id text,
    failed_reason text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deploy_git_repos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deploy_git_repos (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deployment_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_access (
    id text NOT NULL,
    last_access_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deployment_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_identity (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deployment_layer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_layer (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: deployments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployments (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_channel_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_channel_members (
    org_id text NOT NULL,
    channel_id text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_channels (
    org_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    name_lc text NOT NULL,
    is_private boolean DEFAULT false NOT NULL,
    is_external boolean DEFAULT false NOT NULL,
    roster_known boolean DEFAULT false NOT NULL,
    observed_at bigint,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_group_members (
    org_id text NOT NULL,
    group_id text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_groups (
    org_id text NOT NULL,
    group_id text NOT NULL,
    roster_known boolean DEFAULT false NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_members (
    org_id text NOT NULL,
    principal_id text NOT NULL,
    display_name text NOT NULL,
    display_name_lc text NOT NULL,
    type text NOT NULL,
    slack_id text,
    avatar_url text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_meta (
    org_id text NOT NULL,
    workspace_url text,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: directory_sync; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_sync (
    org_id text NOT NULL,
    members_hash text,
    channels_hash text,
    groups_hash text,
    updated_at bigint NOT NULL,
    members_synced_at bigint,
    channels_synced_at bigint,
    groups_synced_at bigint,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: do_managed_agents_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.do_managed_agents_sandbox_bodies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: durable_map_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.durable_map_versions (
    tbl text NOT NULL,
    v bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: e2b_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.e2b_sandbox_bodies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: egress_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_events (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    source text NOT NULL,
    host text NOT NULL,
    allowed boolean NOT NULL,
    scope_label text NOT NULL,
    port integer,
    verdict text,
    via text,
    peer_ip text,
    principal_id text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: egress_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.egress_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: egress_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.egress_events_id_seq OWNED BY public.egress_events.id;


--
-- Name: egress_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_policies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: environment_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environment_attachments (
    scope_id text NOT NULL,
    environment_id text NOT NULL,
    attached_by text NOT NULL,
    attached_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: environments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environments (
    id text NOT NULL,
    org_id text NOT NULL,
    name text,
    owner_actor_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: error_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.error_events (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    scope_label text NOT NULL,
    category text NOT NULL,
    code text NOT NULL,
    message text NOT NULL,
    session_id text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: error_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.error_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: error_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.error_events_id_seq OWNED BY public.error_events.id;


--
-- Name: external_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_members (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: external_slack_participants_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_slack_participants_flag (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: file_artifact_deletions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_artifact_deletions (
    id text NOT NULL,
    deleted_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: file_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_artifacts (
    id text NOT NULL,
    kind text DEFAULT 'file'::text NOT NULL,
    owner_scope_id text NOT NULL,
    path text NOT NULL,
    name text NOT NULL,
    mimetype text NOT NULL,
    size_bytes bigint NOT NULL,
    blob_key text,
    sha256 text,
    direction text NOT NULL,
    created_by text NOT NULL,
    created_in_scope text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    source text DEFAULT 'live'::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: file_uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_uploads (
    id text NOT NULL,
    actor_id text NOT NULL,
    state text NOT NULL,
    size_bytes bigint NOT NULL,
    expires_at bigint NOT NULL,
    data jsonb NOT NULL,
    next_attempt_at bigint DEFAULT 0 NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: individual_model_auth_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.individual_model_auth_flag (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: interactive_fast_mode_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interactive_fast_mode_flag (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    session_id text NOT NULL,
    seq bigint NOT NULL,
    turn_id uuid,
    kind public.item_kind NOT NULL,
    author text,
    call_id text,
    elicit_id text,
    wake_cause public.wake_cause,
    error_code text,
    text text,
    tool text,
    step integer,
    variant text,
    is_error boolean,
    hidden boolean,
    external_id text,
    through_seq bigint,
    approved boolean,
    blob_sha bytea,
    search tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, COALESCE(text, ''::text))) STORED,
    body jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT items_approved_kind CHECK (((approved IS NULL) OR (kind = 'ElicitationResponse'::public.item_kind))),
    CONSTRAINT items_author_check CHECK ((author <> ''::text)),
    CONSTRAINT items_author_kind CHECK (((author IS NULL) OR (kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'ElicitationResponse'::public.item_kind, 'Stop'::public.item_kind, 'RuntimeChange'::public.item_kind])))),
    CONSTRAINT items_blob_sha_kind CHECK (((blob_sha IS NULL) OR (kind = 'ToolResult'::public.item_kind))),
    CONSTRAINT items_body_check CHECK ((jsonb_typeof(body) = 'object'::text)),
    CONSTRAINT items_call_id_check CHECK ((call_id <> ''::text)),
    CONSTRAINT items_call_id_kind CHECK (((call_id IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind])))),
    CONSTRAINT items_elicit_id_check CHECK ((elicit_id <> ''::text)),
    CONSTRAINT items_elicit_id_kind CHECK (((elicit_id IS NOT NULL) = (kind = ANY (ARRAY['Elicitation'::public.item_kind, 'ElicitationResponse'::public.item_kind])))),
    CONSTRAINT items_error_code_check CHECK ((error_code <> ''::text)),
    CONSTRAINT items_error_code_kind CHECK (((error_code IS NOT NULL) = (kind = 'Error'::public.item_kind))),
    CONSTRAINT items_external_id_check CHECK ((external_id <> ''::text)),
    CONSTRAINT items_external_id_kind CHECK (((external_id IS NULL) OR (kind = 'UserMessage'::public.item_kind))),
    CONSTRAINT items_hidden_kind CHECK (((hidden IS NULL) OR (kind = 'UserMessage'::public.item_kind))),
    CONSTRAINT items_is_error_kind CHECK (((is_error IS NULL) OR (kind = 'ToolResult'::public.item_kind))),
    CONSTRAINT items_seq_check CHECK ((seq >= 0)),
    CONSTRAINT items_step_check CHECK ((step >= 0)),
    CONSTRAINT items_step_kind CHECK (((step IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind, 'Reasoning'::public.item_kind, 'AgentMessage'::public.item_kind])))),
    CONSTRAINT items_text_check CHECK ((text <> ''::text)),
    CONSTRAINT items_text_kind CHECK (((text IS NULL) OR (kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'AgentMessage'::public.item_kind, 'Reasoning'::public.item_kind, 'ToolResult'::public.item_kind, 'Error'::public.item_kind, 'ContextCompaction'::public.item_kind])))),
    CONSTRAINT items_through_seq_kind CHECK (((through_seq IS NULL) OR (kind = 'ContextCompaction'::public.item_kind))),
    CONSTRAINT items_tool_check CHECK ((tool <> ''::text)),
    CONSTRAINT items_tool_kind CHECK (((tool IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind])))),
    CONSTRAINT items_variant_check CHECK ((variant = ANY (ARRAY['narration'::text, 'files_delivered'::text]))),
    CONSTRAINT items_variant_kind CHECK (((variant IS NULL) OR (kind = 'AgentMessage'::public.item_kind))),
    CONSTRAINT items_wake_cause_kind CHECK (((wake_cause IS NOT NULL) = (kind = 'Wake'::public.item_kind)))
);


--
-- Name: keychain_asks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_asks (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: keychain_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_credentials (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: keychain_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_grants (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: llm_prompt_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_prompt_envelopes (
    hash text NOT NULL,
    body text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loop_ingress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_ingress (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loop_ingress_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_ingress_deliveries (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loop_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_items (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loop_outputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_outputs (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loop_ship_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_ship_grants (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: loops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loops (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_servers (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: memory_fact_vectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_fact_vectors (
    scope_id text NOT NULL,
    model text NOT NULL,
    fact_id bigint NOT NULL,
    fact_hash text NOT NULL,
    dimensions integer NOT NULL,
    embedding public.vector NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    CONSTRAINT memory_fact_vectors_check CHECK ((public.vector_dims(embedding) = dimensions)),
    CONSTRAINT memory_fact_vectors_dimensions_check CHECK (((dimensions >= 1) AND (dimensions <= 16000)))
);


--
-- Name: memory_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_facts (
    id bigint NOT NULL,
    scope_id text NOT NULL,
    text text NOT NULL,
    sensitivity text NOT NULL,
    sources text[] DEFAULT '{}'::text[] NOT NULL,
    source_unknown boolean NOT NULL,
    author text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    deleted_at bigint,
    text_hash text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: memory_facts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.memory_facts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: memory_facts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.memory_facts_id_seq OWNED BY public.memory_facts.id;


--
-- Name: memory_tidy_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_tidy_profiles (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: modal_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modal_sandbox_bodies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: model_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_credentials (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: model_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_registry (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: monitors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monitors (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: oauth_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_flows (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: org_ambient_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_ambient_flag (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.participants (
    session_id text NOT NULL,
    principal_id text NOT NULL,
    valid_from bigint DEFAULT 0 NOT NULL,
    valid_to bigint,
    valid_from_seq integer DEFAULT 0,
    valid_to_seq integer,
    title text,
    archived boolean DEFAULT false NOT NULL,
    pinned boolean DEFAULT false NOT NULL,
    color text,
    read_at bigint,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: principal_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.principal_links (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: process_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_sessions (
    process_id text NOT NULL,
    scope_id text NOT NULL,
    kind text NOT NULL,
    command text NOT NULL,
    started_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    status text NOT NULL,
    session_ref text,
    run_id text,
    sandbox_id text,
    purpose text,
    credential_files jsonb,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: qm_schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_schema_migrations (
    id text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: qm_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: qm_tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_tenant (
    id uuid NOT NULL
);


--
-- Name: render_deploy_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_deploy_bodies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: render_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_sandbox_bodies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: render_sandbox_cleanup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_sandbox_cleanup (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: render_scratch_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.render_scratch_bodies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: retired_tenant_hosts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retired_tenant_hosts (
    host text NOT NULL,
    retired_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT retired_tenant_hosts_host_check CHECK (((host = lower(host)) AND (host <> ''::text)))
);


--
-- Name: run_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_activity (
    id bigint NOT NULL,
    run_id text NOT NULL,
    seq bigint NOT NULL,
    parent_seq bigint,
    type text NOT NULL,
    payload jsonb NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: run_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_activity_id_seq OWNED BY public.run_activity.id;


--
-- Name: run_signals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_signals (
    id bigint NOT NULL,
    run_id text NOT NULL,
    kind text NOT NULL,
    text text,
    payload jsonb,
    created_at bigint NOT NULL,
    consumed_at bigint,
    dedupe_key text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: run_signals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_signals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_signals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_signals_id_seq OWNED BY public.run_signals.id;


--
-- Name: runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runs (
    id text NOT NULL,
    session_id text NOT NULL,
    status text NOT NULL,
    request text NOT NULL,
    result text,
    idempotency_key text,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    lease_token text,
    lease_expires_at bigint,
    worker_id text,
    created_at bigint NOT NULL,
    started_at bigint,
    finished_at bigint,
    delivery_state text,
    error_attempts integer DEFAULT 0 NOT NULL,
    seq bigint NOT NULL,
    turn_user_seq bigint,
    retry_after bigint DEFAULT 0 NOT NULL,
    returned_at bigint,
    last_stop text,
    claim_priority smallint DEFAULT 2 NOT NULL,
    preemptions integer DEFAULT 0 NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: runs_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.runs_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: runs_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.runs_seq_seq OWNED BY public.runs.seq;


--
-- Name: sandbox_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_defaults (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: sandbox_resource_rollout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_resource_rollout (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: sandbox_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_resources (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: sandbox_routing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_routing (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: secret_drops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secret_drops (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: security_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_postures (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: session_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_goals (
    session_id text NOT NULL,
    objective text NOT NULL,
    status text NOT NULL,
    floor jsonb,
    token_cap bigint,
    tokens_used bigint DEFAULT 0 NOT NULL,
    active_ms bigint,
    active_since timestamp with time zone,
    completion_note text,
    cancel_note text,
    governor jsonb,
    pause_reason text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    CONSTRAINT session_goals_status_check CHECK ((status = ANY (ARRAY['active'::text, 'paused'::text, 'complete'::text, 'cancelled'::text])))
);


--
-- Name: session_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_leases (
    session_id text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    holder text,
    acquired_at bigint,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: session_llm_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_llm_requests (
    id text NOT NULL,
    session_id text NOT NULL,
    turn_seq integer,
    step integer NOT NULL,
    model text NOT NULL,
    scope_label text NOT NULL,
    truncated boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    ttft_ms integer,
    duration_ms integer,
    step_gap_ms integer,
    tool_wall_json text,
    usage_json text,
    transport_json text,
    gap_phases_json text,
    prompt_hash text,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: session_mailbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_mailbox (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: session_pins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_pins (
    id text NOT NULL,
    session_id text NOT NULL,
    text text,
    entry_seq integer,
    added_by text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: session_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_shares (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: session_spend_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_spend_days (
    day bigint NOT NULL,
    rows jsonb NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: session_spend_dirty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_spend_dirty (
    day bigint,
    session_id text,
    writer xid8 DEFAULT pg_current_xact_id() NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    CONSTRAINT session_spend_dirty_check CHECK ((num_nonnulls(day, session_id) = 1))
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    type text NOT NULL,
    scope_id text NOT NULL,
    thread_ref text NOT NULL,
    created_at bigint NOT NULL,
    title text,
    channel_name text,
    surface text,
    last_activity bigint,
    messages integer,
    turns integer,
    forked_from_session_id text,
    forked_from_title text,
    fork_boundary_seq integer,
    origin text,
    origin_id text,
    parent_session_id text,
    spawn_meta text,
    first_user_preview text,
    last_user_preview text,
    client_tools jsonb,
    last_user_activity bigint,
    side_chat jsonb,
    slack_binding jsonb,
    runtime jsonb,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    CONSTRAINT sessions_fork_provenance_pair CHECK (((forked_from_session_id IS NULL) = (fork_boundary_seq IS NULL)))
)
WITH (fillfactor='70');


--
-- Name: sharing_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sharing_postures (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: skill_bundles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_bundles (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: skill_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_packs (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skills (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_accounts (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_emoji_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_emoji_catalog (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_installation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_installation (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_session_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_session_status (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_staged_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_staged_envelopes (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: slack_task_acknowledgements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_task_acknowledgements (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: smolmachines_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smolmachines_sandbox_bodies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: soul_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_configs (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: soul_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_history (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: source_auth_replay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_auth_replay (
    event_id text NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: spend_limit_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spend_limit_configs (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: sprites_initialization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sprites_initialization (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: suggested_activity_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suggested_activity_profiles (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: superserve_config_epochs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superserve_config_epochs (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: superserve_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superserve_sandbox_bodies (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: swarms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.swarms (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_members (
    team_id text NOT NULL,
    principal_id text NOT NULL,
    role text NOT NULL,
    added_by text NOT NULL,
    added_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL,
    CONSTRAINT team_members_role_check CHECK ((role = ANY (ARRAY['member'::text, 'admin'::text])))
);


--
-- Name: team_rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_rooms (
    team_id text NOT NULL,
    scope_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    team_id text NOT NULL,
    name text NOT NULL,
    isolated_in_open boolean DEFAULT false NOT NULL,
    created_by text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: tenant_hosts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_hosts (
    host text NOT NULL,
    tenant_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenant_hosts_host_check CHECK (((host = lower(host)) AND (host <> ''::text)))
);


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT tenants_settings_check CHECK ((jsonb_typeof(settings) = 'object'::text))
);


--
-- Name: web_ui_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_ui_state (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: webhook_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_history (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: webui_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webui_model_configs (
    id text NOT NULL,
    "json" jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_bound_tenant() NOT NULL
);


--
-- Name: job_common; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.job_common DEFAULT;


--
-- Name: queue_stats_20261109; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats ATTACH PARTITION pgboss.queue_stats_20261109 FOR VALUES FROM ('2026-11-09 00:00:00+00') TO ('2026-11-10 00:00:00+00');


--
-- Name: queue_stats_20261110; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats ATTACH PARTITION pgboss.queue_stats_20261110 FOR VALUES FROM ('2026-11-10 00:00:00+00') TO ('2026-11-11 00:00:00+00');


--
-- Name: ack_emoji_picks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks ALTER COLUMN id SET DEFAULT nextval('public.ack_emoji_picks_id_seq'::regclass);


--
-- Name: ambient_judgments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments ALTER COLUMN id SET DEFAULT nextval('public.ambient_judgments_id_seq'::regclass);


--
-- Name: app_page_views id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_page_views ALTER COLUMN id SET DEFAULT nextval('public.app_page_views_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: budget_spend id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_spend ALTER COLUMN id SET DEFAULT nextval('public.budget_spend_id_seq'::regclass);


--
-- Name: channel_policy_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history ALTER COLUMN id SET DEFAULT nextval('public.channel_policy_history_id_seq'::regclass);


--
-- Name: credential_usage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage ALTER COLUMN id SET DEFAULT nextval('public.credential_usage_id_seq'::regclass);


--
-- Name: egress_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events ALTER COLUMN id SET DEFAULT nextval('public.egress_events_id_seq'::regclass);


--
-- Name: error_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events ALTER COLUMN id SET DEFAULT nextval('public.error_events_id_seq'::regclass);


--
-- Name: memory_facts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts ALTER COLUMN id SET DEFAULT nextval('public.memory_facts_id_seq'::regclass);


--
-- Name: run_activity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity ALTER COLUMN id SET DEFAULT nextval('public.run_activity_id_seq'::regclass);


--
-- Name: run_signals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals ALTER COLUMN id SET DEFAULT nextval('public.run_signals_id_seq'::regclass);


--
-- Name: runs seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs ALTER COLUMN seq SET DEFAULT nextval('public.runs_seq_seq'::regclass);


--
-- Data for Name: bam; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.bam VALUES ('31de90ad-5c22-4aa2-bfeb-1882414b76d4', 'upgrade-check', 1, 'pending', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '2026-11-09 20:23:10.502197+00', '2026-11-09 20:23:10.426985+00', '2026-11-09 20:23:10.426985+00');


--
-- Data for Name: job_common; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: job_dependency; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.job_dependency VALUES ('upgrade-check', '1daa88dc-cce9-4d85-aec8-516086e47116', 'upgrade-check', '89f84b14-e01d-4a21-96d4-e288644ddd0a');


--
-- Data for Name: queue; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.queue VALUES ('__pgboss__send-it', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, '{}', NULL, false, NULL, NULL, NULL, '2026-11-09 20:23:05.626888+00', '2026-11-09 20:23:05.626888+00');
INSERT INTO pgboss.queue VALUES ('cron-fire', 'short', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, '{}', NULL, true, NULL, NULL, NULL, '2026-11-09 20:23:05.634732+00', '2026-11-09 20:23:05.634732+00');


--
-- Data for Name: queue_stats_20261109; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.queue_stats_20261109 VALUES ('333e8f54-5d0c-4b0f-b1d9-fb7a25f8f94f', 'upgrade-check', 0, 0, 0, 0, 0, 0, '2026-11-09 20:23:10.426985+00');
INSERT INTO pgboss.queue_stats_20261109 VALUES ('70d04bb6-461f-4939-9e63-7245696b29e1', 'upgrade-check', 0, 0, 0, 0, 0, 0, '2026-11-09 20:23:10.426985+00');


--
-- Data for Name: queue_stats_20261110; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: schedule; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: subscription; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: version; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.version VALUES (37, '2026-11-09 20:23:05.634911+00', '2026-11-09 20:23:05.634956+00', '2026-11-09 20:23:05.634354+00');


--
-- Data for Name: warning; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.warning VALUES ('d9afc3a1-4ec4-4595-9a13-4b9ad41de261', 'upgrade-check', 'upgrade-check', '{}', '2026-11-09 20:23:10.426985+00');


--
-- Data for Name: ack_emoji; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ack_emoji VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: ack_emoji_picks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ack_emoji_picks VALUES (1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: acl_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.acl_grants VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: acl_grants_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.acl_grants_version VALUES (true, 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: admin_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.admin_grants VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: ambient_cursors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ambient_cursors VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: ambient_judgments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ambient_judgments VALUES (1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: app_page_views; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.app_page_views VALUES (2, 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: approval_grant_modes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_grant_modes VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: approval_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approval_grants VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: approvals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.approvals VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_log VALUES (1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: auth_broker_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.auth_broker_sessions VALUES ('upgrade-check', 'upgrade-check', '2026-11-09 20:23:10.426985+00', '2026-11-09 20:23:10.426985+00', '2026-11-09 20:23:10.426985+00', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: aws_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.aws_sandbox_bodies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: base_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.base_model_configs VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: blobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: branding_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.branding_configs VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: browse_max_steps_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.browse_max_steps_configs VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: browser_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.browser_sessions VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: budget_spend; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.budget_spend VALUES (1, 'upgrade-check', 1, 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: channel_files; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_files VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 1, 'slack', '', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: channel_header_pin_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_header_pin_flag VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: channel_messages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_messages VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '', '{}', false, false, false, 1, false, 1, false, DEFAULT, 1, false, 'upgrade-check', 'upgrade-check', '{}', 'slack', '', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: channel_policy; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_policy VALUES ('upgrade-check', 'upgrade-check', '', '{}', 'upgrade-check', 1, false, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: channel_policy_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_policy_history VALUES (1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, '{}', false, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: channel_state; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.channel_state VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '[]', 1, 'slack', '', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: command_policies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.command_policies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: composio_returns; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.composio_returns VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: connector_clients; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.connector_clients VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: consent_links; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.consent_links VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: context_requests; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.context_requests VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: credential_daily_calls; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.credential_daily_calls VALUES ('upgrade-check', 1, 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: credential_usage; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.credential_usage VALUES (1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: cron_fires; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.cron_fires VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: crons; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.crons VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: custom_model_providers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.custom_model_providers VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: deactivated_principals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deactivated_principals VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: decision_providers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.decision_providers VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: decision_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deliveries VALUES ('upgrade-check', 'upgrade-check', '{}', 'upgrade-check', 1, 1, '{}', '{}', 'upgrade-check', false, 1, 1, 1, 1, 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: deploy_git_repos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deploy_git_repos VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: deployment_access; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deployment_access VALUES ('upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: deployment_identity; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deployment_identity VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: deployment_layer; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deployment_layer VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: deployments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deployments VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: directory_channel_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_channel_members VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: directory_channels; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_channels VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', false, false, false, 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: directory_group_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_group_members VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: directory_groups; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_groups VALUES ('upgrade-check', 'upgrade-check', false, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: directory_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_members VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: directory_meta; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_meta VALUES ('upgrade-check', 'upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: directory_sync; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.directory_sync VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, 1, 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: do_managed_agents_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.do_managed_agents_sandbox_bodies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: durable_map_versions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.durable_map_versions VALUES ('upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: e2b_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.e2b_sandbox_bodies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: egress_events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.egress_events VALUES (1, 1, 'upgrade-check', 'upgrade-check', false, 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: egress_policies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.egress_policies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: environment_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.environment_attachments VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: environments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.environments VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: error_events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.error_events VALUES (1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: external_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.external_members VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: external_slack_participants_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.external_slack_participants_flag VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.feature_flags VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: file_artifact_deletions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.file_artifact_deletions VALUES ('upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: file_artifacts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.file_artifacts VALUES ('upgrade-check', 'file', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, true, 'live', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: file_uploads; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.file_uploads VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, '{}', 0, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: idempotency; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.idempotency VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: individual_model_auth_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.individual_model_auth_flag VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: interactive_fast_mode_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.interactive_fast_mode_flag VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: keychain_asks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.keychain_asks VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: keychain_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.keychain_credentials VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: keychain_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.keychain_grants VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: llm_prompt_envelopes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.llm_prompt_envelopes VALUES ('upgrade-check', 'upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: loop_ingress; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loop_ingress VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: loop_ingress_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loop_ingress_deliveries VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: loop_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loop_items VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: loop_outputs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loop_outputs VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: loop_ship_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loop_ship_grants VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: loops; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.loops VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: mcp_servers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.mcp_servers VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: memory_fact_vectors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: memory_facts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.memory_facts VALUES (1, 'upgrade-check', 'upgrade-check', 'upgrade-check', '{}', false, 'upgrade-check', 1, 1, 1, '0e86a3eb66c5a39e77dfdae108be1e0783a1b87813898cda9bb68ba8143b7999', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: memory_tidy_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.memory_tidy_profiles VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: modal_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.modal_sandbox_bodies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: model_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.model_credentials VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: model_registry; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.model_registry VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: monitors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.monitors VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: oauth_flows; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.oauth_flows VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: org_ambient_flag; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.org_ambient_flag VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: participants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.participants VALUES ('upgrade-check', 'upgrade-check', 0, 1, 0, 1, 'upgrade-check', false, false, 'upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: principal_links; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.principal_links VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: process_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.process_sessions VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.projects VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: qm_schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_schema_migrations VALUES ('0000-tenancy/base', 'a8d92d4e6edcca2b8e2e0635347c2bcbc549dc2826def55a9af0afe4bdeea70b', '2026-11-09 20:23:04.394882+00');
INSERT INTO public.qm_schema_migrations VALUES ('0000-tenancy/sole-tenant', '7905025bbf4b0062e0694b4c91f9872e6ac97a694dac65dec579b0104fce6f24', '2026-11-09 20:23:04.398568+00');
INSERT INTO public.qm_schema_migrations VALUES ('0000-tenancy/sole-tenant-search-path', 'd58bb3de5c31432bff3c79cbbb95a154e6bb773c9b074cd174061475197666cf', '2026-11-09 20:23:04.399374+00');
INSERT INTO public.qm_schema_migrations VALUES ('0000-tenancy/unbound-sole-tenant', '3015703fe1161ae34c14142f25c125017c516ffac4efe11f70249d5f5750f277', '2026-11-09 20:23:04.400092+00');
INSERT INTO public.qm_schema_migrations VALUES ('0001-tenancy/hosts-and-settings', '2313feb6dca8bfa9ba419f353dc72d693aef84f22de7cd4ecf1eb127a6fa80c0', '2026-11-09 20:23:04.40079+00');
INSERT INTO public.qm_schema_migrations VALUES ('0001-tenancy/hosts-search-path', 'df39e37ea5acfab70ffa36507b1ea405f3a5b02311ebfeb15e1c9bc7a26ee30b', '2026-11-09 20:23:04.405217+00');
INSERT INTO public.qm_schema_migrations VALUES ('0001-tenancy/retired-hosts', 'cf7c13a450c2964a8ad1b6d0402f7dad449b8c872e97ba9993d77af5691268c2', '2026-11-09 20:23:04.405818+00');
INSERT INTO public.qm_schema_migrations VALUES ('0001-tenancy/tenant-row-security', '4091f31ff00a2cbe54944dd5af102622116bf96de4f91697079229dbdcc89516', '2026-11-09 20:23:04.408726+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0001', '11758af3276004ec5ba9f283d35867d074999b2413b1ab6d74a4545e8fba16fa', '2026-11-09 20:23:04.412729+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0002', '86f3cbd7981ea8e137a31f6e66936ce53654c013c6f20dbb9924692a2263ed0d', '2026-11-09 20:23:04.414622+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0003-file-ids', '2ad7a5a68acb5da6ed801d2b4c1d56391e14bf1eef0356948f661c5a293825de', '2026-11-09 20:23:04.416497+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0004-grantee-index', '30382d67071399576b959afec996363d65176da58f3cde4addcc858fe6f2e7bc', '2026-11-09 20:23:04.421937+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0005-tenants', 'd4c22155442f743d42d0afaab74f50043bd7b16112387c59ff34b1d3bee0bb43', '2026-11-09 20:23:04.422317+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0005-tenants-lookups', 'aebcf96e9ffeebff76d8a7202d8dc363b6ebb16ff7e5509d20ad7152ecee7813', '2026-11-09 20:23:04.432571+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0005-tenants-swap', '98ef3492c7ec2a5a76d4f5fd3a390b718a57cfb3c8cdf15fa9b3d8508bb165ca', '2026-11-09 20:23:04.432962+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0001', '542f2a64d2814b329f2c1ad2eb8ed2728e8044b78efa6343eafb5598bc83cb1d', '2026-11-09 20:23:04.435211+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0002', 'bce8b31764744856dab57f8ced3a2e33b36e5896ff0f915152dc466741be3828', '2026-11-09 20:23:04.439731+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0003-tenants', '1a32526349ab1be23d4e55eaf347b699bad1f01fe476f42f220a4943cbff81dd', '2026-11-09 20:23:04.440562+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0003-tenants-lookups', '2922664cc17a666f150db7e3760d48ab3dd4046314efb543962410062809f4cf', '2026-11-09 20:23:04.447738+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0003-tenants-swap', 'e5b99803c50626e2a419215d611c6298e695eb39107930a7c64bdb48228590c9', '2026-11-09 20:23:04.448073+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/grants/0001', '1a92727b41adaa11bf3029a419a8a5ca9213b0fbab91df905b7e58803cc73ce4', '2026-11-09 20:23:04.44983+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/grants/0002-tenants', '93c989904bbcdc9069c39763adfe7eb3b4c367929070a311003c8e547ff042f0', '2026-11-09 20:23:04.451507+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/grants/0002-tenants-lookups', 'b5b5cc64ba23304f41c207507251cccfc23a7e54ff95f9d3be2ec1d78bfbff25', '2026-11-09 20:23:04.457065+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/grants/0002-tenants-swap', '607c445761ac2042dccfd1cfe9768fe97f00ec530fd7a57c32806d7a8f59334a', '2026-11-09 20:23:04.457443+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0001', '42188c2f50734398496ddd5a47a9ec3c15a507059c713a4a6ced0b0b81d908eb', '2026-11-09 20:23:04.459243+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0002', 'eb3194ec38847b601025c41b99616c4385770930074e808b21e53af9463d7ad0', '2026-11-09 20:23:04.464061+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0003', '74b2011593ba178ca8decc6f7c82528f7bd161c4651fc2700a78839dac32fc04', '2026-11-09 20:23:04.464424+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0004-daily-calls-tenants', '1792dda51dde22fb59bf8fb64f4ec58588a40c3b9d82f9fca6a86a3811f2c737', '2026-11-09 20:23:04.466079+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0004-daily-calls-tenants-lookups', '9595b56e53dd047c2eb9da3332c0888879d1afc3136988e2abc1756d8e89ce24', '2026-11-09 20:23:04.470793+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0004-daily-calls-tenants-swap', '5686b2241f7027b28f34ca94dc7eccf93e298a2f22283260b7382474e5e0a971', '2026-11-09 20:23:04.471124+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0100', 'a0555cfd421b0810fcf6d122e82fc1e2ae63cd6119f46bf07397de1d8ed90ae2', '2026-11-09 20:23:04.472531+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0100-lookups', 'dbba1898784a2f990f4c27f97be9cb98f1ede0754dc9bdb7b9d3048c8b637e0a', '2026-11-09 20:23:04.477127+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0100-swap', 'c1a58f3f26dd5ac29b3ba9615d62e352c77ceeea36b1cafa1cb4b85bb4f5be1c', '2026-11-09 20:23:04.477511+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/egress_events/0001', 'cfbf4ab51c2b0a4ac45eaeeb7a7011d7b2a4a4d9c21072473ed27400b03fe054', '2026-11-09 20:23:04.478829+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/egress_events/0100', 'ed03507aabadac4c1c8ff01309bea0a3f245ad13da51d7f48534703d89527983', '2026-11-09 20:23:04.481145+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/egress_events/0100-lookups', 'b46b63fe1842b58352cdf0f09ee4dee0f35fab04e95c52951d8cef1ddb56ba7a', '2026-11-09 20:23:04.486775+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/egress_events/0100-swap', '96f1f8e6c7226f0ff05397bfb04f525f301a700c4369af49f4d8d6d5b3c919bc', '2026-11-09 20:23:04.487085+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/error_events/0001', 'd5bab01c9f83042aace325e98636b614bcb8a6d77fedaed373f02efde282f5b8', '2026-11-09 20:23:04.488638+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/error_events/0100', '76e198cfdd1107275f1e3d8f6b2a0fa1a7be8687a3df1705f34cd259be7451ec', '2026-11-09 20:23:04.492022+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/error_events/0100-lookups', 'fb39d3d7648842033d53758e47160ac0759eda33a7c4b089b8dedb88b34f92cf', '2026-11-09 20:23:04.496712+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/error_events/0100-swap', '5967a57c4e362b46a6f035a31c8ba53d09a0d92cc779c1ee124f7b5103966b12', '2026-11-09 20:23:04.497023+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/broker-sessions/0001', '2f958c4c732f8a8a79cb1d31215236fea9565ee2ce5e62270952b889ec5c1265', '2026-11-09 20:23:04.498405+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/broker-sessions/0002-tenants', 'fb400d159bb4dc38d644d587f93c1f3c8f1e8d6b5d641b41a272187067e113b2', '2026-11-09 20:23:04.500627+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/broker-sessions/0002-tenants-lookups', '6941ae7ee9e64ee01486a3e5cc27afa70fcb74779fb539fd8e1df1db683140f5', '2026-11-09 20:23:04.505218+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/broker-sessions/0002-tenants-swap', '4600c604fb5bc35929ddd1064442fc94e2f409a068bb62b027a58c589c8bb00e', '2026-11-09 20:23:04.505492+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/replay-dedupe/0001', '8714fae4d626c773edfacf59d807e324955a205abb2be2bc76753cdbbc14adf7', '2026-11-09 20:23:04.506667+00');
INSERT INTO public.qm_schema_migrations VALUES ('cron/fires/0001', '462f9f784160d6e31019707b7df3c35ef0a2979fd3c9fb9d4d581fb89de6cad1', '2026-11-09 20:23:04.508573+00');
INSERT INTO public.qm_schema_migrations VALUES ('cron/fires/0002-tenants', 'd86b1db91b61bb508bf56bd5bea48677d6f92ec757d16b80927beb1224d874f2', '2026-11-09 20:23:04.510608+00');
INSERT INTO public.qm_schema_migrations VALUES ('cron/fires/0002-tenants-lookups', 'af3b1939eb0550e53b18b9e1aa831bb9cbe83e23c04c2abe136147c2bbaec0d9', '2026-11-09 20:23:04.515822+00');
INSERT INTO public.qm_schema_migrations VALUES ('cron/fires/0002-tenants-swap', '20f1d14fe9a7ab16567f7f21950eeb14cab0ea125bc17e3a56d653fa7b14778a', '2026-11-09 20:23:04.516102+00');
INSERT INTO public.qm_schema_migrations VALUES ('decisions/0001', '5259b744d814f2aae9b056e69f4488b87276b8db7eeb17d140d6e89bab93218a', '2026-11-09 20:23:04.517365+00');
INSERT INTO public.qm_schema_migrations VALUES ('decisions/0002-tenants', '79369ba11cd7e2b31e31a21f7731e1837e29c74e5c9b5d8690f82496f59a9f02', '2026-11-09 20:23:04.521226+00');
INSERT INTO public.qm_schema_migrations VALUES ('decisions/0002-tenants-lookups', '326dd735b45503d720acc24feef34549082aeadc3ea461306f87bce805d0afe4', '2026-11-09 20:23:04.529428+00');
INSERT INTO public.qm_schema_migrations VALUES ('decisions/0002-tenants-swap', '4b53e9fa3b9c2d54256b79e4b59fef5cff328e1f599ee279b584565b52b2755c', '2026-11-09 20:23:04.529772+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0001', '518a78830cb91440cee2642d600fb0532084bbe2e2bc4c69c47cc51756be614e', '2026-11-09 20:23:04.532378+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0004', 'a712456e95a8e05c1bfa3dcfe8e2cdffe6a49c94f191bd2cb9e594277e1b895c', '2026-11-09 20:23:04.537355+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0005', 'd725fa7f171c9b29c14146029a2804cf94a814e8146c8c1a2b16953310fbfd1e', '2026-11-09 20:23:04.538168+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0006', '7d0550f008aa2df653dd112199318a24a7151912338aa408e499fce0d1f756a1', '2026-11-09 20:23:04.539058+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0007', 'e22b36237580107662c4bf5541b223f47e7bcec09722f8e224803c1f29f5135e', '2026-11-09 20:23:04.539791+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0008-tenants', 'b1239b162f53e4352349e28cc02acc51d6f1f185fdc4c2556c9712831fb9ea0f', '2026-11-09 20:23:04.54062+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0008-tenants-lookups', '200b5d28273c128faca93af0b9e2a6ff46f4c71226634378f1b2f35b8f6af9c8', '2026-11-09 20:23:04.548307+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0008-tenants-swap', '9404e551fe65a3251e9fdc3effebeac8e6723cf434fd50f979681b5dfad065d7', '2026-11-09 20:23:04.54867+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/access/0000-tenant-keyed-deployments', '178f6f603dde9a902c7e2411a60df09a0a3d6e67fcc888da0143f9b14ed35d7f', '2026-11-09 20:23:04.550391+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/access/0001', 'fa35b86cbdfa9e8766ac5e47ffc926986b87ec5bad3ef1d7070fb8e2a1f3f9c2', '2026-11-09 20:23:04.550956+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/app-page-views/0000-tenant-keyed-deployments', '4072a6dc5604c1787424dce513bacbb6348a8b57598130e7008454ec2d14adf3', '2026-11-09 20:23:04.553026+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/app-page-views/0001', '1a96f651d496b094c41604bedb25f1f5ae4542827668ef7a9a278d5024b38fd1', '2026-11-09 20:23:04.553589+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/app-page-views/0002-tenants', 'eaf251e4d7845633e28b753243367c4dadc12054bac6de1541f4a60a71f6d7b8', '2026-11-09 20:23:04.556066+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/app-page-views/0002-tenants-lookups', '3b1f06eb1b699e9b6292c1fb996dbaf45e83a7091403ba51448fa62f235172c7', '2026-11-09 20:23:04.560457+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/app-page-views/0002-tenants-swap', '20426944a8b8febd7c51a142805275c0c3092fe56b45f6eacd58ea4fb39cf334', '2026-11-09 20:23:04.560753+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0006-base-schema', 'e8dcd5c2a3a8fcba7b1c14db1d1aceb57ca7ef6e1c7366ace6df65043f731198', '2026-11-09 20:23:04.562038+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0006-tenants', 'a8aba57e368b6642c4843311a61a7933b09f4dd030eac4b771d951e0633b401a', '2026-11-09 20:23:04.570065+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0006-tenants-lookups', 'fb0824d7f55c9b6c4822ed3f1a9566a6d6a230a11e95ff0c840cf4506d846f40', '2026-11-09 20:23:04.596671+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0006-tenants-swap', '743623ba605c535d6b7c23a0e049d03e5a77eac6eeade64e34a12d683975e04d', '2026-11-09 20:23:04.59698+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ack_emoji/0001', 'b5cc8b58d6905bf400f15326b4fa4fd3517171dc7e3a2108d23ccc936612ab57', '2026-11-09 20:23:04.60219+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ack_emoji/0010-tenants', '14689d31cfee3e4198d8123cd57838270471a8ce5a616c1dabc72b561c4b8a29', '2026-11-09 20:23:04.60447+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ack_emoji/0010-tenants-lookups', 'a49ca54b80c218d70362cc074a84bb82fd96dd7af1e69620ce15c36d121dc5f6', '2026-11-09 20:23:04.60874+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ack_emoji/0010-tenants-swap', 'eee9ea1e89cc0ea89e2e3f4a3ba2f3bf3dbe1a9d124997aedb5149683cba4eae', '2026-11-09 20:23:04.608971+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ambient_cursors/0001', 'af7f98b52db7c0fe09648b4ca964f6ccaeb1bbe283cc4d39184f8084db465551', '2026-11-09 20:23:04.610218+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ambient_cursors/0010-tenants', '4f4f054f915208219a7102a8f672e0c98e9f3b8a30e1877929d72959753d2266', '2026-11-09 20:23:04.611571+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ambient_cursors/0010-tenants-lookups', 'e75d8951ba31787156321935afaaa2310eae470f1685e7ead9bafe702bc8424f', '2026-11-09 20:23:04.616028+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ambient_cursors/0010-tenants-swap', '052fa2c46fd2e47106b4248157abe456899f6c5a63ea88ca74f2583e92d12c7d', '2026-11-09 20:23:04.616265+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grant_modes/0001', '71fcc4c066ec51b5ea8529444cadf6b02193c31760bde9adbf1d198d31c5829a', '2026-11-09 20:23:04.617339+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grant_modes/0010-tenants', 'a0d7947974ba54e8a4ba915e7c2c925784609c38d59b909425fe9bd6281425ce', '2026-11-09 20:23:04.618672+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grant_modes/0010-tenants-lookups', '3752002f210e7a83427c813b896302c824ab3db9abe206db3b79b2d044011f35', '2026-11-09 20:23:04.622963+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grant_modes/0010-tenants-swap', '9ea73d4a6f8084937a591a9b061c025880b76a12a01cc99dc89ef45037661fa2', '2026-11-09 20:23:04.6232+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/0001', '584a7fe0f0a43a421793efed03be20afc249a2ce02dd3ff4924e4cd536ebbc9d', '2026-11-09 20:23:04.62426+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/0010-tenants', '71fa365b1e9456857632aa9819a87a351fd1da2f4b7e3cb4462d866f964413bc', '2026-11-09 20:23:04.62566+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/0010-tenants-lookups', '47e45d78144517c6d10c02d36ecf582077a4c54c59834e961b44eafec6228271', '2026-11-09 20:23:04.629596+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/0010-tenants-swap', '704d06de40a2c4ac6540c31151dd764ee048f9e1e6f081fa1ac41ec10e1341ef', '2026-11-09 20:23:04.629814+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/lookup-actorid-drop', '0abca61411d1721d89d636d82f15cae23eedbdcc6956596a03aeb31de9535cde', '2026-11-09 20:23:04.630811+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/lookup-actorid-hash', 'c63fc8546cf1a5358a6ad03c02cf00161e03d0e9bb0deda9a1c0a47bdaa53491', '2026-11-09 20:23:04.632718+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/select-actorid', '6d3272c2deba8f75029adb10eb79356e82c57bc127abc0523ade328443047550', '2026-11-09 20:23:04.635297+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/stats-actorid', 'a13b17482a5e4c6d7ee277a046ad358b82de05619c73cb3adf198e8de03c2a88', '2026-11-09 20:23:04.63551+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/0001', 'cd76491910753bae97e30680661f57cdde84d6583d724198cba5e0d71032dcb5', '2026-11-09 20:23:04.636694+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/0010-tenants', 'c61921b34878356239bded563e07ef74ee1b140e663f8c4ad50aec43979fb787', '2026-11-09 20:23:04.638465+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/0010-tenants-lookups', '2ef544a36948865622dfac9289022501d3a2df1b9cdaadc9381a4972817f4a1f', '2026-11-09 20:23:04.643049+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/0010-tenants-swap', '197938e27719c36adcc3f329a62653a2318c457904db4119f7b03a3144d479a8', '2026-11-09 20:23:04.643275+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/lookup-sessionid-drop', 'f97131836d0b702bc1a1693e03bd5d97558a5aa95c5324ec0ce4a8b357814141', '2026-11-09 20:23:04.644385+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/lookup-sessionid-hash', 'cc98fbd26fca3ecf2c80295e1057e90abbcde3481211ce9082daed8aeedab4f3', '2026-11-09 20:23:04.646267+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/select-sessionid', 'e44a660c6180087f9a8b08be2493eedd0595d4029552b08e3c089d2be47796f4', '2026-11-09 20:23:04.648792+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/stats-sessionid', 'c3c521e26580047f3e4b337f1cf2713f30c21e3d3b8c4c44d699b4dd17e7be45', '2026-11-09 20:23:04.649024+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/aws_sandbox_bodies/0001', '190bacea57ed75da62849825a5e3206905422d5ffc9f2192d9039222306b378d', '2026-11-09 20:23:04.649851+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/aws_sandbox_bodies/0010-tenants', '64faa29039860852a9ee2bbe647cd058d986791a58bfc35341426b1d31e80dd7', '2026-11-09 20:23:04.651244+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/aws_sandbox_bodies/0010-tenants-lookups', 'cda34df91adb9b9a864aeef0c0156447e874024e96a47befb7d63bb4490f06bf', '2026-11-09 20:23:04.655412+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/aws_sandbox_bodies/0010-tenants-swap', '9b862069033fc67b83c35b2432c7e412060bb4f495d4c4458ee920f5f042e6a4', '2026-11-09 20:23:04.655631+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/base_model_configs/0001', '7ee3b9db6bc36c92985dddf061cba7ef0b5d736fb44452febaef04c50211624e', '2026-11-09 20:23:04.656779+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/base_model_configs/0010-tenants', 'f8c98c2dba78cd6ad0fc31f4c0968c7e7d693a393c73b060a01a5dd8f49bf705', '2026-11-09 20:23:04.658115+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/base_model_configs/0010-tenants-lookups', '2c82710672211556abb13bb5071b21c4590f0c8d9cfb5a7330d3f472d3052189', '2026-11-09 20:23:04.662368+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/base_model_configs/0010-tenants-swap', '7bbce2e5db7041d3f229563129e9f570a9d2809efcc8732311ed73a3da8b072a', '2026-11-09 20:23:04.662581+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/branding_configs/0001', '06c1123ae332e721fe619c8614392636ff446d1a47cd42396e8d3d819ade6dac', '2026-11-09 20:23:04.663572+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/branding_configs/0010-tenants', '81de369ff707fc17d8a4776b9eb3da50b6ecb54faa68591b612444ab064b593c', '2026-11-09 20:23:04.664882+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/branding_configs/0010-tenants-lookups', '1d4bae4d44b65180c9b97c60e85362adcd2f0bedd2ee60999fe42305ff38ab63', '2026-11-09 20:23:04.66872+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/branding_configs/0010-tenants-swap', 'f4ce231826efcc5e62d7334742325f89c2572fcf6080448ef22f0a0ca551bfb9', '2026-11-09 20:23:04.66893+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browse_max_steps_configs/0001', 'ae78a8a7cd7a78fc6886bbeb9241aadc057b4958713499e0591be82e878f2e41', '2026-11-09 20:23:04.669966+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browse_max_steps_configs/0010-tenants', '009d10aed53dc788bc2941a78c5b8c6a61d146e2ae00a0a5c0d8564ea7907942', '2026-11-09 20:23:04.671171+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browse_max_steps_configs/0010-tenants-lookups', 'd86045a33a7a3e9e9e29d5658023bc813928ebf67cb5f3df414f946b41081231', '2026-11-09 20:23:04.675099+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browse_max_steps_configs/0010-tenants-swap', 'e2d863993675275d711e67aea36e67e66d19ada90938768b26036907a90db780', '2026-11-09 20:23:04.675361+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browser_sessions/0001', '49bcab3ee00cac7b5aa4b3eaa303cfffc34521de73d763cbc4dd204a7a0e8b6f', '2026-11-09 20:23:04.67639+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browser_sessions/0010-tenants', '2c6808ed90122a7a34374b3f985aabbd125acc6ffadf7b0991a4ed4514c3e3d8', '2026-11-09 20:23:04.677675+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browser_sessions/0010-tenants-lookups', '250f44a1784b411f6dbb802b448a942ca8c29372f8e209ba33815ac96dc52765', '2026-11-09 20:23:04.681384+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browser_sessions/0010-tenants-swap', '9df96b2f3033e60fd2a46a57f7b5f8c26a181f44db59047d0bedb51f78da96b2', '2026-11-09 20:23:04.681588+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/channel_header_pin_flag/0001', 'e8f344ed5c29eb3d19ec1a095947f1219e19ddbf0c2b70abdb0784d7c7b0465e', '2026-11-09 20:23:04.682644+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/channel_header_pin_flag/0010-tenants', 'fd3aac6096408ff2cacf90d711f98da0f5a91b58c8aac62f982177b8444d28a0', '2026-11-09 20:23:04.683805+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/channel_header_pin_flag/0010-tenants-lookups', '6e5311625ef166fa4b813a1e04a34f23b324cff65f1ff2f1781d3fe95c2b3f34', '2026-11-09 20:23:04.687717+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/channel_header_pin_flag/0010-tenants-swap', '7a00a4fecbfd5b2cf9b9c4c2348e5155b489ba62effdfd844d7a50abc1b0d7a7', '2026-11-09 20:23:04.687987+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/command_policies/0001', '3b924df4ca67254193724e9a509ce0ee76f1d52bb42c2e0f80f0d408e046749d', '2026-11-09 20:23:04.689102+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/command_policies/0010-tenants', '5b430037c79db01d76460dadab5de8ff0a8e10fb8e5c30c85864ecd88e5c99cd', '2026-11-09 20:23:04.690436+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/command_policies/0010-tenants-lookups', '10362b45b41178b50acd9e6c8b442ffe9d4254aeed30e9a4d5a173c2bbf6a4d1', '2026-11-09 20:23:04.694542+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/command_policies/0010-tenants-swap', 'd9320d9ab7be44134ee55d5099ede87a0740e93ddd0ee74a07578850677bc217', '2026-11-09 20:23:04.69476+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/composio_returns/0001', 'e2c6917d12757feffde5140a25db74adeef597fecfa970ab81f5775b0d802460', '2026-11-09 20:23:04.695784+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/composio_returns/0010-tenants', '70ed6a58e54af140740cc3941d39979a1a334e95e1d5557a6ff9b41c470c5d53', '2026-11-09 20:23:04.697115+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/composio_returns/0010-tenants-lookups', 'b179ee78ee33fb06d07f8ec89f68b771a9f4347f60cbdff13491b15c32940f99', '2026-11-09 20:23:04.701084+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/composio_returns/0010-tenants-swap', '46f57855c049e886edf8bab06ce92316234b35187f72204751cd965d8f465cbd', '2026-11-09 20:23:04.701366+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/connector_clients/0001', 'c8e67053c62396d17890f6d5cbccf60c2097b520ceeb1005007ce4c7ffd38ab9', '2026-11-09 20:23:04.702491+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/connector_clients/0010-tenants', 'fceab1f76e5118d23a180fbe406027307653ec3ac1c99a4fec28876705c5adca', '2026-11-09 20:23:04.703758+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/connector_clients/0010-tenants-lookups', '1dd9c9b1b60b809b2ef21ab549025eda620b0eebce949bda5d83b156105f9945', '2026-11-09 20:23:04.707837+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/connector_clients/0010-tenants-swap', '0775d69190534cad4f4867776b88d8daa19fe20899e1e7577dc130ac0f280e2c', '2026-11-09 20:23:04.708045+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/consent_links/0001', '4023e872f3c4ef2342dd2db8d0a936662868024875a139162d5c1960dfe5a6db', '2026-11-09 20:23:04.70908+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/consent_links/0010-tenants', '6a5f4b811c0ddb09b4560f97774b77e743ee8c3830028658b499baa6e214ec98', '2026-11-09 20:23:04.710443+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/consent_links/0010-tenants-lookups', 'dc2948e9fad69af747a29817a78f97e85137b21dd7bb85c099041224f724fc6c', '2026-11-09 20:23:04.714687+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/consent_links/0010-tenants-swap', '8c56203f91d5f414dbc7e2df26d50edd0e31752b529855456e7b737efd7d38a4', '2026-11-09 20:23:04.714904+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/context_requests/0001', 'c06306bda2afa606283f9a391786e561e5f0854b3efe5c9b761813acd3238b87', '2026-11-09 20:23:04.715912+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/context_requests/0010-tenants', '3d933dd234c9a1a650190c3c7b26cf7a617329bc970bdfd3ce86bc19e3d6cb73', '2026-11-09 20:23:04.717207+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/context_requests/0010-tenants-lookups', 'cf6cddc0eb70c1e46872919dc8c0398ce3b6b3c1f70c888d9808729a55d3edbb', '2026-11-09 20:23:04.721418+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/context_requests/0010-tenants-swap', '438610f5c45ca7f0c8567ec22d6f1e54dd15b657d72fa12168d75a44b0178258', '2026-11-09 20:23:04.721653+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0001', '0235672021171d1e58bd485fae8b56090ed58be3a12b156dc7491ac3d825dea3', '2026-11-09 20:23:04.72286+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0001-drop-run-as', '95e375cb70abd7dff68cf61a371167695b3e3427c31f38a9722142c244b0f97a', '2026-11-09 20:23:04.724295+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0002-drop-fire-log', 'e5c71115a606ee26802f5865e9c040b8f83f59701444b8ee453eb579a974ffa1', '2026-11-09 20:23:04.726274+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0010-tenants', '4d5caa32d2d3c0af91731685753b42c5c55cd413c004e471256a3744514c0d2e', '2026-11-09 20:23:04.726679+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0010-tenants-lookups', 'd2ef3c67a9c7690c2ae4e9f13f9060cc3b3e86435687e7020c365a59c3505d54', '2026-11-09 20:23:04.730315+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0010-tenants-swap', '9060f9707059403335559846f506561a2b795f2ca3fd60d71e88549033c2a4f4', '2026-11-09 20:23:04.730553+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/lookup-ownerscopeid-drop', '1cc2c2306effba05aea7faedf703cdeb164606db17e419e2e49d561864ac31ca', '2026-11-09 20:23:04.731568+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/lookup-ownerscopeid-hash', '433e85de066799d6cd416cd286f95e6257b6067fc91f011fc549f6df43963c9f', '2026-11-09 20:23:04.733678+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/select-ownerscopeid', '7bc92ad7c73d1eddf8b18aee5bff5081aeb0447b5153ea5a90fdd7e78a239628', '2026-11-09 20:23:04.736148+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/stats-ownerscopeid', '190a91573ba35b1fd34091eddf47ca1dd38420b59f14bd594233ff76f5afba49', '2026-11-09 20:23:04.73636+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/custom_model_providers/0001', '151ac01f9e2a37c511b3f56296050b37a7a4c9c13c7ef946259d5805def997d6', '2026-11-09 20:23:04.737269+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/custom_model_providers/0010-tenants', '9a9ac037ae924e21c9997ea0dba859a7f673876936e80b64c38fd610d79161b3', '2026-11-09 20:23:04.738601+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/custom_model_providers/0010-tenants-lookups', 'f3ae797643fe239d1a9ebbd3efee2b0f4f49891882717991fba7cb59318c8a4f', '2026-11-09 20:23:04.742775+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/custom_model_providers/0010-tenants-swap', '497f0a35a78c69c4765a4cc81f4098620c166f4bb260482966aaffa65295bf32', '2026-11-09 20:23:04.743038+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deactivated_principals/0001', '74cf2f5e2185abf08a2c93da115858a42c6f10fe94d814815342888e735ee355', '2026-11-09 20:23:04.744176+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deactivated_principals/0010-tenants', 'c84425790124628daa7be19973e7eeeb6b63e438fb42b53b51d97e180dc9584d', '2026-11-09 20:23:04.745506+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deactivated_principals/0010-tenants-lookups', 'b44a956cf76483f89bd3785ac1a405bd3e662af8b9d4f6fd415ecca6307ce7cd', '2026-11-09 20:23:04.750207+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deactivated_principals/0010-tenants-swap', '76b199fba82e4917be405c9e210d80fdaec6faf9b116650fd0dba6724e5b3a9b', '2026-11-09 20:23:04.750477+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deploy_git_repos/0001', '4957c2777766eb31eaa136953ed5046bc298d8341aab69a43545594f0970ea4c', '2026-11-09 20:23:04.751633+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deploy_git_repos/0010-tenants', '93e132723e0b016ccb987906137126b8b57c512afcfaac8f186eeb419fc11579', '2026-11-09 20:23:04.753208+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deploy_git_repos/0010-tenants-lookups', '033f58bfa27d357fb850efe5a8ec5f12c5c4723f2bdca148ea433b8231bd6911', '2026-11-09 20:23:04.757269+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deploy_git_repos/0010-tenants-swap', 'd693240c9e64dc428b05c6a3871d5cdc483de7acde76150f0cd62434ae702bcc', '2026-11-09 20:23:04.757516+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_identity/0001', '11b012ea31d25b354799885bfc8f1f68a8e9ca2108d72ccee7102a36cbaa1c1b', '2026-11-09 20:23:04.758678+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_identity/0010-tenants', '31052f5d6a06990ce632c8f789628be98fc22039e2af39bc9f39940f32b29fc8', '2026-11-09 20:23:04.759888+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_identity/0010-tenants-lookups', '9a0d37171392d74fcfd6bc38be91164eeba8eb1efee5261bce2a41510f9e4e62', '2026-11-09 20:23:04.763879+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_identity/0010-tenants-swap', '0f4cb99e435c0f03e0ed4353376b68a546e3c40855b92789535b9c9d98b8d3c6', '2026-11-09 20:23:04.764088+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_layer/0001', '1e9f09c7e5ca32924a4074a7cca5fff79865d31794515c02cd287b337b419803', '2026-11-09 20:23:04.765404+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_layer/0010-tenants', '1dedf2bbc5154c6de326b1fb516f5a0e67fd3fc972838815e3fa6d2153baccc8', '2026-11-09 20:23:04.766732+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_layer/0010-tenants-lookups', 'e9b3eec904b0ee362acc2453c08817f5dc3ac05f4e4e87ec12def5fa521f0c64', '2026-11-09 20:23:04.770946+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_layer/0010-tenants-swap', '24dbbda5f60847fda0ed42d99daf2e46fb81206dbbdd122807dc7ca1f188037f', '2026-11-09 20:23:04.77117+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0001', 'f592ba8aeb41d74822e3960e9632d29adfba5bd0e79c7f21fc91e7258ad0e555', '2026-11-09 20:23:04.772159+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0010-tenants', 'ecabc92a9504f46eb5a72f081b8a5e249430a57a09f817aada0de06a62b7ede9', '2026-11-09 20:23:04.772546+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0010-tenants-lookups', '371a1e5f35d9fd8714e54c2eb793fb4f4b2473c85d54d156142a912e31554100', '2026-11-09 20:23:04.77638+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0010-tenants-swap', 'd35990f9ee1ba0646fd9fae3866830ccb722b013656b2a5e8a7c5f34fd17c6d7', '2026-11-09 20:23:04.776599+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0011-access-tenants', '82645245c1397e3a252f2ba45c8b8dec08c31ec3bb903cef23620b7f786654a3', '2026-11-09 20:23:04.777928+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0011-access-tenants-lookups', '2fde547092f1d422faf9838fb84d6939cd1c24774631894509ab99e74c363952', '2026-11-09 20:23:04.782439+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0011-access-tenants-name-lookup', '1df11587acb7dbffb1b0b50367e6c89da832c560ec4728ca18f8d3460ce1100c', '2026-11-09 20:23:04.784002+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0011-access-tenants-swap', '22a3d88aa5914c53df125acd5a6511f2f8de2a7ec286493140f430434bb80d42', '2026-11-09 20:23:04.784255+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0012-page-views-tenants', '544da34b80dc37c58bcc62f2e1972840c472f7a4225aa9c3da913694c6fc6255', '2026-11-09 20:23:04.785963+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/do_managed_agents_sandbox_bodies/0001', '1e4868c1a418add4a2b99f2cf87f147aeafc859eb31e0cf968489ffaa91ee4ad', '2026-11-09 20:23:04.78682+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/do_managed_agents_sandbox_bodies/0010-tenants', 'b3b989234b6d0f9218f75b5a47cfa9e1884566198bc13dfc5ae76f9af4d94fcd', '2026-11-09 20:23:04.788042+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/do_managed_agents_sandbox_bodies/0010-tenants-lookups', '14d2a9483edecf67804ac1f31175b5ddd22cb1e6b5b35049d87de21d78450a6e', '2026-11-09 20:23:04.792041+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/do_managed_agents_sandbox_bodies/0010-tenants-swap', '543c5f709f754e93daf6e50a73034227b49fcbc2f8c112878152145baaa3f36a', '2026-11-09 20:23:04.792339+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/durable_map_versions/0010-tenants', '41cd19cfe0bcb08a9aa437bc2cf48443901ca9e808e114413f3c350a3303e027', '2026-11-09 20:23:04.793474+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/e2b_sandbox_bodies/0001', '86fde308e21c9f2855750b885fc7a2c860eec53662e9713979cb5af7b6a844a0', '2026-11-09 20:23:04.795908+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/e2b_sandbox_bodies/0010-tenants', '3fba62024ac496a82a90071a8573ca88c77ec31d16578ef710e8872385a6759f', '2026-11-09 20:23:04.797088+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/e2b_sandbox_bodies/0010-tenants-lookups', '1f055c03185996eb1e1dcd6a7da55612ced2f9ba465f128696fad24fd4b5629e', '2026-11-09 20:23:04.801223+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/e2b_sandbox_bodies/0010-tenants-swap', '6e293d099cd49c22054aa5ce54317ffb2af104888d4808eaf632cb4c0cee6e63', '2026-11-09 20:23:04.801461+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/egress_policies/0001', 'e26a4391eabca30277592e928b512beacfa4d9388ebb189a6d22b7acc388c775', '2026-11-09 20:23:04.802632+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/egress_policies/0010-tenants', '8ee7ba5328f43435784f621e8f59fea5f67aeea5b523203d3e3ed08e8555ab16', '2026-11-09 20:23:04.804057+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/egress_policies/0010-tenants-lookups', '318dca68846de484b67d5bed0129981dd44994ce062f3bcb57bb50e5b2ab0b53', '2026-11-09 20:23:04.80803+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/egress_policies/0010-tenants-swap', 'e7682a8e2cc7440b0e4701c2a2f99e0f32ac0989d5ae73a7cbbeb51997b13540', '2026-11-09 20:23:04.808334+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_members/0001', 'ea7b43915e8761f9148a2cff9f5c401e192a25b4b71b9535c0ee4710f1fdcba6', '2026-11-09 20:23:04.809461+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_members/0010-tenants', '33cbeaf38273c6e8def79b7e9f010377239432b5afeb5ce594e5590d96a196b5', '2026-11-09 20:23:04.810871+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_members/0010-tenants-lookups', '33b518219c94dd7ec8a1e2be26ffb21c47445429981d5da05584f7647dbc83c4', '2026-11-09 20:23:04.8151+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_members/0010-tenants-swap', 'a1825b9cf663f27d9765860fb42d75d014cc0be6ca0d0c5d81768eb6d1efe664', '2026-11-09 20:23:04.815396+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_slack_participants_flag/0001', '4c7dbf123c9b99cd85215958cfd9581b83e634b2e02b405548c2777001836291', '2026-11-09 20:23:04.816669+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_slack_participants_flag/0010-tenants', '85b7364ddc93808fc7da0f4c42769e57db4953756dbac67c1e5732b8401314b7', '2026-11-09 20:23:04.818165+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_slack_participants_flag/0010-tenants-lookups', 'c906f4a9f08250e2f14fdaa177e154c43825318fd08327b18169f53df424fd56', '2026-11-09 20:23:04.82228+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_slack_participants_flag/0010-tenants-swap', '60c467cf7b6e6dd00c1337eee8813925cc2e5def61a8ece656daee015deed82a', '2026-11-09 20:23:04.822494+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/feature_flags/0001', '10919fe9fb09ca1141ed38917d5d11b6dad1f53f7f35724b03ad33ebb0712319', '2026-11-09 20:23:04.823464+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/feature_flags/0010-tenants', 'b59a551dd74b29b1f19ee7ebb11e9b20e8d4b3178deb3ec7d8fb9cbb6955da25', '2026-11-09 20:23:04.824584+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/feature_flags/0010-tenants-lookups', '8d028f88aa2e894ca8221d848ec6e74d59554c38f2383e98ea94a7ae746383ad', '2026-11-09 20:23:04.828795+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/feature_flags/0010-tenants-swap', 'e42632cf0a0df70266af75415e1b53b7da2586931486f3b22e6e076b7e214135', '2026-11-09 20:23:04.829114+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/idempotency/0001', 'e171e640e06976d6c0f869c90a3775c68a3ef228f78b56da4edbe7a0e29d7f9f', '2026-11-09 20:23:04.830452+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/idempotency/0010-tenants', 'b6eba0a6b7253c46489395db625442b994c465cbc27848e72a44b2a87039ec21', '2026-11-09 20:23:04.831881+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/idempotency/0010-tenants-lookups', '8aad729655ec6c8076c4b241f5a9c67ddf24a892d76efb4ad5812ad93edde543', '2026-11-09 20:23:04.835749+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/idempotency/0010-tenants-swap', '1eddfc070c6a93946ac44c7244269e133b26a323e7a56139f8d61fbb480dc97a', '2026-11-09 20:23:04.835954+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/individual_model_auth_flag/0001', '80e854a8e2377cb348357c97a3485c9739f4abdd65c3bbab523a0d911b7bb19d', '2026-11-09 20:23:04.836951+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/individual_model_auth_flag/0010-tenants', '81ec166e59bb63d6698db924b480f08a4fdcb3894daa2adeb34152682c96266a', '2026-11-09 20:23:04.838409+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/individual_model_auth_flag/0010-tenants-lookups', '52c0a8f7b96e294c748187c29a6ecfd1367fa26707de0216f89e6f4d42d15f40', '2026-11-09 20:23:04.842514+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/individual_model_auth_flag/0010-tenants-swap', 'a30f14d9dddf664ffc49681b2427376dfa28952d84aa368c18bb392b48c6e4f7', '2026-11-09 20:23:04.842779+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/interactive_fast_mode_flag/0001', '3a1e6bcaa71527b414f5bb5f98610230cda67463b86823723b9283cc4b93aaf0', '2026-11-09 20:23:04.84385+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/interactive_fast_mode_flag/0010-tenants', 'bb04a5177ec44e574a8f5167b312f1cd28bf314e2b5c233ca0a68d3a2daeb322', '2026-11-09 20:23:04.8454+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/interactive_fast_mode_flag/0010-tenants-lookups', '6b052a519733f5d2dfbda82a325add272a0064820404fcdc3d112001f14e0c09', '2026-11-09 20:23:04.849561+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/interactive_fast_mode_flag/0010-tenants-swap', 'b8d39a9548d04733b08e3cbcac09998d15d0a99c06deda538b9d045292aa399c', '2026-11-09 20:23:04.849851+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_asks/0001', 'aef8c37ef4fffa25f96ead4d5ae73b5bcb0b60aa7248050f9bd69d6c064a3a55', '2026-11-09 20:23:04.851103+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_asks/0010-tenants', '8492026cc902f0c706cf8d92b4d8b8c04e9003f0461cc40abbdfbdf62690ec40', '2026-11-09 20:23:04.852419+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_asks/0010-tenants-lookups', '504d002ae8df42225eb4ac71b4b96bd6cbc8fd92277d6f10315b416940760af7', '2026-11-09 20:23:04.856702+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_asks/0010-tenants-swap', '13dc734aac003b0b48a9e2ce67fa2b5f9ec53382b0eda77e25ff3e1975f9eb8a', '2026-11-09 20:23:04.857002+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0001', 'b7dd2271dfd424898bc65f6adb658b8b51b07f0a9e6a9ef47b5e76fe51c0eda7', '2026-11-09 20:23:04.85842+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0002-delete-auto-captured-logins', 'e2c3d2c3fb7d240450004a535a8af950db3b6ff35ca284da0f393ec31c0b4fde', '2026-11-09 20:23:04.85987+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0010-tenants', '14ea1f357c8c63f806cfdc5c0a4444b51ab5e4dd1eee28789e691f219d9de19f', '2026-11-09 20:23:04.861544+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0010-tenants-lookups', '3422745ad92e673d6f71ab2e0b5e793a646bfd69644047d4f4569dce24ab43f7', '2026-11-09 20:23:04.865421+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0010-tenants-swap', '5a9b8389a3297df6f4004dd0cfe566594a2a04dc6f2dd01e41976f492a613309', '2026-11-09 20:23:04.865723+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/lookup-ownerid-drop', '460b2be11208138a00b181b518ca38bc58322dcd37f158ff672496b3fc1248c1', '2026-11-09 20:23:04.866783+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/lookup-ownerid-hash', '84860ad9d9f1634d9bf17e0a928a6d11513200dc6fb43c881928bf933d6da455', '2026-11-09 20:23:04.868477+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/select-ownerid', '6ce3ea87541dd9462ef96981c7c3aac35120340f6477a319b46806f717a90039', '2026-11-09 20:23:04.870777+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/stats-ownerid', 'fa449596f80d2fb3d6eff92f3d52a5e82a58db3c5556520b9fc273a5403d7773', '2026-11-09 20:23:04.870975+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/0001', '6331a8b0daa7ae875d6b09457f7ca1f865812e9a036efa23186793632f94d3d4', '2026-11-09 20:23:04.871622+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/0010-tenants', '755fcf50889068330684d32b9b3f93ba931fedd824d6b0df486940cf07e51d82', '2026-11-09 20:23:04.871973+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/0010-tenants-lookups', 'f9c808fe5e59240cc090fdb8d0af96d6affc64782019eb00fc7e37077fe1d745', '2026-11-09 20:23:04.875907+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/0010-tenants-swap', '9cdc37e4a171b818c2aa4597889b8b12a4b3699bee127b9a295b2a769d4210dd', '2026-11-09 20:23:04.876222+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/lookup-ownerid-drop', 'b0d3eb453249ac97e0271a551c0b69f7ff93591507521ae1ffde71ce0cd3cee8', '2026-11-09 20:23:04.877366+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/lookup-ownerid-hash', 'c7f3b4ab099eadee97ffb0d0e30a949b63bab34a1356773c9efa85ef5f87063e', '2026-11-09 20:23:04.879141+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/select-ownerid', '2f8bc9481bd50e162894c41aaca606fb666eadae3600ef2297512d6c27e9c33a', '2026-11-09 20:23:04.882057+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/stats-ownerid', '504fbbd9176f279f9c9ce9e2e58c475196dbbdc3c6697e81704ae568753ec676', '2026-11-09 20:23:04.882303+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/0001', '4d2ab585c043345d1594b6415ff08408e594f3e38af807afaf2eeb21bce93f11', '2026-11-09 20:23:04.883078+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/0010-tenants', '6a91c801b6d69f54472ca026985bfcfdb2f815e50e2c3bb334fa77a9b1de5b15', '2026-11-09 20:23:04.884534+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/0010-tenants-lookups', '68de511533d362e5472bc677931d0471fac85566cdc0d5666320c06de88d9773', '2026-11-09 20:23:04.888599+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/0010-tenants-swap', '373a6591c302a881a6ed2fcf72834bd7c205053bbb9345341b7cedf7a6750365', '2026-11-09 20:23:04.888827+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/lookup-queuekey-drop', 'b0302105ca749092efde87bc17e75762786db0b1aff63a2fc6039ff1745241b2', '2026-11-09 20:23:04.889998+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/lookup-queuekey-hash', 'ad86fd50b697f06a2ca776dcf2ac2881cb0cc8ac5de1a5331e30be6f2c4ed936', '2026-11-09 20:23:04.891699+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/select-queuekey', 'f2723f1f7b7fa434f8ed9251e2ad1234e4d074d13802543abf5141cdedb5dd9f', '2026-11-09 20:23:04.894039+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress_deliveries/stats-queuekey', 'c94b5443b22df93b53ad607e3a9c04ce9b40dfec6de998b771db8ff83c2ae57a', '2026-11-09 20:23:04.89426+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/0001', '9d74414c582e3fd4a3c2319f32b86f516f13ee7731fa54a8a3b567ee052c6aae', '2026-11-09 20:23:04.894949+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/0010-tenants', '393dda6454dc0fe3273bd371da1dfb81fff53800fdd5f1d434ca9fadee2055f2', '2026-11-09 20:23:04.896324+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/0010-tenants-lookups', '0721429aedddd738021ab98da1c452c08866d4b98aa5543f24b23d060eef6e67', '2026-11-09 20:23:04.900454+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/0010-tenants-swap', 'a077a564cd9b931b5d071fdc9b40c9cedbc124d83d00fb89756e13b4c5230643', '2026-11-09 20:23:04.900655+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/lookup-loopid-drop', '9f9e885e67107f38a8a490d6653cc021582439fed748a4129d1c5a4edf87378f', '2026-11-09 20:23:04.901948+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/lookup-loopid-hash', 'd808ba6969eea145047c46626267a9bf9da846db528b5e5f0e4491732b0678c0', '2026-11-09 20:23:04.903914+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/select-loopid', '2a95bd8533d9e39901bee0c2baa743edc3a63d93c56554a95413ef915cfd5017', '2026-11-09 20:23:04.906494+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ingress/stats-loopid', '55593a39f9c53aa1f19a0134fdc3f8f3b18cb4b432a136123f2615b115669e69', '2026-11-09 20:23:04.906723+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/0001', '051d43294fb2c30a5491655d2d21cfdf0f64687bbd64934e32cc05686951aa43', '2026-11-09 20:23:04.907473+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/0010-tenants', 'fe1aee7f6239fe83e45ad8541d3c31365994e18a029362fac786378abe9141e4', '2026-11-09 20:23:04.909018+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/0010-tenants-lookups', '364abd70a21894018cba663677de72f5cdc858da9262bb9a5a5a8e980e276f05', '2026-11-09 20:23:04.913271+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/0010-tenants-swap', '242e1fac61a21b7f7886a4232912e6d25b93dbb2ea82ea983e7fc1d3e974ec6f', '2026-11-09 20:23:04.913521+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/lookup-loopid-drop', 'c49a0f7eb4b19400ea1739d129413d31936a49d5a53e9cb933bd11d06649f42c', '2026-11-09 20:23:04.91471+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/lookup-loopid-hash', 'ad7ed85cad25c85b37d0885352a4822b4ca37e01ca4ae46ebdfbed075e471908', '2026-11-09 20:23:04.916496+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/select-loopid', '00c11d5d6776cedd88870c3b29570b162f721eac857042c34c618a5940d8aad5', '2026-11-09 20:23:04.918983+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_items/stats-loopid', '3a20258517de4424e12f6042fd985486a0abff81806d729d669863557692f856', '2026-11-09 20:23:04.919206+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/0001', 'aa3599a15647d3a3248c397f30180b0b144407b1629f8702c23641da644b9a29', '2026-11-09 20:23:04.919886+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/0010-tenants', 'b357e3b042e9a23296852e8223d40a325b163c6bcc9d8b0020452d325569084a', '2026-11-09 20:23:04.921176+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/0010-tenants-lookups', '4f9f7cab9eab72858bc234326bb37c4c2192b3fb0bbcdb1f1df29f51d4ba5e53', '2026-11-09 20:23:04.925097+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/0010-tenants-swap', 'cbcecee80a1d6ed8b9fdeb9eaa2248c3a8cb1b02800718a106cabd79a7c2df8c', '2026-11-09 20:23:04.925344+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/lookup-itemid-drop', '6d17d66f11252bcda44b6e1004568c2879058032509a8fa29203d17e2fb4b99c', '2026-11-09 20:23:04.926455+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/lookup-itemid-hash', '0b3e31cfdd5546781ac566674717506d96b88c56e9b9ebce2de915c7527e5283', '2026-11-09 20:23:04.928166+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/select-itemid', '0a75890492f409aa80c3fc549ce0f24f6f228f110904fdbbaeabd2cec6a98829', '2026-11-09 20:23:04.930633+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_outputs/stats-itemid', '28a0babc667695fa45a675d047fe7b16d85a973238b4c3678a03e0c122b157a9', '2026-11-09 20:23:04.930834+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ship_grants/0001', '9f567f5220fa83c5e4255f674b18dc5f75c33711447d8eaf9ad46ca710dc6919', '2026-11-09 20:23:04.931507+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ship_grants/0010-tenants', '0ddf99c99cd29eb1000366b983b1914fa5c3521a558a273bfbbeb6042c5cd671', '2026-11-09 20:23:04.932756+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ship_grants/0010-tenants-lookups', 'b713638a73c4d8601f23ba8b81586c7128421ae844bc6ae2818d4c0d3bce6aaf', '2026-11-09 20:23:04.936604+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loop_ship_grants/0010-tenants-swap', '3f6d42c6b94b8bd887c2fc45b4998ae63e9e9f0655169128738ac90227de3eb6', '2026-11-09 20:23:04.936889+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loops/0001', '2ece5bd63a110354855bf2e0a58c31dda1c38c392fd48999aa186443db931af1', '2026-11-09 20:23:04.938009+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loops/0010-tenants', '89b78fc8159ac266818617871b315e2bacbbe8ead3cb87a1034ee05767831941', '2026-11-09 20:23:04.938386+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loops/0010-tenants-lookups', '68ac7ab966c346119b3f6f4451b8196942178c10c8f7b783dc3cc0415fbcfb84', '2026-11-09 20:23:04.942284+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/loops/0010-tenants-swap', '0bd90a7c13c68f4e19dc93798d58932c929ff135d340f1f0445cfa8e5ee64bea', '2026-11-09 20:23:04.94251+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/mcp_servers/0001', '656e5902aface901aa8ccea2d404b26454bdf5fc59b0523132b9c339e08b7800', '2026-11-09 20:23:04.943564+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/mcp_servers/0010-tenants', 'f8a77bada4d6f4c54a90bb4406c4bafa6cff8f28d9f5cdf7af86e245cd9529ee', '2026-11-09 20:23:04.944894+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/mcp_servers/0010-tenants-lookups', 'b64d87fe328a79c86271bfeb629fc4c6a891cc26ee337efbc46de5ece2eb8855', '2026-11-09 20:23:04.949242+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/mcp_servers/0010-tenants-swap', '459dcf8ff470555807101fdb90aaa40783ab29dd260933de124076727c3d8881', '2026-11-09 20:23:04.949505+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/memory_tidy_profiles/0001', '9b4bb200823266468b607b2f81f3a50bd860cf25c41f980ddb0a61d9ea5e643e', '2026-11-09 20:23:04.950576+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/memory_tidy_profiles/0010-tenants', '9a6468408cd1c32d48fb68f94773b564eeba43c2104e23894033f196d7ace91b', '2026-11-09 20:23:04.951993+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/memory_tidy_profiles/0010-tenants-lookups', 'c1dc8147883586445c2ca391d14be2631100b3f894b0e3fa838fe268076a501f', '2026-11-09 20:23:04.955838+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/memory_tidy_profiles/0010-tenants-swap', 'a687d0381ec2dc79f2f35eea74b69914cb35a7522e5eaaef7fa7599b9a161c65', '2026-11-09 20:23:04.956048+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/modal_sandbox_bodies/0001', 'e5a58d41d449a16030a2f8bce471141fe85753cf3e17fe112dfdafea1cf7ddb0', '2026-11-09 20:23:04.957001+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/modal_sandbox_bodies/0010-tenants', '0ebb39df0542d90103b2557a153bdd71616620041da20aa6b7d3e0233003561d', '2026-11-09 20:23:04.958249+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/modal_sandbox_bodies/0010-tenants-lookups', '835c954fd04672377357d4ce62afc9d4c4987aa1bfed9830c1f95fa312f067a8', '2026-11-09 20:23:04.962103+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/modal_sandbox_bodies/0010-tenants-swap', '2f406504cfa6b4fe7d279885b493fc36fca6258660707fdc8deca9ee0f4abede', '2026-11-09 20:23:04.962343+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_credentials/0001', 'ede2f544fbfa17aadf339b7830db978823fdd8ffd626f900816c22bb26817474', '2026-11-09 20:23:04.96346+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_credentials/0010-tenants', 'f1b2ce1d1bb6246d731599da350f48b86a8152a4e2baa3830413d295220c2ba3', '2026-11-09 20:23:04.964918+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_credentials/0010-tenants-lookups', '0d0ae29eb5f13b8c85bed44df4b2f1b2a8b8c4284af86d4cb0410f19aff89f74', '2026-11-09 20:23:04.968809+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_credentials/0010-tenants-swap', '38b8dc86eda726ba8da58b0dae6e56c7ea2ad1f0fdf9a74700bd2ca10bd7a7d3', '2026-11-09 20:23:04.96901+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_registry/0001', 'cb7c405b5b231a9f19f672884c2c8fccb470fae508f60e11ceff3eae7727e834', '2026-11-09 20:23:04.970046+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_registry/0010-tenants', '846249043e0f91d34149b66f3c7098438d563a927c77379eac029ef00d4174fb', '2026-11-09 20:23:04.971472+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_registry/0010-tenants-lookups', 'e9a116952dea6b9e46c5fdb6207deb8fc8ee8e1410cb258b5f57c1edc42dd438', '2026-11-09 20:23:04.975116+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_registry/0010-tenants-swap', 'a9e3a2a44ad58e90174f7f86e6665d40cc5b7cffe101c466608ed2b21683ce4e', '2026-11-09 20:23:04.975336+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/0001', '352b4ae3e97e45c43ffebb22ddafe1fadc56a37ac025a61d660eb0007613b580', '2026-11-09 20:23:04.976394+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/0010-tenants', '81b40381bd2e75d076e2aa381ab3c2a5da898bdea60280424fcffd85d5afe0ca', '2026-11-09 20:23:04.977699+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/0010-tenants-lookups', '53e480b68592add9c5ae417920a7bc6658e768688f85e7a0f5d6684afb03c3dc', '2026-11-09 20:23:04.981646+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/0010-tenants-swap', '54c28203f324a5fa0deb0f43938d629a2fd783ac285ea7fb2100057af300bbdd', '2026-11-09 20:23:04.98186+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/lookup-ownerscopeid-drop', 'da0e6fa54100837c47e88fea27c5f3ed807eb3b026473bbf1f6b64d7ea3d264d', '2026-11-09 20:23:04.982824+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/lookup-ownerscopeid-hash', '309d0a292b6c04131a97c4b0e047cc4dc4b95aa6b327327fc28a7d0f1cc1b015', '2026-11-09 20:23:04.984557+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/select-ownerscopeid', 'ae9b16dfa3c0a31ac987e28a043ddc08c55f0328b76a999d8319ed61dbce8907', '2026-11-09 20:23:04.986758+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/stats-ownerscopeid', '52d4260bb2c2e6d7e3c32a9c50e5395ecfd98b5a83b1f03f649e5b0b804a2c17', '2026-11-09 20:23:04.986945+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/oauth_flows/0001', '043983772bd290d5722456d63082a660c76e26fe9b6fad0e4a46baa138140f4b', '2026-11-09 20:23:04.987632+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/oauth_flows/0010-tenants', 'ad30fdcbf6dc534614f4cc4d2561b60903368743f37ea565e4c7b1e07da861a4', '2026-11-09 20:23:04.988977+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/oauth_flows/0010-tenants-lookups', '43033ef50323a455612380b25099711381ddf20c95aaf223d66266e5b40044ed', '2026-11-09 20:23:04.992744+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/oauth_flows/0010-tenants-swap', '17780520b5f74d79afc10f0ac4854cfb0f18893413a256de5148c2b90137bee9', '2026-11-09 20:23:04.992979+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/org_ambient_flag/0001', '7934678d620174a9abb1571803f937a6828cfad2bfe3dd3714d73d44a2679bc5', '2026-11-09 20:23:04.99429+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/org_ambient_flag/0010-tenants', '2c7a3f3d8d3b32f5f1321893c5f587bcf11d10a969ba7d9afeff046f5a389e6a', '2026-11-09 20:23:04.995774+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/org_ambient_flag/0010-tenants-lookups', 'b82e4894a63bc30d164861ebfb7d03e425523e410b880442de716a972a39eaa8', '2026-11-09 20:23:04.999745+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/org_ambient_flag/0010-tenants-swap', 'cf6597e9d3230f83bd17a2b95877ac99ec9c62ebc6473f8dab8501df8118ef1f', '2026-11-09 20:23:04.999936+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/principal_links/0001', '3b3529b8c4a3803a044be89c7881e1aa1e9e1b430f1e5e5d15f49d80e002c38a', '2026-11-09 20:23:05.001046+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/principal_links/0010-tenants', '76d76f9e6e431d8d2b9073f6156baa63bd24e7c59ff4fdbd5c1d2fd12540379c', '2026-11-09 20:23:05.002324+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/principal_links/0010-tenants-lookups', '118666c82b3abf26049f31dee6996215bcd9c4d10bc68942fd14d78aec1c336a', '2026-11-09 20:23:05.006036+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/principal_links/0010-tenants-swap', '601dcbca75c5806e8cc6becd5cbfc244ab09852b0769367026313ab991eef74a', '2026-11-09 20:23:05.006303+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/projects/0001', 'c3542e30f1dc3a4200d39f2043e94c5e9e9d641902bcdc83cdde198ce79f36f3', '2026-11-09 20:23:05.007405+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/projects/0010-tenants', 'd4dd1d4014d28ae71e8c1907b667385fd49461babfbaeb4fd6ca797c78a575d1', '2026-11-09 20:23:05.008783+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/projects/0010-tenants-lookups', '81079aed184e0a7e377e29111d5dd9630e0872b15949cd525883348f9cf6bd55', '2026-11-09 20:23:05.012856+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/projects/0010-tenants-swap', 'c518c97c08b1d5aa3b1f34bc1dd9e29124f52c075bbdb5178f29538e738fe533', '2026-11-09 20:23:05.013054+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_deploy_bodies/0001', '90bfc2a877940993dc12dd46b717da6a91b4f1fce5f1316d374289b3967b44ca', '2026-11-09 20:23:05.014149+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_deploy_bodies/0010-tenants', '670dc18aba8db6cc7dc0a9965856bcc6ce0e861f7594cf828343a3c222f50d75', '2026-11-09 20:23:05.015405+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_deploy_bodies/0010-tenants-lookups', '30f65f5acc8c91ba79fbfebf8b4bb7956aa8d55d947d0768778a42a1e4cb7db7', '2026-11-09 20:23:05.019189+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_deploy_bodies/0010-tenants-swap', 'b3c3c4b09e52c66d2bbf2e47c84934a260255c33fbad139fbf59f157ec307d56', '2026-11-09 20:23:05.019444+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_sandbox_bodies/0001', 'e64c614383cd6163c1ab1a59d7fa81e08a5edaf94439489382ca4edf288b515b', '2026-11-09 20:23:05.020492+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_sandbox_bodies/0010-tenants', 'ff2f3d8afee16dd4c7a820e1a80737779e3874fe0cbeb71266d30a45b7e8fe28', '2026-11-09 20:23:05.021669+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_sandbox_bodies/0010-tenants-lookups', '62a1f6d45d205a4d9b3163bb5a4c19fe8acd537b6049c7ca61424911757a7de5', '2026-11-09 20:23:05.025326+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_sandbox_bodies/0010-tenants-swap', 'd15e4cebcd2e80646d4a4089b26a82fa7be85e50451b2739853bcd30688c3279', '2026-11-09 20:23:05.025659+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_sandbox_cleanup/0001', '91c90f81a8878869dd6936ad8c0b5f5a70d25dd6989a9792987a856e8c048523', '2026-11-09 20:23:05.026902+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_sandbox_cleanup/0010-tenants', '377b7bcb1691add14ebec56086ae98c056008ccdd566f90556aa07e9cd771714', '2026-11-09 20:23:05.028288+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_sandbox_cleanup/0010-tenants-lookups', 'aa1fe873e19a42bb67167c9fb55a716ede339a683225c08db7f6c37d0373f444', '2026-11-09 20:23:05.032362+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_sandbox_cleanup/0010-tenants-swap', 'bf246dac5b318e0239f5a1ecbaafca3016e4cd24e8587ecf71d0e6c4b2aa4c03', '2026-11-09 20:23:05.032582+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_scratch_bodies/0001', '090542aeaa44e14aa2f7f8e1d9371b5e1251fcdbb31746edd0a39c6843eb69db', '2026-11-09 20:23:05.033723+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_scratch_bodies/0010-tenants', 'f648bfe9c3f2300c11b5c1092ba55e3f848cbc0b45326dffab47a4a8dd487556', '2026-11-09 20:23:05.034983+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_scratch_bodies/0010-tenants-lookups', 'bf8d07f52cde0c54886ff21c501c85557c6a95db35de9c5c26202cd2684db093', '2026-11-09 20:23:05.039154+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/render_scratch_bodies/0010-tenants-swap', 'e5ed456ae339a077d52adcb14dea915c90bca8d76f8c5ecb298c98554a58468b', '2026-11-09 20:23:05.039379+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/retired-tables/0001-drop', '7dea85967ce04a37a73458498a11df8da2aca63f36b1d18dd79545452622723e', '2026-11-09 20:23:05.040334+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_defaults/0001', '781d981103854e2b2c71435edb92d150e76aa8d93a4d519cd0b44c3fd2cb9921', '2026-11-09 20:23:05.042503+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_defaults/0010-tenants', '40f92952185356118dc3d0ced86bfcb258f5a93ead4d16212eecbe44709336dd', '2026-11-09 20:23:05.04379+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_defaults/0010-tenants-lookups', '8cbde45aaf004a317997db364281dab5094e3d6aac44d67258f5daff7f651dea', '2026-11-09 20:23:05.047647+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_defaults/0010-tenants-swap', '5335dca7b6269059a47c3cac58994137ead722573391ac1c3475331c19717fac', '2026-11-09 20:23:05.047844+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resource_rollout/0001', 'dcd22153628d543510d7b0354f04f44e5ced4caace605e4d11fc5d2a23e4951a', '2026-11-09 20:23:05.048971+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resource_rollout/0010-tenants', '50d206fab3d3f9df478cbf05dfe138775f22a1a4f6d34fa62a5098c78838cd95', '2026-11-09 20:23:05.050369+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resource_rollout/0010-tenants-lookups', '7d0292d172790fe4870b5b65f25207c78b5addfac013fc0135edf634a56aff2d', '2026-11-09 20:23:05.054329+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resource_rollout/0010-tenants-swap', '0228d39b0de5c2c471cc90d5bcf9a5020e5c88c1429a8e111a3115d4ad93823f', '2026-11-09 20:23:05.054528+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resources/0001', '162e15a2d6f50446d52b17d3ee77f2461ee0ec1c0207b09498e21d335ebc2bdd', '2026-11-09 20:23:05.055539+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resources/0010-tenants', '6eb3b520046bb535df0625f54b34d0419a1233f096d0a0ef65a1041606357124', '2026-11-09 20:23:05.057033+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resources/0010-tenants-lookups', 'fa2c404c44dea165af536724e243cc41c4e2a46ad3db4273d3008d3758ee7571', '2026-11-09 20:23:05.061015+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resources/0010-tenants-swap', 'f3f9579db6c55749cf9065d1b04e51c380e71cb89cc80ba3d68d85543af8c5db', '2026-11-09 20:23:05.061342+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_routing/0001', '87419da3caad64f369b0b2fab335aba22d336730b4a11abf8bddf24300a49448', '2026-11-09 20:23:05.062401+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_routing/0010-tenants', '8a4803b873fda97a4a2773d5c6c198ceeb85516ffda3964e9fefe13c40a61901', '2026-11-09 20:23:05.063743+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_routing/0010-tenants-lookups', 'fe07fd141ef06219fdad21a200561cca965bd0ebb184b3422501e9cb851139d5', '2026-11-09 20:23:05.067819+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_routing/0010-tenants-swap', 'ed9be29dc012d964caca3eed413a432a425ca7c0c779b9d96efb8cb91615a1e4', '2026-11-09 20:23:05.068047+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/secret_drops/0001', 'd53b8ea0189d918d65ec2f1f521bd1ea1ce7fdf533f516e365cc91732e016b96', '2026-11-09 20:23:05.06909+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/secret_drops/0010-tenants', 'db6c3776aea7c550b1268105d69075f1724240dc7a63bd92ab9142421de0ca06', '2026-11-09 20:23:05.070517+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/secret_drops/0010-tenants-lookups', '26a7186452517dd5d46a5b605284049d4dc9fe9eb49d417e7844c740af17f9b9', '2026-11-09 20:23:05.074463+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/secret_drops/0010-tenants-swap', 'f594ddb43c1be42ce1282c2c7106ce16773d1757a81abae23c55f848aa7f3487', '2026-11-09 20:23:05.074662+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/security_postures/0001', '811ad86fa544d98be740f332eb0315a9935d16b5a48ba0cec1516b819998c27d', '2026-11-09 20:23:05.075672+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/security_postures/0010-tenants', 'be44917c893e782312cc0e18deb9c415d08fa86d33f4cab0367236c5d30f9f2e', '2026-11-09 20:23:05.077008+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/security_postures/0010-tenants-lookups', '1423fdc0ab375d3c3a022b03425e97dd7953af51c9e6e9e7232c5340b35f0fcd', '2026-11-09 20:23:05.081472+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/security_postures/0010-tenants-swap', 'f9788e40be85c1931138b8bad4a48f8d06bfb2acffb0eb6208a753e617ea82c3', '2026-11-09 20:23:05.081691+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/0001', 'ef49edb075b1c00c3bcff3526b595f74ca1d16704e497a83fdede49f21f515d6', '2026-11-09 20:23:05.082657+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/0010-tenants', 'dc8f7e8ecdbdb4599a892bb26738f5895bc8e061a8d5146c80c2103a5aebd25f', '2026-11-09 20:23:05.08386+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/0010-tenants-lookups', '9dd91c4f859b99e10ee12052cc5d65494771edc32ec2e8a96c69872059f0b515', '2026-11-09 20:23:05.088047+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/0010-tenants-swap', '278520bd0d9771b1b46bbba15efeca23f76b2ea61e8d7ebcda91a86ca0230395', '2026-11-09 20:23:05.088287+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/lookup-recipientid-drop', '0515b8739e932343b78ec1052a9e80c773febf0860ded4409618c7e3e3a4aa4f', '2026-11-09 20:23:05.08929+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/lookup-recipientid-hash', 'd4acbff880f7e84d2a1f1eac9ddb44aaa1781e104830c8e2d297ad5c2b324f77', '2026-11-09 20:23:05.091157+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/lookup-wake-drop', '36d1fa0fbb2878177fd89fd272128d1c24a6d03b19cffe8c2277390c5c9631dc', '2026-11-09 20:23:05.091365+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/lookup-wake-hash', '412fef1862afd33ab9c235988829aab134ae9e02e2c562cdb9707e6d04a95c8d', '2026-11-09 20:23:05.093026+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/select-recipientid', '0f783946ba4ea3d80a9542d6a9bc3996678cd465abf0dfa4769c6788e3efe260', '2026-11-09 20:23:05.095371+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/select-wake', 'ef6f6f3c44e7d900032bc507e5ff2f2d1b2aa64daafc25d3c348b5fa08d10510', '2026-11-09 20:23:05.097536+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/stats-recipientid', '6899798a87557911875dfed8682094a5f6ebc0b3f535b9794f28b4705aff0807', '2026-11-09 20:23:05.097725+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/stats-wake', 'd7c3abe7148b7cadd8d2414418b3fcd177af27fed1d4fb95c04f209a194fd56d', '2026-11-09 20:23:05.098501+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_shares/0001', '77d2a755c000aad13df96fdf9433b717b79c5ad8a5e11ac671ea33379aa55f1e', '2026-11-09 20:23:05.099107+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_shares/0010-tenants', 'da7d66baa7f74b80cf58853eb961c11853e8c7002f3ece8d6f0ba7a7a121e891', '2026-11-09 20:23:05.100546+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_shares/0010-tenants-lookups', '2669db6d29568a2c614beeabbdd94c7a0dca8410338b12a0cf33314c92e7142e', '2026-11-09 20:23:05.104457+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_shares/0010-tenants-swap', 'a6f06ae60ebe4be016f75e0e0482a5e7f327a6eb013a54d8aabb89ca0c2f51ba', '2026-11-09 20:23:05.104678+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sharing_postures/0001', '16f5bcc02513285518e6913f70c043dda0d44fa4d0bdbe14ec578b5f06f1d178', '2026-11-09 20:23:05.105815+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sharing_postures/0010-tenants', '1324db3b5bca62502158d553b62f86f213c7bdebb2f60a0bea7cf86ee1602fd9', '2026-11-09 20:23:05.107118+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sharing_postures/0010-tenants-lookups', 'ad531d8a61d10ed443c92561104b9cab051a56eefb3df7add9ecd14ab911fd9f', '2026-11-09 20:23:05.110724+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sharing_postures/0010-tenants-swap', 'fab7f21bede3fa30635ec37067f3e16d5b2bd1623fb8b6dddc1b6e27fc1caac3', '2026-11-09 20:23:05.110913+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_bundles/0001', 'e3e3974648f7657b6dca0c331b64d90f36529e9c3ffec1ae05282a370c0ba1ec', '2026-11-09 20:23:05.111861+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_bundles/0010-tenants', 'bf7f5e4d5d0674b7490f32e00a044137d412826c5609ef54f997852957c2435f', '2026-11-09 20:23:05.113243+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_bundles/0010-tenants-lookups', '607fb841f44bdf6c8050ce627ed2671b305e14d49afb75b65174f44224f3191a', '2026-11-09 20:23:05.117044+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_bundles/0010-tenants-swap', '8da3b30e6a1d1fd2d778d436813941635f9f9ca9e578872a845f7055256c6cca', '2026-11-09 20:23:05.117277+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_packs/0001', 'ec3020db9e97c12b42fd33acc59bac01b741616fb2ac31327f6180068d35f708', '2026-11-09 20:23:05.118213+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_packs/0010-tenants', '3abb967936a451c8d6b798c3f37adcebae025b570bda9af0e83a59456ce8dbef', '2026-11-09 20:23:05.119465+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_packs/0010-tenants-lookups', '9d566042285f83651bf58a7ed836be66da9c4f8f8b53c6c48f5bec04c4efbd7d', '2026-11-09 20:23:05.1232+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_packs/0010-tenants-swap', '3c09c0fef23affa76806ac5a1dd2a9a6b3c49eb25530e0a1d9b190be68b2aa1e', '2026-11-09 20:23:05.123417+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/0001', 'efe2a0c8ad67467be845d93206eddea17c15784175006b9a1cc82615ad0a33ea', '2026-11-09 20:23:05.124537+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/0010-tenants', '1e15137668c41ce1243e40f4a13625db9ad5aeabb5c616e82c8db6a30a79bb8d', '2026-11-09 20:23:05.125944+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/0010-tenants-lookups', '6819cdcc7b3789a3f280c330fae696998deef1addd172a7e4433468abd7f5162', '2026-11-09 20:23:05.129615+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/0010-tenants-swap', '00364dd3b3da63128b98a04b4fcedfa8b8df2c2371b3d32730b9546dd4430428', '2026-11-09 20:23:05.129837+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/lookup-scopeid-drop', '9d6c67dba12d614f52f0699708744290fe34ce3a3c809af0e384c73e8204a50b', '2026-11-09 20:23:05.130799+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/lookup-scopeid-hash', '4ad1cb3e06ff90c35c53e28a20b4299e868b76486dfc561d79724eedfb198fbf', '2026-11-09 20:23:05.132476+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/select-scopeid', 'b010072d152a8c28d5a831ed0fcf75539cb1347f0684a621ff84939a8e0d6017', '2026-11-09 20:23:05.134957+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/stats-scopeid', 'bafceb5216672202808bc727023c3ae8e048a947030742dc82e973571777043c', '2026-11-09 20:23:05.135181+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_accounts/0001', '48ff469a6b3ccaa72d47ce443808b2be4ef38640dec7ba8733419789d5c6e8b9', '2026-11-09 20:23:05.135967+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_accounts/0010-tenants', '63870fb08041039ae6bde4ccc88543b4cb19f130ebc75d7ae274d3e71b813315', '2026-11-09 20:23:05.137351+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_accounts/0010-tenants-lookups', '50359418a719970c7865770d1dc2b50949ec5c730beb2f654f3547bb512ab153', '2026-11-09 20:23:05.141625+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_accounts/0010-tenants-swap', '805d61298edeaff59ba8d766e49998896fbf037e7b401594378b5240b2de0f20', '2026-11-09 20:23:05.141834+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_emoji_catalog/0001', '72e45c26308d61173a6de2ae9e78bbae52dc943e6f12981fa51455d273253a1a', '2026-11-09 20:23:05.142994+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_emoji_catalog/0010-tenants', '2b1e5d23e19d641da91115dc37b38fc801b8c0a4b3a95f477a5c2bfd79eb8bcb', '2026-11-09 20:23:05.144391+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_emoji_catalog/0010-tenants-lookups', 'e5a5f9b1f51e1b28747ce4aeb0de429505cc272f9a3efa56224faeb23ea47908', '2026-11-09 20:23:05.148547+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_emoji_catalog/0010-tenants-swap', '242ffadb3625c6d1694141d51c01bacecb57253fa22e022cbc7785ff53af9b1c', '2026-11-09 20:23:05.148744+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_installation/0001', '31b96f65fded9ee0898ccf44766f6e542d30b0deb3b8da0d06381839be94764c', '2026-11-09 20:23:05.149871+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_installation/0010-tenants', '2d47ee264cd7a08faeebb5acfc99962c8ba21b37a416b476972f7f14619020b2', '2026-11-09 20:23:05.15135+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_installation/0010-tenants-lookups', '7aa4974b1c06595c82702782027378e0b9af9601f744cebdf4f2ab974f262a81', '2026-11-09 20:23:05.155862+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_installation/0010-tenants-swap', '60003f739bd407d6c3c52f40309fe9a0d76b329cee6a2b2b7ddd33e1f5bb2065', '2026-11-09 20:23:05.156068+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_session_status/0001', '211ec9c63a6104511f45ee1f2315e49f5b749e9fb2a8780dfdf5b6174ef0bc51', '2026-11-09 20:23:05.157391+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_session_status/0010-tenants', 'cdd587cb457c241b1a1173e401a15204cd2ba0960f532152b177fd046955e77d', '2026-11-09 20:23:05.158971+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_session_status/0010-tenants-lookups', '2862303d14f3c95eb10064c2c35cd1b752135c6aba70cc6c6b714c3ef62528a1', '2026-11-09 20:23:05.162993+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_session_status/0010-tenants-swap', '37e26ceab02ac0659b9a77bc2ab6b6a45afaf14738650efcba1301fd0b394632', '2026-11-09 20:23:05.163201+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_staged_envelopes/0001', 'c3a5173bc2f0bf0e739fee4a59214c5e2d6236374f44a925016e74ac48188375', '2026-11-09 20:23:05.164209+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_staged_envelopes/0010-tenants', 'd30e934a81c34369146f8593e695d72392995b99a9dd63c1f06c2b0cd2160f8d', '2026-11-09 20:23:05.165415+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_staged_envelopes/0010-tenants-lookups', '37299627337a2c8d43db997c0310c390c75062677457c74e22ca6c00b4a842c5', '2026-11-09 20:23:05.169428+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_staged_envelopes/0010-tenants-swap', '55a5070a4ae95386fb69771a00a04fcdf5595746312db720f6e228678a45b864', '2026-11-09 20:23:05.169636+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_task_acknowledgements/0001', 'bf9fad755c2e7c4dcbb795ad589832b78136e41cac793b0decf98cf180acdcc4', '2026-11-09 20:23:05.170783+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_task_acknowledgements/0010-tenants', 'a845bbda218af87ae224e09e9e77236ad4754f3b3dfb0e2ce256c182c931f326', '2026-11-09 20:23:05.172048+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_task_acknowledgements/0010-tenants-lookups', 'e614786620fb02b647c18070ec225b7a4cf0b33e058f7a51d87801df1911c476', '2026-11-09 20:23:05.176068+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_task_acknowledgements/0010-tenants-swap', 'd21e7e52e808cf29400486504250a4300671b383ff7549ee83cdad80f13f60d0', '2026-11-09 20:23:05.176278+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/smolmachines_sandbox_bodies/0001', '7732ed446a800d053f5dffbcdc24b81b83e57d4cb9ce741b4a294bbd26f15c7d', '2026-11-09 20:23:05.177294+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/smolmachines_sandbox_bodies/0010-tenants', '256f4076f6e8680a123c76289eba4ae71975046e49523a14210d6fba6828d391', '2026-11-09 20:23:05.178466+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/smolmachines_sandbox_bodies/0010-tenants-lookups', '32265cbf84acaa212bfbbd0d5b2151cde346a4324d915617be45656804681ca1', '2026-11-09 20:23:05.182109+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/smolmachines_sandbox_bodies/0010-tenants-swap', 'f9fdb8ca95908598ca3759213cd70e26d466e020e0c172188cd1b2a656a35e93', '2026-11-09 20:23:05.182342+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_configs/0001', '8528037c99399b8fdcba2e29dc7dccbc0bb359d6cd5e9ca8f4e0d34a6fc7a4e3', '2026-11-09 20:23:05.18336+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_configs/0010-tenants', '1f772bcdfd6be986860569c2c07d552ffebd0071166b70c80c6269743f53bdc6', '2026-11-09 20:23:05.184891+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_configs/0010-tenants-lookups', '2f1f00f8eb0d4f05c0181eee932bc3310844cf4e946915db34b5aad13797dd02', '2026-11-09 20:23:05.188789+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_configs/0010-tenants-swap', 'ba4284c3470c745777a6f91c2c474395e2fc4b06a6abeadd62bc14b896c5d91e', '2026-11-09 20:23:05.188986+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_history/0001', '2a9607ecb96935a95b97fdefc042c7517a58802c4cf9fcee67d7e8da3a4603e2', '2026-11-09 20:23:05.190003+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_history/0010-tenants', 'b756e15628a1b7652aa9165341cd3bdcb6a83ec9232fbbf8f46443475cb17405', '2026-11-09 20:23:05.191434+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_history/0010-tenants-lookups', '0555b4d81f8a725ce21b208750251d13ee7e8f993e896aaf840a2050e04ef589', '2026-11-09 20:23:05.195303+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_history/0010-tenants-swap', 'fd5113212e9517321c62b8e5e2ba691e5945045e516708fc041b67d9492eec42', '2026-11-09 20:23:05.195503+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/spend_limit_configs/0001', '526dfb125254549e65e5b02045cd8e165ce0267a1497ec210b8d541df749b558', '2026-11-09 20:23:05.196516+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/spend_limit_configs/0010-tenants', 'f2eb5eed696c50c1cc491784b7f1bdb488c34335e7c2a3399b3a8deb77112070', '2026-11-09 20:23:05.198014+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/spend_limit_configs/0010-tenants-lookups', '6280fad76eef1831ea7e6aa7a11daa934bfc9a3072ac4e85f05085b93a1e88c6', '2026-11-09 20:23:05.20224+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/spend_limit_configs/0010-tenants-swap', '59f933c9d1ea5013f2d18b6debc640df64be40d28a84908dd60c3fc5fe9bfe89', '2026-11-09 20:23:05.202462+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sprites_initialization/0001', 'e987bfe4bd5996dcee71ab6963e051d5192325c6d06a71f4e9da7621df4a50a0', '2026-11-09 20:23:05.203581+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sprites_initialization/0010-tenants', '02b45304b5b16ed48a510e0238f91f8b72d967e563697c4d8647a386c193ad6d', '2026-11-09 20:23:05.204939+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sprites_initialization/0010-tenants-lookups', 'da2c3bf5d11370aa6947006435041a75cfe3087ed7500266ad5008e5a4a86500', '2026-11-09 20:23:05.208895+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sprites_initialization/0010-tenants-swap', 'f9417ceec4e6d1d8f2f00f395d324c1b7457b653596fc474535fa21385562928', '2026-11-09 20:23:05.209091+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0001', 'f0850d1e9f12f26babce849b90b52eab95b81530aabf802e87f160a395985ba3', '2026-11-09 20:23:05.21031+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0001-nightly-on-use', '319965364d5048237981818039583f6e2d97e2f69553906fb8311b569867d720', '2026-11-09 20:23:05.211569+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0010-tenants', 'dd7f8065d47a8ab3ee5fff7e74787e28bf1a0cf363b70862e855d1ba1c18467e', '2026-11-09 20:23:05.212807+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0010-tenants-lookups', '4103e763719b7766a88ab70bb8a8a23131e020efe47ab24622365fe379a2111a', '2026-11-09 20:23:05.216584+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0010-tenants-swap', 'a2ee8f0e1c1b9821c1006101bfa89afe561055d429a137a6a70b4488f7c207d7', '2026-11-09 20:23:05.216833+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_config_epochs/0001', '03a29556205a6f0e0a80fb7e1b828de610ad20169b342cb80623685a31496477', '2026-11-09 20:23:05.21795+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_config_epochs/0010-tenants', '7c9004c01552ae280da292fa7fc89d3d97f9aeca03cacd2c23c9f739fbbdc0c5', '2026-11-09 20:23:05.219285+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_config_epochs/0010-tenants-lookups', 'a873d761093cc1754f2ee5637f44b634b2ba65705a0df499c622d65ab5cc50b5', '2026-11-09 20:23:05.222917+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_config_epochs/0010-tenants-swap', '89f80c674f59803375710b3d94ea158fc09ece47f2a43cc9ed5c3ebb877a1110', '2026-11-09 20:23:05.223108+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_sandbox_bodies/0001', '49673eb711120ab7e1fb3d0b5d5dd2d9ffccaa59c331e88112d5c82d907c6220', '2026-11-09 20:23:05.224037+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_sandbox_bodies/0010-tenants', '7a1fb3090b47439c9b1d7c4cfec0ddeebee7f77fa18ed78187b92ebd696106f4', '2026-11-09 20:23:05.22525+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_sandbox_bodies/0010-tenants-lookups', '1e6792abfb601591453d1d59ece7cae417b9ef4f3199889848c6bc24add07853', '2026-11-09 20:23:05.229068+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_sandbox_bodies/0010-tenants-swap', 'e84b0977a7c77eaa584c8b1f5d32feca3d11cda09ff2395ab2504a19e900fb49', '2026-11-09 20:23:05.229342+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/0001', '06c668b8a0fe2334046b16835e71facb31ef6324bab697acfd0f2a428cf8babe', '2026-11-09 20:23:05.230394+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/0010-tenants', '2c5d0ca89d9e2da0f3c80013d81ba789f8c088d425c64609b2c76a406e63d060', '2026-11-09 20:23:05.231516+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/0010-tenants-lookups', 'a366b0b4ff19f2f406503066bb9e30f20110395c202eeef8342959a82f191bf3', '2026-11-09 20:23:05.235254+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/0010-tenants-swap', '80519aa3a08358f43d7f13b080c509078f9737335b3fa8d9e36ac356579bcf0b', '2026-11-09 20:23:05.235454+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/lookup-pending-drop', '73b853b6b1f937076c35ccc041a7d0b9677f93078402956b2fe85cb07eb4edcb', '2026-11-09 20:23:05.236456+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/lookup-pending-hash', '2ef7efc86dbe12da3a19fc4b7016155a964bf364b28c907489287456919ff422', '2026-11-09 20:23:05.238109+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/select-pending', '2fc4854407c8b8a0f0fc8d8982508164b03ee36a545beece349c379549e84d84', '2026-11-09 20:23:05.240426+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/stats-pending', 'bc2f52d2abd272e95fc41a0ea3649aa5758bd7dfcbc9de666a3b7d097aa9377c', '2026-11-09 20:23:05.240652+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/triggers/0001-drop-recipient-consent', '690a465b166e66765bd18fc38375020f8b9adbc3d503e384e307d2e02c00c320', '2026-11-09 20:23:05.241434+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/web_ui_state/0001', 'c432e9df04d30e5533c79ae12ec1564541072ce1138af9ea320f08c533a7cac0', '2026-11-09 20:23:05.243414+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/web_ui_state/0010-tenants', 'b6a8e6eceb6c084eff045d1b602a75fb19d0727f0df2cb1f01737f5a1976f7c2', '2026-11-09 20:23:05.244726+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/web_ui_state/0010-tenants-lookups', '5eb4e4588fcd46da50b34579397145228b729a737f7ca66eef470b8ff9c20b9b', '2026-11-09 20:23:05.248539+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/web_ui_state/0010-tenants-swap', '9203f283ab5490e333ab6affdcc2986d67143c87c1f0d8d44e0004eb58083ac7', '2026-11-09 20:23:05.248728+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhook_history/0001', '5d99f7bc000a792e237082339eccb490bf124c0dfe7fb14f816b8978e73ec7b4', '2026-11-09 20:23:05.249882+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhook_history/0010-tenants', '769537c00ff6d4b29fa98bbc7542791cd1d2bcb8a882f501ff757bd00d181455', '2026-11-09 20:23:05.251165+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhook_history/0010-tenants-lookups', '0ee52c5b03473554c622d41de759a91742403ff8aa5d515d1f54b32c9811f481', '2026-11-09 20:23:05.254949+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhook_history/0010-tenants-swap', 'bf17bdd800df70a272012ecc06a17464dbae0b3f01d73cdf58c4cd828448b32d', '2026-11-09 20:23:05.25523+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0001', '95a66510c7e6983e713290d0066264128baa406a19f390af6ba18873e2360c28', '2026-11-09 20:23:05.256204+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0002-disable-rows-orphaned-by-webhook-removal', '5049d35f8e432183fed151377a615e25ec6a97677b7a7ec7da57b155c7425db7', '2026-11-09 20:23:05.256592+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0010-tenants', 'e28cff83b5c1cda50e4c903c3334b17f37f27a526bd027f8dc9fa1051b62bca5', '2026-11-09 20:23:05.25734+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0010-tenants-lookups', 'e030392ecbd0595f702f5254fd622293746e4bc9435ae767af6b58885476aebe', '2026-11-09 20:23:05.261045+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0010-tenants-swap', '648377e84da5abcdfc06e6abf478b322a2bda9e4133457998c8ef3d4d9898639', '2026-11-09 20:23:05.261292+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/lookup-ownerscopeid-drop', '1661691fa2024faa4bc1c713d6ef00b9285d84fa36ed0a6427843dfa6ce22927', '2026-11-09 20:23:05.262403+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/lookup-ownerscopeid-hash', '0f72885639dbc0ea755bc4f42a4edb0fb2fe34ae486bba6b1f68965a5305c539', '2026-11-09 20:23:05.264164+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/select-ownerscopeid', '8a21c4276fc53492b23562c5eb76db6b91527a0acaae648d1e112727dd048c47', '2026-11-09 20:23:05.266522+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/stats-ownerscopeid', '71e358b93e8e66ccb60553c8ad576dc97d11bf2e73e6eab99bb47c42870200d4', '2026-11-09 20:23:05.266719+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webui_model_configs/0001', '37bb44ffc7579effc5c0ea6c47fc8e7a231207c2e123711daaac34b79f379983', '2026-11-09 20:23:05.267474+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webui_model_configs/0010-tenants', '28c07cc437feb93dd7686b75e9990bf770a799c43a89eb759211f793f6f495c8', '2026-11-09 20:23:05.268836+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webui_model_configs/0010-tenants-lookups', 'da287fee2207aa425b5e240c058df9a113fd03aee7ac8d2acd06e3b0d2b42b92', '2026-11-09 20:23:05.272797+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webui_model_configs/0010-tenants-swap', 'a9bc16c9d5f1f224554d1b2f7351d1c1f0339438e3d4b6b6a8a2c31b2650ee2d', '2026-11-09 20:23:05.273027+00');
INSERT INTO public.qm_schema_migrations VALUES ('environments/store/0001', 'f6eb00919601e6c50bca7857a93061761d2bd1a31396ed7cf9373f93c8ffcae7', '2026-11-09 20:23:05.274158+00');
INSERT INTO public.qm_schema_migrations VALUES ('environments/store/0002-tenants', '033b3a8990868e35c29f2d69d456b241f35b72dbd1bffb5fc02fc983e516a482', '2026-11-09 20:23:05.276902+00');
INSERT INTO public.qm_schema_migrations VALUES ('environments/store/0002-tenants-lookups', '0fb3d4c0fe76fad9c90ef1f7fc17d92c97e49b603ea41920cf2f2d856f1c4f57', '2026-11-09 20:23:05.284776+00');
INSERT INTO public.qm_schema_migrations VALUES ('environments/store/0002-tenants-swap', 'b562021582a62e190c3884f6f11845d927c6fd4480a0f83f7e6f0fdf19535bdb', '2026-11-09 20:23:05.285016+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0001', '568d83afca3a8ce6287cbe85ad570612d9bb01ad0a8b7d78aa54e6fdc1dc1b0e', '2026-11-09 20:23:05.287151+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0002', 'fc47df852bd24c895b47e97d407eec54a71db90f407c5731627d82b2c63b5819', '2026-11-09 20:23:05.289722+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0003-tenants', '5ed91a4ee97afcea6d7059b9039914fa1df8926c4ff813c03d6aae510f4a00b2', '2026-11-09 20:23:05.290758+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0003-tenants-lookups', '4286990bd75ff0625d96b72036bbcfd00fcb73835e2e779a2ab63c093983eb84', '2026-11-09 20:23:05.298484+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0003-tenants-swap', '7c47eb6b52afed8336604a738f756db2b1ca920f6f239b842b5582dd1f510406', '2026-11-09 20:23:05.29873+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/uploads/0001', 'f3d699810703e9323f42978510407cd0023c8dc164600a5f5ccd8c339f0841c0', '2026-11-09 20:23:05.300612+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/uploads/0002', 'c9a204a21fc0f2a978dd90bbdb5d72497383c82956fd171da66af62ca8a40b42', '2026-11-09 20:23:05.302664+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/uploads/0003-tenants', '978a5262c5dfc1b06949250d27f00e9254f0e92e20875b1a7e41d21deb4c6145', '2026-11-09 20:23:05.303447+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/uploads/0003-tenants-lookups', '5c1ef125c05ad1b97a9e45005484fe6c64ddc59911a291c44579833bf528b08a', '2026-11-09 20:23:05.30786+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/uploads/0003-tenants-swap', 'bb095b58cec7bfa183c195311352a66cf466ffa77d4ad7f1ac52425c1659ffb1', '2026-11-09 20:23:05.308097+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0000-records-column', '450e71b07659508640f782635a5019fa31b906cc63fdc97e7236d28b0d4c3aea', '2026-11-09 20:23:05.309562+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0001', 'cc560bef4c54ea2007b66eb46bf7258b70c9de98da901348f271c5da38c06597', '2026-11-09 20:23:05.309952+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0002-text-hash', 'c7ca6a779272265e9201ccf0430ec1ca98836701b2eff508b08af22e008aadb5', '2026-11-09 20:23:05.312947+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0003-tenants', '91a2f5096cf5d7cff9e53872b9d2244d36f533da9a94f2ee5f811fc5f89ac8d2', '2026-11-09 20:23:05.314149+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0003-tenants-lookups', 'd773412c2e3cef480a56f69623e6011e89bc19b9c604fdaa63ffe61ac0d75f50', '2026-11-09 20:23:05.318087+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0003-tenants-swap', '56dd56045de6f57e8e05b139d0f364b0b077948545e63676c31eda6643530e52', '2026-11-09 20:23:05.318292+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/vectors/0001-extension', 'f1f590b46100d98de9606d763c3556a8c6e055a277c5f4b3f5dc189fc82a3309', '2026-11-09 20:23:05.319353+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/vectors/0002', '9ac35a0030e6d7d272fc8b0f52416c9d5ccb7e9f8224e166ff01b115aebe6801', '2026-11-09 20:23:05.331782+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/vectors/0003-tenants', 'a1fb1ac1a6619d8f5104934d2d6eeb4302d6dee777a75f8e8176794774f0e063', '2026-11-09 20:23:05.333302+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/vectors/0003-tenants-lookups', '5aa8eb4f96a7e25b276a7b02d22281bad457a18ffb420f06f1ba8634b1f20618', '2026-11-09 20:23:05.338249+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/vectors/0003-tenants-swap', '94a33739b3c96f09ecd5a11d700b30eb7110f53aa12165466506da0d735ebde4', '2026-11-09 20:23:05.33859+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0001', '5ca2d3af76a021c55ec15829f5798347851f3d73df53f36041dc04fbb2253324', '2026-11-09 20:23:05.340082+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0002', '3677d509807832aecda3cf903f22c42bc3d31a6d9c97b4156f981d376f589999', '2026-11-09 20:23:05.342013+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0003', 'd24a770a83eddffda0658e3e650a3c420ffddb6f68c379d5933f720b2e98cb19', '2026-11-09 20:23:05.342387+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0004', '9c17b6f267eb528657ab97b7bf27735d1c8aa5b8eaefdfe9489346839ea89052', '2026-11-09 20:23:05.3428+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0005-tenants', '08a8934a3db5302926512ae3e8fcafd03cf436724a7be1c9ea4639455b08132a', '2026-11-09 20:23:05.343135+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0005-tenants-lookups', 'd691949cd1f2641d2daee308c3ef4dea3fb5c1fa932cc8c5137d18c8159d2273', '2026-11-09 20:23:05.347317+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0005-tenants-swap', 'a73547ded7cb0510e212b66d4e4af5e5c0d2086b2b21ce716e4d2ebd5706837c', '2026-11-09 20:23:05.347518+00');
INSERT INTO public.qm_schema_migrations VALUES ('ratelimit/budget/0001', '0186484b961f396532706137612082ed9c052f476e79b243d7b89897a0ec4880', '2026-11-09 20:23:05.348527+00');
INSERT INTO public.qm_schema_migrations VALUES ('ratelimit/budget/0002-tenants', 'fbe02bf40177a7967ee908bebd99a7cf446d0c016a795e3bf131b142b85d95f4', '2026-11-09 20:23:05.350296+00');
INSERT INTO public.qm_schema_migrations VALUES ('ratelimit/budget/0002-tenants-lookups', '39f85c10fc6c6d2ecb26326c4b68d9e5ec034ddfc1265f9ea074a9143fede91e', '2026-11-09 20:23:05.354215+00');
INSERT INTO public.qm_schema_migrations VALUES ('ratelimit/budget/0002-tenants-swap', 'c3af729132b0fa25a78638bd08a442755a21473871ce465b48762de416e39234', '2026-11-09 20:23:05.354412+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/crons/0001', '1e33169a8550366f1651f4a9be634b8c04293f3cc197cbf7f741c45af798b632', '2026-11-09 20:23:05.355561+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/deploys/0001', '97db7e33f1bd293034b3e1eb24909bb28ac2c31db3c128dc8d378bd18b91929e', '2026-11-09 20:23:05.356977+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/skills/0001', '77217c6a8da2b9714ede4668b3b52497b83399c65bea3b9c9a311e9565d4d5ef', '2026-11-09 20:23:05.357907+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/webhooks/0001', 'afdb2392eed83a8db7402eececbbdaebbc1563444c21616db1998fd330e40881', '2026-11-09 20:23:05.359184+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/activity/0001', '985e4430016c037b986909566aceb68f53870fc50a71158dbaf73c1c5a15c509', '2026-11-09 20:23:05.360128+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/activity/0002-tenants', 'debf8b7a49d43357107e1393a51f14109a38d5d66b5b940439659fea2c254ba2', '2026-11-09 20:23:05.362479+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/activity/0002-tenants-lookups', '895ff68b14a5d3a1d12c351df7ba852b6320f599c8a36e5d808ca184e69c1eaf', '2026-11-09 20:23:05.366679+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/activity/0002-tenants-swap', '83897e9762b678a8f0b55a7c7e1088c2accef9db93e00f9b7bc498c7e462b4a9', '2026-11-09 20:23:05.366933+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0001', 'f94f67b5c878383af0026a0a44b1f252f83585dec0e12b79b9db6e8de841cacf', '2026-11-09 20:23:05.368026+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0002', '5eaf490533f72a518bd27d4846b052532a7715976e2e5b3b3432b16d1416bb59', '2026-11-09 20:23:05.369939+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0003-tenants', '572654f5a3cdb98d21c3ee001bc95a985b00c534a17964b0057889b91bb31d2d', '2026-11-09 20:23:05.370671+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0003-tenants-lookups', '69b7030047079035d2def30453fcd8c7a349d382fea039f0013ec09780b6d1bb', '2026-11-09 20:23:05.377256+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0003-tenants-swap', '193d7fb642b65aa0d16dd6760ce6b24c6eec26a120d1dfc802ce2a00555d76fc', '2026-11-09 20:23:05.377459+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0011-base-schema', '77ca2d1c3ec5253374c0eadbf47d91d53c6d2c3fc7232079b33006bc9233a24e', '2026-11-09 20:23:05.37888+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0012-tenants', 'a7d063bc5d1b00a1a9bd7131bbebf9305e9ff60e8a1e51cfff32c0c6da4b375d', '2026-11-09 20:23:05.383718+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0012-tenants-lookups', '6f5143e98460c4b164aa28ab6b5e2c429803a005fafba6ac641503e5fd31e687', '2026-11-09 20:23:05.394534+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0012-tenants-swap', '1ea89263a9cabdf39ebce593a7d9ba7ea417928c384923121efaade449ea4a1a', '2026-11-09 20:23:05.394818+00');
INSERT INTO public.qm_schema_migrations VALUES ('runtime/0002-drop-harness-choice', '2e7a8523090c84d00b557197f2e3038b5b2fd418e6b3b4b08c10ef0cf596a792', '2026-11-09 20:23:05.396927+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0047-base-schema', '09cc3da1e893709927f3a18d593d543289d9d92dc416c56f426e3a5d69957099', '2026-11-09 20:23:05.398766+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0048-message-search-index', 'f1996db3a8774e9c0b1e7dc35ecc70b2cfb1d64e8923225e40cdfc351a0b9cf4', '2026-11-09 20:23:05.440453+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0049-drop-items-search', '0d987ff91662ce4509dfe4a31b7d3400ae5369ae3e3fbae1a31e30d223483c66', '2026-11-09 20:23:05.440728+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0049-seeded-tenant', '763c5b0f30c70d15ec4cd991c180f1630236dbcad611dc7347324a00a86a5d25', '2026-11-09 20:23:05.442+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0050-tenant-backfill', '73f0b5440a2bccaefe16bbdc2d826e95bcf8da2e8af937c6c911c9f48e75a18e', '2026-11-09 20:23:05.443063+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0051-spend-recovery-index', '4afb2779caa4de04dbd6210f1bf1fda4ae52e6e3158294ce42ef1f9821f89c41', '2026-11-09 20:23:05.444972+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0052-session-facts', 'cc6b8210d1fb814301e48e051fb225e96e67a09827241f78d5ef31b5524d4784', '2026-11-09 20:23:05.445178+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0054-session-facts-copy', '233524866d2259689e40a9d9e95dfdc514981fe8e8dc3f3919293506e382b637', '2026-11-09 20:23:05.447152+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0054-tenant-tables', '2f5d1a5445a510d30e8bf931d897a6d0cb937eb0bdc5295c95f6fdc26fbe80d5', '2026-11-09 20:23:05.447356+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0054-tenant-tables-lookups', '0bd2437aed7c67ec7c3f546d3bcfdb4eef235f96c235c19a96809b7f8eb5afed', '2026-11-09 20:23:05.484046+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0054-tenant-tables-swap', '0f1c53116bc610a39a64133a776d499229f5341a9cd654444feefd31602353a9', '2026-11-09 20:23:05.484301+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0055-participant-membership', '3432fb84aca3eb8b5dcd9856cb8b8151428f5ccf7b1e5bf80fb75045f6841fc0', '2026-11-09 20:23:05.492517+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ack-emoji-pick/0001', 'f810bb939d938048d4852a518c04ee315dc42e415e237a31b35129fe08678228', '2026-11-09 20:23:05.493399+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ack-emoji-pick/0002-tenants', '9f7196ebfea01f5d0f05641cdf741ca9b94fb46ad056173d61d8126d97db9f85', '2026-11-09 20:23:05.49641+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ack-emoji-pick/0002-tenants-lookups', '0724b21796a552ff617fef132278708edd6e34e7f0c256bdab310f95fa54ae2b', '2026-11-09 20:23:05.501359+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ack-emoji-pick/0002-tenants-swap', '5b88215a52c838d4e1ad38ae070b04a1961006dd6a4dd76ec78845441fb7d75a', '2026-11-09 20:23:05.501656+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ambient-judgment/0001', '70c0f2d71fdc4d464b4a9d35fcb078b5efdf4dc4fcf769f8379eaa1afb4ad61e', '2026-11-09 20:23:05.503009+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ambient-judgment/0002-tenants', '6927f1b516f861c21e089527c3d654bd2132a9d5db14167dce994b451a5b5211', '2026-11-09 20:23:05.506059+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ambient-judgment/0002-tenants-lookups', '462081fde0cfdb6938fa013d7dd4b851b31b4ccbffceec6d1beb7361fcd4afd8', '2026-11-09 20:23:05.510374+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ambient-judgment/0002-tenants-swap', 'e4169e14649278917a32fccc7f5504fa3c41325b098bdecd9f13cd6dd41689e2', '2026-11-09 20:23:05.510634+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/channel-policy/0001', '5be6f79d080af7a40c4c28708c906359fab2e5cdb23ffd24823da12186fa19ef', '2026-11-09 20:23:05.511904+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/channel-policy/0002-tenants', 'a24d50c5da7852aa830863b846ea364e881f978ecea93ee9d73404a30a3a307d', '2026-11-09 20:23:05.515795+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/channel-policy/0002-tenants-lookups', '4551eb9c39f5769ed4d29e2ae3169ad7c4e544614f6a2b660eeecd1e4196ee89', '2026-11-09 20:23:05.523819+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/channel-policy/0002-tenants-swap', 'af588563de4839f7c78a92c00669973feabaae788901ae0b8d100f6e023b2cfc', '2026-11-09 20:23:05.524051+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0001', 'd823cafcb1d6fbe0400d4ec7cbf745d768af8d02b492681092b95136b706518d', '2026-11-09 20:23:05.525891+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0002', 'a940914e3f7a04f8508e88b31035c3b4d74438087f716b6d1832f90ed78c9357', '2026-11-09 20:23:05.536221+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0003', 'b3f05a3e976216b758fd8482c603917505c231787c853b46e8c76a7d80377f08', '2026-11-09 20:23:05.537207+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0004', 'e64e42c1db30b3f2fe0cf8de0a274316bba539131c677b8242cb11ab55304eee', '2026-11-09 20:23:05.538813+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0005', '0730c53e72559cdd0eba1830f2e243dd539dabfeceb2702161fc0511dabba8e0', '2026-11-09 20:23:05.539499+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0006', '17e5f4f46573989bf031b3c79a41f191bc614c53e265829bb7bd5a17cad19208', '2026-11-09 20:23:05.540042+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0007', '81eef9a5a6a935a52af7819aa144d2172b31de53e8623f6b6fd554fee8ced127', '2026-11-09 20:23:05.540833+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0008', '0c6b9e3e3a035695ee1b00412a4cb1a806e6ddaa87d4fb3893ad06e0bd1ca74d', '2026-11-09 20:23:05.541466+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0009', '1082a4d18ca1146761ae7ffdca0e3f3b2fbdc66df4efd8702fe40f51878bbcf6', '2026-11-09 20:23:05.547619+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0010-tenants', 'edc5cd642d5a4ea43493841b4929b07a2a54ba17dcb9a4f7276b6687e33993f5', '2026-11-09 20:23:05.547836+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0010-tenants-lookups', '19089b9fa9c15eb60ce7842b7322d136f21792b3632174829a60ee474e1edb8b', '2026-11-09 20:23:05.566893+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0010-tenants-swap', 'b4bf4292c5baf5c40459c1b82fc984da8c0b684b9b2f92a59d06e12f0ac0379a', '2026-11-09 20:23:05.567141+00');
INSERT INTO public.qm_schema_migrations VALUES ('surfaces/0005-retired-origin-sweep', '0fbf5f01f7e35129d4a6544ee3d3b5bacf65458d07bead9115a4c40931769f39', '2026-11-09 20:23:05.570493+00');
INSERT INTO public.qm_schema_migrations VALUES ('teams/0001', '2b8c0d4f17fb526e042960f55feab31d269a33b644872e2c87266be47429a174', '2026-11-09 20:23:05.573522+00');
INSERT INTO public.qm_schema_migrations VALUES ('teams/0002-tenants', 'cec8a1ac3e35cbe06310037aca8b77680a164f05b297d575d71cf3c3d198bf3c', '2026-11-09 20:23:05.577554+00');
INSERT INTO public.qm_schema_migrations VALUES ('teams/0002-tenants-lookups', '17f5c625f4648f50dcd5fcfd9492b2691c57b636394c16f4b9e6f4edbba84671', '2026-11-09 20:23:05.58823+00');
INSERT INTO public.qm_schema_migrations VALUES ('teams/0002-tenants-swap', 'd3db52c4825df29ba337f5cd5c75a20a7288648460d0e0ebe417b481383c8e0e', '2026-11-09 20:23:05.58845+00');


--
-- Data for Name: qm_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_settings VALUES ('upgrade-check', '{}', '2026-11-09 20:23:10.426985+00');


--
-- Data for Name: qm_tenant; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_tenant VALUES ('5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: render_deploy_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.render_deploy_bodies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: render_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.render_sandbox_bodies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: render_sandbox_cleanup; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.render_sandbox_cleanup VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: render_scratch_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.render_scratch_bodies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: retired_tenant_hosts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.retired_tenant_hosts VALUES ('upgrade-check', '2026-11-09 20:23:10.426985+00');


--
-- Data for Name: run_activity; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.run_activity VALUES (1, 'upgrade-check', 1, 1, 'upgrade-check', '{}', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: run_signals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.run_signals VALUES (1, 'upgrade-check', 'upgrade-check', 'upgrade-check', '{}', 1, 1, 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.runs VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 0, 3, 'upgrade-check', 1, 'upgrade-check', 1, 1, 1, 'upgrade-check', 0, 1, 1, 0, 1, 'upgrade-check', 2, 0, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: sandbox_defaults; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sandbox_defaults VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: sandbox_resource_rollout; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sandbox_resource_rollout VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: sandbox_resources; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sandbox_resources VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: sandbox_routing; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sandbox_routing VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: secret_drops; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.secret_drops VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: security_postures; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.security_postures VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: session_goals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_leases; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.session_leases VALUES ('upgrade-check', 'upgrade-check', 1, 'upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: session_llm_requests; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.session_llm_requests VALUES ('upgrade-check', 'upgrade-check', 1, 1, 'upgrade-check', 'upgrade-check', false, 1, 1, 1, 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: session_mailbox; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.session_mailbox VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: session_pins; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.session_pins VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: session_shares; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.session_shares VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: session_spend_days; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.session_spend_days VALUES (1, '{}', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: session_spend_dirty; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.session_spend_dirty VALUES (0, NULL, '67400', '5870d898-0d55-4acc-bfc6-7beb49f91455');
INSERT INTO public.session_spend_dirty VALUES (NULL, 'upgrade-check', '67400', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sessions VALUES ('upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 1, 1, 1, 'upgrade-check', 'upgrade-check', 1, 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', 'upgrade-check', '{}', 1, '{}', '{}', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: sharing_postures; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sharing_postures VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: skill_bundles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.skill_bundles VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: skill_packs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.skill_packs VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.skills VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: slack_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_accounts VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: slack_emoji_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_emoji_catalog VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: slack_installation; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_installation VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: slack_session_status; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_session_status VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: slack_staged_envelopes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_staged_envelopes VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: slack_task_acknowledgements; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.slack_task_acknowledgements VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: smolmachines_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.smolmachines_sandbox_bodies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: soul_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.soul_configs VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: soul_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.soul_history VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: source_auth_replay; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.source_auth_replay VALUES ('upgrade-check', '2026-11-09 20:23:10.426985+00');


--
-- Data for Name: spend_limit_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.spend_limit_configs VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: sprites_initialization; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sprites_initialization VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: suggested_activity_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.suggested_activity_profiles VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: superserve_config_epochs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.superserve_config_epochs VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: superserve_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.superserve_sandbox_bodies VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: swarms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.swarms VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_rooms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.team_rooms VALUES ('upgrade-check', 'upgrade-check', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.teams VALUES ('upgrade-check', 'upgrade-check', false, 'upgrade-check', 1, '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: tenant_hosts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.tenants VALUES ('5870d898-0d55-4acc-bfc6-7beb49f91455', '2026-11-09 20:23:05.443063+00', '{}');


--
-- Data for Name: web_ui_state; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.web_ui_state VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: webhook_history; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.webhook_history VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.webhooks VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Data for Name: webui_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.webui_model_configs VALUES ('upgrade-check', '{}', '5870d898-0d55-4acc-bfc6-7beb49f91455');


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ack_emoji_picks_id_seq', 1, true);


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ambient_judgments_id_seq', 1, true);


--
-- Name: app_page_views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.app_page_views_id_seq', 2, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, true);


--
-- Name: budget_spend_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_spend_id_seq', 1, true);


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.channel_policy_history_id_seq', 1, true);


--
-- Name: credential_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credential_usage_id_seq', 1, true);


--
-- Name: egress_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.egress_events_id_seq', 1, true);


--
-- Name: error_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.error_events_id_seq', 1, true);


--
-- Name: memory_facts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.memory_facts_id_seq', 1, true);


--
-- Name: run_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.run_activity_id_seq', 1, true);


--
-- Name: run_signals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.run_signals_id_seq', 1, true);


--
-- Name: runs_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.runs_seq_seq', 1, true);


--
-- Name: bam bam_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.bam
    ADD CONSTRAINT bam_pkey PRIMARY KEY (id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (name, id);


--
-- Name: job_common job_common_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT job_common_pkey PRIMARY KEY (name, id);


--
-- Name: job_dependency job_dependency_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_dependency
    ADD CONSTRAINT job_dependency_pkey PRIMARY KEY (child_name, child_id, parent_name, parent_id);


--
-- Name: queue queue_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue
    ADD CONSTRAINT queue_pkey PRIMARY KEY (name);


--
-- Name: queue_stats queue_stats_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats
    ADD CONSTRAINT queue_stats_pkey PRIMARY KEY (id, captured_on);


--
-- Name: queue_stats_20261109 queue_stats_20261109_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats_20261109
    ADD CONSTRAINT queue_stats_20261109_pkey PRIMARY KEY (id, captured_on);


--
-- Name: queue_stats_20261110 queue_stats_20261110_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats_20261110
    ADD CONSTRAINT queue_stats_20261110_pkey PRIMARY KEY (id, captured_on);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (name, key);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (event, name);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (version);


--
-- Name: warning warning_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.warning
    ADD CONSTRAINT warning_pkey PRIMARY KEY (id);


--
-- Name: ack_emoji_picks ack_emoji_picks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks
    ADD CONSTRAINT ack_emoji_picks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: ack_emoji ack_emoji_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji
    ADD CONSTRAINT ack_emoji_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: acl_grants acl_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants
    ADD CONSTRAINT acl_grants_pkey PRIMARY KEY (tenant_id, owner_scope_id, path, grantee_scope_id, permission);


--
-- Name: acl_grants_version acl_grants_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants_version
    ADD CONSTRAINT acl_grants_version_pkey PRIMARY KEY (tenant_id, only_row);


--
-- Name: admin_grants admin_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_grants
    ADD CONSTRAINT admin_grants_pkey PRIMARY KEY (tenant_id, principal_id, scope_id, role);


--
-- Name: ambient_cursors ambient_cursors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_cursors
    ADD CONSTRAINT ambient_cursors_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: ambient_judgments ambient_judgments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments
    ADD CONSTRAINT ambient_judgments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: app_page_views app_page_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_page_views
    ADD CONSTRAINT app_page_views_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approval_grant_modes approval_grant_modes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grant_modes
    ADD CONSTRAINT approval_grant_modes_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approval_grants approval_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grants
    ADD CONSTRAINT approval_grants_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: auth_broker_sessions auth_broker_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_broker_sessions
    ADD CONSTRAINT auth_broker_sessions_pkey PRIMARY KEY (tenant_id, token_hash);


--
-- Name: aws_sandbox_bodies aws_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_sandbox_bodies
    ADD CONSTRAINT aws_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: base_model_configs base_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.base_model_configs
    ADD CONSTRAINT base_model_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: blobs blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blobs
    ADD CONSTRAINT blobs_pkey PRIMARY KEY (tenant_id, sha256);


--
-- Name: branding_configs branding_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_configs
    ADD CONSTRAINT branding_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: browse_max_steps_configs browse_max_steps_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_max_steps_configs
    ADD CONSTRAINT browse_max_steps_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: browser_sessions browser_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browser_sessions
    ADD CONSTRAINT browser_sessions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: budget_spend budget_spend_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_spend
    ADD CONSTRAINT budget_spend_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_files channel_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_files
    ADD CONSTRAINT channel_files_pkey PRIMARY KEY (tenant_id, org_id, container, ts, file_id);


--
-- Name: channel_header_pin_flag channel_header_pin_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_header_pin_flag
    ADD CONSTRAINT channel_header_pin_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_messages channel_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_messages
    ADD CONSTRAINT channel_messages_pkey PRIMARY KEY (tenant_id, org_id, container, ts);


--
-- Name: channel_policy_history channel_policy_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history
    ADD CONSTRAINT channel_policy_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_policy channel_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy
    ADD CONSTRAINT channel_policy_pkey PRIMARY KEY (tenant_id, org_id, container);


--
-- Name: channel_state channel_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_state
    ADD CONSTRAINT channel_state_pkey PRIMARY KEY (tenant_id, org_id, container);


--
-- Name: command_policies command_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_policies
    ADD CONSTRAINT command_policies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: composio_returns composio_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composio_returns
    ADD CONSTRAINT composio_returns_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: connector_clients connector_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_clients
    ADD CONSTRAINT connector_clients_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: consent_links consent_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_links
    ADD CONSTRAINT consent_links_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: context_requests context_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.context_requests
    ADD CONSTRAINT context_requests_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: credential_daily_calls credential_daily_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_daily_calls
    ADD CONSTRAINT credential_daily_calls_pkey PRIMARY KEY (tenant_id, slug, day);


--
-- Name: credential_usage credential_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage
    ADD CONSTRAINT credential_usage_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: cron_fires cron_fires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_fires
    ADD CONSTRAINT cron_fires_pkey PRIMARY KEY (tenant_id, cron_id, fire_key);


--
-- Name: crons crons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crons
    ADD CONSTRAINT crons_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: custom_model_providers custom_model_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_model_providers
    ADD CONSTRAINT custom_model_providers_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deactivated_principals deactivated_principals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deactivated_principals
    ADD CONSTRAINT deactivated_principals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: decision_providers decision_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_providers
    ADD CONSTRAINT decision_providers_pkey PRIMARY KEY (tenant_id, provider_id);


--
-- Name: decision_rules decision_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_pkey PRIMARY KEY (tenant_id, rule_id);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deploy_git_repos deploy_git_repos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_git_repos
    ADD CONSTRAINT deploy_git_repos_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_access deployment_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_identity deployment_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_identity
    ADD CONSTRAINT deployment_identity_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_layer deployment_layer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_layer
    ADD CONSTRAINT deployment_layer_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployments deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: directory_channel_members directory_channel_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channel_members
    ADD CONSTRAINT directory_channel_members_pkey PRIMARY KEY (tenant_id, org_id, channel_id, principal_id);


--
-- Name: directory_channels directory_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channels
    ADD CONSTRAINT directory_channels_pkey PRIMARY KEY (tenant_id, org_id, channel_id);


--
-- Name: directory_group_members directory_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_group_members
    ADD CONSTRAINT directory_group_members_pkey PRIMARY KEY (tenant_id, org_id, group_id, principal_id);


--
-- Name: directory_groups directory_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_groups
    ADD CONSTRAINT directory_groups_pkey PRIMARY KEY (tenant_id, org_id, group_id);


--
-- Name: directory_members directory_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_members
    ADD CONSTRAINT directory_members_pkey PRIMARY KEY (tenant_id, org_id, principal_id);


--
-- Name: directory_meta directory_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_meta
    ADD CONSTRAINT directory_meta_pkey PRIMARY KEY (tenant_id, org_id);


--
-- Name: directory_sync directory_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_sync
    ADD CONSTRAINT directory_sync_pkey PRIMARY KEY (tenant_id, org_id);


--
-- Name: do_managed_agents_sandbox_bodies do_managed_agents_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.do_managed_agents_sandbox_bodies
    ADD CONSTRAINT do_managed_agents_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: durable_map_versions durable_map_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.durable_map_versions
    ADD CONSTRAINT durable_map_versions_pkey PRIMARY KEY (tenant_id, tbl);


--
-- Name: e2b_sandbox_bodies e2b_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2b_sandbox_bodies
    ADD CONSTRAINT e2b_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: egress_events egress_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events
    ADD CONSTRAINT egress_events_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: egress_policies egress_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_policies
    ADD CONSTRAINT egress_policies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: environment_attachments environment_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_pkey PRIMARY KEY (tenant_id, scope_id);


--
-- Name: environments environments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: error_events error_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events
    ADD CONSTRAINT error_events_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: external_members external_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_members
    ADD CONSTRAINT external_members_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: external_slack_participants_flag external_slack_participants_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_slack_participants_flag
    ADD CONSTRAINT external_slack_participants_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: file_artifact_deletions file_artifact_deletions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifact_deletions
    ADD CONSTRAINT file_artifact_deletions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: file_artifacts file_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifacts
    ADD CONSTRAINT file_artifacts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: file_uploads file_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_uploads
    ADD CONSTRAINT file_uploads_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: idempotency idempotency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency
    ADD CONSTRAINT idempotency_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: individual_model_auth_flag individual_model_auth_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.individual_model_auth_flag
    ADD CONSTRAINT individual_model_auth_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: interactive_fast_mode_flag interactive_fast_mode_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interactive_fast_mode_flag
    ADD CONSTRAINT interactive_fast_mode_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (tenant_id, session_id, seq);


--
-- Name: keychain_asks keychain_asks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_asks
    ADD CONSTRAINT keychain_asks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: keychain_credentials keychain_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_credentials
    ADD CONSTRAINT keychain_credentials_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: keychain_grants keychain_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_grants
    ADD CONSTRAINT keychain_grants_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: llm_prompt_envelopes llm_prompt_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_prompt_envelopes
    ADD CONSTRAINT llm_prompt_envelopes_pkey PRIMARY KEY (tenant_id, hash);


--
-- Name: loop_ingress_deliveries loop_ingress_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ingress_deliveries
    ADD CONSTRAINT loop_ingress_deliveries_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loop_ingress loop_ingress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ingress
    ADD CONSTRAINT loop_ingress_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loop_items loop_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_items
    ADD CONSTRAINT loop_items_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loop_outputs loop_outputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_outputs
    ADD CONSTRAINT loop_outputs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loop_ship_grants loop_ship_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ship_grants
    ADD CONSTRAINT loop_ship_grants_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loops loops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loops
    ADD CONSTRAINT loops_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: memory_fact_vectors memory_fact_vectors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_fact_vectors
    ADD CONSTRAINT memory_fact_vectors_pkey PRIMARY KEY (tenant_id, scope_id, model, fact_id);


--
-- Name: memory_facts memory_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: memory_tidy_profiles memory_tidy_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_tidy_profiles
    ADD CONSTRAINT memory_tidy_profiles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: modal_sandbox_bodies modal_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modal_sandbox_bodies
    ADD CONSTRAINT modal_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: model_credentials model_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_credentials
    ADD CONSTRAINT model_credentials_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: model_registry model_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: monitors monitors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: oauth_flows oauth_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_flows
    ADD CONSTRAINT oauth_flows_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: org_ambient_flag org_ambient_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_ambient_flag
    ADD CONSTRAINT org_ambient_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: participants participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_pkey PRIMARY KEY (tenant_id, session_id, principal_id);


--
-- Name: principal_links principal_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.principal_links
    ADD CONSTRAINT principal_links_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: process_sessions process_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_sessions
    ADD CONSTRAINT process_sessions_pkey PRIMARY KEY (tenant_id, process_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: qm_schema_migrations qm_schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_schema_migrations
    ADD CONSTRAINT qm_schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: qm_settings qm_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_settings
    ADD CONSTRAINT qm_settings_pkey PRIMARY KEY (key);


--
-- Name: qm_tenant qm_tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_tenant
    ADD CONSTRAINT qm_tenant_pkey PRIMARY KEY (id);


--
-- Name: render_deploy_bodies render_deploy_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_deploy_bodies
    ADD CONSTRAINT render_deploy_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: render_sandbox_bodies render_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_sandbox_bodies
    ADD CONSTRAINT render_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: render_sandbox_cleanup render_sandbox_cleanup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_sandbox_cleanup
    ADD CONSTRAINT render_sandbox_cleanup_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: render_scratch_bodies render_scratch_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_scratch_bodies
    ADD CONSTRAINT render_scratch_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: retired_tenant_hosts retired_tenant_hosts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retired_tenant_hosts
    ADD CONSTRAINT retired_tenant_hosts_pkey PRIMARY KEY (host);


--
-- Name: run_activity run_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity
    ADD CONSTRAINT run_activity_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: run_signals run_signals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals
    ADD CONSTRAINT run_signals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: runs runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_defaults sandbox_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_defaults
    ADD CONSTRAINT sandbox_defaults_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_resource_rollout sandbox_resource_rollout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resource_rollout
    ADD CONSTRAINT sandbox_resource_rollout_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_resources sandbox_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resources
    ADD CONSTRAINT sandbox_resources_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_routing sandbox_routing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_routing
    ADD CONSTRAINT sandbox_routing_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: secret_drops secret_drops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_drops
    ADD CONSTRAINT secret_drops_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: security_postures security_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_postures
    ADD CONSTRAINT security_postures_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_goals session_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_pkey PRIMARY KEY (tenant_id, session_id);


--
-- Name: session_leases session_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_leases
    ADD CONSTRAINT session_leases_pkey PRIMARY KEY (tenant_id, session_id);


--
-- Name: session_llm_requests session_llm_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_llm_requests
    ADD CONSTRAINT session_llm_requests_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_mailbox session_mailbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_mailbox
    ADD CONSTRAINT session_mailbox_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_pins session_pins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_pins
    ADD CONSTRAINT session_pins_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_shares session_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_shares
    ADD CONSTRAINT session_shares_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_spend_days session_spend_days_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_days
    ADD CONSTRAINT session_spend_days_pkey PRIMARY KEY (tenant_id, day);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sharing_postures sharing_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sharing_postures
    ADD CONSTRAINT sharing_postures_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skill_bundles skill_bundles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_bundles
    ADD CONSTRAINT skill_bundles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skill_packs skill_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_packs
    ADD CONSTRAINT skill_packs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_accounts slack_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_accounts
    ADD CONSTRAINT slack_accounts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_emoji_catalog slack_emoji_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_emoji_catalog
    ADD CONSTRAINT slack_emoji_catalog_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_installation slack_installation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_installation
    ADD CONSTRAINT slack_installation_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_session_status slack_session_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_session_status
    ADD CONSTRAINT slack_session_status_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_staged_envelopes slack_staged_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_staged_envelopes
    ADD CONSTRAINT slack_staged_envelopes_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_task_acknowledgements slack_task_acknowledgements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_task_acknowledgements
    ADD CONSTRAINT slack_task_acknowledgements_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: smolmachines_sandbox_bodies smolmachines_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smolmachines_sandbox_bodies
    ADD CONSTRAINT smolmachines_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: soul_configs soul_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_configs
    ADD CONSTRAINT soul_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: soul_history soul_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_history
    ADD CONSTRAINT soul_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: source_auth_replay source_auth_replay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_auth_replay
    ADD CONSTRAINT source_auth_replay_pkey PRIMARY KEY (event_id);


--
-- Name: spend_limit_configs spend_limit_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend_limit_configs
    ADD CONSTRAINT spend_limit_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sprites_initialization sprites_initialization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprites_initialization
    ADD CONSTRAINT sprites_initialization_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: suggested_activity_profiles suggested_activity_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggested_activity_profiles
    ADD CONSTRAINT suggested_activity_profiles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: superserve_config_epochs superserve_config_epochs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_config_epochs
    ADD CONSTRAINT superserve_config_epochs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: superserve_sandbox_bodies superserve_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_sandbox_bodies
    ADD CONSTRAINT superserve_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: swarms swarms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swarms
    ADD CONSTRAINT swarms_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (tenant_id, team_id, principal_id);


--
-- Name: team_rooms team_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_pkey PRIMARY KEY (tenant_id, team_id, scope_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (tenant_id, team_id);


--
-- Name: tenant_hosts tenant_hosts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_hosts
    ADD CONSTRAINT tenant_hosts_pkey PRIMARY KEY (host);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: web_ui_state web_ui_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_ui_state
    ADD CONSTRAINT web_ui_state_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webhook_history webhook_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_history
    ADD CONSTRAINT webhook_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webui_model_configs webui_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webui_model_configs
    ADD CONSTRAINT webui_model_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: job_common_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i1 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: job_common_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i2 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: job_common_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i3 ON pgboss.job_common USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: job_common_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i4 ON pgboss.job_common USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: job_common_i5; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i5 ON pgboss.job_common USING btree (name, start_after) WHERE ((state < 'active'::pgboss.job_state) AND (NOT blocked));


--
-- Name: job_common_i6; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i6 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'exclusive'::text));


--
-- Name: job_common_i7; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i7 ON pgboss.job_common USING btree (name, group_id) WHERE ((state = 'active'::pgboss.job_state) AND (group_id IS NOT NULL));


--
-- Name: job_common_i8; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i8 ON pgboss.job_common USING btree (name, singleton_key) WHERE ((state = ANY (ARRAY['active'::pgboss.job_state, 'retry'::pgboss.job_state, 'failed'::pgboss.job_state])) AND (policy = 'key_strict_fifo'::text));


--
-- Name: job_common_i9; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i9 ON pgboss.job_common USING btree (name, id) WHERE (blocking AND (state = 'completed'::pgboss.job_state));


--
-- Name: job_dep_parent_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_dep_parent_idx ON pgboss.job_dependency USING btree (parent_name, parent_id);


--
-- Name: queue_stats_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_i1 ON ONLY pgboss.queue_stats USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: queue_stats_20261109_name_captured_on_deferred_count_queued_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_20261109_name_captured_on_deferred_count_queued_idx ON pgboss.queue_stats_20261109 USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: queue_stats_20261110_name_captured_on_deferred_count_queued_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_20261110_name_captured_on_deferred_count_queued_idx ON pgboss.queue_stats_20261110 USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: warning_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX warning_i1 ON pgboss.warning USING btree (created_on DESC);


--
-- Name: ack_emoji_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_id_lookup ON public.ack_emoji USING btree (id);


--
-- Name: ack_emoji_picks_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_key_lookup ON public.ack_emoji_picks USING btree (id);


--
-- Name: ack_emoji_picks_org_channel_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_channel_created ON public.ack_emoji_picks USING btree (org_id, channel, created_at DESC);


--
-- Name: ack_emoji_picks_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_created ON public.ack_emoji_picks USING btree (org_id, created_at DESC, id DESC);


--
-- Name: ack_emoji_picks_org_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_outcome ON public.ack_emoji_picks USING btree (org_id, outcome);


--
-- Name: acl_grants_by_grantee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX acl_grants_by_grantee ON public.acl_grants USING btree (grantee_scope_id, path text_pattern_ops);


--
-- Name: acl_grants_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX acl_grants_key_lookup ON public.acl_grants USING btree (owner_scope_id, path, grantee_scope_id, permission);


--
-- Name: acl_grants_version_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX acl_grants_version_key_lookup ON public.acl_grants_version USING btree (only_row);


--
-- Name: admin_grants_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_grants_key_lookup ON public.admin_grants USING btree (principal_id, scope_id, role);


--
-- Name: ambient_cursors_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_cursors_id_lookup ON public.ambient_cursors USING btree (id);


--
-- Name: ambient_judgments_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_key_lookup ON public.ambient_judgments USING btree (id);


--
-- Name: ambient_judgments_org_container_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_container_created ON public.ambient_judgments USING btree (org_id, container, created_at DESC);


--
-- Name: ambient_judgments_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_created ON public.ambient_judgments USING btree (org_id, created_at DESC, id DESC);


--
-- Name: ambient_judgments_org_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_decision ON public.ambient_judgments USING btree (org_id, decision);


--
-- Name: app_page_views_by_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX app_page_views_by_at ON public.app_page_views USING btree (at);


--
-- Name: app_page_views_by_deployment_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX app_page_views_by_deployment_at ON public.app_page_views USING btree (deployment_id, at DESC);


--
-- Name: app_page_views_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX app_page_views_key_lookup ON public.app_page_views USING btree (id);


--
-- Name: approval_grant_modes_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_grant_modes_id_lookup ON public.approval_grant_modes USING btree (id);


--
-- Name: approval_grants_actorid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_grants_actorid_fold ON public.approval_grants USING hash (lower(("json" ->> 'actorId'::text)));


--
-- Name: approval_grants_actorid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_grants_actorid_unicode ON public.approval_grants USING btree (id) WHERE (("json" ->> 'actorId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: approval_grants_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_grants_id_lookup ON public.approval_grants USING btree (id);


--
-- Name: approvals_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_id_lookup ON public.approvals USING btree (id);


--
-- Name: approvals_sessionid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_sessionid_fold ON public.approvals USING hash (lower(("json" ->> 'sessionId'::text)));


--
-- Name: approvals_sessionid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_sessionid_unicode ON public.approvals USING btree (id) WHERE (("json" ->> 'sessionId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: audit_log_by_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_action ON public.audit_log USING btree (action, at DESC);


--
-- Name: audit_log_by_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_at ON public.audit_log USING btree (at DESC);


--
-- Name: audit_log_by_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX audit_log_by_idempotency_key ON public.audit_log USING btree (tenant_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: audit_log_by_idempotency_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_idempotency_key_lookup ON public.audit_log USING btree (idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: audit_log_by_scope_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_scope_at ON public.audit_log USING btree (scope_label, at DESC);


--
-- Name: audit_log_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_key_lookup ON public.audit_log USING btree (id);


--
-- Name: auth_broker_sessions_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_email ON public.auth_broker_sessions USING btree (email);


--
-- Name: auth_broker_sessions_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_expiry ON public.auth_broker_sessions USING btree (expires_at);


--
-- Name: auth_broker_sessions_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_key_lookup ON public.auth_broker_sessions USING btree (token_hash);


--
-- Name: aws_sandbox_bodies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aws_sandbox_bodies_id_lookup ON public.aws_sandbox_bodies USING btree (id);


--
-- Name: base_model_configs_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX base_model_configs_id_lookup ON public.base_model_configs USING btree (id);


--
-- Name: branding_configs_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX branding_configs_id_lookup ON public.branding_configs USING btree (id);


--
-- Name: browse_max_steps_configs_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX browse_max_steps_configs_id_lookup ON public.browse_max_steps_configs USING btree (id);


--
-- Name: browser_sessions_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX browser_sessions_id_lookup ON public.browser_sessions USING btree (id);


--
-- Name: budget_spend_by_principal_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_spend_by_principal_at ON public.budget_spend USING btree (principal_id, at);


--
-- Name: budget_spend_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_spend_key_lookup ON public.budget_spend USING btree (id);


--
-- Name: channel_files_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_files_key_lookup ON public.channel_files USING btree (org_id, container, ts, file_id);


--
-- Name: channel_files_surface_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX channel_files_surface_key ON public.channel_files USING btree (tenant_id, org_id, surface, account, container, ts, file_id);


--
-- Name: channel_files_surface_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_files_surface_key_lookup ON public.channel_files USING btree (org_id, surface, account, container, ts, file_id);


--
-- Name: channel_header_pin_flag_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_header_pin_flag_id_lookup ON public.channel_header_pin_flag USING btree (id);


--
-- Name: channel_messages_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_by_container ON public.channel_messages USING btree (org_id, container, ts);


--
-- Name: channel_messages_by_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_by_sub ON public.channel_messages USING btree (org_id, container, sub, ts);


--
-- Name: channel_messages_deleted_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_deleted_by_container ON public.channel_messages USING btree (org_id, container, deleted_at) WHERE (deleted_at > 0);


--
-- Name: channel_messages_edited_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_edited_by_container ON public.channel_messages USING btree (org_id, container, edited_at) WHERE (edited_at > 0);


--
-- Name: channel_messages_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_key_lookup ON public.channel_messages USING btree (org_id, container, ts);


--
-- Name: channel_messages_live_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_live_by_container ON public.channel_messages USING btree (org_id, container) WHERE (deleted = false);


--
-- Name: channel_messages_surface_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX channel_messages_surface_key ON public.channel_messages USING btree (tenant_id, org_id, surface, account, container, ts);


--
-- Name: channel_messages_surface_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_surface_key_lookup ON public.channel_messages USING btree (org_id, surface, account, container, ts);


--
-- Name: channel_messages_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_tsv ON public.channel_messages USING gin (tsv);


--
-- Name: channel_policy_history_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_policy_history_container ON public.channel_policy_history USING btree (org_id, container, id DESC);


--
-- Name: channel_policy_history_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_policy_history_key_lookup ON public.channel_policy_history USING btree (id);


--
-- Name: channel_policy_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_policy_key_lookup ON public.channel_policy USING btree (org_id, container);


--
-- Name: channel_state_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_state_key_lookup ON public.channel_state USING btree (org_id, container);


--
-- Name: channel_state_surface_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX channel_state_surface_key ON public.channel_state USING btree (tenant_id, org_id, surface, account, container);


--
-- Name: channel_state_surface_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_state_surface_key_lookup ON public.channel_state USING btree (org_id, surface, account, container);


--
-- Name: command_policies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX command_policies_id_lookup ON public.command_policies USING btree (id);


--
-- Name: composio_returns_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX composio_returns_id_lookup ON public.composio_returns USING btree (id);


--
-- Name: connector_clients_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX connector_clients_id_lookup ON public.connector_clients USING btree (id);


--
-- Name: consent_links_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consent_links_id_lookup ON public.consent_links USING btree (id);


--
-- Name: context_requests_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX context_requests_id_lookup ON public.context_requests USING btree (id);


--
-- Name: credential_daily_calls_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_daily_calls_key_lookup ON public.credential_daily_calls USING btree (slug, day);


--
-- Name: credential_usage_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_scope_ts ON public.credential_usage USING btree (scope_label, ts DESC);


--
-- Name: credential_usage_by_slug_ts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_slug_ts_id ON public.credential_usage USING btree (slug, ts DESC, id DESC);


--
-- Name: credential_usage_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_ts ON public.credential_usage USING btree (ts DESC);


--
-- Name: credential_usage_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_key_lookup ON public.credential_usage USING btree (id);


--
-- Name: cron_fires_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cron_fires_key_lookup ON public.cron_fires USING btree (cron_id, fire_key);


--
-- Name: crons_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_id_lookup ON public.crons USING btree (id);


--
-- Name: crons_ownerscopeid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_ownerscopeid_fold ON public.crons USING hash (lower(("json" ->> 'ownerScopeId'::text)));


--
-- Name: crons_ownerscopeid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_ownerscopeid_unicode ON public.crons USING btree (id) WHERE (("json" ->> 'ownerScopeId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: crons_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_resource_search_gin ON public.crons USING gin (to_tsvector('simple'::regconfig, ((((COALESCE(("json" ->> 'title'::text), ''::text) || ' '::text) || COALESCE(("json" ->> 'action'::text), ''::text)) || ' '::text) || COALESCE(("json" ->> 'message'::text), ''::text))));


--
-- Name: custom_model_providers_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX custom_model_providers_id_lookup ON public.custom_model_providers USING btree (id);


--
-- Name: deactivated_principals_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deactivated_principals_id_lookup ON public.deactivated_principals USING btree (id);


--
-- Name: decision_providers_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX decision_providers_key_lookup ON public.decision_providers USING btree (provider_id);


--
-- Name: decision_rules_hook; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX decision_rules_hook ON public.decision_rules USING btree (hook) WHERE (mode <> 'off'::text);


--
-- Name: decision_rules_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX decision_rules_key_lookup ON public.decision_rules USING btree (rule_id);


--
-- Name: deliveries_idempotency_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX deliveries_idempotency_key_key ON public.deliveries USING btree (tenant_id, idempotency_key);


--
-- Name: deliveries_idempotency_key_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deliveries_idempotency_key_key_lookup ON public.deliveries USING btree (idempotency_key);


--
-- Name: deliveries_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deliveries_key_lookup ON public.deliveries USING btree (id);


--
-- Name: deploy_git_repos_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deploy_git_repos_id_lookup ON public.deploy_git_repos USING btree (id);


--
-- Name: deployment_access_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deployment_access_key_lookup ON public.deployment_access USING btree (id);


--
-- Name: deployment_identity_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deployment_identity_id_lookup ON public.deployment_identity USING btree (id);


--
-- Name: deployment_layer_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deployment_layer_id_lookup ON public.deployment_layer USING btree (id);


--
-- Name: deployments_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deployments_id_lookup ON public.deployments USING btree (id);


--
-- Name: deployments_name_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deployments_name_lookup ON public.deployments USING btree ((("json" ->> 'name'::text))) WHERE (("json" ->> 'name'::text) IS NOT NULL);


--
-- Name: deployments_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX deployments_name_unique ON public.deployments USING btree (tenant_id, (("json" ->> 'name'::text))) WHERE (("json" ->> 'name'::text) IS NOT NULL);


--
-- Name: deployments_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deployments_resource_search_gin ON public.deployments USING gin (to_tsvector('simple'::regconfig, ((COALESCE(("json" ->> 'displayName'::text), ("json" ->> 'name'::text), ''::text) || ' '::text) || COALESCE(("json" ->> 'name'::text), ''::text))));


--
-- Name: directory_channel_members_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channel_members_key_lookup ON public.directory_channel_members USING btree (org_id, channel_id, principal_id);


--
-- Name: directory_channels_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_key_lookup ON public.directory_channels USING btree (org_id, channel_id);


--
-- Name: directory_channels_lower_cid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_lower_cid ON public.directory_channels USING btree (org_id, lower(channel_id));


--
-- Name: directory_channels_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_name ON public.directory_channels USING btree (org_id, name_lc);


--
-- Name: directory_group_members_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_group_members_key_lookup ON public.directory_group_members USING btree (org_id, group_id, principal_id);


--
-- Name: directory_group_members_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_group_members_principal ON public.directory_group_members USING btree (org_id, principal_id, group_id);


--
-- Name: directory_groups_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_groups_key_lookup ON public.directory_groups USING btree (org_id, group_id);


--
-- Name: directory_members_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_key_lookup ON public.directory_members USING btree (org_id, principal_id);


--
-- Name: directory_members_lower_pid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_lower_pid ON public.directory_members USING btree (org_id, lower(principal_id));


--
-- Name: directory_members_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_name ON public.directory_members USING btree (org_id, display_name_lc);


--
-- Name: directory_meta_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_meta_key_lookup ON public.directory_meta USING btree (org_id);


--
-- Name: directory_sync_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_sync_key_lookup ON public.directory_sync USING btree (org_id);


--
-- Name: do_managed_agents_sandbox_bodies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX do_managed_agents_sandbox_bodies_id_lookup ON public.do_managed_agents_sandbox_bodies USING btree (id);


--
-- Name: e2b_sandbox_bodies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX e2b_sandbox_bodies_id_lookup ON public.e2b_sandbox_bodies USING btree (id);


--
-- Name: egress_events_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_by_scope_ts ON public.egress_events USING btree (scope_label, ts DESC);


--
-- Name: egress_events_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_by_ts ON public.egress_events USING btree (ts DESC);


--
-- Name: egress_events_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_key_lookup ON public.egress_events USING btree (id);


--
-- Name: egress_policies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_policies_id_lookup ON public.egress_policies USING btree (id);


--
-- Name: environment_attachments_by_env; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_attachments_by_env ON public.environment_attachments USING btree (environment_id);


--
-- Name: environment_attachments_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_attachments_key_lookup ON public.environment_attachments USING btree (scope_id);


--
-- Name: environments_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environments_key_lookup ON public.environments USING btree (id);


--
-- Name: error_events_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_scope_ts ON public.error_events USING btree (scope_label, ts DESC);


--
-- Name: error_events_by_session_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_session_ts ON public.error_events USING btree (session_id, ts DESC);


--
-- Name: error_events_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_ts ON public.error_events USING btree (ts DESC);


--
-- Name: error_events_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_key_lookup ON public.error_events USING btree (id);


--
-- Name: external_members_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX external_members_id_lookup ON public.external_members USING btree (id);


--
-- Name: external_slack_participants_flag_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX external_slack_participants_flag_id_lookup ON public.external_slack_participants_flag USING btree (id);


--
-- Name: feature_flags_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feature_flags_id_lookup ON public.feature_flags USING btree (id);


--
-- Name: file_artifact_deletions_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifact_deletions_key_lookup ON public.file_artifact_deletions USING btree (id);


--
-- Name: file_artifacts_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_key_lookup ON public.file_artifacts USING btree (id);


--
-- Name: file_artifacts_owner_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_owner_created ON public.file_artifacts USING btree (owner_scope_id, created_at DESC, id DESC);


--
-- Name: file_artifacts_owner_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_owner_path ON public.file_artifacts USING btree (owner_scope_id, path);


--
-- Name: file_artifacts_scope_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_scope_created ON public.file_artifacts USING btree (created_in_scope, created_at DESC, id DESC) WHERE (enabled = true);


--
-- Name: file_uploads_actor_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_uploads_actor_state ON public.file_uploads USING btree (actor_id, state);


--
-- Name: file_uploads_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_uploads_expiry ON public.file_uploads USING btree (expires_at) WHERE (state <> ALL (ARRAY['complete'::text, 'aborted'::text]));


--
-- Name: file_uploads_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_uploads_key_lookup ON public.file_uploads USING btree (id);


--
-- Name: file_uploads_retry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_uploads_retry ON public.file_uploads USING btree (next_attempt_at, expires_at) WHERE (state <> ALL (ARRAY['complete'::text, 'aborted'::text, 'failed'::text]));


--
-- Name: idempotency_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idempotency_id_lookup ON public.idempotency USING btree (id);


--
-- Name: idx_cron_fires_cron_fired_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cron_fires_cron_fired_at ON public.cron_fires USING btree (cron_id, fired_at DESC);


--
-- Name: idx_cron_fires_thread_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cron_fires_thread_ref ON public.cron_fires USING btree (thread_ref);


--
-- Name: idx_deliveries_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_pending ON public.deliveries USING btree (((destination ->> 'type'::text)), created_at) WHERE (delivered_at IS NULL);


--
-- Name: idx_deliveries_pending_live; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_pending_live ON public.deliveries USING btree (((destination ->> 'type'::text)), created_at) WHERE ((delivered_at IS NULL) AND (expired_at IS NULL));


--
-- Name: idx_deliveries_recipient_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_recipient_thread ON public.deliveries USING btree (recipient_thread_ref, created_at) WHERE (recipient_thread_ref IS NOT NULL);


--
-- Name: idx_deliveries_shadow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_shadow ON public.deliveries USING btree (created_at) WHERE (shadow AND (delivered_at IS NULL));


--
-- Name: idx_deliveries_source_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_source_session ON public.deliveries USING btree (((provenance ->> 'sourceSessionId'::text)), created_at) WHERE (provenance IS NOT NULL);


--
-- Name: idx_deliveries_source_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_source_thread ON public.deliveries USING btree (((provenance ->> 'sourceThreadRef'::text)), created_at) WHERE (provenance IS NOT NULL);


--
-- Name: idx_proc_scope_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proc_scope_status ON public.process_sessions USING btree (scope_id, status);


--
-- Name: idx_run_activity_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_activity_created ON public.run_activity USING btree (created_at);


--
-- Name: idx_run_activity_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_activity_run ON public.run_activity USING btree (run_id, id);


--
-- Name: idx_run_signals_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_signals_pending ON public.run_signals USING btree (run_id) WHERE (consumed_at IS NULL);


--
-- Name: idx_runs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_created ON public.runs USING btree (created_at DESC);


--
-- Name: idx_runs_one_running_per_session; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_runs_one_running_per_session ON public.runs USING btree (tenant_id, session_id) WHERE (status = 'running'::text);


--
-- Name: idx_runs_one_running_per_session_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_one_running_per_session_lookup ON public.runs USING btree (session_id) WHERE (status = 'running'::text);


--
-- Name: idx_runs_pending_child_returns; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_pending_child_returns ON public.runs USING btree (id) WHERE ((status = ANY (ARRAY['done'::text, 'failed'::text])) AND (returned_at IS NULL) AND (session_id ~~ 'agent:main:subagent:%'::text));


--
-- Name: idx_runs_pending_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_pending_priority ON public.runs USING btree (claim_priority, created_at, seq) WHERE (status = 'pending'::text);


--
-- Name: idx_runs_session_active_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_active_created ON public.runs USING btree (session_id, created_at DESC) WHERE (status = ANY (ARRAY['pending'::text, 'running'::text]));


--
-- Name: idx_runs_session_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_created_seq ON public.runs USING btree (session_id, created_at DESC, seq DESC);


--
-- Name: idx_runs_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created ON public.runs USING btree (status, created_at);


--
-- Name: idx_runs_status_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created_seq ON public.runs USING btree (status, created_at, seq);


--
-- Name: idx_runs_terminal_finished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_terminal_finished ON public.runs USING btree (finished_at, id) WHERE (status = ANY (ARRAY['done'::text, 'failed'::text]));


--
-- Name: idx_sessions_parent_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_parent_session_id ON public.sessions USING btree (parent_session_id) WHERE (parent_session_id IS NOT NULL);


--
-- Name: individual_model_auth_flag_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX individual_model_auth_flag_id_lookup ON public.individual_model_auth_flag USING btree (id);


--
-- Name: interactive_fast_mode_flag_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interactive_fast_mode_flag_id_lookup ON public.interactive_fast_mode_flag USING btree (id);


--
-- Name: items_by_elicit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_elicit ON public.items USING btree (tenant_id, session_id, elicit_id) WHERE (elicit_id IS NOT NULL);


--
-- Name: items_by_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_external_id ON public.items USING btree (tenant_id, session_id, external_id) WHERE (external_id IS NOT NULL);


--
-- Name: items_by_turn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_turn ON public.items USING btree (tenant_id, turn_id, seq) WHERE (turn_id IS NOT NULL);


--
-- Name: items_message_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_message_search ON public.items USING gin (tenant_id, search) WHERE ((kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'AgentMessage'::public.item_kind])) AND (variant IS DISTINCT FROM 'files_delivered'::text) AND (text IS NOT NULL));


--
-- Name: items_one_call_per_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX items_one_call_per_kind ON public.items USING btree (tenant_id, session_id, kind, md5(call_id)) WHERE (call_id IS NOT NULL);


--
-- Name: items_session_kind_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_session_kind_created ON public.items USING btree (tenant_id, session_id, kind, created_at);


--
-- Name: keychain_asks_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_asks_id_lookup ON public.keychain_asks USING btree (id);


--
-- Name: keychain_credentials_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_credentials_id_lookup ON public.keychain_credentials USING btree (id);


--
-- Name: keychain_credentials_ownerid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_credentials_ownerid_fold ON public.keychain_credentials USING hash (lower(("json" ->> 'ownerId'::text)));


--
-- Name: keychain_credentials_ownerid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_credentials_ownerid_unicode ON public.keychain_credentials USING btree (id) WHERE (("json" ->> 'ownerId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: keychain_grants_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_id_lookup ON public.keychain_grants USING btree (id);


--
-- Name: keychain_grants_ownerid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_ownerid_fold ON public.keychain_grants USING hash (lower(("json" ->> 'ownerId'::text)));


--
-- Name: keychain_grants_ownerid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_ownerid_unicode ON public.keychain_grants USING btree (id) WHERE (("json" ->> 'ownerId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: llm_prompt_envelopes_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX llm_prompt_envelopes_created_at ON public.llm_prompt_envelopes USING btree (created_at);


--
-- Name: llm_prompt_envelopes_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX llm_prompt_envelopes_key_lookup ON public.llm_prompt_envelopes USING btree (hash);


--
-- Name: loop_ingress_deliveries_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_deliveries_id_lookup ON public.loop_ingress_deliveries USING btree (id);


--
-- Name: loop_ingress_deliveries_queuekey_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_deliveries_queuekey_fold ON public.loop_ingress_deliveries USING hash (lower(("json" ->> 'queueKey'::text)));


--
-- Name: loop_ingress_deliveries_queuekey_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_deliveries_queuekey_unicode ON public.loop_ingress_deliveries USING btree (id) WHERE (("json" ->> 'queueKey'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: loop_ingress_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_id_lookup ON public.loop_ingress USING btree (id);


--
-- Name: loop_ingress_loopid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_loopid_fold ON public.loop_ingress USING hash (lower(("json" ->> 'loopId'::text)));


--
-- Name: loop_ingress_loopid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ingress_loopid_unicode ON public.loop_ingress USING btree (id) WHERE (("json" ->> 'loopId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: loop_items_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_items_id_lookup ON public.loop_items USING btree (id);


--
-- Name: loop_items_loopid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_items_loopid_fold ON public.loop_items USING hash (lower(("json" ->> 'loopId'::text)));


--
-- Name: loop_items_loopid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_items_loopid_unicode ON public.loop_items USING btree (id) WHERE (("json" ->> 'loopId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: loop_outputs_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_outputs_id_lookup ON public.loop_outputs USING btree (id);


--
-- Name: loop_outputs_itemid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_outputs_itemid_fold ON public.loop_outputs USING hash (lower(("json" ->> 'itemId'::text)));


--
-- Name: loop_outputs_itemid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_outputs_itemid_unicode ON public.loop_outputs USING btree (id) WHERE (("json" ->> 'itemId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: loop_ship_grants_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loop_ship_grants_id_lookup ON public.loop_ship_grants USING btree (id);


--
-- Name: loops_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX loops_id_lookup ON public.loops USING btree (id);


--
-- Name: mcp_servers_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mcp_servers_id_lookup ON public.mcp_servers USING btree (id);


--
-- Name: memory_fact_vectors_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX memory_fact_vectors_key_lookup ON public.memory_fact_vectors USING btree (scope_id, model, fact_id);


--
-- Name: memory_facts_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX memory_facts_key_lookup ON public.memory_facts USING btree (id);


--
-- Name: memory_facts_live; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX memory_facts_live ON public.memory_facts USING btree (scope_id, id) WHERE (deleted_at IS NULL);


--
-- Name: memory_tidy_profiles_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX memory_tidy_profiles_id_lookup ON public.memory_tidy_profiles USING btree (id);


--
-- Name: modal_sandbox_bodies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX modal_sandbox_bodies_id_lookup ON public.modal_sandbox_bodies USING btree (id);


--
-- Name: model_credentials_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_credentials_id_lookup ON public.model_credentials USING btree (id);


--
-- Name: model_registry_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_registry_id_lookup ON public.model_registry USING btree (id);


--
-- Name: monitors_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX monitors_id_lookup ON public.monitors USING btree (id);


--
-- Name: monitors_ownerscopeid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX monitors_ownerscopeid_fold ON public.monitors USING hash (lower(("json" ->> 'ownerScopeId'::text)));


--
-- Name: monitors_ownerscopeid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX monitors_ownerscopeid_unicode ON public.monitors USING btree (id) WHERE (("json" ->> 'ownerScopeId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: oauth_flows_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX oauth_flows_id_lookup ON public.oauth_flows USING btree (id);


--
-- Name: org_ambient_flag_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX org_ambient_flag_id_lookup ON public.org_ambient_flag USING btree (id);


--
-- Name: participants_by_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX participants_by_principal ON public.participants USING btree (principal_id, session_id);


--
-- Name: participants_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX participants_key_lookup ON public.participants USING btree (session_id, principal_id);


--
-- Name: principal_links_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX principal_links_id_lookup ON public.principal_links USING btree (id);


--
-- Name: process_sessions_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX process_sessions_key_lookup ON public.process_sessions USING btree (process_id);


--
-- Name: projects_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_id_lookup ON public.projects USING btree (id);


--
-- Name: qm_tenant_singleton; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX qm_tenant_singleton ON public.qm_tenant USING btree ((true));


--
-- Name: render_deploy_bodies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX render_deploy_bodies_id_lookup ON public.render_deploy_bodies USING btree (id);


--
-- Name: render_sandbox_bodies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX render_sandbox_bodies_id_lookup ON public.render_sandbox_bodies USING btree (id);


--
-- Name: render_sandbox_cleanup_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX render_sandbox_cleanup_id_lookup ON public.render_sandbox_cleanup USING btree (id);


--
-- Name: render_scratch_bodies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX render_scratch_bodies_id_lookup ON public.render_scratch_bodies USING btree (id);


--
-- Name: run_activity_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX run_activity_key_lookup ON public.run_activity USING btree (id);


--
-- Name: run_signals_by_dedupe_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX run_signals_by_dedupe_key ON public.run_signals USING btree (tenant_id, dedupe_key) WHERE (dedupe_key IS NOT NULL);


--
-- Name: run_signals_by_dedupe_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX run_signals_by_dedupe_key_lookup ON public.run_signals USING btree (dedupe_key) WHERE (dedupe_key IS NOT NULL);


--
-- Name: run_signals_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX run_signals_key_lookup ON public.run_signals USING btree (id);


--
-- Name: runs_idempotency_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX runs_idempotency_key_key ON public.runs USING btree (tenant_id, idempotency_key);


--
-- Name: runs_idempotency_key_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX runs_idempotency_key_key_lookup ON public.runs USING btree (idempotency_key);


--
-- Name: runs_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX runs_key_lookup ON public.runs USING btree (id);


--
-- Name: sandbox_defaults_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sandbox_defaults_id_lookup ON public.sandbox_defaults USING btree (id);


--
-- Name: sandbox_resource_rollout_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sandbox_resource_rollout_id_lookup ON public.sandbox_resource_rollout USING btree (id);


--
-- Name: sandbox_resources_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sandbox_resources_id_lookup ON public.sandbox_resources USING btree (id);


--
-- Name: sandbox_routing_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sandbox_routing_id_lookup ON public.sandbox_routing USING btree (id);


--
-- Name: secret_drops_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX secret_drops_id_lookup ON public.secret_drops USING btree (id);


--
-- Name: security_postures_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX security_postures_id_lookup ON public.security_postures USING btree (id);


--
-- Name: session_goals_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_goals_key_lookup ON public.session_goals USING btree (session_id);


--
-- Name: session_leases_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_leases_key_lookup ON public.session_leases USING btree (session_id);


--
-- Name: session_llm_requests_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_by_session ON public.session_llm_requests USING btree (session_id, created_at, step);


--
-- Name: session_llm_requests_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_created_at ON public.session_llm_requests USING btree (created_at);


--
-- Name: session_llm_requests_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_key_lookup ON public.session_llm_requests USING btree (id);


--
-- Name: session_llm_requests_screens; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_screens ON public.session_llm_requests USING btree (created_at DESC) WHERE (step = '-1'::integer);


--
-- Name: session_llm_requests_session_spend_recovery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_session_spend_recovery ON public.session_llm_requests USING btree (session_id, created_at) WHERE (usage_json IS NOT NULL);


--
-- Name: session_llm_requests_spend; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_spend ON public.session_llm_requests USING btree (created_at, (((public.spend_usage_json(usage_json) ->> 'costUsd'::text))::double precision), (((public.spend_usage_json(usage_json) ->> 'input'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'output'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'cacheRead'::text))::bigint), (((public.spend_usage_json(usage_json) ->> 'cacheWrite'::text))::bigint)) INCLUDE (session_id, model, usage_json) WHERE ((usage_json IS NOT NULL) AND ((public.spend_usage_json(usage_json) IS NOT NULL) AND (((octet_length(session_id) + octet_length(model)) + octet_length(usage_json)) <= 2000)));


--
-- Name: session_llm_requests_spend_wide; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_spend_wide ON public.session_llm_requests USING btree (created_at) WHERE ((usage_json IS NOT NULL) AND (NOT ((public.spend_usage_json(usage_json) IS NOT NULL) AND (((octet_length(session_id) + octet_length(model)) + octet_length(usage_json)) <= 2000))));


--
-- Name: session_mailbox_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_id_lookup ON public.session_mailbox USING btree (id);


--
-- Name: session_mailbox_recipientid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_recipientid_fold ON public.session_mailbox USING hash (lower(("json" ->> 'recipientId'::text)));


--
-- Name: session_mailbox_recipientid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_recipientid_unicode ON public.session_mailbox USING btree (id) WHERE (("json" ->> 'recipientId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: session_mailbox_wake_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_wake_fold ON public.session_mailbox USING hash (lower(("json" ->> 'wake'::text)));


--
-- Name: session_mailbox_wake_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_wake_unicode ON public.session_mailbox USING btree (id) WHERE (("json" ->> 'wake'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: session_pins_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_pins_by_session ON public.session_pins USING btree (session_id, created_at);


--
-- Name: session_pins_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_pins_key_lookup ON public.session_pins USING btree (id);


--
-- Name: session_shares_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_shares_id_lookup ON public.session_shares USING btree (id);


--
-- Name: session_spend_days_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_spend_days_key_lookup ON public.session_spend_days USING btree (day);


--
-- Name: session_spend_dirty_day_writer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX session_spend_dirty_day_writer_key ON public.session_spend_dirty USING btree (tenant_id, day, writer);


--
-- Name: session_spend_dirty_day_writer_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_spend_dirty_day_writer_key_lookup ON public.session_spend_dirty USING btree (day, writer);


--
-- Name: sessions_by_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_activity ON public.sessions USING btree (COALESCE(last_activity, created_at) DESC, id DESC);


--
-- Name: sessions_by_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_scope ON public.sessions USING btree (scope_id, created_at DESC);


--
-- Name: sessions_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC);


--
-- Name: sessions_conversations_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_conversations_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC) WHERE (origin = 'conversation'::text);


--
-- Name: sessions_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_key_lookup ON public.sessions USING btree (id);


--
-- Name: sessions_other_background_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_other_background_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC) WHERE (origin <> ALL (ARRAY['conversation'::text, 'cron'::text]));


--
-- Name: sessions_side_chat_origin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_side_chat_origin ON public.sessions USING btree (forked_from_session_id) WHERE (side_chat IS NOT NULL);


--
-- Name: sessions_thread_ref_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sessions_thread_ref_key ON public.sessions USING btree (tenant_id, thread_ref);


--
-- Name: sessions_thread_ref_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_thread_ref_key_lookup ON public.sessions USING btree (thread_ref);


--
-- Name: sharing_postures_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sharing_postures_id_lookup ON public.sharing_postures USING btree (id);


--
-- Name: skill_bundles_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skill_bundles_id_lookup ON public.skill_bundles USING btree (id);


--
-- Name: skill_packs_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skill_packs_id_lookup ON public.skill_packs USING btree (id);


--
-- Name: skills_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_id_lookup ON public.skills USING btree (id);


--
-- Name: skills_resource_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_resource_name_idx ON public.skills USING btree (((("json" -> 'manifest'::text) ->> 'name'::text)));


--
-- Name: skills_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_resource_search_gin ON public.skills USING gin (to_tsvector('simple'::regconfig, ((COALESCE((("json" -> 'manifest'::text) ->> 'name'::text), ''::text) || ' '::text) || COALESCE((("json" -> 'manifest'::text) ->> 'description'::text), ''::text))));


--
-- Name: skills_scopeid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_scopeid_fold ON public.skills USING hash (lower(("json" ->> 'scopeId'::text)));


--
-- Name: skills_scopeid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_scopeid_unicode ON public.skills USING btree (id) WHERE (("json" ->> 'scopeId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: slack_accounts_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX slack_accounts_id_lookup ON public.slack_accounts USING btree (id);


--
-- Name: slack_emoji_catalog_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX slack_emoji_catalog_id_lookup ON public.slack_emoji_catalog USING btree (id);


--
-- Name: slack_installation_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX slack_installation_id_lookup ON public.slack_installation USING btree (id);


--
-- Name: slack_session_status_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX slack_session_status_id_lookup ON public.slack_session_status USING btree (id);


--
-- Name: slack_staged_envelopes_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX slack_staged_envelopes_id_lookup ON public.slack_staged_envelopes USING btree (id);


--
-- Name: slack_task_acknowledgements_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX slack_task_acknowledgements_id_lookup ON public.slack_task_acknowledgements USING btree (id);


--
-- Name: smolmachines_sandbox_bodies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX smolmachines_sandbox_bodies_id_lookup ON public.smolmachines_sandbox_bodies USING btree (id);


--
-- Name: soul_configs_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX soul_configs_id_lookup ON public.soul_configs USING btree (id);


--
-- Name: soul_history_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX soul_history_id_lookup ON public.soul_history USING btree (id);


--
-- Name: source_auth_replay_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_auth_replay_expires_at ON public.source_auth_replay USING btree (expires_at);


--
-- Name: spend_limit_configs_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX spend_limit_configs_id_lookup ON public.spend_limit_configs USING btree (id);


--
-- Name: sprites_initialization_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sprites_initialization_id_lookup ON public.sprites_initialization USING btree (id);


--
-- Name: suggested_activity_profiles_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suggested_activity_profiles_id_lookup ON public.suggested_activity_profiles USING btree (id);


--
-- Name: superserve_config_epochs_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX superserve_config_epochs_id_lookup ON public.superserve_config_epochs USING btree (id);


--
-- Name: superserve_sandbox_bodies_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX superserve_sandbox_bodies_id_lookup ON public.superserve_sandbox_bodies USING btree (id);


--
-- Name: swarms_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX swarms_id_lookup ON public.swarms USING btree (id);


--
-- Name: swarms_pending_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX swarms_pending_fold ON public.swarms USING hash (lower(("json" ->> 'pending'::text)));


--
-- Name: swarms_pending_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX swarms_pending_unicode ON public.swarms USING btree (id) WHERE (("json" ->> 'pending'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: team_members_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_members_key_lookup ON public.team_members USING btree (team_id, principal_id);


--
-- Name: team_members_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_members_principal ON public.team_members USING btree (principal_id);


--
-- Name: team_rooms_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_rooms_key_lookup ON public.team_rooms USING btree (team_id, scope_id);


--
-- Name: team_rooms_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_rooms_scope ON public.team_rooms USING btree (scope_id);


--
-- Name: teams_key_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX teams_key_lookup ON public.teams USING btree (team_id);


--
-- Name: tenant_hosts_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenant_hosts_tenant ON public.tenant_hosts USING btree (tenant_id);


--
-- Name: web_ui_state_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX web_ui_state_id_lookup ON public.web_ui_state USING btree (id);


--
-- Name: webhook_history_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook_history_id_lookup ON public.webhook_history USING btree (id);


--
-- Name: webhooks_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_id_lookup ON public.webhooks USING btree (id);


--
-- Name: webhooks_ownerscopeid_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_ownerscopeid_fold ON public.webhooks USING hash (lower(("json" ->> 'ownerScopeId'::text)));


--
-- Name: webhooks_ownerscopeid_unicode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_ownerscopeid_unicode ON public.webhooks USING btree (id) WHERE (("json" ->> 'ownerScopeId'::text) ~ '[^\x01-\x7f]'::text);


--
-- Name: webhooks_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_resource_search_gin ON public.webhooks USING gin (to_tsvector('simple'::regconfig, ((COALESCE(("json" ->> 'action'::text), ''::text) || ' '::text) || COALESCE((("json" -> 'verification'::text) ->> 'scheme'::text), ''::text))));


--
-- Name: webui_model_configs_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webui_model_configs_id_lookup ON public.webui_model_configs USING btree (id);


--
-- Name: job_common_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.job_common_pkey;


--
-- Name: queue_stats_20261109_name_captured_on_deferred_count_queued_idx; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_i1 ATTACH PARTITION pgboss.queue_stats_20261109_name_captured_on_deferred_count_queued_idx;


--
-- Name: queue_stats_20261109_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_pkey ATTACH PARTITION pgboss.queue_stats_20261109_pkey;


--
-- Name: queue_stats_20261110_name_captured_on_deferred_count_queued_idx; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_i1 ATTACH PARTITION pgboss.queue_stats_20261110_name_captured_on_deferred_count_queued_idx;


--
-- Name: queue_stats_20261110_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_pkey ATTACH PARTITION pgboss.queue_stats_20261110_pkey;


--
-- Name: approval_grants_actorid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.approval_grants_actorid_stats ON ("json" ->> 'actorId'::text) FROM public.approval_grants;


--
-- Name: approvals_sessionid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.approvals_sessionid_stats ON ("json" ->> 'sessionId'::text) FROM public.approvals;


--
-- Name: crons_ownerscopeid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.crons_ownerscopeid_stats ON ("json" ->> 'ownerScopeId'::text) FROM public.crons;


--
-- Name: keychain_credentials_ownerid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.keychain_credentials_ownerid_stats ON ("json" ->> 'ownerId'::text) FROM public.keychain_credentials;


--
-- Name: keychain_grants_ownerid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.keychain_grants_ownerid_stats ON ("json" ->> 'ownerId'::text) FROM public.keychain_grants;


--
-- Name: loop_ingress_deliveries_queuekey_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_ingress_deliveries_queuekey_stats ON ("json" ->> 'queueKey'::text) FROM public.loop_ingress_deliveries;


--
-- Name: loop_ingress_loopid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_ingress_loopid_stats ON ("json" ->> 'loopId'::text) FROM public.loop_ingress;


--
-- Name: loop_items_loopid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_items_loopid_stats ON ("json" ->> 'loopId'::text) FROM public.loop_items;


--
-- Name: loop_outputs_itemid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.loop_outputs_itemid_stats ON ("json" ->> 'itemId'::text) FROM public.loop_outputs;


--
-- Name: monitors_ownerscopeid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.monitors_ownerscopeid_stats ON ("json" ->> 'ownerScopeId'::text) FROM public.monitors;


--
-- Name: session_mailbox_recipientid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.session_mailbox_recipientid_stats ON ("json" ->> 'recipientId'::text) FROM public.session_mailbox;


--
-- Name: session_mailbox_wake_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.session_mailbox_wake_stats ON ("json" ->> 'wake'::text) FROM public.session_mailbox;


--
-- Name: skills_scopeid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.skills_scopeid_stats ON ("json" ->> 'scopeId'::text) FROM public.skills;


--
-- Name: swarms_pending_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.swarms_pending_stats ON ("json" ->> 'pending'::text) FROM public.swarms;


--
-- Name: webhooks_ownerscopeid_stats; Type: STATISTICS; Schema: public; Owner: -
--

CREATE STATISTICS public.webhooks_ownerscopeid_stats ON ("json" ->> 'ownerScopeId'::text) FROM public.webhooks;


--
-- Name: acl_grants acl_grants_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER acl_grants_bump AFTER INSERT OR DELETE OR UPDATE ON public.acl_grants FOR EACH ROW EXECUTE FUNCTION public.acl_grants_bump_version();


--
-- Name: acl_grants acl_grants_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER acl_grants_truncate AFTER TRUNCATE ON public.acl_grants FOR EACH STATEMENT EXECUTE FUNCTION public.acl_grants_bump_version();


--
-- Name: blobs blobs_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER blobs_immutable BEFORE DELETE OR UPDATE ON public.blobs FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: blobs blobs_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER blobs_no_truncate BEFORE TRUNCATE ON public.blobs FOR EACH STATEMENT EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: items items_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_append_only BEFORE UPDATE ON public.items FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: items items_delete_through_session; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_delete_through_session BEFORE DELETE ON public.items FOR EACH ROW EXECUTE FUNCTION public.forbid_direct_delete();


--
-- Name: items items_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_no_truncate BEFORE TRUNCATE ON public.items FOR EACH STATEMENT EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: memory_facts memory_facts_text_hash; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER memory_facts_text_hash BEFORE INSERT OR UPDATE OF text ON public.memory_facts FOR EACH ROW EXECUTE FUNCTION public.memory_facts_text_hash();


--
-- Name: session_llm_requests session_llm_requests_spend_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER session_llm_requests_spend_dirty AFTER INSERT OR DELETE OR UPDATE OF created_at, session_id, model, usage_json ON public.session_llm_requests FOR EACH ROW EXECUTE FUNCTION public.invalidate_request_spend();


--
-- Name: sessions sessions_spend_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sessions_spend_dirty AFTER INSERT OR DELETE OR UPDATE OF id, scope_id, origin, thread_ref, parent_session_id ON public.sessions FOR EACH ROW EXECUTE FUNCTION public.invalidate_session_spend();


--
-- Name: tenants tenants_retire_hosts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tenants_retire_hosts BEFORE DELETE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.qm_retire_tenant_hosts();


--
-- Name: job_common dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: job_common q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: queue queue_dead_letter_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue
    ADD CONSTRAINT queue_dead_letter_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name);


--
-- Name: schedule schedule_name_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.schedule
    ADD CONSTRAINT schedule_name_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE CASCADE;


--
-- Name: subscription subscription_name_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.subscription
    ADD CONSTRAINT subscription_name_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE CASCADE;


--
-- Name: ack_emoji_picks ack_emoji_picks_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks
    ADD CONSTRAINT ack_emoji_picks_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: ack_emoji ack_emoji_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji
    ADD CONSTRAINT ack_emoji_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: acl_grants acl_grants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants
    ADD CONSTRAINT acl_grants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: acl_grants_version acl_grants_version_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants_version
    ADD CONSTRAINT acl_grants_version_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: admin_grants admin_grants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_grants
    ADD CONSTRAINT admin_grants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: ambient_cursors ambient_cursors_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_cursors
    ADD CONSTRAINT ambient_cursors_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: ambient_judgments ambient_judgments_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments
    ADD CONSTRAINT ambient_judgments_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: app_page_views app_page_views_deployment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_page_views
    ADD CONSTRAINT app_page_views_deployment_id_fkey FOREIGN KEY (tenant_id, deployment_id) REFERENCES public.deployments(tenant_id, id) NOT VALID;


--
-- Name: app_page_views app_page_views_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_page_views
    ADD CONSTRAINT app_page_views_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: approval_grant_modes approval_grant_modes_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grant_modes
    ADD CONSTRAINT approval_grant_modes_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: approval_grants approval_grants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grants
    ADD CONSTRAINT approval_grants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: approvals approvals_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: audit_log audit_log_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: auth_broker_sessions auth_broker_sessions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_broker_sessions
    ADD CONSTRAINT auth_broker_sessions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: aws_sandbox_bodies aws_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_sandbox_bodies
    ADD CONSTRAINT aws_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: base_model_configs base_model_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.base_model_configs
    ADD CONSTRAINT base_model_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: blobs blobs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blobs
    ADD CONSTRAINT blobs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: branding_configs branding_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_configs
    ADD CONSTRAINT branding_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: browse_max_steps_configs browse_max_steps_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_max_steps_configs
    ADD CONSTRAINT browse_max_steps_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: browser_sessions browser_sessions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browser_sessions
    ADD CONSTRAINT browser_sessions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: budget_spend budget_spend_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_spend
    ADD CONSTRAINT budget_spend_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: channel_files channel_files_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_files
    ADD CONSTRAINT channel_files_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: channel_header_pin_flag channel_header_pin_flag_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_header_pin_flag
    ADD CONSTRAINT channel_header_pin_flag_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: channel_messages channel_messages_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_messages
    ADD CONSTRAINT channel_messages_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: channel_policy_history channel_policy_history_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history
    ADD CONSTRAINT channel_policy_history_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: channel_policy channel_policy_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy
    ADD CONSTRAINT channel_policy_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: channel_state channel_state_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_state
    ADD CONSTRAINT channel_state_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: command_policies command_policies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_policies
    ADD CONSTRAINT command_policies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: composio_returns composio_returns_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composio_returns
    ADD CONSTRAINT composio_returns_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: connector_clients connector_clients_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_clients
    ADD CONSTRAINT connector_clients_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: consent_links consent_links_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_links
    ADD CONSTRAINT consent_links_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: context_requests context_requests_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.context_requests
    ADD CONSTRAINT context_requests_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: credential_daily_calls credential_daily_calls_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_daily_calls
    ADD CONSTRAINT credential_daily_calls_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: credential_usage credential_usage_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage
    ADD CONSTRAINT credential_usage_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: cron_fires cron_fires_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_fires
    ADD CONSTRAINT cron_fires_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: crons crons_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crons
    ADD CONSTRAINT crons_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: custom_model_providers custom_model_providers_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_model_providers
    ADD CONSTRAINT custom_model_providers_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: deactivated_principals deactivated_principals_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deactivated_principals
    ADD CONSTRAINT deactivated_principals_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: decision_providers decision_providers_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_providers
    ADD CONSTRAINT decision_providers_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: decision_rules decision_rules_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_provider_id_fkey FOREIGN KEY (tenant_id, provider_id) REFERENCES public.decision_providers(tenant_id, provider_id) NOT VALID;


--
-- Name: decision_rules decision_rules_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: deliveries deliveries_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: deploy_git_repos deploy_git_repos_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_git_repos
    ADD CONSTRAINT deploy_git_repos_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: deployment_access deployment_access_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_id_fkey FOREIGN KEY (tenant_id, id) REFERENCES public.deployments(tenant_id, id) ON DELETE CASCADE NOT VALID;


--
-- Name: deployment_access deployment_access_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: deployment_identity deployment_identity_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_identity
    ADD CONSTRAINT deployment_identity_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: deployment_layer deployment_layer_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_layer
    ADD CONSTRAINT deployment_layer_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: deployments deployments_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: directory_channel_members directory_channel_members_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channel_members
    ADD CONSTRAINT directory_channel_members_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: directory_channels directory_channels_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channels
    ADD CONSTRAINT directory_channels_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: directory_group_members directory_group_members_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_group_members
    ADD CONSTRAINT directory_group_members_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: directory_groups directory_groups_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_groups
    ADD CONSTRAINT directory_groups_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: directory_members directory_members_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_members
    ADD CONSTRAINT directory_members_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: directory_meta directory_meta_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_meta
    ADD CONSTRAINT directory_meta_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: directory_sync directory_sync_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_sync
    ADD CONSTRAINT directory_sync_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: do_managed_agents_sandbox_bodies do_managed_agents_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.do_managed_agents_sandbox_bodies
    ADD CONSTRAINT do_managed_agents_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: durable_map_versions durable_map_versions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.durable_map_versions
    ADD CONSTRAINT durable_map_versions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: e2b_sandbox_bodies e2b_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2b_sandbox_bodies
    ADD CONSTRAINT e2b_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: egress_events egress_events_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events
    ADD CONSTRAINT egress_events_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: egress_policies egress_policies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_policies
    ADD CONSTRAINT egress_policies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: environment_attachments environment_attachments_environment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_environment_id_fkey FOREIGN KEY (tenant_id, environment_id) REFERENCES public.environments(tenant_id, id) NOT VALID;


--
-- Name: environment_attachments environment_attachments_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: environments environments_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: error_events error_events_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events
    ADD CONSTRAINT error_events_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: external_members external_members_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_members
    ADD CONSTRAINT external_members_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: external_slack_participants_flag external_slack_participants_flag_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_slack_participants_flag
    ADD CONSTRAINT external_slack_participants_flag_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: feature_flags feature_flags_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: file_artifact_deletions file_artifact_deletions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifact_deletions
    ADD CONSTRAINT file_artifact_deletions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: file_artifacts file_artifacts_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifacts
    ADD CONSTRAINT file_artifacts_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: file_uploads file_uploads_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_uploads
    ADD CONSTRAINT file_uploads_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: idempotency idempotency_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency
    ADD CONSTRAINT idempotency_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: individual_model_auth_flag individual_model_auth_flag_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.individual_model_auth_flag
    ADD CONSTRAINT individual_model_auth_flag_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: interactive_fast_mode_flag interactive_fast_mode_flag_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interactive_fast_mode_flag
    ADD CONSTRAINT interactive_fast_mode_flag_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: items items_blob; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_blob FOREIGN KEY (tenant_id, blob_sha) REFERENCES public.blobs(tenant_id, sha256);


--
-- Name: items items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_session_id_fkey FOREIGN KEY (tenant_id, session_id) REFERENCES public.sessions(tenant_id, id) ON DELETE CASCADE NOT VALID;


--
-- Name: items items_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: keychain_asks keychain_asks_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_asks
    ADD CONSTRAINT keychain_asks_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: keychain_credentials keychain_credentials_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_credentials
    ADD CONSTRAINT keychain_credentials_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: keychain_grants keychain_grants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_grants
    ADD CONSTRAINT keychain_grants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: llm_prompt_envelopes llm_prompt_envelopes_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_prompt_envelopes
    ADD CONSTRAINT llm_prompt_envelopes_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: loop_ingress_deliveries loop_ingress_deliveries_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ingress_deliveries
    ADD CONSTRAINT loop_ingress_deliveries_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: loop_ingress loop_ingress_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ingress
    ADD CONSTRAINT loop_ingress_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: loop_items loop_items_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_items
    ADD CONSTRAINT loop_items_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: loop_outputs loop_outputs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_outputs
    ADD CONSTRAINT loop_outputs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: loop_ship_grants loop_ship_grants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_ship_grants
    ADD CONSTRAINT loop_ship_grants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: loops loops_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loops
    ADD CONSTRAINT loops_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: mcp_servers mcp_servers_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: memory_fact_vectors memory_fact_vectors_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_fact_vectors
    ADD CONSTRAINT memory_fact_vectors_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: memory_facts memory_facts_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: memory_tidy_profiles memory_tidy_profiles_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_tidy_profiles
    ADD CONSTRAINT memory_tidy_profiles_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: modal_sandbox_bodies modal_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modal_sandbox_bodies
    ADD CONSTRAINT modal_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: model_credentials model_credentials_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_credentials
    ADD CONSTRAINT model_credentials_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: model_registry model_registry_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: monitors monitors_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: oauth_flows oauth_flows_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_flows
    ADD CONSTRAINT oauth_flows_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: org_ambient_flag org_ambient_flag_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_ambient_flag
    ADD CONSTRAINT org_ambient_flag_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: participants participants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: principal_links principal_links_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.principal_links
    ADD CONSTRAINT principal_links_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: process_sessions process_sessions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_sessions
    ADD CONSTRAINT process_sessions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: projects projects_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: render_deploy_bodies render_deploy_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_deploy_bodies
    ADD CONSTRAINT render_deploy_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: render_sandbox_bodies render_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_sandbox_bodies
    ADD CONSTRAINT render_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: render_sandbox_cleanup render_sandbox_cleanup_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_sandbox_cleanup
    ADD CONSTRAINT render_sandbox_cleanup_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: render_scratch_bodies render_scratch_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.render_scratch_bodies
    ADD CONSTRAINT render_scratch_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: run_activity run_activity_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity
    ADD CONSTRAINT run_activity_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: run_signals run_signals_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals
    ADD CONSTRAINT run_signals_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: runs runs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: sandbox_defaults sandbox_defaults_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_defaults
    ADD CONSTRAINT sandbox_defaults_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: sandbox_resource_rollout sandbox_resource_rollout_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resource_rollout
    ADD CONSTRAINT sandbox_resource_rollout_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: sandbox_resources sandbox_resources_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resources
    ADD CONSTRAINT sandbox_resources_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: sandbox_routing sandbox_routing_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_routing
    ADD CONSTRAINT sandbox_routing_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: secret_drops secret_drops_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_drops
    ADD CONSTRAINT secret_drops_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: security_postures security_postures_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_postures
    ADD CONSTRAINT security_postures_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_goals session_goals_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_session_id_fkey FOREIGN KEY (tenant_id, session_id) REFERENCES public.sessions(tenant_id, id) ON DELETE CASCADE NOT VALID;


--
-- Name: session_goals session_goals_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_leases session_leases_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_leases
    ADD CONSTRAINT session_leases_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_llm_requests session_llm_requests_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_llm_requests
    ADD CONSTRAINT session_llm_requests_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_mailbox session_mailbox_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_mailbox
    ADD CONSTRAINT session_mailbox_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_pins session_pins_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_pins
    ADD CONSTRAINT session_pins_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_shares session_shares_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_shares
    ADD CONSTRAINT session_shares_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_spend_days session_spend_days_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_days
    ADD CONSTRAINT session_spend_days_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: session_spend_dirty session_spend_dirty_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_dirty
    ADD CONSTRAINT session_spend_dirty_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: sessions sessions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: sharing_postures sharing_postures_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sharing_postures
    ADD CONSTRAINT sharing_postures_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: skill_bundles skill_bundles_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_bundles
    ADD CONSTRAINT skill_bundles_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: skill_packs skill_packs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_packs
    ADD CONSTRAINT skill_packs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: skills skills_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: slack_accounts slack_accounts_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_accounts
    ADD CONSTRAINT slack_accounts_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: slack_emoji_catalog slack_emoji_catalog_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_emoji_catalog
    ADD CONSTRAINT slack_emoji_catalog_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: slack_installation slack_installation_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_installation
    ADD CONSTRAINT slack_installation_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: slack_session_status slack_session_status_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_session_status
    ADD CONSTRAINT slack_session_status_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: slack_staged_envelopes slack_staged_envelopes_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_staged_envelopes
    ADD CONSTRAINT slack_staged_envelopes_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: slack_task_acknowledgements slack_task_acknowledgements_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_task_acknowledgements
    ADD CONSTRAINT slack_task_acknowledgements_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: smolmachines_sandbox_bodies smolmachines_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smolmachines_sandbox_bodies
    ADD CONSTRAINT smolmachines_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: soul_configs soul_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_configs
    ADD CONSTRAINT soul_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: soul_history soul_history_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_history
    ADD CONSTRAINT soul_history_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: spend_limit_configs spend_limit_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend_limit_configs
    ADD CONSTRAINT spend_limit_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: sprites_initialization sprites_initialization_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprites_initialization
    ADD CONSTRAINT sprites_initialization_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: suggested_activity_profiles suggested_activity_profiles_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggested_activity_profiles
    ADD CONSTRAINT suggested_activity_profiles_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: superserve_config_epochs superserve_config_epochs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_config_epochs
    ADD CONSTRAINT superserve_config_epochs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: superserve_sandbox_bodies superserve_sandbox_bodies_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_sandbox_bodies
    ADD CONSTRAINT superserve_sandbox_bodies_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: swarms swarms_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swarms
    ADD CONSTRAINT swarms_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (tenant_id, team_id) REFERENCES public.teams(tenant_id, team_id) ON DELETE CASCADE NOT VALID;


--
-- Name: team_members team_members_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: team_rooms team_rooms_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_team_id_fkey FOREIGN KEY (tenant_id, team_id) REFERENCES public.teams(tenant_id, team_id) ON DELETE CASCADE NOT VALID;


--
-- Name: team_rooms team_rooms_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: teams teams_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: tenant_hosts tenant_hosts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_hosts
    ADD CONSTRAINT tenant_hosts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: web_ui_state web_ui_state_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_ui_state
    ADD CONSTRAINT web_ui_state_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: webhook_history webhook_history_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_history
    ADD CONSTRAINT webhook_history_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: webhooks webhooks_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: webui_model_configs webui_model_configs_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webui_model_configs
    ADD CONSTRAINT webui_model_configs_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) NOT VALID;


--
-- Name: ack_emoji; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ack_emoji ENABLE ROW LEVEL SECURITY;

--
-- Name: ack_emoji_picks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ack_emoji_picks ENABLE ROW LEVEL SECURITY;

--
-- Name: acl_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.acl_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: acl_grants_version; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.acl_grants_version ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: ambient_cursors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ambient_cursors ENABLE ROW LEVEL SECURITY;

--
-- Name: ambient_judgments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ambient_judgments ENABLE ROW LEVEL SECURITY;

--
-- Name: app_page_views; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.app_page_views ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_grant_modes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_grant_modes ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: approvals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approvals ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: auth_broker_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auth_broker_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: aws_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.aws_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: base_model_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.base_model_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: blobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.blobs ENABLE ROW LEVEL SECURITY;

--
-- Name: branding_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.branding_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: browse_max_steps_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.browse_max_steps_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: browser_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.browser_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: budget_spend; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.budget_spend ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_files; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_files ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_header_pin_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_header_pin_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_policy; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_policy ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_policy_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_policy_history ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_state ENABLE ROW LEVEL SECURITY;

--
-- Name: command_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.command_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: composio_returns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.composio_returns ENABLE ROW LEVEL SECURITY;

--
-- Name: connector_clients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.connector_clients ENABLE ROW LEVEL SECURITY;

--
-- Name: consent_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.consent_links ENABLE ROW LEVEL SECURITY;

--
-- Name: context_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.context_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_daily_calls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credential_daily_calls ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_usage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credential_usage ENABLE ROW LEVEL SECURITY;

--
-- Name: cron_fires; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cron_fires ENABLE ROW LEVEL SECURITY;

--
-- Name: crons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.crons ENABLE ROW LEVEL SECURITY;

--
-- Name: custom_model_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.custom_model_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: deactivated_principals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deactivated_principals ENABLE ROW LEVEL SECURITY;

--
-- Name: decision_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decision_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: decision_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decision_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: deploy_git_repos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deploy_git_repos ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_access; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_access ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_identity; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_identity ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_layer; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_layer ENABLE ROW LEVEL SECURITY;

--
-- Name: deployments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployments ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_channel_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_channel_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_channels; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_channels ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_group_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_group_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_meta; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_meta ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_sync; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_sync ENABLE ROW LEVEL SECURITY;

--
-- Name: do_managed_agents_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.do_managed_agents_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: durable_map_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.durable_map_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: e2b_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.e2b_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: egress_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.egress_events ENABLE ROW LEVEL SECURITY;

--
-- Name: egress_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.egress_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: environment_attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.environment_attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: environments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.environments ENABLE ROW LEVEL SECURITY;

--
-- Name: error_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.error_events ENABLE ROW LEVEL SECURITY;

--
-- Name: external_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_members ENABLE ROW LEVEL SECURITY;

--
-- Name: external_slack_participants_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_slack_participants_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_flags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;

--
-- Name: file_artifact_deletions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_artifact_deletions ENABLE ROW LEVEL SECURITY;

--
-- Name: file_artifacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_artifacts ENABLE ROW LEVEL SECURITY;

--
-- Name: file_uploads; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: idempotency; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.idempotency ENABLE ROW LEVEL SECURITY;

--
-- Name: individual_model_auth_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.individual_model_auth_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: interactive_fast_mode_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.interactive_fast_mode_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.items ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_asks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_asks ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: llm_prompt_envelopes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.llm_prompt_envelopes ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_ingress; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_ingress ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_ingress_deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_ingress_deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_items ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_outputs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_outputs ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_ship_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_ship_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: loops; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loops ENABLE ROW LEVEL SECURITY;

--
-- Name: mcp_servers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mcp_servers ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_fact_vectors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_fact_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_facts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_facts ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_tidy_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_tidy_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: modal_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.modal_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: model_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.model_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: model_registry; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.model_registry ENABLE ROW LEVEL SECURITY;

--
-- Name: monitors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.monitors ENABLE ROW LEVEL SECURITY;

--
-- Name: oauth_flows; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.oauth_flows ENABLE ROW LEVEL SECURITY;

--
-- Name: org_ambient_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_ambient_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: participants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.participants ENABLE ROW LEVEL SECURITY;

--
-- Name: principal_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.principal_links ENABLE ROW LEVEL SECURITY;

--
-- Name: process_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.process_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: projects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

--
-- Name: render_deploy_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.render_deploy_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: render_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.render_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: render_sandbox_cleanup; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.render_sandbox_cleanup ENABLE ROW LEVEL SECURITY;

--
-- Name: render_scratch_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.render_scratch_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: retired_tenant_hosts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.retired_tenant_hosts ENABLE ROW LEVEL SECURITY;

--
-- Name: run_activity; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.run_activity ENABLE ROW LEVEL SECURITY;

--
-- Name: run_signals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.run_signals ENABLE ROW LEVEL SECURITY;

--
-- Name: runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runs ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_defaults; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_defaults ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_resource_rollout; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_resource_rollout ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_resources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_resources ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_routing; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_routing ENABLE ROW LEVEL SECURITY;

--
-- Name: secret_drops; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.secret_drops ENABLE ROW LEVEL SECURITY;

--
-- Name: security_postures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.security_postures ENABLE ROW LEVEL SECURITY;

--
-- Name: session_goals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_goals ENABLE ROW LEVEL SECURITY;

--
-- Name: session_leases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_leases ENABLE ROW LEVEL SECURITY;

--
-- Name: session_llm_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_llm_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: session_mailbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_mailbox ENABLE ROW LEVEL SECURITY;

--
-- Name: session_pins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_pins ENABLE ROW LEVEL SECURITY;

--
-- Name: session_shares; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_shares ENABLE ROW LEVEL SECURITY;

--
-- Name: session_spend_days; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_spend_days ENABLE ROW LEVEL SECURITY;

--
-- Name: session_spend_dirty; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_spend_dirty ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sharing_postures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sharing_postures ENABLE ROW LEVEL SECURITY;

--
-- Name: skill_bundles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skill_bundles ENABLE ROW LEVEL SECURITY;

--
-- Name: skill_packs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skill_packs ENABLE ROW LEVEL SECURITY;

--
-- Name: skills; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skills ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_emoji_catalog; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_emoji_catalog ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_installation; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_installation ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_session_status; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_session_status ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_staged_envelopes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_staged_envelopes ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_task_acknowledgements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_task_acknowledgements ENABLE ROW LEVEL SECURITY;

--
-- Name: smolmachines_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.smolmachines_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: soul_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.soul_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: soul_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.soul_history ENABLE ROW LEVEL SECURITY;

--
-- Name: spend_limit_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.spend_limit_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: sprites_initialization; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sprites_initialization ENABLE ROW LEVEL SECURITY;

--
-- Name: suggested_activity_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suggested_activity_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: superserve_config_epochs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.superserve_config_epochs ENABLE ROW LEVEL SECURITY;

--
-- Name: superserve_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.superserve_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: swarms; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.swarms ENABLE ROW LEVEL SECURITY;

--
-- Name: team_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;

--
-- Name: team_rooms; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.team_rooms ENABLE ROW LEVEL SECURITY;

--
-- Name: teams; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_hosts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tenant_hosts ENABLE ROW LEVEL SECURITY;

--
-- Name: ack_emoji tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.ack_emoji USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: ack_emoji_picks tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.ack_emoji_picks USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: acl_grants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.acl_grants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: acl_grants_version tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.acl_grants_version USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: admin_grants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.admin_grants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: ambient_cursors tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.ambient_cursors USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: ambient_judgments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.ambient_judgments USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: app_page_views tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.app_page_views USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: approval_grant_modes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.approval_grant_modes USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: approval_grants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.approval_grants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: approvals tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.approvals USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: audit_log tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.audit_log USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: auth_broker_sessions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.auth_broker_sessions USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: aws_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.aws_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: base_model_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.base_model_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: blobs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.blobs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: branding_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.branding_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: browse_max_steps_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.browse_max_steps_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: browser_sessions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.browser_sessions USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: budget_spend tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.budget_spend USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: channel_files tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.channel_files USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: channel_header_pin_flag tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.channel_header_pin_flag USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: channel_messages tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.channel_messages USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: channel_policy tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.channel_policy USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: channel_policy_history tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.channel_policy_history USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: channel_state tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.channel_state USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: command_policies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.command_policies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: composio_returns tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.composio_returns USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: connector_clients tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.connector_clients USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: consent_links tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.consent_links USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: context_requests tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.context_requests USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: credential_daily_calls tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.credential_daily_calls USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: credential_usage tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.credential_usage USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: cron_fires tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.cron_fires USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: crons tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.crons USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: custom_model_providers tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.custom_model_providers USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deactivated_principals tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deactivated_principals USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: decision_providers tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.decision_providers USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: decision_rules tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.decision_rules USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deliveries tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deliveries USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deploy_git_repos tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deploy_git_repos USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deployment_access tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deployment_access USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deployment_identity tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deployment_identity USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deployment_layer tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deployment_layer USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: deployments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.deployments USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_channel_members tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_channel_members USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_channels tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_channels USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_group_members tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_group_members USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_groups tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_groups USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_members tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_members USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_meta tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_meta USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: directory_sync tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.directory_sync USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: do_managed_agents_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.do_managed_agents_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: durable_map_versions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.durable_map_versions USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: e2b_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.e2b_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: egress_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.egress_events USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: egress_policies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.egress_policies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: environment_attachments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.environment_attachments USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: environments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.environments USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: error_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.error_events USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: external_members tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.external_members USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: external_slack_participants_flag tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.external_slack_participants_flag USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: feature_flags tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.feature_flags USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: file_artifact_deletions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.file_artifact_deletions USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: file_artifacts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.file_artifacts USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: file_uploads tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.file_uploads USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: idempotency tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.idempotency USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: individual_model_auth_flag tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.individual_model_auth_flag USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: interactive_fast_mode_flag tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.interactive_fast_mode_flag USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: items tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.items USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: keychain_asks tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.keychain_asks USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: keychain_credentials tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.keychain_credentials USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: keychain_grants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.keychain_grants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: llm_prompt_envelopes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.llm_prompt_envelopes USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loop_ingress tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loop_ingress USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loop_ingress_deliveries tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loop_ingress_deliveries USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loop_items tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loop_items USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loop_outputs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loop_outputs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loop_ship_grants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loop_ship_grants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: loops tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.loops USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: mcp_servers tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.mcp_servers USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: memory_fact_vectors tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.memory_fact_vectors USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: memory_facts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.memory_facts USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: memory_tidy_profiles tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.memory_tidy_profiles USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: modal_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.modal_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: model_credentials tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.model_credentials USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: model_registry tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.model_registry USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: monitors tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.monitors USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: oauth_flows tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.oauth_flows USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: org_ambient_flag tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.org_ambient_flag USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: participants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.participants USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: principal_links tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.principal_links USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: process_sessions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.process_sessions USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: projects tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.projects USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: render_deploy_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.render_deploy_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: render_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.render_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: render_sandbox_cleanup tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.render_sandbox_cleanup USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: render_scratch_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.render_scratch_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: run_activity tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.run_activity USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: run_signals tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.run_signals USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: runs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.runs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sandbox_defaults tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sandbox_defaults USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sandbox_resource_rollout tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sandbox_resource_rollout USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sandbox_resources tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sandbox_resources USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sandbox_routing tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sandbox_routing USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: secret_drops tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.secret_drops USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: security_postures tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.security_postures USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: session_goals tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_goals USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: session_leases tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_leases USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: session_llm_requests tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_llm_requests USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: session_mailbox tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_mailbox USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: session_pins tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_pins USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: session_shares tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_shares USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: session_spend_days tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_spend_days USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: session_spend_dirty tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.session_spend_dirty USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sessions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sessions USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sharing_postures tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sharing_postures USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: skill_bundles tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.skill_bundles USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: skill_packs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.skill_packs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: skills tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.skills USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_accounts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_accounts USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_emoji_catalog tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_emoji_catalog USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_installation tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_installation USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_session_status tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_session_status USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_staged_envelopes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_staged_envelopes USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: slack_task_acknowledgements tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.slack_task_acknowledgements USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: smolmachines_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.smolmachines_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: soul_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.soul_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: soul_history tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.soul_history USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: spend_limit_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.spend_limit_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: sprites_initialization tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sprites_initialization USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: suggested_activity_profiles tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.suggested_activity_profiles USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: superserve_config_epochs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.superserve_config_epochs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: superserve_sandbox_bodies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.superserve_sandbox_bodies USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: swarms tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.swarms USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: team_members tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.team_members USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: team_rooms tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.team_rooms USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: teams tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.teams USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: tenant_hosts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.tenant_hosts FOR SELECT USING ((tenant_id = public.qm_bound_tenant()));


--
-- Name: tenants tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.tenants FOR SELECT USING ((id = public.qm_bound_tenant()));


--
-- Name: web_ui_state tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.web_ui_state USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: webhook_history tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.webhook_history USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: webhooks tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.webhooks USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: webui_model_configs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.webui_model_configs USING ((tenant_id = public.qm_bound_tenant())) WITH CHECK ((tenant_id = public.qm_bound_tenant()));


--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: web_ui_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.web_ui_state ENABLE ROW LEVEL SECURITY;

--
-- Name: webhook_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhook_history ENABLE ROW LEVEL SECURITY;

--
-- Name: webhooks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhooks ENABLE ROW LEVEL SECURITY;

--
-- Name: webui_model_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webui_model_configs ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--


