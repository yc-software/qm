--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgboss; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgboss;


--
-- Name: job_state; Type: TYPE; Schema: pgboss; Owner: -
--

CREATE TYPE pgboss.job_state AS ENUM (
    'created',
    'retry',
    'active',
    'completed',
    'cancelled',
    'failed'
);


--
-- Name: create_queue(text, jsonb); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.create_queue(queue_name text, options jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $_$
    DECLARE
      tablename varchar := CASE WHEN options->>'partition' = 'true'
                            THEN 'j' || encode(sha224(queue_name::bytea), 'hex')
                            ELSE 'job_common'
                            END;
      queue_created_on timestamptz;
    BEGIN

      WITH q as (
        INSERT INTO pgboss.queue (
          name,
          policy,
          retry_limit,
          retry_delay,
          retry_backoff,
          retry_delay_max,
          expire_seconds,
          retention_seconds,
          deletion_seconds,
          warning_queued,
          dead_letter,
          partition,
          table_name,
          heartbeat_seconds,
          notify
        )
        VALUES (
          queue_name,
          options->>'policy',
          COALESCE((options->>'retryLimit')::int, 2),
          COALESCE((options->>'retryDelay')::int, 0),
          COALESCE((options->>'retryBackoff')::bool, false),
          (options->>'retryDelayMax')::int,
          COALESCE((options->>'expireInSeconds')::int, 900),
          COALESCE((options->>'retentionSeconds')::int, 1209600),
          COALESCE((options->>'deleteAfterSeconds')::int, 604800),
          COALESCE((options->>'warningQueueSize')::int, 0),
          options->>'deadLetter',
          COALESCE((options->>'partition')::bool, false),
          tablename,
          (options->>'heartbeatSeconds')::int,
          COALESCE((options->>'notify')::bool, false)
        )
        ON CONFLICT DO NOTHING
        RETURNING created_on
      )
      SELECT created_on into queue_created_on from q;

      IF queue_created_on IS NULL OR options->>'partition' IS DISTINCT FROM 'true' THEN
        RETURN;
      END IF;

      EXECUTE format('CREATE TABLE pgboss.%I (LIKE pgboss.job INCLUDING DEFAULTS)', tablename);

      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD PRIMARY KEY (name, id)$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED$cmd$, tablename);

      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i5 ON pgboss.job (name, start_after) WHERE state < 'active' AND NOT blocked$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i4 ON pgboss.job (name, singleton_on, COALESCE(singleton_key, '')) WHERE state <> 'cancelled' AND singleton_on IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i7 ON pgboss.job (name, group_id) WHERE state = 'active' AND group_id IS NOT NULL$cmd$, tablename);
      EXECUTE pgboss.job_table_format($cmd$CREATE INDEX job_i9 ON pgboss.job (name, id) WHERE blocking AND state = 'completed'$cmd$, tablename);

      IF options->>'policy' = 'short' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i1 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state = 'created' AND policy = 'short'$cmd$, tablename);
      ELSIF options->>'policy' = 'singleton' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i2 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state = 'active' AND policy = 'singleton'$cmd$, tablename);
      ELSIF options->>'policy' = 'stately' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i3 ON pgboss.job (name, state, COALESCE(singleton_key, '')) WHERE state <= 'active' AND policy = 'stately'$cmd$, tablename);
      ELSIF options->>'policy' = 'exclusive' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i6 ON pgboss.job (name, COALESCE(singleton_key, '')) WHERE state <= 'active' AND policy = 'exclusive'$cmd$, tablename);
      ELSIF options->>'policy' = 'key_strict_fifo' THEN
        EXECUTE pgboss.job_table_format($cmd$CREATE UNIQUE INDEX job_i8 ON pgboss.job (name, singleton_key) WHERE state IN ('active', 'retry', 'failed') AND policy = 'key_strict_fifo'$cmd$, tablename);
        EXECUTE pgboss.job_table_format($cmd$ALTER TABLE pgboss.job ADD CONSTRAINT job_key_strict_fifo_singleton_key_check CHECK (NOT (policy = 'key_strict_fifo' AND singleton_key IS NULL))$cmd$, tablename);
      END IF;

      EXECUTE format('ALTER TABLE pgboss.%I ADD CONSTRAINT cjc CHECK (name=%L)', tablename, queue_name);
      EXECUTE format('ALTER TABLE pgboss.job ATTACH PARTITION pgboss.%I FOR VALUES IN (%L)', tablename, queue_name);
    END;
    $_$;


--
-- Name: delete_queue(text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.delete_queue(queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      v_table varchar;
      v_partition bool;
    BEGIN
      
      SELECT table_name, partition
      FROM pgboss.queue
      WHERE name = queue_name
      INTO v_table, v_partition;

      IF v_partition THEN
        EXECUTE format('DROP TABLE IF EXISTS pgboss.%I', v_table);
      ELSE
        EXECUTE format('DELETE FROM pgboss.%I WHERE name = %L', v_table, queue_name);
      END IF;
    
      DELETE FROM pgboss.queue WHERE name = queue_name;
    END;
    $$;


--
-- Name: job_table_format(text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_format(command text, table_name text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $_$
      SELECT format(
        regexp_replace(
          regexp_replace(command, '\.job\y', '.%1$I', 'g'),
          '\yjob_i(\d+)', '%1$s_i\1', 'g'
        ),
        table_name
      );
    $_$;


--
-- Name: job_table_run(text, text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_run(command text, tbl_name text DEFAULT NULL::text, queue_name text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      tbl RECORD;
    BEGIN
      IF queue_name IS NOT NULL THEN
        SELECT table_name INTO tbl_name FROM pgboss.queue WHERE name = queue_name;
      END IF;

      IF tbl_name IS NOT NULL THEN
        EXECUTE pgboss.job_table_format(command, tbl_name);
        RETURN;
      END IF;

      EXECUTE pgboss.job_table_format(command, 'job_common');

      FOR tbl IN SELECT table_name FROM pgboss.queue WHERE partition = true
      LOOP
        EXECUTE pgboss.job_table_format(command, tbl.table_name);
      END LOOP;
    END;
    $$;


--
-- Name: job_table_run_async(text, integer, text, text, text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.job_table_run_async(command_name text, version integer, command text, tbl_name text DEFAULT NULL::text, queue_name text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF queue_name IS NOT NULL THEN
        SELECT table_name INTO tbl_name FROM pgboss.queue WHERE name = queue_name;
      END IF;

      IF tbl_name IS NOT NULL THEN
        INSERT INTO pgboss.bam (name, version, status, queue, table_name, command)
        VALUES (
          command_name,
          version,
          'pending',
          queue_name,
          tbl_name,
          pgboss.job_table_format(command, tbl_name)
        );
        RETURN;
      END IF;

      INSERT INTO pgboss.bam (name, version, status, queue, table_name, command)
      SELECT
        command_name,
        version,
        'pending',
        NULL,
        'job_common',
        pgboss.job_table_format(command, 'job_common')
      UNION ALL
      SELECT
        command_name,
        version,
        'pending',
        queue.name,
        queue.table_name,
        pgboss.job_table_format(command, queue.table_name)
      FROM pgboss.queue
      WHERE partition = true;
    END;
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bam; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.bam (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    version integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    queue text,
    table_name text NOT NULL,
    command text NOT NULL,
    error text,
    created_on timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone
);


--
-- Name: job; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    retry_delay_max integer,
    expire_seconds integer DEFAULT 900 NOT NULL,
    deletion_seconds integer DEFAULT 604800 NOT NULL,
    singleton_key text,
    singleton_on timestamp without time zone,
    group_id text,
    group_tier text,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '336:00:00'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    heartbeat_on timestamp with time zone,
    heartbeat_seconds integer,
    blocked boolean DEFAULT false NOT NULL,
    blocking boolean DEFAULT false NOT NULL,
    pending_dependencies integer DEFAULT 0 NOT NULL,
    source_name text,
    source_id uuid,
    source_created_on timestamp with time zone,
    source_retry_count integer
)
PARTITION BY LIST (name);


--
-- Name: job_common; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job_common (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    retry_delay_max integer,
    expire_seconds integer DEFAULT 900 NOT NULL,
    deletion_seconds integer DEFAULT 604800 NOT NULL,
    singleton_key text,
    singleton_on timestamp without time zone,
    group_id text,
    group_tier text,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '336:00:00'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    heartbeat_on timestamp with time zone,
    heartbeat_seconds integer,
    blocked boolean DEFAULT false NOT NULL,
    blocking boolean DEFAULT false NOT NULL,
    pending_dependencies integer DEFAULT 0 NOT NULL,
    source_name text,
    source_id uuid,
    source_created_on timestamp with time zone,
    source_retry_count integer,
    CONSTRAINT job_key_strict_fifo_singleton_key_check CHECK ((NOT ((policy = 'key_strict_fifo'::text) AND (singleton_key IS NULL))))
);


--
-- Name: job_dependency; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job_dependency (
    child_name text NOT NULL,
    child_id uuid NOT NULL,
    parent_name text NOT NULL,
    parent_id uuid NOT NULL
);


--
-- Name: queue; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue (
    name text NOT NULL,
    policy text NOT NULL,
    retry_limit integer NOT NULL,
    retry_delay integer NOT NULL,
    retry_backoff boolean NOT NULL,
    retry_delay_max integer,
    expire_seconds integer NOT NULL,
    retention_seconds integer NOT NULL,
    deletion_seconds integer NOT NULL,
    dead_letter text,
    partition boolean NOT NULL,
    table_name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    warning_queued integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    ready_history integer[] DEFAULT '{}'::integer[] NOT NULL,
    heartbeat_seconds integer,
    notify boolean DEFAULT false NOT NULL,
    singletons_active text[],
    monitor_on timestamp with time zone,
    maintain_on timestamp with time zone,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT queue_check CHECK ((dead_letter IS DISTINCT FROM name))
);


--
-- Name: queue_stats; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    captured_on timestamp with time zone DEFAULT now() NOT NULL
)
PARTITION BY RANGE (captured_on);


--
-- Name: queue_stats_20261027; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats_20261027 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    captured_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: queue_stats_20261028; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue_stats_20261028 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    deferred_count integer DEFAULT 0 NOT NULL,
    queued_count integer DEFAULT 0 NOT NULL,
    ready_count integer DEFAULT 0 NOT NULL,
    active_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    captured_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schedule; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.schedule (
    name text NOT NULL,
    key text DEFAULT ''::text NOT NULL,
    cron text NOT NULL,
    timezone text,
    data jsonb,
    options jsonb,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscription; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.subscription (
    event text NOT NULL,
    name text NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: version; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.version (
    version integer NOT NULL,
    cron_on timestamp with time zone,
    bam_on timestamp with time zone,
    flow_on timestamp with time zone
);


--
-- Name: warning; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.warning (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type text NOT NULL,
    message text NOT NULL,
    data jsonb,
    created_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ack_emoji; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: approval_grant_modes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grant_modes (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: approved_harness_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approved_harness_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: auto_flagger_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_flagger_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: base_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.base_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: branding_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: browse_max_steps_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_max_steps_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: browse_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: channel_header_pin_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_header_pin_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: command_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.command_policies (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: cron_fire_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cron_fire_log (
    cron_id text NOT NULL,
    fire_key text NOT NULL,
    fired_at bigint NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: crons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crons (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: custom_model_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_model_providers (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: deactivated_principals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deactivated_principals (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: deployment_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_identity (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: deployment_layer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_layer (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: durable_map_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.durable_map_versions (
    tbl text NOT NULL,
    v bigint NOT NULL
);


--
-- Name: egress_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_policies (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: external_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_members (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: external_slack_participants_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_slack_participants_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: individual_model_auth_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.individual_model_auth_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: interactive_fast_mode_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interactive_fast_mode_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: keychain_asks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_asks (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_servers (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: monitors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monitors (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: org_ambient_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_ambient_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: people_directory_urls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.people_directory_urls (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: process_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_sessions (
    process_id text NOT NULL,
    scope_id text NOT NULL,
    kind text NOT NULL,
    command text NOT NULL,
    started_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    status text NOT NULL,
    session_ref text,
    run_id text
);


--
-- Name: run_signals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_signals (
    id bigint NOT NULL,
    run_id text NOT NULL,
    kind text NOT NULL,
    text text,
    payload jsonb,
    created_at bigint NOT NULL,
    consumed_at bigint
);


--
-- Name: run_signals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_signals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_signals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_signals_id_seq OWNED BY public.run_signals.id;


--
-- Name: runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runs (
    id text NOT NULL,
    session_id text NOT NULL,
    status text NOT NULL,
    request text NOT NULL,
    result text,
    idempotency_key text,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    lease_token text,
    lease_expires_at bigint,
    worker_id text,
    created_at bigint NOT NULL,
    started_at bigint,
    finished_at bigint,
    delivery_state text,
    error_attempts integer DEFAULT 0 NOT NULL,
    seq bigint NOT NULL
);


--
-- Name: runs_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.runs_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: runs_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.runs_seq_seq OWNED BY public.runs.seq;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    id text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: security_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_postures (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skills (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: slack_installation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_installation (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: soul_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: soul_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_history (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: tool_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_calls (
    run_id text NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    call_index integer NOT NULL,
    output text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: turn_wall_clock_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.turn_wall_clock_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: unfulfilled_insights_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unfulfilled_insights_flag (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: webui_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webui_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL
);


--
-- Name: job_common; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.job_common DEFAULT;


--
-- Name: queue_stats_20261027; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats ATTACH PARTITION pgboss.queue_stats_20261027 FOR VALUES FROM ('2026-10-27 00:00:00+00') TO ('2026-10-28 00:00:00+00');


--
-- Name: queue_stats_20261028; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats ATTACH PARTITION pgboss.queue_stats_20261028 FOR VALUES FROM ('2026-10-28 00:00:00+00') TO ('2026-10-29 00:00:00+00');


--
-- Name: run_signals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals ALTER COLUMN id SET DEFAULT nextval('public.run_signals_id_seq'::regclass);


--
-- Name: runs seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs ALTER COLUMN seq SET DEFAULT nextval('public.runs_seq_seq'::regclass);


--
-- Data for Name: bam; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: job_common; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.job_common VALUES ('f41feddf-833a-4591-b61c-5571a0a4ba2a', 'cron-tick', 0, '{}', 'completed', 0, 0, 0, false, NULL, 60, 604800, NULL, '2026-10-27 17:46:25', NULL, NULL, '2026-10-27 17:46:28.102998+00', '2026-10-27 17:46:28.102998+00', '2026-10-27 17:46:29.099238+00', '2026-10-27 17:46:29.128366+00', '2026-11-10 17:46:28.102998+00', NULL, NULL, 'short', '2026-10-27 17:46:29.099238+00', NULL, false, false, 0, NULL, NULL, NULL, NULL);
INSERT INTO pgboss.job_common VALUES ('2900f33f-228e-409d-a599-cff45edf5b1f', 'cron-tick', 0, '{}', 'completed', 0, 0, 0, false, NULL, 60, 604800, NULL, '2026-10-27 17:46:30', NULL, NULL, '2026-10-27 17:46:30.100733+00', '2026-10-27 17:46:30.100733+00', '2026-10-27 17:46:31.100995+00', '2026-10-27 17:46:31.104371+00', '2026-11-10 17:46:30.100733+00', NULL, NULL, 'short', '2026-10-27 17:46:31.100995+00', NULL, false, false, 0, NULL, NULL, NULL, NULL);
INSERT INTO pgboss.job_common VALUES ('7d199161-d6d0-483e-8ff3-4b3b20db438c', 'cron-tick', 0, '{}', 'completed', 0, 0, 0, false, NULL, 60, 604800, NULL, '2026-10-27 17:46:35', NULL, NULL, '2026-10-27 17:46:35.100785+00', '2026-10-27 17:46:35.100785+00', '2026-10-27 17:46:36.101467+00', '2026-10-27 17:46:36.104095+00', '2026-11-10 17:46:35.100785+00', NULL, NULL, 'short', '2026-10-27 17:46:36.101467+00', NULL, false, false, 0, NULL, NULL, NULL, NULL);
INSERT INTO pgboss.job_common VALUES ('0facb73f-8794-4b8e-81d8-855152db7c68', 'cron-tick', 0, '{}', 'completed', 0, 0, 0, false, NULL, 60, 604800, NULL, '2026-10-27 17:46:40', NULL, NULL, '2026-10-27 17:46:40.101217+00', '2026-10-27 17:46:40.101217+00', '2026-10-27 17:46:41.101527+00', '2026-10-27 17:46:41.105713+00', '2026-11-10 17:46:40.101217+00', NULL, NULL, 'short', '2026-10-27 17:46:41.101527+00', NULL, false, false, 0, NULL, NULL, NULL, NULL);
INSERT INTO pgboss.job_common VALUES ('14d5b9d6-e637-4904-8698-f2a4ebeff6a7', 'cron-tick', 0, '{}', 'completed', 0, 0, 0, false, NULL, 60, 604800, NULL, '2026-10-27 17:46:45', NULL, NULL, '2026-10-27 17:46:45.102746+00', '2026-10-27 17:46:45.102746+00', '2026-10-27 17:46:46.103304+00', '2026-10-27 17:46:46.107185+00', '2026-11-10 17:46:45.102746+00', NULL, NULL, 'short', '2026-10-27 17:46:46.103304+00', NULL, false, false, 0, NULL, NULL, NULL, NULL);
INSERT INTO pgboss.job_common VALUES ('cddbe78e-5658-4a53-8cf2-fda53864463e', 'cron-tick', 0, '{}', 'completed', 0, 0, 0, false, NULL, 60, 604800, NULL, '2026-10-27 17:46:50', NULL, NULL, '2026-10-27 17:46:50.105382+00', '2026-10-27 17:46:50.105382+00', '2026-10-27 17:46:51.105572+00', '2026-10-27 17:46:51.1089+00', '2026-11-10 17:46:50.105382+00', NULL, NULL, 'short', '2026-10-27 17:46:51.105572+00', NULL, false, false, 0, NULL, NULL, NULL, NULL);
INSERT INTO pgboss.job_common VALUES ('e1bb1868-07e3-4894-9b45-b61a11f416b5', 'cron-tick', 0, '{}', 'completed', 0, 0, 0, false, NULL, 60, 604800, NULL, '2026-10-27 17:46:55', NULL, NULL, '2026-10-27 17:46:55.109061+00', '2026-10-27 17:46:55.109061+00', '2026-10-27 17:46:56.107792+00', '2026-10-27 17:46:56.1112+00', '2026-11-10 17:46:55.109061+00', NULL, NULL, 'short', '2026-10-27 17:46:56.107792+00', NULL, false, false, 0, NULL, NULL, NULL, NULL);
INSERT INTO pgboss.job_common VALUES ('3dc02fb3-f32f-4a77-bc23-da1c460aac04', 'cron-tick', 0, '{}', 'completed', 0, 0, 0, false, NULL, 60, 604800, NULL, '2026-10-27 17:47:00', NULL, NULL, '2026-10-27 17:47:00.10869+00', '2026-10-27 17:47:00.10869+00', '2026-10-27 17:47:01.109102+00', '2026-10-27 17:47:01.11514+00', '2026-11-10 17:47:00.10869+00', NULL, NULL, 'short', '2026-10-27 17:47:01.109102+00', NULL, false, false, 0, NULL, NULL, NULL, NULL);
INSERT INTO pgboss.job_common VALUES ('3ee3498e-1afe-4f8f-9867-30c20487b374', 'cron-tick', 0, '{}', 'created', 0, 0, 0, false, NULL, 60, 604800, NULL, '2026-10-27 17:47:05', NULL, NULL, '2026-10-27 17:47:05.111536+00', '2026-10-27 17:47:05.111536+00', NULL, NULL, '2026-11-10 17:47:05.111536+00', NULL, NULL, 'short', NULL, NULL, false, false, 0, NULL, NULL, NULL, NULL);


--
-- Data for Name: job_dependency; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: queue; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.queue VALUES ('__pgboss__send-it', 'standard', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, '{}', NULL, false, NULL, NULL, NULL, '2026-10-27 17:46:28.087176+00', '2026-10-27 17:46:28.087176+00');
INSERT INTO pgboss.queue VALUES ('cron-fire', 'short', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, '{}', NULL, true, NULL, NULL, NULL, '2026-10-27 17:46:28.096179+00', '2026-10-27 17:46:28.096179+00');
INSERT INTO pgboss.queue VALUES ('cron-tick', 'short', 2, 0, false, NULL, 900, 1209600, 604800, NULL, false, 'job_common', 0, 0, 0, 0, 0, 0, 0, '{}', NULL, true, NULL, NULL, NULL, '2026-10-27 17:46:28.098918+00', '2026-10-27 17:46:28.098918+00');


--
-- Data for Name: queue_stats_20261027; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: queue_stats_20261028; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: schedule; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: subscription; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: version; Type: TABLE DATA; Schema: pgboss; Owner: -
--

INSERT INTO pgboss.version VALUES (37, '2026-10-27 17:46:28.096497+00', '2026-10-27 17:46:28.096217+00', '2026-10-27 17:47:03.088888+00');


--
-- Data for Name: warning; Type: TABLE DATA; Schema: pgboss; Owner: -
--



--
-- Data for Name: ack_emoji; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_grant_modes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approved_harness_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auto_flagger_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: base_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: branding_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: browse_max_steps_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: browse_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_header_pin_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: command_policies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cron_fire_log; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: crons; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: custom_model_providers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deactivated_principals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deployment_identity; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.deployment_identity VALUES ('singleton', '{"orgId": "default-org"}');


--
-- Data for Name: deployment_layer; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: durable_map_versions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.durable_map_versions VALUES ('deployment_identity', 1);
INSERT INTO public.durable_map_versions VALUES ('skills', 63);


--
-- Data for Name: egress_policies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: external_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: external_slack_participants_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: individual_model_auth_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: interactive_fast_mode_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: keychain_asks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mcp_servers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: monitors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: org_ambient_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: people_directory_urls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: process_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_signals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.schema_migrations VALUES ('durable-map/webhooks/0002-disable-rows-orphaned-by-webhook-removal', '2026-10-27 17:46:27.842168+00');


--
-- Data for Name: security_postures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: slack_installation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: soul_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: soul_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tool_calls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: turn_wall_clock_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: unfulfilled_insights_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webui_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: run_signals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.run_signals_id_seq', 1, false);


--
-- Name: runs_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.runs_seq_seq', 1, false);


--
-- Name: bam bam_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.bam
    ADD CONSTRAINT bam_pkey PRIMARY KEY (id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (name, id);


--
-- Name: job_common job_common_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT job_common_pkey PRIMARY KEY (name, id);


--
-- Name: job_dependency job_dependency_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_dependency
    ADD CONSTRAINT job_dependency_pkey PRIMARY KEY (child_name, child_id, parent_name, parent_id);


--
-- Name: queue queue_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue
    ADD CONSTRAINT queue_pkey PRIMARY KEY (name);


--
-- Name: queue_stats queue_stats_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats
    ADD CONSTRAINT queue_stats_pkey PRIMARY KEY (id, captured_on);


--
-- Name: queue_stats_20261027 queue_stats_20261027_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats_20261027
    ADD CONSTRAINT queue_stats_20261027_pkey PRIMARY KEY (id, captured_on);


--
-- Name: queue_stats_20261028 queue_stats_20261028_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue_stats_20261028
    ADD CONSTRAINT queue_stats_20261028_pkey PRIMARY KEY (id, captured_on);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (name, key);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (event, name);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (version);


--
-- Name: warning warning_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.warning
    ADD CONSTRAINT warning_pkey PRIMARY KEY (id);


--
-- Name: ack_emoji ack_emoji_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji
    ADD CONSTRAINT ack_emoji_pkey PRIMARY KEY (id);


--
-- Name: approval_grant_modes approval_grant_modes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grant_modes
    ADD CONSTRAINT approval_grant_modes_pkey PRIMARY KEY (id);


--
-- Name: approved_harness_configs approved_harness_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approved_harness_configs
    ADD CONSTRAINT approved_harness_configs_pkey PRIMARY KEY (id);


--
-- Name: auto_flagger_configs auto_flagger_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_flagger_configs
    ADD CONSTRAINT auto_flagger_configs_pkey PRIMARY KEY (id);


--
-- Name: base_model_configs base_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.base_model_configs
    ADD CONSTRAINT base_model_configs_pkey PRIMARY KEY (id);


--
-- Name: branding_configs branding_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_configs
    ADD CONSTRAINT branding_configs_pkey PRIMARY KEY (id);


--
-- Name: browse_max_steps_configs browse_max_steps_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_max_steps_configs
    ADD CONSTRAINT browse_max_steps_configs_pkey PRIMARY KEY (id);


--
-- Name: browse_model_configs browse_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_model_configs
    ADD CONSTRAINT browse_model_configs_pkey PRIMARY KEY (id);


--
-- Name: channel_header_pin_flag channel_header_pin_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_header_pin_flag
    ADD CONSTRAINT channel_header_pin_flag_pkey PRIMARY KEY (id);


--
-- Name: command_policies command_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_policies
    ADD CONSTRAINT command_policies_pkey PRIMARY KEY (id);


--
-- Name: cron_fire_log cron_fire_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_fire_log
    ADD CONSTRAINT cron_fire_log_pkey PRIMARY KEY (cron_id, fire_key);


--
-- Name: crons crons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crons
    ADD CONSTRAINT crons_pkey PRIMARY KEY (id);


--
-- Name: custom_model_providers custom_model_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_model_providers
    ADD CONSTRAINT custom_model_providers_pkey PRIMARY KEY (id);


--
-- Name: deactivated_principals deactivated_principals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deactivated_principals
    ADD CONSTRAINT deactivated_principals_pkey PRIMARY KEY (id);


--
-- Name: deployment_identity deployment_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_identity
    ADD CONSTRAINT deployment_identity_pkey PRIMARY KEY (id);


--
-- Name: deployment_layer deployment_layer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_layer
    ADD CONSTRAINT deployment_layer_pkey PRIMARY KEY (id);


--
-- Name: durable_map_versions durable_map_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.durable_map_versions
    ADD CONSTRAINT durable_map_versions_pkey PRIMARY KEY (tbl);


--
-- Name: egress_policies egress_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_policies
    ADD CONSTRAINT egress_policies_pkey PRIMARY KEY (id);


--
-- Name: external_members external_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_members
    ADD CONSTRAINT external_members_pkey PRIMARY KEY (id);


--
-- Name: external_slack_participants_flag external_slack_participants_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_slack_participants_flag
    ADD CONSTRAINT external_slack_participants_flag_pkey PRIMARY KEY (id);


--
-- Name: individual_model_auth_flag individual_model_auth_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.individual_model_auth_flag
    ADD CONSTRAINT individual_model_auth_flag_pkey PRIMARY KEY (id);


--
-- Name: interactive_fast_mode_flag interactive_fast_mode_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interactive_fast_mode_flag
    ADD CONSTRAINT interactive_fast_mode_flag_pkey PRIMARY KEY (id);


--
-- Name: keychain_asks keychain_asks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_asks
    ADD CONSTRAINT keychain_asks_pkey PRIMARY KEY (id);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (id);


--
-- Name: monitors monitors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_pkey PRIMARY KEY (id);


--
-- Name: org_ambient_flag org_ambient_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_ambient_flag
    ADD CONSTRAINT org_ambient_flag_pkey PRIMARY KEY (id);


--
-- Name: people_directory_urls people_directory_urls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.people_directory_urls
    ADD CONSTRAINT people_directory_urls_pkey PRIMARY KEY (id);


--
-- Name: process_sessions process_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_sessions
    ADD CONSTRAINT process_sessions_pkey PRIMARY KEY (process_id);


--
-- Name: run_signals run_signals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals
    ADD CONSTRAINT run_signals_pkey PRIMARY KEY (id);


--
-- Name: runs runs_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: runs runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: security_postures security_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_postures
    ADD CONSTRAINT security_postures_pkey PRIMARY KEY (id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (id);


--
-- Name: slack_installation slack_installation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_installation
    ADD CONSTRAINT slack_installation_pkey PRIMARY KEY (id);


--
-- Name: soul_configs soul_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_configs
    ADD CONSTRAINT soul_configs_pkey PRIMARY KEY (id);


--
-- Name: soul_history soul_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_history
    ADD CONSTRAINT soul_history_pkey PRIMARY KEY (id);


--
-- Name: tool_calls tool_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_calls
    ADD CONSTRAINT tool_calls_pkey PRIMARY KEY (run_id, attempt, call_index);


--
-- Name: turn_wall_clock_configs turn_wall_clock_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.turn_wall_clock_configs
    ADD CONSTRAINT turn_wall_clock_configs_pkey PRIMARY KEY (id);


--
-- Name: unfulfilled_insights_flag unfulfilled_insights_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unfulfilled_insights_flag
    ADD CONSTRAINT unfulfilled_insights_flag_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: webui_model_configs webui_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webui_model_configs
    ADD CONSTRAINT webui_model_configs_pkey PRIMARY KEY (id);


--
-- Name: job_common_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i1 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: job_common_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i2 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: job_common_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i3 ON pgboss.job_common USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: job_common_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i4 ON pgboss.job_common USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: job_common_i5; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i5 ON pgboss.job_common USING btree (name, start_after) WHERE ((state < 'active'::pgboss.job_state) AND (NOT blocked));


--
-- Name: job_common_i6; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i6 ON pgboss.job_common USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'exclusive'::text));


--
-- Name: job_common_i7; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i7 ON pgboss.job_common USING btree (name, group_id) WHERE ((state = 'active'::pgboss.job_state) AND (group_id IS NOT NULL));


--
-- Name: job_common_i8; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX job_common_i8 ON pgboss.job_common USING btree (name, singleton_key) WHERE ((state = ANY (ARRAY['active'::pgboss.job_state, 'retry'::pgboss.job_state, 'failed'::pgboss.job_state])) AND (policy = 'key_strict_fifo'::text));


--
-- Name: job_common_i9; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_common_i9 ON pgboss.job_common USING btree (name, id) WHERE (blocking AND (state = 'completed'::pgboss.job_state));


--
-- Name: job_dep_parent_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX job_dep_parent_idx ON pgboss.job_dependency USING btree (parent_name, parent_id);


--
-- Name: queue_stats_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_i1 ON ONLY pgboss.queue_stats USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: queue_stats_20261027_name_captured_on_deferred_count_queued_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_20261027_name_captured_on_deferred_count_queued_idx ON pgboss.queue_stats_20261027 USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: queue_stats_20261028_name_captured_on_deferred_count_queued_idx; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX queue_stats_20261028_name_captured_on_deferred_count_queued_idx ON pgboss.queue_stats_20261028 USING btree (name, captured_on DESC) INCLUDE (deferred_count, queued_count, ready_count, active_count, failed_count, total_count);


--
-- Name: warning_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX warning_i1 ON pgboss.warning USING btree (created_on DESC);


--
-- Name: cron_fire_log_cron_fired_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cron_fire_log_cron_fired_idx ON public.cron_fire_log USING btree (cron_id, fired_at DESC, fire_key DESC);


--
-- Name: cron_fire_log_inline_cron_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cron_fire_log_inline_cron_idx ON public.crons USING btree (id) WHERE (json ? 'fireLog'::text);


--
-- Name: idx_proc_scope_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proc_scope_status ON public.process_sessions USING btree (scope_id, status);


--
-- Name: idx_run_signals_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_signals_pending ON public.run_signals USING btree (run_id) WHERE (consumed_at IS NULL);


--
-- Name: idx_runs_one_running_per_session; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_runs_one_running_per_session ON public.runs USING btree (session_id) WHERE (status = 'running'::text);


--
-- Name: idx_runs_session_active_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_active_created ON public.runs USING btree (session_id, created_at DESC) WHERE (status = ANY (ARRAY['pending'::text, 'running'::text]));


--
-- Name: idx_runs_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created ON public.runs USING btree (status, created_at);


--
-- Name: idx_runs_status_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created_seq ON public.runs USING btree (status, created_at, seq);


--
-- Name: job_common_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.job_common_pkey;


--
-- Name: queue_stats_20261027_name_captured_on_deferred_count_queued_idx; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_i1 ATTACH PARTITION pgboss.queue_stats_20261027_name_captured_on_deferred_count_queued_idx;


--
-- Name: queue_stats_20261027_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_pkey ATTACH PARTITION pgboss.queue_stats_20261027_pkey;


--
-- Name: queue_stats_20261028_name_captured_on_deferred_count_queued_idx; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_i1 ATTACH PARTITION pgboss.queue_stats_20261028_name_captured_on_deferred_count_queued_idx;


--
-- Name: queue_stats_20261028_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.queue_stats_pkey ATTACH PARTITION pgboss.queue_stats_20261028_pkey;


--
-- Name: job_common dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: job_common q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job_common
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: queue queue_dead_letter_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue
    ADD CONSTRAINT queue_dead_letter_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name);


--
-- Name: schedule schedule_name_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.schedule
    ADD CONSTRAINT schedule_name_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE CASCADE;


--
-- Name: subscription subscription_name_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.subscription
    ADD CONSTRAINT subscription_name_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE CASCADE;


--
-- Name: cron_fire_log cron_fire_log_cron_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_fire_log
    ADD CONSTRAINT cron_fire_log_cron_id_fkey FOREIGN KEY (cron_id) REFERENCES public.crons(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


