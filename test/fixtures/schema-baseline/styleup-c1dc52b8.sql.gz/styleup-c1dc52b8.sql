--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: absurd; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA absurd;


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: item_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.item_kind AS ENUM (
    'UserMessage',
    'SteeringMessage',
    'AgentMessage',
    'Reasoning',
    'ToolCall',
    'ToolResult',
    'Elicitation',
    'ElicitationResponse',
    'Wake',
    'Error',
    'ContextCompaction',
    'Retraction',
    'Stop',
    'RuntimeChange'
);


--
-- Name: wake_cause; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.wake_cause AS ENUM (
    'cron',
    'webhook',
    'child_done',
    'system'
);


--
-- Name: await_event(text, uuid, uuid, text, text, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.await_event(p_queue_name text, p_task_id uuid, p_run_id uuid, p_step_name text, p_event_name text, p_timeout integer DEFAULT NULL::integer) RETURNS TABLE(should_suspend boolean, payload jsonb)
    LANGUAGE plpgsql
    AS $_$
declare
  v_run_state text;
  v_existing_payload jsonb;
  v_event_payload jsonb;
  v_checkpoint_payload jsonb;
  v_resolved_payload jsonb;
  v_timeout_at timestamptz;
  v_available_at timestamptz;
  v_now timestamptz := absurd.current_time();
  v_task_state text;
  v_wake_event text;
begin
  if p_event_name is null or length(trim(p_event_name)) = 0 then
    raise exception 'event_name must be provided';
  end if;

  if p_timeout is not null then
    if p_timeout < 0 then
      raise exception 'timeout must be non-negative';
    end if;
    v_timeout_at := v_now + (p_timeout::double precision * interval '1 second');
  end if;

  v_available_at := coalesce(v_timeout_at, 'infinity'::timestamptz);

  execute format(
    'select state
       from absurd.%I
      where task_id = $1
        and checkpoint_name = $2',
    'c_' || p_queue_name
  )
  into v_checkpoint_payload
  using p_task_id, p_step_name;

  if v_checkpoint_payload is not null then
    return query select false, v_checkpoint_payload;
    return;
  end if;

  -- Ensure a row exists for this event so we can take a row-level lock.
  --
  -- We use payload IS NULL as the sentinel for "not emitted yet".  emit_event
  -- always writes a non-NULL payload (at minimum JSON null).
  --
  -- Lock ordering is important to avoid deadlocks: await_event locks the event
  -- row first (FOR SHARE) and then the run row (FOR UPDATE).  emit_event
  -- naturally locks the event row via its UPSERT before touching waits/runs.
  execute format(
    'insert into absurd.%I (event_name, payload, emitted_at)
     values ($1, null, ''epoch''::timestamptz)
     on conflict (event_name) do nothing',
    'e_' || p_queue_name
  ) using p_event_name;

  execute format(
    'select 1
       from absurd.%I
      where event_name = $1
      for share',
    'e_' || p_queue_name
  ) using p_event_name;

  execute format(
    'select r.state, r.event_payload, r.wake_event, t.state
       from absurd.%I r
       join absurd.%I t on t.task_id = r.task_id
      where r.run_id = $1
      for update',
    'r_' || p_queue_name,
    't_' || p_queue_name
  )
  into v_run_state, v_existing_payload, v_wake_event, v_task_state
  using p_run_id;

  if v_run_state is null then
    raise exception 'Run "%" not found while awaiting event', p_run_id;
  end if;

  if v_task_state = 'cancelled' then
    raise exception sqlstate 'AB001' using message = 'Task has been cancelled';
  end if;

  execute format(
    'select payload
       from absurd.%I
      where event_name = $1',
    'e_' || p_queue_name
  )
  into v_event_payload
  using p_event_name;

  if v_existing_payload is not null then
    execute format(
      'update absurd.%I
          set event_payload = null
        where run_id = $1',
      'r_' || p_queue_name
    ) using p_run_id;

    if v_event_payload is not null and v_event_payload = v_existing_payload then
      v_resolved_payload := v_existing_payload;
    end if;
  end if;

  if v_run_state <> 'running' then
    raise exception 'Run "%" must be running to await events', p_run_id;
  end if;

  if v_resolved_payload is null and v_event_payload is not null then
    v_resolved_payload := v_event_payload;
  end if;

  if v_resolved_payload is not null then
    execute format(
      'insert into absurd.%I (task_id, checkpoint_name, state, status, owner_run_id, updated_at)
       values ($1, $2, $3, ''committed'', $4, $5)
       on conflict (task_id, checkpoint_name)
       do update set state = excluded.state,
                     status = excluded.status,
                     owner_run_id = excluded.owner_run_id,
                     updated_at = excluded.updated_at',
      'c_' || p_queue_name
    ) using p_task_id, p_step_name, v_resolved_payload, p_run_id, v_now;
    return query select false, v_resolved_payload;
    return;
  end if;

  -- Detect if we resumed due to timeout: wake_event matches and payload is null
  if v_resolved_payload is null and v_wake_event = p_event_name and v_existing_payload is null then
    -- Resumed due to timeout; don't re-sleep and don't create a new wait
    execute format(
      'update absurd.%I set wake_event = null where run_id = $1',
      'r_' || p_queue_name
    ) using p_run_id;
    return query select false, null::jsonb;
    return;
  end if;

  execute format(
    'insert into absurd.%I (task_id, run_id, step_name, event_name, timeout_at, created_at)
     values ($1, $2, $3, $4, $5, $6)
     on conflict (run_id, step_name)
     do update set event_name = excluded.event_name,
                   timeout_at = excluded.timeout_at,
                   created_at = excluded.created_at',
    'w_' || p_queue_name
  ) using p_task_id, p_run_id, p_step_name, p_event_name, v_timeout_at, v_now;

  execute format(
    'update absurd.%I
        set state = ''sleeping'',
            claimed_by = null,
            claim_expires_at = null,
            available_at = $3,
            wake_event = $2,
            event_payload = null
      where run_id = $1',
    'r_' || p_queue_name
  ) using p_run_id, p_event_name, v_available_at;

  execute format(
    'update absurd.%I
        set state = ''sleeping''
      where task_id = $1',
    't_' || p_queue_name
  ) using p_task_id;

  return query select true, null::jsonb;
  return;
end;
$_$;


--
-- Name: cancel_task(text, uuid); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.cancel_task(p_queue_name text, p_task_id uuid) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_task_state text;
begin
  -- Lock active runs before the task row so cancel_task() uses the same
  -- lock acquisition order as complete_run()/fail_run().
  execute format(
    'select run_id
       from absurd.%I
      where task_id = $1
        and state not in (''completed'', ''failed'', ''cancelled'')
      order by run_id
      for update',
    'r_' || p_queue_name
  ) using p_task_id;

  execute format(
    'select state
       from absurd.%I
      where task_id = $1
      for update',
    't_' || p_queue_name
  )
  into v_task_state
  using p_task_id;

  if v_task_state is null then
    raise exception 'Task "%" not found in queue "%"', p_task_id, p_queue_name;
  end if;

  if v_task_state in ('completed', 'failed', 'cancelled') then
    return;
  end if;

  execute format(
    'update absurd.%I
        set state = ''cancelled'',
            cancelled_at = coalesce(cancelled_at, $2)
      where task_id = $1',
    't_' || p_queue_name
  ) using p_task_id, v_now;

  execute format(
    'update absurd.%I
        set state = ''cancelled'',
            claimed_by = null,
            claim_expires_at = null
      where task_id = $1
        and state not in (''completed'', ''failed'', ''cancelled'')',
    'r_' || p_queue_name
  ) using p_task_id;

  execute format(
    'delete from absurd.%I where task_id = $1',
    'w_' || p_queue_name
  ) using p_task_id;
end;
$_$;


--
-- Name: claim_task(text, text, integer, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.claim_task(p_queue_name text, p_worker_id text, p_claim_timeout integer DEFAULT 30, p_qty integer DEFAULT 1) RETURNS TABLE(run_id uuid, task_id uuid, attempt integer, task_name text, params jsonb, retry_strategy jsonb, max_attempts integer, headers jsonb, wake_event text, event_payload jsonb)
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_claim_timeout integer := greatest(coalesce(p_claim_timeout, 30), 0);
  v_worker_id text := coalesce(nullif(p_worker_id, ''), 'worker');
  v_qty integer := greatest(coalesce(p_qty, 1), 1);
  v_claim_until timestamptz := null;
  v_sql text;
  v_expired_run record;
  v_cancel_candidate record;
  v_expired_sweep_limit integer;
begin
  if v_claim_timeout > 0 then
    v_claim_until := v_now + make_interval(secs => v_claim_timeout);
  end if;

  -- Keep claim polling work bounded: process at most v_qty expired leases
  -- per claim call.
  v_expired_sweep_limit := greatest(v_qty, 1);

  -- Apply cancellation rules before claiming.
  --
  -- Use cancel_task() so lock order stays consistent (runs first, task second)
  -- with complete_run()/fail_run().
  for v_cancel_candidate in
    execute format(
      'select task_id
         from absurd.%I
        where state in (''pending'', ''sleeping'', ''running'')
          and cancellation is not null
          and (
            (
              (cancellation->>''max_delay'')::bigint is not null
              and first_started_at is null
              and extract(epoch from ($1 - enqueue_at)) >= (cancellation->>''max_delay'')::bigint
            )
            or
            (
              (cancellation->>''max_duration'')::bigint is not null
              and first_started_at is not null
              and extract(epoch from ($1 - first_started_at)) >= (cancellation->>''max_duration'')::bigint
            )
          )
        order by task_id',
      't_' || p_queue_name
    )
  using v_now
  loop
    perform absurd.cancel_task(p_queue_name, v_cancel_candidate.task_id);
  end loop;

  for v_expired_run in
    execute format(
      'select run_id,
              claimed_by,
              claim_expires_at,
              attempt
         from absurd.%I
        where state = ''running''
          and claim_expires_at is not null
          and claim_expires_at <= $1
        order by claim_expires_at, run_id
        limit $2
        for update skip locked',
      'r_' || p_queue_name
    )
  using v_now, v_expired_sweep_limit
  loop
    perform absurd.fail_run(
      p_queue_name,
      v_expired_run.run_id,
      jsonb_strip_nulls(jsonb_build_object(
        'name', '$ClaimTimeout',
        'message', 'worker did not finish task within claim interval',
        'workerId', v_expired_run.claimed_by,
        'claimExpiredAt', v_expired_run.claim_expires_at,
        'attempt', v_expired_run.attempt
      )),
      null
    );
  end loop;

  v_sql := format(
    'with candidate as (
        select r.run_id
          from absurd.%1$I r
          join absurd.%2$I t on t.task_id = r.task_id
         where r.state in (''pending'', ''sleeping'')
           and t.state in (''pending'', ''sleeping'', ''running'')
           and r.available_at <= $1
         order by r.available_at, r.run_id
         limit $2
         for update skip locked
     ),
     updated as (
        update absurd.%1$I r
           set state = ''running'',
               claimed_by = $3,
               claim_expires_at = $4,
               started_at = $1,
               available_at = $1
         where run_id in (select run_id from candidate)
         returning r.run_id, r.task_id, r.attempt
     ),
     task_upd as (
        update absurd.%2$I t
           set state = ''running'',
               attempts = greatest(t.attempts, u.attempt),
               first_started_at = coalesce(t.first_started_at, $1),
               last_attempt_run = u.run_id
          from updated u
         where t.task_id = u.task_id
         returning t.task_id
     ),
     wait_cleanup as (
        delete from absurd.%3$I w
         using updated u
        where w.run_id = u.run_id
          and w.timeout_at is not null
          and w.timeout_at <= $1
        returning w.run_id
     )
     select
       u.run_id,
       u.task_id,
       u.attempt,
       t.task_name,
       t.params,
       t.retry_strategy,
       t.max_attempts,
      t.headers,
      r.wake_event,
      r.event_payload
     from updated u
     join absurd.%1$I r on r.run_id = u.run_id
     join absurd.%2$I t on t.task_id = u.task_id
     order by r.available_at, u.run_id',
    'r_' || p_queue_name,
    't_' || p_queue_name,
    'w_' || p_queue_name
  );

  return query execute v_sql using v_now, v_qty, v_worker_id, v_claim_until;
end;
$_$;


--
-- Name: cleanup_all_queues(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.cleanup_all_queues(p_queue_name text DEFAULT NULL::text) RETURNS TABLE(queue_name text, tasks_deleted integer, events_deleted integer)
    LANGUAGE plpgsql
    AS $$
declare
  v_queue record;
  v_cleanup_ttl_seconds integer;
begin
  if p_queue_name is not null then
    p_queue_name := absurd.validate_queue_name(p_queue_name);

    if not exists (
      select 1
      from absurd.queues q
      where q.queue_name = p_queue_name
    ) then
      raise exception 'Queue "%" does not exist', p_queue_name;
    end if;
  end if;

  for v_queue in
    select
      q.queue_name,
      q.cleanup_ttl,
      q.cleanup_limit
    from absurd.queues q
    where p_queue_name is null or q.queue_name = p_queue_name
    order by q.queue_name
  loop
    v_cleanup_ttl_seconds := greatest(
      floor(extract(epoch from v_queue.cleanup_ttl))::integer,
      0
    );

    queue_name := v_queue.queue_name;
    tasks_deleted := absurd.cleanup_tasks(
      v_queue.queue_name,
      v_cleanup_ttl_seconds,
      v_queue.cleanup_limit
    );
    events_deleted := absurd.cleanup_events(
      v_queue.queue_name,
      v_cleanup_ttl_seconds,
      v_queue.cleanup_limit
    );
    return next;
  end loop;
end;
$$;


--
-- Name: cleanup_events(text, integer, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.cleanup_events(p_queue_name text, p_ttl_seconds integer, p_limit integer DEFAULT 1000) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_cutoff timestamptz;
  v_deleted_count integer;
begin
  if p_ttl_seconds is null or p_ttl_seconds < 0 then
    raise exception 'TTL must be a non-negative number of seconds';
  end if;

  v_cutoff := v_now - (p_ttl_seconds * interval '1 second');

  execute format(
    'with to_delete as (
        select event_name
          from absurd.%I
         where emitted_at < $1
         order by emitted_at
         limit $2
     ),
     del_events as (
        delete from absurd.%I e
         where e.event_name in (select event_name from to_delete)
         returning 1
     )
     select count(*) from del_events',
    'e_' || p_queue_name,
    'e_' || p_queue_name
  )
  into v_deleted_count
  using v_cutoff, p_limit;

  return v_deleted_count;
end;
$_$;


--
-- Name: cleanup_tasks(text, integer, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.cleanup_tasks(p_queue_name text, p_ttl_seconds integer, p_limit integer DEFAULT 1000) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_cutoff timestamptz;
  v_deleted_count integer;
  v_storage_mode text := 'unpartitioned';
begin
  if p_ttl_seconds is null or p_ttl_seconds < 0 then
    raise exception 'TTL must be a non-negative number of seconds';
  end if;

  v_cutoff := v_now - (p_ttl_seconds * interval '1 second');

  select storage_mode into v_storage_mode
  from absurd.queues
  where queue_name = p_queue_name;

  v_storage_mode := coalesce(v_storage_mode, 'unpartitioned');

  if v_storage_mode = 'partitioned' then
    -- Delete in order: wait registrations, checkpoints, runs, idempotency keys,
    -- then tasks.
    execute format(
      'with eligible_tasks as (
          select t.task_id,
                 case
                   when t.state = ''completed'' then r.completed_at
                   when t.state = ''failed'' then r.failed_at
                   when t.state = ''cancelled'' then t.cancelled_at
                   else null
                 end as terminal_at
            from absurd.%1$I t
            left join absurd.%2$I r on r.run_id = t.last_attempt_run
           where t.state in (''completed'', ''failed'', ''cancelled'')
       ),
       to_delete as (
          select task_id
            from eligible_tasks
           where terminal_at is not null
             and terminal_at < $1
           order by terminal_at
           limit $2
       ),
       del_waits as (
          delete from absurd.%3$I w
           where w.task_id in (select task_id from to_delete)
       ),
       del_checkpoints as (
          delete from absurd.%4$I c
           where c.task_id in (select task_id from to_delete)
       ),
       del_runs as (
          delete from absurd.%2$I r
           where r.task_id in (select task_id from to_delete)
       ),
       del_idempotency as (
          delete from absurd.%5$I i
           where i.task_id in (select task_id from to_delete)
       ),
       del_tasks as (
          delete from absurd.%1$I t
           where t.task_id in (select task_id from to_delete)
           returning 1
       )
       select count(*) from del_tasks',
      't_' || p_queue_name,
      'r_' || p_queue_name,
      'w_' || p_queue_name,
      'c_' || p_queue_name,
      'i_' || p_queue_name
    )
    into v_deleted_count
    using v_cutoff, p_limit;
  else
    -- Unpartitioned queues keep idempotency key ownership on the task row,
    -- so no side-table cleanup is needed.
    execute format(
      'with eligible_tasks as (
          select t.task_id,
                 case
                   when t.state = ''completed'' then r.completed_at
                   when t.state = ''failed'' then r.failed_at
                   when t.state = ''cancelled'' then t.cancelled_at
                   else null
                 end as terminal_at
            from absurd.%1$I t
            left join absurd.%2$I r on r.run_id = t.last_attempt_run
           where t.state in (''completed'', ''failed'', ''cancelled'')
       ),
       to_delete as (
          select task_id
            from eligible_tasks
           where terminal_at is not null
             and terminal_at < $1
           order by terminal_at
           limit $2
       ),
       del_waits as (
          delete from absurd.%3$I w
           where w.task_id in (select task_id from to_delete)
       ),
       del_checkpoints as (
          delete from absurd.%4$I c
           where c.task_id in (select task_id from to_delete)
       ),
       del_runs as (
          delete from absurd.%2$I r
           where r.task_id in (select task_id from to_delete)
       ),
       del_tasks as (
          delete from absurd.%1$I t
           where t.task_id in (select task_id from to_delete)
           returning 1
       )
       select count(*) from del_tasks',
      't_' || p_queue_name,
      'r_' || p_queue_name,
      'w_' || p_queue_name,
      'c_' || p_queue_name
    )
    into v_deleted_count
    using v_cutoff, p_limit;
  end if;

  return v_deleted_count;
end;
$_$;


--
-- Name: complete_run(text, uuid, jsonb); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.complete_run(p_queue_name text, p_run_id uuid, p_state jsonb DEFAULT NULL::jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_task_id uuid;
  v_state text;
  v_now timestamptz := absurd.current_time();
begin
  execute format(
    'select task_id, state
       from absurd.%I
      where run_id = $1
      for update',
    'r_' || p_queue_name
  )
  into v_task_id, v_state
  using p_run_id;

  if v_task_id is null then
    raise exception 'Run "%" not found in queue "%"', p_run_id, p_queue_name;
  end if;

  if v_state <> 'running' then
    if v_state = 'cancelled' then
      raise exception sqlstate 'AB001' using message = 'Task has been cancelled';
    end if;
    if v_state = 'failed' then
      raise exception sqlstate 'AB002' using message = format('Run "%s" has already failed in queue "%s"', p_run_id, p_queue_name);
    end if;
    raise exception 'Run "%" is not currently running in queue "%"', p_run_id, p_queue_name;
  end if;

  execute format(
    'update absurd.%I
        set state = ''completed'',
            completed_at = $2,
            result = $3
      where run_id = $1',
    'r_' || p_queue_name
  ) using p_run_id, v_now, p_state;

  execute format(
    'update absurd.%I
        set state = ''completed'',
            completed_payload = $2,
            last_attempt_run = $3
      where task_id = $1',
    't_' || p_queue_name
  ) using v_task_id, p_state, p_run_id;

  execute format(
    'delete from absurd.%I where run_id = $1',
    'w_' || p_queue_name
  ) using p_run_id;
end;
$_$;


--
-- Name: create_queue(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.create_queue(p_queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform absurd.create_queue(p_queue_name, 'unpartitioned');
end;
$$;


--
-- Name: create_queue(text, text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.create_queue(p_queue_name text, p_storage_mode text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_storage_mode text;
  v_existing_mode text;
begin
  p_queue_name := absurd.validate_queue_name(p_queue_name);

  v_storage_mode := lower(trim(coalesce(p_storage_mode, '')));
  if v_storage_mode <> 'unpartitioned' then
    raise exception 'Unsupported queue storage mode "%"', p_storage_mode;
  end if;

  insert into absurd.queues (queue_name, storage_mode)
  values (p_queue_name, v_storage_mode)
  on conflict (queue_name) do nothing;

  select storage_mode into v_existing_mode
  from absurd.queues
  where queue_name = p_queue_name;

  if v_existing_mode is null then
    raise exception 'Queue "%" was not found after create attempt', p_queue_name;
  end if;

  if v_existing_mode <> v_storage_mode then
    raise exception 'Queue "%" already exists with storage mode "%"', p_queue_name, v_existing_mode;
  end if;

  perform absurd.ensure_queue_tables(p_queue_name);
end;
$$;


--
-- Name: current_time(); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd."current_time"() RETURNS timestamp with time zone
    LANGUAGE plpgsql
    AS $$
declare
  v_fake text;
begin
  v_fake := current_setting('absurd.fake_now', true);
  if v_fake is not null and length(trim(v_fake)) > 0 then
    return v_fake::timestamptz;
  end if;

  return clock_timestamp();
end;
$$;


--
-- Name: drop_queue(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.drop_queue(p_queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_existing_queue text;
begin
  select queue_name into v_existing_queue
  from absurd.queues
  where queue_name = p_queue_name;

  if v_existing_queue is null then
    return;
  end if;

  execute format('drop table if exists absurd.%I cascade', 'i_' || p_queue_name);
  execute format('drop table if exists absurd.%I cascade', 'w_' || p_queue_name);
  execute format('drop table if exists absurd.%I cascade', 'e_' || p_queue_name);
  execute format('drop table if exists absurd.%I cascade', 'c_' || p_queue_name);
  execute format('drop table if exists absurd.%I cascade', 'r_' || p_queue_name);
  execute format('drop table if exists absurd.%I cascade', 't_' || p_queue_name);

  delete from absurd.queues where queue_name = p_queue_name;
end;
$$;


--
-- Name: emit_event(text, text, jsonb); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.emit_event(p_queue_name text, p_event_name text, p_payload jsonb DEFAULT NULL::jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_payload jsonb := coalesce(p_payload, 'null'::jsonb);
  v_emit_applied integer;
begin
  if p_event_name is null or length(trim(p_event_name)) = 0 then
    raise exception 'event_name must be provided';
  end if;

  -- Events are immutable once emitted: first write wins.
  --
  -- await_event() may pre-create a row with payload=NULL as a "not emitted"
  -- sentinel. We allow exactly one transition NULL -> JSON payload.
  execute format(
    'insert into absurd.%1$I as e (event_name, payload, emitted_at)
     values ($1, $2, $3)
     on conflict (event_name)
     do update set payload = excluded.payload,
                   emitted_at = excluded.emitted_at
      where e.payload is null',
    'e_' || p_queue_name
  ) using p_event_name, v_payload, v_now;

  get diagnostics v_emit_applied = row_count;

  -- Event was already emitted earlier; do not overwrite cached payload or
  -- re-run wakeup side effects.
  if v_emit_applied = 0 then
    return;
  end if;

  execute format(
    'with expired_waits as (
        delete from absurd.%1$I w
         where w.event_name = $1
           and w.timeout_at is not null
           and w.timeout_at <= $2
         returning w.run_id
     ),
     affected as (
        select run_id, task_id, step_name
          from absurd.%1$I
         where event_name = $1
           and (timeout_at is null or timeout_at > $2)
     ),
     updated_runs as (
        update absurd.%2$I r
           set state = ''pending'',
               available_at = $2,
               wake_event = null,
               event_payload = $3,
               claimed_by = null,
               claim_expires_at = null
         where r.run_id in (select run_id from affected)
           and r.state = ''sleeping''
         returning r.run_id, r.task_id
     ),
     checkpoint_upd as (
        insert into absurd.%3$I (task_id, checkpoint_name, state, status, owner_run_id, updated_at)
        select a.task_id, a.step_name, $3, ''committed'', a.run_id, $2
          from affected a
          join updated_runs ur on ur.run_id = a.run_id
        on conflict (task_id, checkpoint_name)
        do update set state = excluded.state,
                      status = excluded.status,
                      owner_run_id = excluded.owner_run_id,
                      updated_at = excluded.updated_at
     ),
     updated_tasks as (
        update absurd.%4$I t
           set state = ''pending''
         where t.task_id in (select task_id from updated_runs)
         returning task_id
     )
     delete from absurd.%5$I w
      where w.event_name = $1
        and w.run_id in (select run_id from updated_runs)',
    'w_' || p_queue_name,
    'r_' || p_queue_name,
    'c_' || p_queue_name,
    't_' || p_queue_name,
    'w_' || p_queue_name
  ) using p_event_name, v_now, v_payload;
end;
$_$;


--
-- Name: ensure_queue_tables(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.ensure_queue_tables(p_queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_storage_mode text := 'unpartitioned';
  v_t_suffix text;
  v_r_suffix text;
  v_c_suffix text;
  v_w_suffix text;
  v_t_idempotency_def text;
begin
  perform absurd.validate_queue_name(p_queue_name);

  select storage_mode into v_storage_mode
  from absurd.queues
  where queue_name = p_queue_name;

  v_storage_mode := coalesce(v_storage_mode, 'unpartitioned');

  if v_storage_mode not in ('unpartitioned', 'partitioned') then
    raise exception 'Unsupported queue storage mode "%"', v_storage_mode;
  end if;

  if v_storage_mode = 'partitioned' then
    v_t_suffix := 'partition by range (task_id)';
    v_r_suffix := 'partition by range (run_id)';
    v_c_suffix := 'partition by range (task_id)';
    v_w_suffix := 'partition by range (run_id)';
    v_t_idempotency_def := 'idempotency_key text';
  else
    v_t_suffix := 'with (fillfactor=70)';
    v_r_suffix := 'with (fillfactor=70)';
    v_c_suffix := 'with (fillfactor=70)';
    v_w_suffix := '';
    v_t_idempotency_def := 'idempotency_key text unique';
  end if;

  execute format(
    'create table if not exists absurd.%I (
        task_id uuid primary key,
        task_name text not null,
        params jsonb not null,
        headers jsonb,
        retry_strategy jsonb,
        max_attempts integer,
        cancellation jsonb,
        enqueue_at timestamptz not null default absurd.current_time(),
        first_started_at timestamptz,
        state text not null check (state in (''pending'', ''running'', ''sleeping'', ''completed'', ''failed'', ''cancelled'')),
        attempts integer not null default 0,
        last_attempt_run uuid,
        completed_payload jsonb,
        cancelled_at timestamptz,
        %s
     ) %s',
    't_' || p_queue_name,
    v_t_idempotency_def,
    v_t_suffix
  );

  execute format(
    'create table if not exists absurd.%I (
        run_id uuid primary key,
        task_id uuid not null,
        attempt integer not null,
        state text not null check (state in (''pending'', ''running'', ''sleeping'', ''completed'', ''failed'', ''cancelled'')),
        claimed_by text,
        claim_expires_at timestamptz,
        available_at timestamptz not null,
        wake_event text,
        event_payload jsonb,
        started_at timestamptz,
        completed_at timestamptz,
        failed_at timestamptz,
        result jsonb,
        failure_reason jsonb,
        created_at timestamptz not null default absurd.current_time()
     ) %s',
    'r_' || p_queue_name,
    v_r_suffix
  );

  execute format(
    'create table if not exists absurd.%I (
        task_id uuid not null,
        checkpoint_name text not null,
        state jsonb,
        status text not null default ''committed'',
        owner_run_id uuid,
        updated_at timestamptz not null default absurd.current_time(),
        primary key (task_id, checkpoint_name)
     ) %s',
    'c_' || p_queue_name,
    v_c_suffix
  );

  execute format(
    'create table if not exists absurd.%I (
        event_name text primary key,
        payload jsonb,
        emitted_at timestamptz not null default absurd.current_time()
     )',
    'e_' || p_queue_name
  );

  execute format(
    'create table if not exists absurd.%I (
        task_id uuid not null,
        run_id uuid not null,
        step_name text not null,
        event_name text not null,
        timeout_at timestamptz,
        created_at timestamptz not null default absurd.current_time(),
        primary key (run_id, step_name)
     ) %s',
    'w_' || p_queue_name,
    v_w_suffix
  );

  if v_storage_mode = 'partitioned' then
    execute format(
      'create table if not exists absurd.%I (
          idempotency_key text primary key,
          task_id uuid not null
       )',
      'i_' || p_queue_name
    );
  end if;

  execute format(
    'create index if not exists %I on absurd.%I (state, available_at)',
    ('r_' || p_queue_name) || '_sai',
    'r_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (task_id)',
    ('r_' || p_queue_name) || '_ti',
    'r_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (claim_expires_at)
      where state = ''running''
        and claim_expires_at is not null',
    ('r_' || p_queue_name) || '_cei',
    'r_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (task_id)
      where cancellation is not null',
    ('t_' || p_queue_name) || '_ci',
    't_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (event_name)',
    ('w_' || p_queue_name) || '_eni',
    'w_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (task_id)',
    ('w_' || p_queue_name) || '_ti',
    'w_' || p_queue_name
  );

  execute format(
    'create index if not exists %I on absurd.%I (emitted_at)',
    ('e_' || p_queue_name) || '_eai',
    'e_' || p_queue_name
  );

  if v_storage_mode = 'partitioned' then
    execute format(
      'create index if not exists %I on absurd.%I (task_id)',
      ('i_' || p_queue_name) || '_ti',
      'i_' || p_queue_name
    );
  end if;
end;
$$;


--
-- Name: extend_claim(text, uuid, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.extend_claim(p_queue_name text, p_run_id uuid, p_extend_by integer) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_task_state text;
  v_run_state text;
  v_claim_expires_at timestamptz;
begin
  if p_extend_by is null or p_extend_by <= 0 then
    raise exception 'extend_by must be > 0';
  end if;

  execute format(
    'select r.state,
            r.claim_expires_at,
            t.state
       from absurd.%I r
       join absurd.%I t on t.task_id = r.task_id
      where r.run_id = $1
      for update',
    'r_' || p_queue_name,
    't_' || p_queue_name
  )
  into v_run_state, v_claim_expires_at, v_task_state
  using p_run_id;

  if v_run_state is null then
    raise exception 'Run "%" not found in queue "%"', p_run_id, p_queue_name;
  end if;

  if v_task_state = 'cancelled' then
    raise exception sqlstate 'AB001' using message = 'Task has been cancelled';
  end if;

  if v_run_state <> 'running' then
    if v_run_state = 'failed' then
      raise exception sqlstate 'AB002' using message = format('Run "%s" has already failed in queue "%s"', p_run_id, p_queue_name);
    end if;
    raise exception 'Run "%" is not currently running in queue "%"', p_run_id, p_queue_name;
  end if;

  if v_claim_expires_at is null then
    raise exception 'Run "%" does not have an active claim in queue "%"', p_run_id, p_queue_name;
  end if;

  execute format(
    'update absurd.%I
        set claim_expires_at = $2 + make_interval(secs => $3)
      where run_id = $1',
    'r_' || p_queue_name
  )
  using p_run_id, v_now, p_extend_by;
end;
$_$;


--
-- Name: fail_run(text, uuid, jsonb, timestamp with time zone); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.fail_run(p_queue_name text, p_run_id uuid, p_reason jsonb, p_retry_at timestamp with time zone DEFAULT NULL::timestamp with time zone) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_task_id uuid;
  v_attempt integer;
  v_run_state text;
  v_retry_strategy jsonb;
  v_max_attempts integer;
  v_now timestamptz := absurd.current_time();
  v_next_attempt integer;
  v_delay_seconds double precision := 0;
  v_next_available timestamptz;
  v_first_started timestamptz;
  v_cancellation jsonb;
  v_max_duration bigint;
  v_task_cancel boolean := false;
  v_new_run_id uuid;
  v_task_state_after text;
  v_recorded_attempt integer;
  v_last_attempt_run uuid := p_run_id;
  v_cancelled_at timestamptz := null;
begin
  execute format(
    'select r.task_id, r.attempt, r.state
       from absurd.%I r
      where r.run_id = $1
      for update',
    'r_' || p_queue_name
  )
  into v_task_id, v_attempt, v_run_state
  using p_run_id;

  if v_task_id is null then
    raise exception 'Run "%" cannot be failed in queue "%"', p_run_id, p_queue_name;
  end if;

  if v_run_state = 'cancelled' then
    raise exception sqlstate 'AB001' using message = 'Task has been cancelled';
  end if;

  if v_run_state = 'failed' then
    raise exception sqlstate 'AB002' using message = format('Run "%s" has already failed in queue "%s"', p_run_id, p_queue_name);
  end if;

  if v_run_state not in ('running', 'sleeping') then
    raise exception 'Run "%" cannot be failed in queue "%"', p_run_id, p_queue_name;
  end if;

  execute format(
    'select retry_strategy, max_attempts, first_started_at, cancellation
       from absurd.%I
      where task_id = $1
      for update',
    't_' || p_queue_name
  )
  into v_retry_strategy, v_max_attempts, v_first_started, v_cancellation
  using v_task_id;

  execute format(
    'update absurd.%I
        set state = ''failed'',
            wake_event = null,
            failed_at = $2,
            failure_reason = $3
      where run_id = $1',
    'r_' || p_queue_name
  ) using p_run_id, v_now, p_reason;

  v_next_attempt := v_attempt + 1;
  v_task_state_after := 'failed';
  v_recorded_attempt := v_attempt;

  if v_max_attempts is null or v_next_attempt <= v_max_attempts then
    if p_retry_at is not null then
      v_next_available := p_retry_at;
    else
      -- Legacy tasks may contain retry strategies that predate validation. If
      -- one is invalid, fail the task permanently rather than wedging the queue.
      begin
        v_delay_seconds := absurd.retry_delay_seconds(v_retry_strategy, v_attempt);
        v_next_available := v_now + (v_delay_seconds * interval '1 second');
      exception
        when sqlstate 'AB003' then
          v_next_available := null;
      end;
    end if;

    if v_next_available < v_now then
      v_next_available := v_now;
    end if;

    if v_cancellation is not null then
      v_max_duration := (v_cancellation->>'max_duration')::bigint;
      if v_max_duration is not null and v_first_started is not null then
        if extract(epoch from (v_next_available - v_first_started)) >= v_max_duration then
          v_task_cancel := true;
        end if;
      end if;
    end if;

    if not v_task_cancel and v_next_available is not null then
      v_task_state_after := case when v_next_available > v_now then 'sleeping' else 'pending' end;
      v_new_run_id := absurd.portable_uuidv7();
      v_recorded_attempt := v_next_attempt;
      v_last_attempt_run := v_new_run_id;
      execute format(
        'insert into absurd.%I (run_id, task_id, attempt, state, available_at, wake_event, event_payload, result, failure_reason)
         values ($1, $2, $3, $4, $5, null, null, null, null)',
        'r_' || p_queue_name
      )
      using v_new_run_id, v_task_id, v_next_attempt, v_task_state_after, v_next_available;
    end if;
  end if;

  if v_task_cancel then
    v_task_state_after := 'cancelled';
    v_cancelled_at := v_now;
    v_recorded_attempt := greatest(v_recorded_attempt, v_attempt);
    v_last_attempt_run := p_run_id;
  end if;

  execute format(
    'update absurd.%I
        set state = $2,
            attempts = greatest(attempts, $3),
            last_attempt_run = $4,
            cancelled_at = coalesce(cancelled_at, $5)
      where task_id = $1',
    't_' || p_queue_name
  ) using v_task_id, v_task_state_after, v_recorded_attempt, v_last_attempt_run, v_cancelled_at;

  execute format(
    'delete from absurd.%I where run_id = $1',
    'w_' || p_queue_name
  ) using p_run_id;
end;
$_$;


--
-- Name: get_queue_policy(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.get_queue_policy(p_queue_name text) RETURNS TABLE(queue_name text, storage_mode text, default_partition text, partition_lookahead interval, partition_lookback interval, cleanup_ttl interval, cleanup_limit integer, detach_mode text, detach_min_age interval)
    LANGUAGE sql
    AS $$
  select
    q.queue_name,
    q.storage_mode,
    q.default_partition,
    q.partition_lookahead,
    q.partition_lookback,
    q.cleanup_ttl,
    q.cleanup_limit,
    q.detach_mode,
    q.detach_min_age
  from absurd.queues q
  where q.queue_name = p_queue_name;
$$;


--
-- Name: get_schema_version(); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.get_schema_version() RETURNS text
    LANGUAGE sql
    AS $$
  select '0.5.1'::text;
$$;


--
-- Name: get_task_checkpoint_state(text, uuid, text, boolean); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.get_task_checkpoint_state(p_queue_name text, p_task_id uuid, p_step_name text, p_include_pending boolean DEFAULT false) RETURNS TABLE(checkpoint_name text, state jsonb, status text, owner_run_id uuid, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
begin
  return query execute format(
    'select checkpoint_name, state, status, owner_run_id, updated_at
       from absurd.%I
      where task_id = $1
        and checkpoint_name = $2
        and ($3 or status = ''committed'')',
    'c_' || p_queue_name
  ) using p_task_id, p_step_name, coalesce(p_include_pending, false);
end;
$_$;


--
-- Name: get_task_checkpoint_states(text, uuid, uuid); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.get_task_checkpoint_states(p_queue_name text, p_task_id uuid, p_run_id uuid) RETURNS TABLE(checkpoint_name text, state jsonb, status text, owner_run_id uuid, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
declare
  v_run_task_id uuid;
  v_run_attempt integer;
begin
  execute format(
    'select task_id, attempt
       from absurd.%I
      where run_id = $1',
    'r_' || p_queue_name
  )
  into v_run_task_id, v_run_attempt
  using p_run_id;

  if v_run_task_id is null then
    raise exception 'Run "%" not found in queue "%"', p_run_id, p_queue_name;
  end if;

  if v_run_task_id <> p_task_id then
    raise exception 'Run "%" does not belong to task "%" in queue "%"', p_run_id, p_task_id, p_queue_name;
  end if;

  return query execute format(
    'select c.checkpoint_name,
            c.state,
            c.status,
            c.owner_run_id,
            c.updated_at
       from absurd.%1$I c
       left join absurd.%2$I owner_run on owner_run.run_id = c.owner_run_id
      where c.task_id = $1
        and c.status = ''committed''
        and (owner_run.attempt is null or owner_run.attempt <= $2)
      order by c.updated_at asc',
    'c_' || p_queue_name,
    'r_' || p_queue_name
  ) using p_task_id, v_run_attempt;
end;
$_$;


--
-- Name: get_task_result(text, uuid); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.get_task_result(p_queue_name text, p_task_id uuid) RETURNS TABLE(task_id uuid, state text, result jsonb, failure_reason jsonb)
    LANGUAGE plpgsql
    AS $_$
begin
  p_queue_name := absurd.validate_queue_name(p_queue_name);

  return query execute format(
    'select t.task_id,
            t.state,
            case when t.state = ''completed'' then t.completed_payload else null end as result,
            case when t.state = ''failed'' then r.failure_reason else null end as failure_reason
       from absurd.%I t
       left join absurd.%I r on r.run_id = t.last_attempt_run
      where t.task_id = $1',
    't_' || p_queue_name,
    'r_' || p_queue_name
  ) using p_task_id;
end;
$_$;


--
-- Name: list_queues(); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.list_queues() RETURNS TABLE(queue_name text)
    LANGUAGE sql
    AS $$
  select queue_name from absurd.queues order by queue_name;
$$;


--
-- Name: portable_uuidv7(); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.portable_uuidv7() RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare
  ts_ms bigint;
  b bytea;
  rnd bytea;
  i int;
begin
  if to_regprocedure('pg_catalog.uuidv7()') is not null then
    return pg_catalog.uuidv7 ();
  end if;
  ts_ms := floor(extract(epoch from absurd.current_time()) * 1000)::bigint;
  rnd := uuid_send(pg_catalog.gen_random_uuid ());
  b := repeat(E'\\000', 16)::bytea;
  for i in 0..5 loop
    b := set_byte(b, i, ((ts_ms >> ((5 - i) * 8)) & 255)::int);
  end loop;
  for i in 6..15 loop
    b := set_byte(b, i, get_byte(rnd, i));
  end loop;
  b := set_byte(b, 6, ((get_byte(b, 6) & 15) | (7 << 4)));
  b := set_byte(b, 8, ((get_byte(b, 8) & 63) | 128));
  return encode(b, 'hex')::uuid;
end;
$$;


--
-- Name: retry_delay_seconds(jsonb, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.retry_delay_seconds(p_strategy jsonb, p_attempt integer) RETURNS double precision
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  v_limit constant double precision := 86400;
  v_kind text;
  v_base double precision;
  v_factor double precision;
  v_max_seconds double precision;
  v_exponent integer := greatest(coalesce(p_attempt, 1) - 1, 0);
begin
  if p_strategy is null then
    return 0;
  end if;
  if jsonb_typeof(p_strategy) <> 'object' then
    raise exception sqlstate 'AB003'
      using message = 'retry_strategy must be a JSON object';
  end if;

  v_kind := coalesce(p_strategy->>'kind', 'none');
  if v_kind not in ('none', 'fixed', 'exponential') then
    raise exception sqlstate 'AB003'
      using message = format('Unsupported retry strategy kind "%s"', v_kind);
  end if;
  if v_kind = 'none' then
    return 0;
  end if;

  v_base := coalesce(
    (p_strategy->>'base_seconds')::double precision,
    case when v_kind = 'fixed' then 60 else 30 end
  );
  if v_base not between 0 and v_limit then
    raise exception sqlstate 'AB003'
      using message = 'retry_strategy.base_seconds must be between 0 and 86400';
  end if;
  if v_kind = 'fixed' then
    return v_base;
  end if;

  v_factor := coalesce((p_strategy->>'factor')::double precision, 2);
  v_max_seconds := coalesce(
    (p_strategy->>'max_seconds')::double precision,
    v_limit
  );
  if v_factor < 0 or v_factor::text in ('NaN', 'Infinity', '-Infinity') then
    raise exception sqlstate 'AB003'
      using message = 'retry_strategy.factor must be a finite non-negative number';
  end if;
  if v_max_seconds not between 0 and v_limit then
    raise exception sqlstate 'AB003'
      using message = 'retry_strategy.max_seconds must be between 0 and 86400';
  end if;
  if v_base = 0 then
    return 0;
  end if;

  begin
    return least(v_base * power(v_factor, v_exponent), v_max_seconds);
  exception
    when numeric_value_out_of_range then
      return case when v_factor < 1 then 0 else v_max_seconds end;
  end;
exception
  when invalid_text_representation or numeric_value_out_of_range then
    raise exception sqlstate 'AB003'
      using message = 'retry_strategy contains an invalid number';
end;
$$;


--
-- Name: retry_task(text, uuid, jsonb); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.retry_task(p_queue_name text, p_task_id uuid, p_options jsonb DEFAULT '{}'::jsonb) RETURNS TABLE(task_id uuid, run_id uuid, attempt integer, created boolean)
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_spawn_new boolean := false;
  v_requested_max_attempts integer;

  v_task_name text;
  v_params jsonb;
  v_headers jsonb;
  v_retry_strategy jsonb;
  v_task_max_attempts integer;
  v_cancellation jsonb;
  v_task_attempts integer;
  v_task_state text;

  v_new_run_id uuid;
  v_new_attempt integer;
  v_spawn_options jsonb;
begin
  if p_options is not null then
    if p_options ? 'spawn_new' then
      v_spawn_new := coalesce((p_options->>'spawn_new')::boolean, false);
    end if;
    if p_options ? 'max_attempts' then
      v_requested_max_attempts := (p_options->>'max_attempts')::int;
      if v_requested_max_attempts is not null and v_requested_max_attempts < 1 then
        raise exception 'max_attempts must be >= 1';
      end if;
    end if;
  end if;

  execute format(
    'select task_name,
            params,
            headers,
            retry_strategy,
            max_attempts,
            cancellation,
            attempts,
            state
       from absurd.%I
      where task_id = $1
      for update',
    't_' || p_queue_name
  )
  into v_task_name,
       v_params,
       v_headers,
       v_retry_strategy,
       v_task_max_attempts,
       v_cancellation,
       v_task_attempts,
       v_task_state
  using p_task_id;

  if v_task_state is null then
    raise exception 'Task "%" not found in queue "%"', p_task_id, p_queue_name;
  end if;

  if v_task_state <> 'failed' then
    raise exception 'Task "%" is not currently failed in queue "%"', p_task_id, p_queue_name;
  end if;

  if v_spawn_new then
    v_spawn_options := jsonb_strip_nulls(jsonb_build_object(
      'headers', v_headers,
      'retry_strategy', v_retry_strategy,
      'max_attempts', coalesce(v_requested_max_attempts, v_task_max_attempts),
      'cancellation', v_cancellation
    ));

    return query
      select s.task_id, s.run_id, s.attempt, s.created
        from absurd.spawn_task(p_queue_name, v_task_name, v_params, v_spawn_options) s;
    return;
  end if;

  if v_requested_max_attempts is null then
    v_requested_max_attempts := coalesce(v_task_max_attempts, v_task_attempts) + 1;
  end if;

  if v_requested_max_attempts <= v_task_attempts then
    raise exception 'max_attempts (%) must be greater than current attempts (%)',
      v_requested_max_attempts,
      v_task_attempts;
  end if;

  v_new_run_id := absurd.portable_uuidv7();
  v_new_attempt := v_task_attempts + 1;

  execute format(
    'insert into absurd.%I (run_id, task_id, attempt, state, available_at, wake_event, event_payload, result, failure_reason)
     values ($1, $2, $3, ''pending'', $4, null, null, null, null)',
    'r_' || p_queue_name
  )
  using v_new_run_id, p_task_id, v_new_attempt, v_now;

  execute format(
    'update absurd.%I
        set state = ''pending'',
            attempts = greatest(attempts, $2),
            max_attempts = $3,
            last_attempt_run = $4,
            cancelled_at = null
      where task_id = $1',
    't_' || p_queue_name
  )
  using p_task_id, v_new_attempt, v_requested_max_attempts, v_new_run_id;

  return query select p_task_id, v_new_run_id, v_new_attempt, false;
end;
$_$;


--
-- Name: schedule_run(text, uuid, timestamp with time zone); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.schedule_run(p_queue_name text, p_run_id uuid, p_wake_at timestamp with time zone) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_task_id uuid;
begin
  execute format(
    'select task_id
       from absurd.%I
      where run_id = $1
        and state = ''running''
      for update',
    'r_' || p_queue_name
  )
  into v_task_id
  using p_run_id;

  if v_task_id is null then
    raise exception 'Run "%" is not currently running in queue "%"', p_run_id, p_queue_name;
  end if;

  execute format(
    'update absurd.%I
        set state = ''sleeping'',
            claimed_by = null,
            claim_expires_at = null,
            available_at = $2,
            wake_event = null
      where run_id = $1',
    'r_' || p_queue_name
  ) using p_run_id, p_wake_at;

  execute format(
    'update absurd.%I
        set state = ''sleeping''
      where task_id = $1',
    't_' || p_queue_name
  ) using v_task_id;
end;
$_$;


--
-- Name: set_queue_policy(text, jsonb); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.set_queue_policy(p_queue_name text, p_policy jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_policy jsonb := coalesce(p_policy, '{}'::jsonb);
  v_unknown_key text;
  v_exists boolean := false;
  v_storage_mode text;
  v_default_partition text;

  v_partition_lookahead interval;
  v_partition_lookback interval;
  v_cleanup_ttl interval;
  v_cleanup_limit integer;
  v_detach_mode text;
  v_detach_min_age interval;
begin
  p_queue_name := absurd.validate_queue_name(p_queue_name);

  if jsonb_typeof(v_policy) <> 'object' then
    raise exception 'Queue policy must be a JSON object';
  end if;

  select k.key
    into v_unknown_key
    from jsonb_object_keys(v_policy) as k(key)
   where k.key not in (
      'partition_lookahead',
      'partition_lookback',
      'cleanup_ttl',
      'cleanup_limit',
      'detach_mode',
      'detach_min_age',
      'default_partition'
   )
   limit 1;

  if v_unknown_key is not null then
    raise exception 'Unsupported queue policy key "%"', v_unknown_key;
  end if;

  select exists (
    select 1
    from absurd.queues
    where queue_name = p_queue_name
  )
  into v_exists;

  if not v_exists then
    raise exception 'Queue "%" does not exist', p_queue_name;
  end if;

  select
    storage_mode,
    default_partition,
    partition_lookahead,
    partition_lookback,
    cleanup_ttl,
    cleanup_limit,
    detach_mode,
    detach_min_age
  into
    v_storage_mode,
    v_default_partition,
    v_partition_lookahead,
    v_partition_lookback,
    v_cleanup_ttl,
    v_cleanup_limit,
    v_detach_mode,
    v_detach_min_age
  from absurd.queues
  where queue_name = p_queue_name
  for update;

  if v_policy ? 'partition_lookahead' then
    v_partition_lookahead := (v_policy->>'partition_lookahead')::interval;
  end if;

  if v_policy ? 'partition_lookback' then
    v_partition_lookback := (v_policy->>'partition_lookback')::interval;
  end if;

  if v_policy ? 'cleanup_ttl' then
    v_cleanup_ttl := (v_policy->>'cleanup_ttl')::interval;
  end if;

  if v_policy ? 'cleanup_limit' then
    v_cleanup_limit := (v_policy->>'cleanup_limit')::integer;
  end if;

  if v_policy ? 'detach_mode' then
    v_detach_mode := lower(trim(coalesce(v_policy->>'detach_mode', '')));
  end if;

  if v_policy ? 'detach_min_age' then
    v_detach_min_age := (v_policy->>'detach_min_age')::interval;
  end if;


  if v_policy ? 'default_partition' then
    v_default_partition := lower(trim(coalesce(v_policy->>'default_partition', '')));
  end if;

  if v_partition_lookahead < interval '0 seconds' then
    raise exception 'partition_lookahead must be non-negative';
  end if;

  if v_partition_lookback < interval '0 seconds' then
    raise exception 'partition_lookback must be non-negative';
  end if;

  if v_cleanup_ttl < interval '0 seconds' then
    raise exception 'cleanup_ttl must be non-negative';
  end if;

  if v_cleanup_limit < 1 then
    raise exception 'cleanup_limit must be at least 1';
  end if;

  if v_detach_mode not in ('none', 'empty') then
    raise exception 'Unsupported detach mode "%"', v_detach_mode;
  end if;

  if v_detach_min_age < interval '0 seconds' then
    raise exception 'detach_min_age must be non-negative';
  end if;

  if v_default_partition not in ('enabled', 'disabled') then
    raise exception 'Unsupported default_partition mode "%"', v_default_partition;
  end if;

  if v_storage_mode <> 'partitioned' and v_policy ? 'default_partition' then
    raise exception 'default_partition policy is only supported for partitioned queues';
  end if;

  update absurd.queues
     set default_partition = v_default_partition,
         partition_lookahead = v_partition_lookahead,
         partition_lookback = v_partition_lookback,
         cleanup_ttl = v_cleanup_ttl,
         cleanup_limit = v_cleanup_limit,
         detach_mode = v_detach_mode,
         detach_min_age = v_detach_min_age
   where queue_name = p_queue_name;

end;
$$;


--
-- Name: set_task_checkpoint_state(text, uuid, text, jsonb, uuid, integer); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.set_task_checkpoint_state(p_queue_name text, p_task_id uuid, p_step_name text, p_state jsonb, p_owner_run uuid, p_extend_claim_by integer DEFAULT NULL::integer) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  v_now timestamptz := absurd.current_time();
  v_new_attempt integer;
  v_existing_attempt integer;
  v_existing_owner uuid;
  v_task_state text;
  v_run_state text;
begin
  if p_step_name is null or length(trim(p_step_name)) = 0 then
    raise exception 'step_name must be provided';
  end if;

  execute format(
    'select r.attempt, r.state, t.state
       from absurd.%I r
       join absurd.%I t on t.task_id = r.task_id
      where r.run_id = $1',
    'r_' || p_queue_name,
    't_' || p_queue_name
  )
  into v_new_attempt, v_run_state, v_task_state
  using p_owner_run;

  if v_new_attempt is null then
    raise exception 'Run "%" not found for checkpoint', p_owner_run;
  end if;

  if v_task_state = 'cancelled' then
    raise exception sqlstate 'AB001' using message = 'Task has been cancelled';
  end if;

  if v_run_state = 'failed' then
    raise exception sqlstate 'AB002' using message = format('Run "%s" has already failed in queue "%s"', p_owner_run, p_queue_name);
  end if;

  -- Extend the claim if requested
  if p_extend_claim_by is not null and p_extend_claim_by > 0 then
    execute format(
      'update absurd.%I
          set claim_expires_at = $2 + make_interval(secs => $3)
        where run_id = $1
          and state = ''running''
          and claim_expires_at is not null',
      'r_' || p_queue_name
    )
    using p_owner_run, v_now, p_extend_claim_by;
  end if;

  execute format(
    'select c.owner_run_id,
            r.attempt
       from absurd.%I c
       left join absurd.%I r on r.run_id = c.owner_run_id
      where c.task_id = $1
        and c.checkpoint_name = $2',
    'c_' || p_queue_name,
    'r_' || p_queue_name
  )
  into v_existing_owner, v_existing_attempt
  using p_task_id, p_step_name;

  if v_existing_owner is null or v_existing_attempt is null or v_new_attempt >= v_existing_attempt then
    execute format(
      'insert into absurd.%I (task_id, checkpoint_name, state, status, owner_run_id, updated_at)
       values ($1, $2, $3, ''committed'', $4, $5)
       on conflict (task_id, checkpoint_name)
       do update set state = excluded.state,
                     status = excluded.status,
                     owner_run_id = excluded.owner_run_id,
                     updated_at = excluded.updated_at',
      'c_' || p_queue_name
    ) using p_task_id, p_step_name, p_state, p_owner_run, v_now;
  end if;
end;
$_$;


--
-- Name: spawn_task(text, text, jsonb, jsonb); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.spawn_task(p_queue_name text, p_task_name text, p_params jsonb, p_options jsonb DEFAULT '{}'::jsonb) RETURNS TABLE(task_id uuid, run_id uuid, attempt integer, created boolean)
    LANGUAGE plpgsql
    AS $_$
declare
  v_task_id uuid := absurd.portable_uuidv7();
  v_run_id uuid := absurd.portable_uuidv7();
  v_attempt integer := 1;
  v_headers jsonb;
  v_retry_strategy jsonb;
  v_max_attempts integer;
  v_cancellation jsonb;
  v_idempotency_key text;
  v_existing_task_id uuid;
  v_existing_run_id uuid;
  v_existing_attempt integer;
  v_row_count integer;
  v_storage_mode text := 'unpartitioned';
  v_task_inserted boolean := false;
  v_now timestamptz := absurd.current_time();
  v_params jsonb := coalesce(p_params, 'null'::jsonb);
begin
  if p_task_name is null or length(trim(p_task_name)) = 0 then
    raise exception 'task_name must be provided';
  end if;

  if p_options is not null then
    v_headers := p_options->'headers';
    v_retry_strategy := p_options->'retry_strategy';
    perform absurd.retry_delay_seconds(v_retry_strategy, 1);
    if p_options ? 'max_attempts' then
      v_max_attempts := (p_options->>'max_attempts')::int;
      if v_max_attempts is not null and v_max_attempts < 1 then
        raise exception 'max_attempts must be >= 1';
      end if;
    end if;
    v_cancellation := p_options->'cancellation';
    v_idempotency_key := p_options->>'idempotency_key';
  end if;

  if v_idempotency_key is not null then
    select storage_mode into v_storage_mode
    from absurd.queues
    where queue_name = p_queue_name;

    v_storage_mode := coalesce(v_storage_mode, 'unpartitioned');
    if v_storage_mode not in ('unpartitioned', 'partitioned') then
      raise exception 'Unsupported queue storage mode "%"', v_storage_mode;
    end if;

    if v_storage_mode = 'partitioned' then
      -- Reserve idempotency key via dedicated side table.
      execute format(
        'insert into absurd.%I (idempotency_key, task_id)
         values ($1, $2)
         on conflict (idempotency_key) do nothing',
        'i_' || p_queue_name
      )
      using v_idempotency_key, v_task_id;

      get diagnostics v_row_count = row_count;

      if v_row_count = 0 then
        execute format(
          'select i.task_id, t.last_attempt_run, t.attempts
             from absurd.%I i
             join absurd.%I t on t.task_id = i.task_id
            where i.idempotency_key = $1
              for key share of i',
          'i_' || p_queue_name,
          't_' || p_queue_name
        )
        into v_existing_task_id, v_existing_run_id, v_existing_attempt
        using v_idempotency_key;

        if v_existing_task_id is null then
          raise exception 'Idempotency key "%" in queue "%" was concurrently cleaned up', v_idempotency_key, p_queue_name
            using errcode = '40001',
                  hint = 'Retry spawn_task with the same idempotency key.';
        end if;

        if v_existing_run_id is null then
          raise exception 'Idempotency key "%" in queue "%" resolved to task "%" without a run', v_idempotency_key, p_queue_name, v_existing_task_id;
        end if;

        return query select v_existing_task_id, v_existing_run_id, v_existing_attempt, false;
        return;
      end if;
    else
      -- Unpartitioned queues keep the original unique(idempotency_key)
      -- behavior directly on t_<queue>.
      execute format(
        'insert into absurd.%I (task_id, task_name, params, headers, retry_strategy, max_attempts, cancellation, enqueue_at, first_started_at, state, attempts, last_attempt_run, completed_payload, cancelled_at, idempotency_key)
         values ($1, $2, $3, $4, $5, $6, $7, $8, null, ''pending'', $9, $10, null, null, $11)
         on conflict (idempotency_key) do nothing',
        't_' || p_queue_name
      )
      using v_task_id, p_task_name, v_params, v_headers, v_retry_strategy, v_max_attempts, v_cancellation, v_now, v_attempt, v_run_id, v_idempotency_key;

      get diagnostics v_row_count = row_count;

      if v_row_count = 0 then
        execute format(
          'select task_id, last_attempt_run, attempts
             from absurd.%I
            where idempotency_key = $1',
          't_' || p_queue_name
        )
        into v_existing_task_id, v_existing_run_id, v_existing_attempt
        using v_idempotency_key;

        return query select v_existing_task_id, v_existing_run_id, v_existing_attempt, false;
        return;
      end if;

      v_task_inserted := true;
    end if;
  end if;

  if not v_task_inserted then
    execute format(
      'insert into absurd.%I (task_id, task_name, params, headers, retry_strategy, max_attempts, cancellation, enqueue_at, first_started_at, state, attempts, last_attempt_run, completed_payload, cancelled_at, idempotency_key)
       values ($1, $2, $3, $4, $5, $6, $7, $8, null, ''pending'', $9, $10, null, null, $11)',
      't_' || p_queue_name
    )
    using v_task_id, p_task_name, v_params, v_headers, v_retry_strategy, v_max_attempts, v_cancellation, v_now, v_attempt, v_run_id, v_idempotency_key;
  end if;

  execute format(
    'insert into absurd.%I (run_id, task_id, attempt, state, available_at, wake_event, event_payload, result, failure_reason)
     values ($1, $2, $3, ''pending'', $4, null, null, null, null)',
    'r_' || p_queue_name
  )
  using v_run_id, v_task_id, v_attempt, v_now;

  return query select v_task_id, v_run_id, v_attempt, true;
end;
$_$;


--
-- Name: validate_queue_name(text); Type: FUNCTION; Schema: absurd; Owner: -
--

CREATE FUNCTION absurd.validate_queue_name(p_queue_name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
  if p_queue_name is null or p_queue_name = '' then
    raise exception 'Queue name must be provided';
  end if;

  if octet_length(p_queue_name) > 57 then
    raise exception 'Queue name "%" is too long (max 57 bytes).', p_queue_name;
  end if;

  return p_queue_name;
end;
$$;


--
-- Name: ack_emoji_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ack_emoji_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."names" := CASE WHEN jsonb_typeof(NEW.json->'names') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'names')) END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'names', to_jsonb(NEW."names"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: acl_grants_bump_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.acl_grants_bump_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        INSERT INTO acl_grants_version(only_row, v) VALUES (TRUE, 1)
        ON CONFLICT (tenant_id, only_row) DO UPDATE SET v = acl_grants_version.v + 1;
        RETURN NULL;
      END
      $$;


--
-- Name: ambient_cursors_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ambient_cursors_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."last_judged_ts" := CASE WHEN jsonb_typeof(NEW.json->'lastJudgedTs') = 'string' THEN NEW.json->>'lastJudgedTs' END;
        NEW."last_judged_at" := CASE WHEN jsonb_typeof(NEW.json->'lastJudgedAt') = 'number' THEN round((NEW.json->>'lastJudgedAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('lastJudgedTs', to_jsonb(NEW."last_judged_ts"), 'lastJudgedAt', to_jsonb(NEW."last_judged_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: approval_grant_modes_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.approval_grant_modes_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."modes" := CASE WHEN jsonb_typeof(NEW.json->'modes') <> 'null' THEN NEW.json->'modes' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'modes', to_jsonb(NEW."modes"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: approval_grants_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.approval_grants_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."actor_id" := CASE WHEN jsonb_typeof(NEW.json->'actorId') = 'string' THEN NEW.json->>'actorId' END;
        NEW."command" := CASE WHEN jsonb_typeof(NEW.json->'command') = 'string' THEN NEW.json->>'command' END;
        NEW."scope" := CASE WHEN jsonb_typeof(NEW.json->'scope') = 'string' THEN NEW.json->>'scope' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."session_id" := CASE WHEN jsonb_typeof(NEW.json->'sessionId') = 'string' THEN NEW.json->>'sessionId' END;
        NEW."approval_key" := CASE WHEN jsonb_typeof(NEW.json->'approvalKey') = 'string' THEN NEW.json->>'approvalKey' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('actorId', to_jsonb(NEW."actor_id"), 'command', to_jsonb(NEW."command"), 'scope', to_jsonb(NEW."scope"), 'createdAt', to_jsonb(NEW."created_at"), 'sessionId', to_jsonb(NEW."session_id"), 'approvalKey', to_jsonb(NEW."approval_key"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: approvals_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.approvals_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."session_id" := CASE WHEN jsonb_typeof(NEW.json->'sessionId') = 'string' THEN NEW.json->>'sessionId' END;
        NEW."command" := CASE WHEN jsonb_typeof(NEW.json->'command') = 'string' THEN NEW.json->>'command' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."reason" := CASE WHEN jsonb_typeof(NEW.json->'reason') = 'string' THEN NEW.json->>'reason' END;
        NEW."matched" := CASE WHEN jsonb_typeof(NEW.json->'matched') = 'string' THEN NEW.json->>'matched' END;
        NEW."purpose" := CASE WHEN jsonb_typeof(NEW.json->'purpose') = 'string' THEN NEW.json->>'purpose' END;
        NEW."summary" := CASE WHEN jsonb_typeof(NEW.json->'summary') = 'string' THEN NEW.json->>'summary' END;
        NEW."summary_detail" := CASE WHEN jsonb_typeof(NEW.json->'summaryDetail') = 'string' THEN NEW.json->>'summaryDetail' END;
        NEW."approval_key" := CASE WHEN jsonb_typeof(NEW.json->'approvalKey') = 'string' THEN NEW.json->>'approvalKey' END;
        NEW."grant_modes" := CASE WHEN jsonb_typeof(NEW.json->'grantModes') <> 'null' THEN NEW.json->'grantModes' END;
        NEW."request" := CASE WHEN jsonb_typeof(NEW.json->'request') <> 'null' THEN NEW.json->'request' END;
        NEW."blocks_input" := CASE WHEN jsonb_typeof(NEW.json->'blocksInput') = 'boolean' THEN (NEW.json->'blocksInput')::boolean END;
        NEW."kind" := CASE WHEN jsonb_typeof(NEW.json->'kind') = 'string' THEN NEW.json->>'kind' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('sessionId', to_jsonb(NEW."session_id"), 'command', to_jsonb(NEW."command"), 'createdAt', to_jsonb(NEW."created_at"), 'reason', to_jsonb(NEW."reason"), 'matched', to_jsonb(NEW."matched"), 'purpose', to_jsonb(NEW."purpose"), 'summary', to_jsonb(NEW."summary"), 'summaryDetail', to_jsonb(NEW."summary_detail"), 'approvalKey', to_jsonb(NEW."approval_key"), 'grantModes', to_jsonb(NEW."grant_modes"), 'request', to_jsonb(NEW."request"), 'blocksInput', to_jsonb(NEW."blocks_input"), 'kind', to_jsonb(NEW."kind"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: auto_flagger_configs_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auto_flagger_configs_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."model_id" := CASE WHEN jsonb_typeof(NEW.json->'modelId') = 'string' THEN NEW.json->>'modelId' END;
        NEW."rubric" := CASE WHEN jsonb_typeof(NEW.json->'rubric') = 'string' THEN NEW.json->>'rubric' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'modelId', to_jsonb(NEW."model_id"), 'rubric', to_jsonb(NEW."rubric"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: base_model_configs_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.base_model_configs_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."embedding_model_id" := CASE WHEN jsonb_typeof(NEW.json->'embeddingModelId') = 'string' THEN NEW.json->>'embeddingModelId' END;
        NEW."model_id" := CASE WHEN jsonb_typeof(NEW.json->'modelId') = 'string' THEN NEW.json->>'modelId' END;
        NEW."cron_runtime" := CASE WHEN jsonb_typeof(NEW.json->'cronRuntime') <> 'null' THEN NEW.json->'cronRuntime' END;
        NEW."subagent_runtime" := CASE WHEN jsonb_typeof(NEW.json->'subagentRuntime') <> 'null' THEN NEW.json->'subagentRuntime' END;
        NEW."fallback_runtime" := CASE WHEN jsonb_typeof(NEW.json->'fallbackRuntime') <> 'null' THEN NEW.json->'fallbackRuntime' END;
        NEW."org_revision" := CASE WHEN jsonb_typeof(NEW.json->'orgRevision') = 'number' THEN round((NEW.json->>'orgRevision')::numeric)::bigint END;
        NEW."revision" := CASE WHEN jsonb_typeof(NEW.json->'revision') = 'number' THEN round((NEW.json->>'revision')::numeric)::bigint END;
        NEW."effort_level" := CASE WHEN jsonb_typeof(NEW.json->'effortLevel') = 'string' THEN NEW.json->>'effortLevel' END;
        NEW."fast_mode" := CASE WHEN jsonb_typeof(NEW.json->'fastMode') = 'boolean' THEN (NEW.json->'fastMode')::boolean END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'embeddingModelId', to_jsonb(NEW."embedding_model_id"), 'modelId', to_jsonb(NEW."model_id"), 'cronRuntime', to_jsonb(NEW."cron_runtime"), 'subagentRuntime', to_jsonb(NEW."subagent_runtime"), 'fallbackRuntime', to_jsonb(NEW."fallback_runtime"), 'orgRevision', to_jsonb(NEW."org_revision"), 'revision', to_jsonb(NEW."revision"), 'effortLevel', to_jsonb(NEW."effort_level"), 'fastMode', to_jsonb(NEW."fast_mode"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: branding_configs_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.branding_configs_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."branding" := CASE WHEN jsonb_typeof(NEW.json->'branding') <> 'null' THEN NEW.json->'branding' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'branding', to_jsonb(NEW."branding"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: browse_max_steps_configs_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.browse_max_steps_configs_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."steps" := CASE WHEN jsonb_typeof(NEW.json->'steps') = 'number' THEN round((NEW.json->>'steps')::numeric)::bigint END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'steps', to_jsonb(NEW."steps"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: browse_model_configs_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.browse_model_configs_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."model_id" := CASE WHEN jsonb_typeof(NEW.json->'modelId') = 'string' THEN NEW.json->>'modelId' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'modelId', to_jsonb(NEW."model_id"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: browser_sessions_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.browser_sessions_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."state_enc" := CASE WHEN jsonb_typeof(NEW.json->'stateEnc') = 'string' THEN NEW.json->>'stateEnc' END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."principal_id" := NEW.id;
      ELSE
        NEW.id := NEW."principal_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('principalId', to_jsonb(NEW.id), 'stateEnc', to_jsonb(NEW."state_enc"), 'updatedAt', to_jsonb(NEW."updated_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: channel_header_pin_flag_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.channel_header_pin_flag_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."on" := CASE WHEN jsonb_typeof(NEW.json->'on') = 'boolean' THEN (NEW.json->'on')::boolean END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'on', to_jsonb(NEW."on"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: command_policies_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.command_policies_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."policy" := CASE WHEN jsonb_typeof(NEW.json->'policy') <> 'null' THEN NEW.json->'policy' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'policy', to_jsonb(NEW."policy"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: composio_returns_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.composio_returns_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."url" := CASE WHEN jsonb_typeof(NEW.json->'url') = 'string' THEN NEW.json->>'url' END;
        NEW."toolkit" := CASE WHEN jsonb_typeof(NEW.json->'toolkit') = 'string' THEN NEW.json->>'toolkit' END;
        NEW."expires_at" := CASE WHEN jsonb_typeof(NEW.json->'expiresAt') = 'number' THEN round((NEW.json->>'expiresAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('url', to_jsonb(NEW."url"), 'toolkit', to_jsonb(NEW."toolkit"), 'expiresAt', to_jsonb(NEW."expires_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: connector_clients_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.connector_clients_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."scope_id" := CASE WHEN jsonb_typeof(NEW.json->'scopeId') = 'string' THEN NEW.json->>'scopeId' END;
        NEW."provider" := CASE WHEN jsonb_typeof(NEW.json->'provider') = 'string' THEN NEW.json->>'provider' END;
        NEW."client_id" := CASE WHEN jsonb_typeof(NEW.json->'clientId') = 'string' THEN NEW.json->>'clientId' END;
        NEW."secret_enc" := CASE WHEN jsonb_typeof(NEW.json->'secretEnc') = 'string' THEN NEW.json->>'secretEnc' END;
        NEW."scopes" := CASE WHEN jsonb_typeof(NEW.json->'scopes') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'scopes')) END;
        NEW."redirect_allowlist" := CASE WHEN jsonb_typeof(NEW.json->'redirectAllowlist') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'redirectAllowlist')) END;
        NEW."consent_mode" := CASE WHEN jsonb_typeof(NEW.json->'consentMode') = 'string' THEN NEW.json->>'consentMode' END;
        NEW."hosted_domain" := CASE WHEN jsonb_typeof(NEW.json->'hostedDomain') = 'string' THEN NEW.json->>'hostedDomain' END;
        NEW."enabled" := CASE WHEN jsonb_typeof(NEW.json->'enabled') = 'boolean' THEN (NEW.json->'enabled')::boolean END;
        NEW."updated_by" := CASE WHEN jsonb_typeof(NEW.json->'updatedBy') = 'string' THEN NEW.json->>'updatedBy' END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW."scope_id"), 'provider', to_jsonb(NEW."provider"), 'clientId', to_jsonb(NEW."client_id"), 'secretEnc', to_jsonb(NEW."secret_enc"), 'scopes', to_jsonb(NEW."scopes"), 'redirectAllowlist', to_jsonb(NEW."redirect_allowlist"), 'consentMode', to_jsonb(NEW."consent_mode"), 'hostedDomain', to_jsonb(NEW."hosted_domain"), 'enabled', to_jsonb(NEW."enabled"), 'updatedBy', to_jsonb(NEW."updated_by"), 'updatedAt', to_jsonb(NEW."updated_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: connector_status_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.connector_status_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."checked_at" := CASE WHEN jsonb_typeof(NEW.json->'checkedAt') = 'number' THEN round((NEW.json->>'checkedAt')::numeric)::bigint END;
        NEW."providers" := CASE WHEN jsonb_typeof(NEW.json->'providers') <> 'null' THEN NEW.json->'providers' END;
        NEW."principal_id" := NEW.id;
      ELSE
        NEW.id := NEW."principal_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('principalId', to_jsonb(NEW.id), 'checkedAt', to_jsonb(NEW."checked_at"), 'providers', to_jsonb(NEW."providers"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: consent_links_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.consent_links_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."principal_id" := CASE WHEN jsonb_typeof(NEW.json->'principalId') = 'string' THEN NEW.json->>'principalId' END;
        NEW."org_id" := CASE WHEN jsonb_typeof(NEW.json->'orgId') = 'string' THEN NEW.json->>'orgId' END;
        NEW."provider" := CASE WHEN jsonb_typeof(NEW.json->'provider') = 'string' THEN NEW.json->>'provider' END;
        NEW."account_type" := CASE WHEN jsonb_typeof(NEW.json->'accountType') = 'string' THEN NEW.json->>'accountType' END;
        NEW."redirect_uri" := CASE WHEN jsonb_typeof(NEW.json->'redirectUri') = 'string' THEN NEW.json->>'redirectUri' END;
        NEW."return_to" := CASE WHEN jsonb_typeof(NEW.json->'returnTo') = 'string' THEN NEW.json->>'returnTo' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('principalId', to_jsonb(NEW."principal_id"), 'orgId', to_jsonb(NEW."org_id"), 'provider', to_jsonb(NEW."provider"), 'accountType', to_jsonb(NEW."account_type"), 'redirectUri', to_jsonb(NEW."redirect_uri"), 'returnTo', to_jsonb(NEW."return_to"), 'createdAt', to_jsonb(NEW."created_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: context_requests_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.context_requests_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."source" := CASE WHEN jsonb_typeof(NEW.json->'source') = 'string' THEN NEW.json->>'source' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."status" := CASE WHEN jsonb_typeof(NEW.json->'status') = 'string' THEN NEW.json->>'status' END;
        NEW."query" := CASE WHEN jsonb_typeof(NEW.json->'query') <> 'null' THEN NEW.json->'query' END;
        NEW."result" := CASE WHEN jsonb_typeof(NEW.json->'result') <> 'null' THEN NEW.json->'result' END;
        NEW."error" := CASE WHEN jsonb_typeof(NEW.json->'error') = 'string' THEN NEW.json->>'error' END;
        NEW."sealed_viewer_token" := CASE WHEN jsonb_typeof(NEW.json->'sealedViewerToken') = 'string' THEN NEW.json->>'sealedViewerToken' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'source', to_jsonb(NEW."source"), 'createdAt', to_jsonb(NEW."created_at"), 'status', to_jsonb(NEW."status"), 'query', to_jsonb(NEW."query"), 'result', to_jsonb(NEW."result"), 'error', to_jsonb(NEW."error"), 'sealedViewerToken', to_jsonb(NEW."sealed_viewer_token"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: cron_items_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cron_items_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."cron_id" := CASE WHEN jsonb_typeof(NEW.json->'cronId') = 'string' THEN NEW.json->>'cronId' END;
        NEW."source_key" := CASE WHEN jsonb_typeof(NEW.json->'sourceKey') = 'string' THEN NEW.json->>'sourceKey' END;
        NEW."source_summary" := CASE WHEN jsonb_typeof(NEW.json->'sourceSummary') = 'string' THEN NEW.json->>'sourceSummary' END;
        NEW."source" := CASE WHEN jsonb_typeof(NEW.json->'source') = 'string' THEN NEW.json->>'source' END;
        NEW."source_payload" := CASE WHEN jsonb_typeof(NEW.json->'sourcePayload') <> 'null' THEN NEW.json->'sourcePayload' END;
        NEW."conversation_key" := CASE WHEN jsonb_typeof(NEW.json->'conversationKey') = 'string' THEN NEW.json->>'conversationKey' END;
        NEW."source_at" := CASE WHEN jsonb_typeof(NEW.json->'sourceAt') = 'number' THEN (NEW.json->>'sourceAt')::float8 END;
        NEW."inbox_preview" := CASE WHEN jsonb_typeof(NEW.json->'inboxPreview') <> 'null' THEN NEW.json->'inboxPreview' END;
        NEW."proposal" := CASE WHEN jsonb_typeof(NEW.json->'proposal') <> 'null' THEN NEW.json->'proposal' END;
        NEW."agent_drafts" := CASE WHEN jsonb_typeof(NEW.json->'agentDrafts') <> 'null' THEN NEW.json->'agentDrafts' END;
        NEW."agent_mention_keys" := CASE WHEN jsonb_typeof(NEW.json->'agentMentionKeys') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'agentMentionKeys')) END;
        NEW."thread" := CASE WHEN jsonb_typeof(NEW.json->'thread') <> 'null' THEN NEW.json->'thread' END;
        NEW."status" := CASE WHEN jsonb_typeof(NEW.json->'status') = 'string' THEN NEW.json->>'status' END;
        NEW."parked_reason" := CASE WHEN jsonb_typeof(NEW.json->'parkedReason') = 'string' THEN NEW.json->>'parkedReason' END;
        NEW."acted_at" := CASE WHEN jsonb_typeof(NEW.json->'actedAt') = 'number' THEN round((NEW.json->>'actedAt')::numeric)::bigint END;
        NEW."action_kind" := CASE WHEN jsonb_typeof(NEW.json->'actionKind') = 'string' THEN NEW.json->>'actionKind' END;
        NEW."action_result" := CASE WHEN jsonb_typeof(NEW.json->'actionResult') = 'string' THEN NEW.json->>'actionResult' END;
        NEW."decision_at" := CASE WHEN jsonb_typeof(NEW.json->'decisionAt') = 'number' THEN (NEW.json->>'decisionAt')::float8 END;
        NEW."decision_token" := CASE WHEN jsonb_typeof(NEW.json->'decisionToken') = 'string' THEN NEW.json->>'decisionToken' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'cronId', to_jsonb(NEW."cron_id"), 'sourceKey', to_jsonb(NEW."source_key"), 'sourceSummary', to_jsonb(NEW."source_summary"), 'source', to_jsonb(NEW."source"), 'sourcePayload', to_jsonb(NEW."source_payload"), 'conversationKey', to_jsonb(NEW."conversation_key"), 'sourceAt', to_jsonb(NEW."source_at"), 'inboxPreview', to_jsonb(NEW."inbox_preview"), 'proposal', to_jsonb(NEW."proposal"), 'agentDrafts', to_jsonb(NEW."agent_drafts"), 'agentMentionKeys', to_jsonb(NEW."agent_mention_keys"), 'thread', to_jsonb(NEW."thread"), 'status', to_jsonb(NEW."status"), 'parkedReason', to_jsonb(NEW."parked_reason"), 'actedAt', to_jsonb(NEW."acted_at"), 'actionKind', to_jsonb(NEW."action_kind"), 'actionResult', to_jsonb(NEW."action_result"), 'decisionAt', to_jsonb(NEW."decision_at"), 'decisionToken', to_jsonb(NEW."decision_token"), 'createdAt', to_jsonb(NEW."created_at"), 'updatedAt', to_jsonb(NEW."updated_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: crons_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.crons_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."owner_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'ownerScopeId') = 'string' THEN NEW.json->>'ownerScopeId' END;
        NEW."owner" := CASE WHEN jsonb_typeof(NEW.json->'owner') = 'string' THEN NEW.json->>'owner' END;
        NEW."created_by" := CASE WHEN jsonb_typeof(NEW.json->'createdBy') = 'string' THEN NEW.json->>'createdBy' END;
        NEW."owner_consented_at" := CASE WHEN jsonb_typeof(NEW.json->'ownerConsentedAt') = 'number' THEN round((NEW.json->>'ownerConsentedAt')::numeric)::bigint END;
        NEW."destination" := CASE WHEN jsonb_typeof(NEW.json->'destination') <> 'null' THEN NEW.json->'destination' END;
        NEW."enabled" := CASE WHEN jsonb_typeof(NEW.json->'enabled') = 'boolean' THEN (NEW.json->'enabled')::boolean END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."last_fired_at" := CASE WHEN jsonb_typeof(NEW.json->'lastFiredAt') = 'number' THEN round((NEW.json->>'lastFiredAt')::numeric)::bigint END;
        NEW."runtime" := CASE WHEN jsonb_typeof(NEW.json->'runtime') <> 'null' THEN NEW.json->'runtime' END;
        NEW."schedule" := CASE WHEN jsonb_typeof(NEW.json->'schedule') <> 'null' THEN NEW.json->'schedule' END;
        NEW."next_fire_at" := CASE WHEN jsonb_typeof(NEW.json->'nextFireAt') = 'number' THEN round((NEW.json->>'nextFireAt')::numeric)::bigint END;
        NEW."defer_until" := CASE WHEN jsonb_typeof(NEW.json->'deferUntil') = 'number' THEN round((NEW.json->>'deferUntil')::numeric)::bigint END;
        NEW."title" := CASE WHEN jsonb_typeof(NEW.json->'title') = 'string' THEN NEW.json->>'title' END;
        NEW."archived" := CASE WHEN jsonb_typeof(NEW.json->'archived') = 'boolean' THEN (NEW.json->'archived')::boolean END;
        NEW."action" := CASE WHEN jsonb_typeof(NEW.json->'action') = 'string' THEN NEW.json->>'action' END;
        NEW."message" := CASE WHEN jsonb_typeof(NEW.json->'message') = 'string' THEN NEW.json->>'message' END;
        NEW."inbox" := CASE WHEN jsonb_typeof(NEW.json->'inbox') <> 'null' THEN NEW.json->'inbox' END;
        NEW."unattended_grants" := CASE WHEN jsonb_typeof(NEW.json->'unattendedGrants') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'unattendedGrants')) END;
        NEW."session_ref" := CASE WHEN jsonb_typeof(NEW.json->'sessionRef') = 'string' THEN NEW.json->>'sessionRef' END;
        NEW."last_fire_note" := CASE WHEN jsonb_typeof(NEW.json->'lastFireNote') <> 'null' THEN NEW.json->'lastFireNote' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'ownerScopeId', to_jsonb(NEW."owner_scope_id"), 'owner', to_jsonb(NEW."owner"), 'createdBy', to_jsonb(NEW."created_by"), 'ownerConsentedAt', to_jsonb(NEW."owner_consented_at"), 'destination', to_jsonb(NEW."destination"), 'enabled', to_jsonb(NEW."enabled"), 'createdAt', to_jsonb(NEW."created_at"), 'lastFiredAt', to_jsonb(NEW."last_fired_at"), 'runtime', to_jsonb(NEW."runtime"), 'schedule', to_jsonb(NEW."schedule"), 'nextFireAt', to_jsonb(NEW."next_fire_at"), 'deferUntil', to_jsonb(NEW."defer_until"), 'title', to_jsonb(NEW."title"), 'archived', to_jsonb(NEW."archived"), 'action', to_jsonb(NEW."action"), 'message', to_jsonb(NEW."message"), 'inbox', to_jsonb(NEW."inbox"), 'unattendedGrants', to_jsonb(NEW."unattended_grants"), 'sessionRef', to_jsonb(NEW."session_ref"), 'lastFireNote', to_jsonb(NEW."last_fire_note"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: custom_model_providers_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.custom_model_providers_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."name" := CASE WHEN jsonb_typeof(NEW.json->'name') = 'string' THEN NEW.json->>'name' END;
        NEW."protocol" := CASE WHEN jsonb_typeof(NEW.json->'protocol') = 'string' THEN NEW.json->>'protocol' END;
        NEW."base_url" := CASE WHEN jsonb_typeof(NEW.json->'baseUrl') = 'string' THEN NEW.json->>'baseUrl' END;
        NEW."models" := CASE WHEN jsonb_typeof(NEW.json->'models') <> 'null' THEN NEW.json->'models' END;
        NEW."api_key_enc" := CASE WHEN jsonb_typeof(NEW.json->'apiKeyEnc') = 'string' THEN NEW.json->>'apiKeyEnc' END;
        NEW."disabled" := CASE WHEN jsonb_typeof(NEW.json->'disabled') = 'boolean' THEN (NEW.json->'disabled')::boolean END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."updated_by" := CASE WHEN jsonb_typeof(NEW.json->'updatedBy') = 'string' THEN NEW.json->>'updatedBy' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'name', to_jsonb(NEW."name"), 'protocol', to_jsonb(NEW."protocol"), 'baseUrl', to_jsonb(NEW."base_url"), 'models', to_jsonb(NEW."models"), 'apiKeyEnc', to_jsonb(NEW."api_key_enc"), 'disabled', to_jsonb(NEW."disabled"), 'updatedAt', to_jsonb(NEW."updated_at"), 'updatedBy', to_jsonb(NEW."updated_by"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: deactivated_principals_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.deactivated_principals_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."principal_id" := CASE WHEN jsonb_typeof(NEW.json->'principalId') = 'string' THEN NEW.json->>'principalId' END;
        NEW."source" := CASE WHEN jsonb_typeof(NEW.json->'source') = 'string' THEN NEW.json->>'source' END;
        NEW."at" := CASE WHEN jsonb_typeof(NEW.json->'at') = 'number' THEN round((NEW.json->>'at')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('principalId', to_jsonb(NEW."principal_id"), 'source', to_jsonb(NEW."source"), 'at', to_jsonb(NEW."at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: deploy_git_repos_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.deploy_git_repos_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."bundle_b64" := CASE WHEN jsonb_typeof(NEW.json->'bundleB64') = 'string' THEN NEW.json->>'bundleB64' END;
        NEW."blob_key" := CASE WHEN jsonb_typeof(NEW.json->'blobKey') = 'string' THEN NEW.json->>'blobKey' END;
        NEW."etag" := CASE WHEN jsonb_typeof(NEW.json->'etag') = 'string' THEN NEW.json->>'etag' END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."deployment_id" := NEW.id;
      ELSE
        NEW.id := NEW."deployment_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('deploymentId', to_jsonb(NEW.id), 'bundleB64', to_jsonb(NEW."bundle_b64"), 'blobKey', to_jsonb(NEW."blob_key"), 'etag', to_jsonb(NEW."etag"), 'updatedAt', to_jsonb(NEW."updated_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: deployment_identity_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.deployment_identity_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."org_id" := CASE WHEN jsonb_typeof(NEW.json->'orgId') = 'string' THEN NEW.json->>'orgId' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('orgId', to_jsonb(NEW."org_id"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: deployment_layer_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.deployment_layer_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."content_hash" := CASE WHEN jsonb_typeof(NEW.json->'contentHash') = 'string' THEN NEW.json->>'contentHash' END;
        NEW."version" := CASE WHEN jsonb_typeof(NEW.json->'version') = 'number' THEN round((NEW.json->>'version')::numeric)::bigint END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."updated_by" := CASE WHEN jsonb_typeof(NEW.json->'updatedBy') = 'string' THEN NEW.json->>'updatedBy' END;
        NEW."bundle" := CASE WHEN jsonb_typeof(NEW.json->'bundle') <> 'null' THEN NEW.json->'bundle' END;
        NEW."resolved" := CASE WHEN jsonb_typeof(NEW.json->'resolved') <> 'null' THEN NEW.json->'resolved' END;
        NEW."pending_audits" := CASE WHEN jsonb_typeof(NEW.json->'pendingAudits') <> 'null' THEN NEW.json->'pendingAudits' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('contentHash', to_jsonb(NEW."content_hash"), 'version', to_jsonb(NEW."version"), 'updatedAt', to_jsonb(NEW."updated_at"), 'updatedBy', to_jsonb(NEW."updated_by"), 'bundle', to_jsonb(NEW."bundle"), 'resolved', to_jsonb(NEW."resolved"), 'pendingAudits', to_jsonb(NEW."pending_audits"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: deployments_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.deployments_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."owner_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'ownerScopeId') = 'string' THEN NEW.json->>'ownerScopeId' END;
        NEW."created_by" := CASE WHEN jsonb_typeof(NEW.json->'createdBy') = 'string' THEN NEW.json->>'createdBy' END;
        NEW."created_in_scope" := CASE WHEN jsonb_typeof(NEW.json->'createdInScope') = 'string' THEN NEW.json->>'createdInScope' END;
        NEW."default_audience" := CASE WHEN jsonb_typeof(NEW.json->'defaultAudience') <> 'null' THEN NEW.json->'defaultAudience' END;
        NEW."name" := CASE WHEN jsonb_typeof(NEW.json->'name') = 'string' THEN NEW.json->>'name' END;
        NEW."display_name" := CASE WHEN jsonb_typeof(NEW.json->'displayName') = 'string' THEN NEW.json->>'displayName' END;
        NEW."current_version" := CASE WHEN jsonb_typeof(NEW.json->'currentVersion') = 'number' THEN round((NEW.json->>'currentVersion')::numeric)::bigint END;
        NEW."status" := CASE WHEN jsonb_typeof(NEW.json->'status') = 'string' THEN NEW.json->>'status' END;
        NEW."endpoint" := CASE WHEN jsonb_typeof(NEW.json->'endpoint') <> 'null' THEN NEW.json->'endpoint' END;
        NEW."always_on" := CASE WHEN jsonb_typeof(NEW.json->'alwaysOn') = 'boolean' THEN (NEW.json->'alwaysOn')::boolean END;
        NEW."embed_ancestors" := CASE WHEN jsonb_typeof(NEW.json->'embedAncestors') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'embedAncestors')) END;
        NEW."public" := CASE WHEN jsonb_typeof(NEW.json->'public') = 'boolean' THEN (NEW.json->'public')::boolean END;
        NEW."applied_version" := CASE WHEN jsonb_typeof(NEW.json->'appliedVersion') = 'number' THEN round((NEW.json->>'appliedVersion')::numeric)::bigint END;
        NEW."last_access_at" := CASE WHEN jsonb_typeof(NEW.json->'lastAccessAt') = 'number' THEN round((NEW.json->>'lastAccessAt')::numeric)::bigint END;
        NEW."versions" := CASE WHEN jsonb_typeof(NEW.json->'versions') <> 'null' THEN NEW.json->'versions' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'ownerScopeId', to_jsonb(NEW."owner_scope_id"), 'createdBy', to_jsonb(NEW."created_by"), 'createdInScope', to_jsonb(NEW."created_in_scope"), 'defaultAudience', to_jsonb(NEW."default_audience"), 'name', to_jsonb(NEW."name"), 'displayName', to_jsonb(NEW."display_name"), 'currentVersion', to_jsonb(NEW."current_version"), 'status', to_jsonb(NEW."status"), 'endpoint', to_jsonb(NEW."endpoint"), 'alwaysOn', to_jsonb(NEW."always_on"), 'embedAncestors', to_jsonb(NEW."embed_ancestors"), 'public', to_jsonb(NEW."public"), 'appliedVersion', to_jsonb(NEW."applied_version"), 'lastAccessAt', to_jsonb(NEW."last_access_at"), 'versions', to_jsonb(NEW."versions"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: e2b_sandbox_bodies_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.e2b_sandbox_bodies_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."initialization_pending" := CASE WHEN jsonb_typeof(NEW.json->'initializationPending') = 'boolean' THEN (NEW.json->'initializationPending')::boolean END;
        NEW."last_snapshot_ms" := CASE WHEN jsonb_typeof(NEW.json->'lastSnapshotMs') = 'number' THEN round((NEW.json->>'lastSnapshotMs')::numeric)::bigint END;
        NEW."home_dirty" := CASE WHEN jsonb_typeof(NEW.json->'homeDirty') = 'boolean' THEN (NEW.json->'homeDirty')::boolean END;
        NEW."snapshot_error" := CASE WHEN jsonb_typeof(NEW.json->'snapshotError') = 'string' THEN NEW.json->>'snapshotError' END;
        NEW."checkpoint_id" := CASE WHEN jsonb_typeof(NEW.json->'checkpointId') = 'string' THEN NEW.json->>'checkpointId' END;
        NEW."checkpoint_at_ms" := CASE WHEN jsonb_typeof(NEW.json->'checkpointAtMs') = 'number' THEN round((NEW.json->>'checkpointAtMs')::numeric)::bigint END;
        NEW."sandbox_id" := CASE WHEN jsonb_typeof(NEW.json->'sandboxId') = 'string' THEN NEW.json->>'sandboxId' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('initializationPending', to_jsonb(NEW."initialization_pending"), 'lastSnapshotMs', to_jsonb(NEW."last_snapshot_ms"), 'homeDirty', to_jsonb(NEW."home_dirty"), 'snapshotError', to_jsonb(NEW."snapshot_error"), 'checkpointId', to_jsonb(NEW."checkpoint_id"), 'checkpointAtMs', to_jsonb(NEW."checkpoint_at_ms"), 'sandboxId', to_jsonb(NEW."sandbox_id"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: egress_policies_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.egress_policies_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."policy" := CASE WHEN jsonb_typeof(NEW.json->'policy') <> 'null' THEN NEW.json->'policy' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'policy', to_jsonb(NEW."policy"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: external_members_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.external_members_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."email" := CASE WHEN jsonb_typeof(NEW.json->'email') = 'string' THEN NEW.json->>'email' END;
        NEW."role" := CASE WHEN jsonb_typeof(NEW.json->'role') = 'string' THEN NEW.json->>'role' END;
        NEW."expires_at" := CASE WHEN jsonb_typeof(NEW.json->'expiresAt') = 'number' THEN round((NEW.json->>'expiresAt')::numeric)::bigint END;
        NEW."kind" := CASE WHEN jsonb_typeof(NEW.json->'kind') = 'string' THEN NEW.json->>'kind' END;
        NEW."invite_id" := CASE WHEN jsonb_typeof(NEW.json->'inviteId') = 'string' THEN NEW.json->>'inviteId' END;
        NEW."invited_by" := CASE WHEN jsonb_typeof(NEW.json->'invitedBy') = 'string' THEN NEW.json->>'invitedBy' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('email', to_jsonb(NEW."email"), 'role', to_jsonb(NEW."role"), 'expiresAt', to_jsonb(NEW."expires_at"), 'kind', to_jsonb(NEW."kind"), 'inviteId', to_jsonb(NEW."invite_id"), 'invitedBy', to_jsonb(NEW."invited_by"), 'createdAt', to_jsonb(NEW."created_at"), 'updatedAt', to_jsonb(NEW."updated_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: external_slack_participants_flag_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.external_slack_participants_flag_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."on" := CASE WHEN jsonb_typeof(NEW.json->'on') = 'boolean' THEN (NEW.json->'on')::boolean END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'on', to_jsonb(NEW."on"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: feature_flags_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.feature_flags_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."enabled_scopes" := CASE WHEN jsonb_typeof(NEW.json->'enabledScopes') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'enabledScopes')) END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."updated_by" := CASE WHEN jsonb_typeof(NEW.json->'updatedBy') = 'string' THEN NEW.json->>'updatedBy' END;
        NEW."feature_name" := NEW.id;
      ELSE
        NEW.id := NEW."feature_name";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('featureName', to_jsonb(NEW.id), 'enabledScopes', to_jsonb(NEW."enabled_scopes"), 'updatedAt', to_jsonb(NEW."updated_at"), 'updatedBy', to_jsonb(NEW."updated_by"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: forbid_direct_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_direct_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     IF pg_trigger_depth() > 1 THEN RETURN OLD; END IF;
     RAISE EXCEPTION 'DELETE on % is only allowed through its session', TG_TABLE_NAME
       USING ERRCODE = 'integrity_constraint_violation';
   END $$;


--
-- Name: forbid_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.forbid_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
     RAISE EXCEPTION '% on % is forbidden', TG_OP, TG_TABLE_NAME USING ERRCODE = 'integrity_constraint_violation';
   END $$;


--
-- Name: idempotency_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.idempotency_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."at" := CASE WHEN jsonb_typeof(NEW.json->'at') = 'number' THEN round((NEW.json->>'at')::numeric)::bigint END;
        NEW."claim" := CASE WHEN jsonb_typeof(NEW.json->'claim') = 'string' THEN NEW.json->>'claim' END;
        NEW."key" := NEW.id;
      ELSE
        NEW.id := NEW."key";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('key', to_jsonb(NEW.id), 'at', to_jsonb(NEW."at"), 'claim', to_jsonb(NEW."claim"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: individual_model_auth_flag_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.individual_model_auth_flag_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."on" := CASE WHEN jsonb_typeof(NEW.json->'on') = 'boolean' THEN (NEW.json->'on')::boolean END;
        NEW."provider" := CASE WHEN jsonb_typeof(NEW.json->'provider') = 'string' THEN NEW.json->>'provider' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'on', to_jsonb(NEW."on"), 'provider', to_jsonb(NEW."provider"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: interactive_fast_mode_flag_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.interactive_fast_mode_flag_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."on" := CASE WHEN jsonb_typeof(NEW.json->'on') = 'boolean' THEN (NEW.json->'on')::boolean END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'on', to_jsonb(NEW."on"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: invalidate_request_spend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_request_spend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
           BEGIN
             INSERT INTO session_spend_dirty(day)
             SELECT DISTINCT floor(at::numeric / 86400000)::bigint
               FROM (VALUES
                 (CASE WHEN TG_OP <> 'INSERT' AND OLD.usage_json IS NOT NULL THEN OLD.created_at END),
                 (CASE WHEN TG_OP <> 'DELETE' AND NEW.usage_json IS NOT NULL THEN NEW.created_at END)
               ) changed(at) WHERE at IS NOT NULL
             ON CONFLICT DO NOTHING;
             RETURN NULL;
           END $$;


--
-- Name: invalidate_session_spend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_session_spend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
           BEGIN
             IF TG_OP = 'UPDATE' AND ROW(OLD.id, OLD.scope_id, OLD.origin, OLD.thread_ref, OLD.parent_session_id)
                  IS NOT DISTINCT FROM ROW(NEW.id, NEW.scope_id, NEW.origin, NEW.thread_ref, NEW.parent_session_id) THEN
               RETURN NULL;
             END IF;
             INSERT INTO session_spend_dirty(session_id)
             SELECT DISTINCT id FROM (VALUES (OLD.id), (NEW.id)) changed(id) WHERE id IS NOT NULL;
             RETURN NULL;
           END $$;


--
-- Name: keychain_asks_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.keychain_asks_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."credential_id" := CASE WHEN jsonb_typeof(NEW.json->'credentialId') = 'string' THEN NEW.json->>'credentialId' END;
        NEW."owner_id" := CASE WHEN jsonb_typeof(NEW.json->'ownerId') = 'string' THEN NEW.json->>'ownerId' END;
        NEW."requester_id" := CASE WHEN jsonb_typeof(NEW.json->'requesterId') = 'string' THEN NEW.json->>'requesterId' END;
        NEW."org_id" := CASE WHEN jsonb_typeof(NEW.json->'orgId') = 'string' THEN NEW.json->>'orgId' END;
        NEW."requester_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'requesterScopeId') = 'string' THEN NEW.json->>'requesterScopeId' END;
        NEW."requester_destination" := CASE WHEN jsonb_typeof(NEW.json->'requesterDestination') <> 'null' THEN NEW.json->'requesterDestination' END;
        NEW."requester_thread_ref" := CASE WHEN jsonb_typeof(NEW.json->'requesterThreadRef') = 'string' THEN NEW.json->>'requesterThreadRef' END;
        NEW."requester_seq" := CASE WHEN jsonb_typeof(NEW.json->'requesterSeq') = 'number' THEN round((NEW.json->>'requesterSeq')::numeric)::bigint END;
        NEW."requester_message_ts" := CASE WHEN jsonb_typeof(NEW.json->'requesterMessageTs') = 'string' THEN NEW.json->>'requesterMessageTs' END;
        NEW."purpose" := CASE WHEN jsonb_typeof(NEW.json->'purpose') = 'string' THEN NEW.json->>'purpose' END;
        NEW."requested_mode" := CASE WHEN jsonb_typeof(NEW.json->'requestedMode') = 'string' THEN NEW.json->>'requestedMode' END;
        NEW."status" := CASE WHEN jsonb_typeof(NEW.json->'status') = 'string' THEN NEW.json->>'status' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."expires_at" := CASE WHEN jsonb_typeof(NEW.json->'expiresAt') = 'number' THEN round((NEW.json->>'expiresAt')::numeric)::bigint END;
        NEW."resolved_at" := CASE WHEN jsonb_typeof(NEW.json->'resolvedAt') = 'number' THEN round((NEW.json->>'resolvedAt')::numeric)::bigint END;
        NEW."grant_id" := CASE WHEN jsonb_typeof(NEW.json->'grantId') = 'string' THEN NEW.json->>'grantId' END;
        NEW."note" := CASE WHEN jsonb_typeof(NEW.json->'note') = 'string' THEN NEW.json->>'note' END;
        NEW."notified_at" := CASE WHEN jsonb_typeof(NEW.json->'notifiedAt') = 'number' THEN round((NEW.json->>'notifiedAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'credentialId', to_jsonb(NEW."credential_id"), 'ownerId', to_jsonb(NEW."owner_id"), 'requesterId', to_jsonb(NEW."requester_id"), 'orgId', to_jsonb(NEW."org_id"), 'requesterScopeId', to_jsonb(NEW."requester_scope_id"), 'requesterDestination', to_jsonb(NEW."requester_destination"), 'requesterThreadRef', to_jsonb(NEW."requester_thread_ref"), 'requesterSeq', to_jsonb(NEW."requester_seq"), 'requesterMessageTs', to_jsonb(NEW."requester_message_ts"), 'purpose', to_jsonb(NEW."purpose"), 'requestedMode', to_jsonb(NEW."requested_mode"), 'status', to_jsonb(NEW."status"), 'createdAt', to_jsonb(NEW."created_at"), 'expiresAt', to_jsonb(NEW."expires_at"), 'resolvedAt', to_jsonb(NEW."resolved_at"), 'grantId', to_jsonb(NEW."grant_id"), 'note', to_jsonb(NEW."note"), 'notifiedAt', to_jsonb(NEW."notified_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: keychain_credentials_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.keychain_credentials_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."owner_id" := CASE WHEN jsonb_typeof(NEW.json->'ownerId') = 'string' THEN NEW.json->>'ownerId' END;
        NEW."org_id" := CASE WHEN jsonb_typeof(NEW.json->'orgId') = 'string' THEN NEW.json->>'orgId' END;
        NEW."service" := CASE WHEN jsonb_typeof(NEW.json->'service') = 'string' THEN NEW.json->>'service' END;
        NEW."kind" := CASE WHEN jsonb_typeof(NEW.json->'kind') = 'string' THEN NEW.json->>'kind' END;
        NEW."env_key" := CASE WHEN jsonb_typeof(NEW.json->'envKey') = 'string' THEN NEW.json->>'envKey' END;
        NEW."targets" := CASE WHEN jsonb_typeof(NEW.json->'targets') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'targets')) END;
        NEW."host" := CASE WHEN jsonb_typeof(NEW.json->'host') = 'string' THEN NEW.json->>'host' END;
        NEW."account_label" := CASE WHEN jsonb_typeof(NEW.json->'accountLabel') = 'string' THEN NEW.json->>'accountLabel' END;
        NEW."fields" := CASE WHEN jsonb_typeof(NEW.json->'fields') <> 'null' THEN NEW.json->'fields' END;
        NEW."broker" := CASE WHEN jsonb_typeof(NEW.json->'broker') <> 'null' THEN NEW.json->'broker' END;
        NEW."refresh" := CASE WHEN jsonb_typeof(NEW.json->'refresh') <> 'null' THEN NEW.json->'refresh' END;
        NEW."managed" := CASE WHEN jsonb_typeof(NEW.json->'managed') = 'string' THEN NEW.json->>'managed' END;
        NEW."secret_enc" := CASE WHEN jsonb_typeof(NEW.json->'secretEnc') = 'string' THEN NEW.json->>'secretEnc' END;
        NEW."fingerprint" := CASE WHEN jsonb_typeof(NEW.json->'fingerprint') = 'string' THEN NEW.json->>'fingerprint' END;
        NEW."origin" := CASE WHEN jsonb_typeof(NEW.json->'origin') = 'string' THEN NEW.json->>'origin' END;
        NEW."expires_at" := CASE WHEN jsonb_typeof(NEW.json->'expiresAt') = 'number' THEN round((NEW.json->>'expiresAt')::numeric)::bigint END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."target" := CASE WHEN jsonb_typeof(NEW.json->'target') = 'string' THEN NEW.json->>'target' END;
        NEW."username" := CASE WHEN jsonb_typeof(NEW.json->'username') = 'string' THEN NEW.json->>'username' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'ownerId', to_jsonb(NEW."owner_id"), 'orgId', to_jsonb(NEW."org_id"), 'service', to_jsonb(NEW."service"), 'kind', to_jsonb(NEW."kind"), 'envKey', to_jsonb(NEW."env_key"), 'targets', to_jsonb(NEW."targets"), 'host', to_jsonb(NEW."host"), 'accountLabel', to_jsonb(NEW."account_label"), 'fields', to_jsonb(NEW."fields"), 'broker', to_jsonb(NEW."broker"), 'refresh', to_jsonb(NEW."refresh"), 'managed', to_jsonb(NEW."managed"), 'secretEnc', to_jsonb(NEW."secret_enc"), 'fingerprint', to_jsonb(NEW."fingerprint"), 'origin', to_jsonb(NEW."origin"), 'expiresAt', to_jsonb(NEW."expires_at"), 'createdAt', to_jsonb(NEW."created_at"), 'updatedAt', to_jsonb(NEW."updated_at"), 'target', to_jsonb(NEW."target"), 'username', to_jsonb(NEW."username"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: keychain_grants_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.keychain_grants_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."credential_id" := CASE WHEN jsonb_typeof(NEW.json->'credentialId') = 'string' THEN NEW.json->>'credentialId' END;
        NEW."owner_id" := CASE WHEN jsonb_typeof(NEW.json->'ownerId') = 'string' THEN NEW.json->>'ownerId' END;
        NEW."org_id" := CASE WHEN jsonb_typeof(NEW.json->'orgId') = 'string' THEN NEW.json->>'orgId' END;
        NEW."audience_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'audienceScopeId') = 'string' THEN NEW.json->>'audienceScopeId' END;
        NEW."mode" := CASE WHEN jsonb_typeof(NEW.json->'mode') = 'string' THEN NEW.json->>'mode' END;
        NEW."purpose" := CASE WHEN jsonb_typeof(NEW.json->'purpose') = 'string' THEN NEW.json->>'purpose' END;
        NEW."status" := CASE WHEN jsonb_typeof(NEW.json->'status') = 'string' THEN NEW.json->>'status' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."expires_at" := CASE WHEN jsonb_typeof(NEW.json->'expiresAt') = 'number' THEN round((NEW.json->>'expiresAt')::numeric)::bigint END;
        NEW."revoked_at" := CASE WHEN jsonb_typeof(NEW.json->'revokedAt') = 'number' THEN round((NEW.json->>'revokedAt')::numeric)::bigint END;
        NEW."used_at" := CASE WHEN jsonb_typeof(NEW.json->'usedAt') = 'number' THEN round((NEW.json->>'usedAt')::numeric)::bigint END;
        NEW."used_by" := CASE WHEN jsonb_typeof(NEW.json->'usedBy') = 'string' THEN NEW.json->>'usedBy' END;
        NEW."ask_id" := CASE WHEN jsonb_typeof(NEW.json->'askId') = 'string' THEN NEW.json->>'askId' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'credentialId', to_jsonb(NEW."credential_id"), 'ownerId', to_jsonb(NEW."owner_id"), 'orgId', to_jsonb(NEW."org_id"), 'audienceScopeId', to_jsonb(NEW."audience_scope_id"), 'mode', to_jsonb(NEW."mode"), 'purpose', to_jsonb(NEW."purpose"), 'status', to_jsonb(NEW."status"), 'createdAt', to_jsonb(NEW."created_at"), 'expiresAt', to_jsonb(NEW."expires_at"), 'revokedAt', to_jsonb(NEW."revoked_at"), 'usedAt', to_jsonb(NEW."used_at"), 'usedBy', to_jsonb(NEW."used_by"), 'askId', to_jsonb(NEW."ask_id"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: llm_request_spend_columns(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.llm_request_spend_columns() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
             DECLARE u jsonb := llm_spend_usage(NEW.usage_json);
             BEGIN
               IF NEW.usage_json IS NULL THEN
                 NEW.spend_cost_usd := NULL; NEW.spend_input := NULL; NEW.spend_output := NULL; NEW.spend_cache_read := NULL; NEW.spend_cache_write := NULL;
               ELSE
                 NEW.spend_cost_usd := COALESCE((u ->> 'costUsd')::double precision, 0); NEW.spend_input := COALESCE((u ->> 'input')::bigint, 0); NEW.spend_output := COALESCE((u ->> 'output')::bigint, 0); NEW.spend_cache_read := COALESCE((u ->> 'cacheRead')::bigint, 0); NEW.spend_cache_write := COALESCE((u ->> 'cacheWrite')::bigint, 0);
               END IF;
               RETURN NEW;
             END
             $$;


--
-- Name: llm_spend_usage(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.llm_spend_usage(t text) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE PARALLEL RESTRICTED
    AS $$
             DECLARE j jsonb;
             BEGIN
               IF t IS NULL OR NOT pg_input_is_valid(t, 'jsonb') THEN RETURN NULL; END IF;
               j := t::jsonb;
               IF pg_input_is_valid(j ->> 'costUsd', 'double precision') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'input', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'output', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheRead', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheWrite', 'bigint') IS NOT FALSE THEN
                 RETURN j;
               END IF;
               RETURN NULL;
             EXCEPTION WHEN statement_too_complex OR program_limit_exceeded THEN
               RETURN NULL;
             END
             $$;


--
-- Name: mark_attribution_dirty(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mark_attribution_dirty() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
           BEGIN
             IF NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = 'attributed_turns_dirty'::regclass
                             AND attname = 'tenant_id' AND NOT attisdropped) THEN
               INSERT INTO attributed_turns_dirty(session_id) VALUES (COALESCE(NEW.session_id, OLD.session_id))
               ON CONFLICT DO NOTHING;
             ELSIF TG_OP = 'DELETE' THEN
               INSERT INTO attributed_turns_dirty(tenant_id, session_id) VALUES (OLD.tenant_id, OLD.session_id)
               ON CONFLICT DO NOTHING;
             ELSE
               INSERT INTO attributed_turns_dirty(tenant_id, session_id) VALUES (NEW.tenant_id, NEW.session_id)
               ON CONFLICT DO NOTHING;
             END IF;
             RETURN NULL;
           END $$;


--
-- Name: mcp_servers_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mcp_servers_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."name" := CASE WHEN jsonb_typeof(NEW.json->'name') = 'string' THEN NEW.json->>'name' END;
        NEW."url" := CASE WHEN jsonb_typeof(NEW.json->'url') = 'string' THEN NEW.json->>'url' END;
        NEW."auth" := CASE WHEN jsonb_typeof(NEW.json->'auth') = 'string' THEN NEW.json->>'auth' END;
        NEW."credential_scope" := CASE WHEN jsonb_typeof(NEW.json->'credentialScope') = 'string' THEN NEW.json->>'credentialScope' END;
        NEW."credential_host" := CASE WHEN jsonb_typeof(NEW.json->'credentialHost') = 'string' THEN NEW.json->>'credentialHost' END;
        NEW."credential_account_type" := CASE WHEN jsonb_typeof(NEW.json->'credentialAccountType') = 'string' THEN NEW.json->>'credentialAccountType' END;
        NEW."bearer_token" := CASE WHEN jsonb_typeof(NEW.json->'bearerToken') = 'string' THEN NEW.json->>'bearerToken' END;
        NEW."client_id" := CASE WHEN jsonb_typeof(NEW.json->'clientId') = 'string' THEN NEW.json->>'clientId' END;
        NEW."client_secret" := CASE WHEN jsonb_typeof(NEW.json->'clientSecret') = 'string' THEN NEW.json->>'clientSecret' END;
        NEW."oauth_authorize_url" := CASE WHEN jsonb_typeof(NEW.json->'oauthAuthorizeUrl') = 'string' THEN NEW.json->>'oauthAuthorizeUrl' END;
        NEW."oauth_token_url" := CASE WHEN jsonb_typeof(NEW.json->'oauthTokenUrl') = 'string' THEN NEW.json->>'oauthTokenUrl' END;
        NEW."oauth_scopes" := CASE WHEN jsonb_typeof(NEW.json->'oauthScopes') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'oauthScopes')) END;
        NEW."tools" := CASE WHEN jsonb_typeof(NEW.json->'tools') <> 'null' THEN NEW.json->'tools' END;
        NEW."approval" := CASE WHEN jsonb_typeof(NEW.json->'approval') = 'string' THEN NEW.json->>'approval' END;
        NEW."catalog" := CASE WHEN jsonb_typeof(NEW.json->'catalog') = 'boolean' THEN (NEW.json->'catalog')::boolean END;
        NEW."attest_actor" := CASE WHEN jsonb_typeof(NEW.json->'attestActor') = 'boolean' THEN (NEW.json->'attestActor')::boolean END;
        NEW."read_only" := CASE WHEN jsonb_typeof(NEW.json->'readOnly') = 'boolean' THEN (NEW.json->'readOnly')::boolean END;
        NEW."enabled" := CASE WHEN jsonb_typeof(NEW.json->'enabled') = 'boolean' THEN (NEW.json->'enabled')::boolean END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."updated_by" := CASE WHEN jsonb_typeof(NEW.json->'updatedBy') = 'string' THEN NEW.json->>'updatedBy' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'name', to_jsonb(NEW."name"), 'url', to_jsonb(NEW."url"), 'auth', to_jsonb(NEW."auth"), 'credentialScope', to_jsonb(NEW."credential_scope"), 'credentialHost', to_jsonb(NEW."credential_host"), 'credentialAccountType', to_jsonb(NEW."credential_account_type"), 'bearerToken', to_jsonb(NEW."bearer_token"), 'clientId', to_jsonb(NEW."client_id"), 'clientSecret', to_jsonb(NEW."client_secret"), 'oauthAuthorizeUrl', to_jsonb(NEW."oauth_authorize_url"), 'oauthTokenUrl', to_jsonb(NEW."oauth_token_url"), 'oauthScopes', to_jsonb(NEW."oauth_scopes"), 'tools', to_jsonb(NEW."tools"), 'approval', to_jsonb(NEW."approval"), 'catalog', to_jsonb(NEW."catalog"), 'attestActor', to_jsonb(NEW."attest_actor"), 'readOnly', to_jsonb(NEW."read_only"), 'enabled', to_jsonb(NEW."enabled"), 'updatedAt', to_jsonb(NEW."updated_at"), 'updatedBy', to_jsonb(NEW."updated_by"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: memory_capture_pending_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.memory_capture_pending_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."scope_id" := CASE WHEN jsonb_typeof(NEW.json->'scopeId') = 'string' THEN NEW.json->>'scopeId' END;
        NEW."actor_id" := CASE WHEN jsonb_typeof(NEW.json->'actorId') = 'string' THEN NEW.json->>'actorId' END;
        NEW."conversation_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'conversationScopeId') = 'string' THEN NEW.json->>'conversationScopeId' END;
        NEW."session_id" := CASE WHEN jsonb_typeof(NEW.json->'sessionId') = 'string' THEN NEW.json->>'sessionId' END;
        NEW."idempotency_key" := CASE WHEN jsonb_typeof(NEW.json->'idempotencyKey') = 'string' THEN NEW.json->>'idempotencyKey' END;
        NEW."sensitivity" := CASE WHEN jsonb_typeof(NEW.json->'sensitivity') = 'string' THEN NEW.json->>'sensitivity' END;
        NEW."inherited_facts" := CASE WHEN jsonb_typeof(NEW.json->'inheritedFacts') <> 'null' THEN NEW.json->'inheritedFacts' END;
        NEW."turns" := CASE WHEN jsonb_typeof(NEW.json->'turns') <> 'null' THEN NEW.json->'turns' END;
        NEW."token" := CASE WHEN jsonb_typeof(NEW.json->'token') = 'string' THEN NEW.json->>'token' END;
        NEW."at" := CASE WHEN jsonb_typeof(NEW.json->'at') = 'number' THEN round((NEW.json->>'at')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW."scope_id"), 'actorId', to_jsonb(NEW."actor_id"), 'conversationScopeId', to_jsonb(NEW."conversation_scope_id"), 'sessionId', to_jsonb(NEW."session_id"), 'idempotencyKey', to_jsonb(NEW."idempotency_key"), 'sensitivity', to_jsonb(NEW."sensitivity"), 'inheritedFacts', to_jsonb(NEW."inherited_facts"), 'turns', to_jsonb(NEW."turns"), 'token', to_jsonb(NEW."token"), 'at', to_jsonb(NEW."at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: memory_facts_text_hash(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.memory_facts_text_hash() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
       BEGIN
         NEW.text_hash := encode(sha256(convert_to(NEW.text, 'UTF8')), 'hex');
         RETURN NEW;
       END $$;


--
-- Name: memory_tidy_profiles_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.memory_tidy_profiles_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."cron_id" := CASE WHEN jsonb_typeof(NEW.json->'cronId') = 'string' THEN NEW.json->>'cronId' END;
        NEW."arming" := CASE WHEN jsonb_typeof(NEW.json->'arming') = 'boolean' THEN (NEW.json->'arming')::boolean END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('cronId', to_jsonb(NEW."cron_id"), 'arming', to_jsonb(NEW."arming"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: modal_sandbox_bodies_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.modal_sandbox_bodies_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."initialization_pending" := CASE WHEN jsonb_typeof(NEW.json->'initializationPending') = 'boolean' THEN (NEW.json->'initializationPending')::boolean END;
        NEW."last_snapshot_ms" := CASE WHEN jsonb_typeof(NEW.json->'lastSnapshotMs') = 'number' THEN round((NEW.json->>'lastSnapshotMs')::numeric)::bigint END;
        NEW."home_dirty" := CASE WHEN jsonb_typeof(NEW.json->'homeDirty') = 'boolean' THEN (NEW.json->'homeDirty')::boolean END;
        NEW."snapshot_error" := CASE WHEN jsonb_typeof(NEW.json->'snapshotError') = 'string' THEN NEW.json->>'snapshotError' END;
        NEW."checkpoint_id" := CASE WHEN jsonb_typeof(NEW.json->'checkpointId') = 'string' THEN NEW.json->>'checkpointId' END;
        NEW."checkpoint_at_ms" := CASE WHEN jsonb_typeof(NEW.json->'checkpointAtMs') = 'number' THEN round((NEW.json->>'checkpointAtMs')::numeric)::bigint END;
        NEW."sandbox_id" := CASE WHEN jsonb_typeof(NEW.json->'sandboxId') = 'string' THEN NEW.json->>'sandboxId' END;
        NEW."created_at_ms" := CASE WHEN jsonb_typeof(NEW.json->'createdAtMs') = 'number' THEN round((NEW.json->>'createdAtMs')::numeric)::bigint END;
        NEW."expires_at_ms" := CASE WHEN jsonb_typeof(NEW.json->'expiresAtMs') = 'number' THEN round((NEW.json->>'expiresAtMs')::numeric)::bigint END;
        NEW."last_activity_ms" := CASE WHEN jsonb_typeof(NEW.json->'lastActivityMs') = 'number' THEN round((NEW.json->>'lastActivityMs')::numeric)::bigint END;
        NEW."org_id" := CASE WHEN jsonb_typeof(NEW.json->'orgId') = 'string' THEN NEW.json->>'orgId' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('initializationPending', to_jsonb(NEW."initialization_pending"), 'lastSnapshotMs', to_jsonb(NEW."last_snapshot_ms"), 'homeDirty', to_jsonb(NEW."home_dirty"), 'snapshotError', to_jsonb(NEW."snapshot_error"), 'checkpointId', to_jsonb(NEW."checkpoint_id"), 'checkpointAtMs', to_jsonb(NEW."checkpoint_at_ms"), 'sandboxId', to_jsonb(NEW."sandbox_id"), 'createdAtMs', to_jsonb(NEW."created_at_ms"), 'expiresAtMs', to_jsonb(NEW."expires_at_ms"), 'lastActivityMs', to_jsonb(NEW."last_activity_ms"), 'orgId', to_jsonb(NEW."org_id"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: model_credentials_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.model_credentials_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."secret_enc" := CASE WHEN jsonb_typeof(NEW.json->'secretEnc') = 'string' THEN NEW.json->>'secretEnc' END;
        NEW."disabled" := CASE WHEN jsonb_typeof(NEW.json->'disabled') = 'boolean' THEN (NEW.json->'disabled')::boolean END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."updated_by" := CASE WHEN jsonb_typeof(NEW.json->'updatedBy') = 'string' THEN NEW.json->>'updatedBy' END;
        NEW."provider" := NEW.id;
      ELSE
        NEW.id := NEW."provider";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('provider', to_jsonb(NEW.id), 'secretEnc', to_jsonb(NEW."secret_enc"), 'disabled', to_jsonb(NEW."disabled"), 'updatedAt', to_jsonb(NEW."updated_at"), 'updatedBy', to_jsonb(NEW."updated_by"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: monitors_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.monitors_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."owner_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'ownerScopeId') = 'string' THEN NEW.json->>'ownerScopeId' END;
        NEW."owner" := CASE WHEN jsonb_typeof(NEW.json->'owner') = 'string' THEN NEW.json->>'owner' END;
        NEW."created_by" := CASE WHEN jsonb_typeof(NEW.json->'createdBy') = 'string' THEN NEW.json->>'createdBy' END;
        NEW."owner_consented_at" := CASE WHEN jsonb_typeof(NEW.json->'ownerConsentedAt') = 'number' THEN round((NEW.json->>'ownerConsentedAt')::numeric)::bigint END;
        NEW."destination" := CASE WHEN jsonb_typeof(NEW.json->'destination') <> 'null' THEN NEW.json->'destination' END;
        NEW."enabled" := CASE WHEN jsonb_typeof(NEW.json->'enabled') = 'boolean' THEN (NEW.json->'enabled')::boolean END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."last_fired_at" := CASE WHEN jsonb_typeof(NEW.json->'lastFiredAt') = 'number' THEN round((NEW.json->>'lastFiredAt')::numeric)::bigint END;
        NEW."process_id" := CASE WHEN jsonb_typeof(NEW.json->'processId') = 'string' THEN NEW.json->>'processId' END;
        NEW."command" := CASE WHEN jsonb_typeof(NEW.json->'command') = 'string' THEN NEW.json->>'command' END;
        NEW."purpose" := CASE WHEN jsonb_typeof(NEW.json->'purpose') = 'string' THEN NEW.json->>'purpose' END;
        NEW."thread_ref" := CASE WHEN jsonb_typeof(NEW.json->'threadRef') = 'string' THEN NEW.json->>'threadRef' END;
        NEW."instructions" := CASE WHEN jsonb_typeof(NEW.json->'instructions') = 'string' THEN NEW.json->>'instructions' END;
        NEW."pattern" := CASE WHEN jsonb_typeof(NEW.json->'pattern') = 'string' THEN NEW.json->>'pattern' END;
        NEW."cursor" := CASE WHEN jsonb_typeof(NEW.json->'cursor') = 'number' THEN round((NEW.json->>'cursor')::numeric)::bigint END;
        NEW."tail" := CASE WHEN jsonb_typeof(NEW.json->'tail') = 'string' THEN NEW.json->>'tail' END;
        NEW."expires_at" := CASE WHEN jsonb_typeof(NEW.json->'expiresAt') = 'number' THEN round((NEW.json->>'expiresAt')::numeric)::bigint END;
        NEW."last_error" := CASE WHEN jsonb_typeof(NEW.json->'lastError') = 'string' THEN NEW.json->>'lastError' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'ownerScopeId', to_jsonb(NEW."owner_scope_id"), 'owner', to_jsonb(NEW."owner"), 'createdBy', to_jsonb(NEW."created_by"), 'ownerConsentedAt', to_jsonb(NEW."owner_consented_at"), 'destination', to_jsonb(NEW."destination"), 'enabled', to_jsonb(NEW."enabled"), 'createdAt', to_jsonb(NEW."created_at"), 'lastFiredAt', to_jsonb(NEW."last_fired_at"), 'processId', to_jsonb(NEW."process_id"), 'command', to_jsonb(NEW."command"), 'purpose', to_jsonb(NEW."purpose"), 'threadRef', to_jsonb(NEW."thread_ref"), 'instructions', to_jsonb(NEW."instructions"), 'pattern', to_jsonb(NEW."pattern"), 'cursor', to_jsonb(NEW."cursor"), 'tail', to_jsonb(NEW."tail"), 'expiresAt', to_jsonb(NEW."expires_at"), 'lastError', to_jsonb(NEW."last_error"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: oauth_flows_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.oauth_flows_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."provider" := CASE WHEN jsonb_typeof(NEW.json->'provider') = 'string' THEN NEW.json->>'provider' END;
        NEW."principal_id" := CASE WHEN jsonb_typeof(NEW.json->'principalId') = 'string' THEN NEW.json->>'principalId' END;
        NEW."redirect_uri" := CASE WHEN jsonb_typeof(NEW.json->'redirectUri') = 'string' THEN NEW.json->>'redirectUri' END;
        NEW."issued_at" := CASE WHEN jsonb_typeof(NEW.json->'issuedAt') = 'number' THEN round((NEW.json->>'issuedAt')::numeric)::bigint END;
        NEW."return_to" := CASE WHEN jsonb_typeof(NEW.json->'returnTo') = 'string' THEN NEW.json->>'returnTo' END;
        NEW."org_id" := CASE WHEN jsonb_typeof(NEW.json->'orgId') = 'string' THEN NEW.json->>'orgId' END;
        NEW."account_type" := CASE WHEN jsonb_typeof(NEW.json->'accountType') = 'string' THEN NEW.json->>'accountType' END;
        NEW."client_ref" := CASE WHEN jsonb_typeof(NEW.json->'clientRef') = 'string' THEN NEW.json->>'clientRef' END;
        NEW."code_verifier" := CASE WHEN jsonb_typeof(NEW.json->'codeVerifier') = 'string' THEN NEW.json->>'codeVerifier' END;
        NEW."consent_link_id" := CASE WHEN jsonb_typeof(NEW.json->'consentLinkId') = 'string' THEN NEW.json->>'consentLinkId' END;
        NEW."nonce" := NEW.id;
      ELSE
        NEW.id := NEW."nonce";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('nonce', to_jsonb(NEW.id), 'provider', to_jsonb(NEW."provider"), 'principalId', to_jsonb(NEW."principal_id"), 'redirectUri', to_jsonb(NEW."redirect_uri"), 'issuedAt', to_jsonb(NEW."issued_at"), 'returnTo', to_jsonb(NEW."return_to"), 'orgId', to_jsonb(NEW."org_id"), 'accountType', to_jsonb(NEW."account_type"), 'clientRef', to_jsonb(NEW."client_ref"), 'codeVerifier', to_jsonb(NEW."code_verifier"), 'consentLinkId', to_jsonb(NEW."consent_link_id"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: org_ambient_flag_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.org_ambient_flag_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."on" := CASE WHEN jsonb_typeof(NEW.json->'on') = 'boolean' THEN (NEW.json->'on')::boolean END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'on', to_jsonb(NEW."on"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: principal_links_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.principal_links_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."principal_id" := CASE WHEN jsonb_typeof(NEW.json->'principalId') = 'string' THEN NEW.json->>'principalId' END;
        NEW."canonical_id" := CASE WHEN jsonb_typeof(NEW.json->'canonicalId') = 'string' THEN NEW.json->>'canonicalId' END;
        NEW."evidence" := CASE WHEN jsonb_typeof(NEW.json->'evidence') = 'string' THEN NEW.json->>'evidence' END;
        NEW."linked_by" := CASE WHEN jsonb_typeof(NEW.json->'linkedBy') = 'string' THEN NEW.json->>'linkedBy' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('principalId', to_jsonb(NEW."principal_id"), 'canonicalId', to_jsonb(NEW."canonical_id"), 'evidence', to_jsonb(NEW."evidence"), 'linkedBy', to_jsonb(NEW."linked_by"), 'createdAt', to_jsonb(NEW."created_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: projects_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.projects_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."org_id" := CASE WHEN jsonb_typeof(NEW.json->'orgId') = 'string' THEN NEW.json->>'orgId' END;
        NEW."name" := CASE WHEN jsonb_typeof(NEW.json->'name') = 'string' THEN NEW.json->>'name' END;
        NEW."owner_id" := CASE WHEN jsonb_typeof(NEW.json->'ownerId') = 'string' THEN NEW.json->>'ownerId' END;
        NEW."member_ids" := CASE WHEN jsonb_typeof(NEW.json->'memberIds') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'memberIds')) END;
        NEW."channel_member_ids" := CASE WHEN jsonb_typeof(NEW.json->'channelMemberIds') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'channelMemberIds')) END;
        NEW."slack_channel" := CASE WHEN jsonb_typeof(NEW.json->'slackChannel') <> 'null' THEN NEW.json->'slackChannel' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'orgId', to_jsonb(NEW."org_id"), 'name', to_jsonb(NEW."name"), 'ownerId', to_jsonb(NEW."owner_id"), 'memberIds', to_jsonb(NEW."member_ids"), 'channelMemberIds', to_jsonb(NEW."channel_member_ids"), 'slackChannel', to_jsonb(NEW."slack_channel"), 'createdAt', to_jsonb(NEW."created_at"), 'updatedAt', to_jsonb(NEW."updated_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: qm_durable_map_bump(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_durable_map_bump() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
        UPDATE durable_map_versions SET v = v + 1 WHERE tbl = TG_ARGV[0];
        RETURN NULL;
      END $$;


--
-- Name: qm_tenant_bypass(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_bypass() RETURNS boolean
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$ SELECT COALESCE(current_setting('qm.tenant_bypass', true), '') = 'on' $$;


--
-- Name: qm_tenant_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenant_id() RETURNS uuid
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
     SELECT COALESCE(NULLIF(current_setting('qm.tenant_id', true), '')::uuid, (SELECT id FROM qm_tenant))
   $$;


--
-- Name: qm_tenantize(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_tenantize() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
  t record;
  ix record;
  fk record;
  fn record;
  fks text[] := '{}';
  fk_tables text[] := '{}';
  def text;
  tmp text;
  changed integer := 0;
  tenant_att smallint;
BEGIN
  -- 1. tenant_id column on every table.
  FOR t IN
    SELECT c.oid, c.relname FROM pg_class c
    WHERE c.relnamespace = current_schema()::regnamespace AND c.relkind = 'r'
      AND c.relname NOT IN ('qm_tenant', 'tenants', 'qm_schema_migrations') AND c.relname NOT LIKE 'pg\_%'
      AND NOT EXISTS (SELECT 1 FROM pg_attribute a WHERE a.attrelid = c.oid AND a.attname = 'tenant_id' AND NOT a.attisdropped)
  LOOP
    EXECUTE format('ALTER TABLE %I ADD COLUMN tenant_id uuid NOT NULL DEFAULT qm_tenant_id()', t.relname);
    changed := changed + 1;
  END LOOP;

  -- 2. Drop foreign keys between tenant tables that do not lead with tenant_id; they are recreated below.
  FOR fk IN
    SELECT con.conname, con.conrelid::regclass::text AS tbl, con.conrelid, con.conkey,
           pg_get_constraintdef(con.oid) AS def
    FROM pg_constraint con
    JOIN pg_class src ON src.oid = con.conrelid
    JOIN pg_class dst ON dst.oid = con.confrelid
    WHERE con.contype = 'f'
      AND src.relnamespace = current_schema()::regnamespace AND dst.relnamespace = current_schema()::regnamespace
      AND src.relname NOT IN ('qm_tenant', 'tenants', 'qm_schema_migrations') AND dst.relname NOT IN ('qm_tenant', 'tenants', 'qm_schema_migrations')
      AND (SELECT attname FROM pg_attribute WHERE attrelid = con.conrelid AND attnum = con.conkey[1]) <> 'tenant_id'
  LOOP
    def := regexp_replace(fk.def, '^FOREIGN KEY \(', 'FOREIGN KEY (tenant_id, ');
    def := regexp_replace(def, ' REFERENCES ([^(]+)\(', ' REFERENCES \1(tenant_id, ');
    IF def ~ 'ON DELETE SET NULL' AND def !~ 'ON DELETE SET NULL \(' THEN
      def := replace(def, 'ON DELETE SET NULL', 'ON DELETE SET NULL (' ||
        (SELECT string_agg(quote_ident(attname), ', ' ORDER BY array_position(fk.conkey, attnum))
           FROM pg_attribute WHERE attrelid = fk.conrelid AND attnum = ANY(fk.conkey)) || ')');
    END IF;
    fks := fks || format('ALTER TABLE %s ADD CONSTRAINT %I %s', fk.tbl, fk.conname, def);
    EXECUTE format('ALTER TABLE %s DROP CONSTRAINT %I', fk.tbl, fk.conname);
    changed := changed + 1;
  END LOOP;

  -- 3. Primary keys, unique constraints and unique indexes lead with tenant_id.
  FOR ix IN
    SELECT i.indexrelid, i.indrelid, ic.relname AS index_name, tc.relname AS table_name,
           con.conname, con.contype, pg_get_indexdef(i.indexrelid) AS def
    FROM pg_index i
    JOIN pg_class ic ON ic.oid = i.indexrelid
    JOIN pg_class tc ON tc.oid = i.indrelid
    LEFT JOIN pg_constraint con ON con.conindid = i.indexrelid AND con.contype IN ('p', 'u')
    WHERE i.indisunique AND tc.relnamespace = current_schema()::regnamespace AND tc.relkind = 'r'
      AND tc.relname NOT IN ('qm_tenant', 'tenants', 'qm_schema_migrations')
      AND COALESCE((SELECT attname FROM pg_attribute WHERE attrelid = i.indrelid AND attnum = i.indkey[0]), '') <> 'tenant_id'
  LOOP
    def := regexp_replace(ix.def, ' USING (\w+) \(', ' USING \1 (tenant_id, ');
    IF ix.conname IS NULL THEN
      EXECUTE format('DROP INDEX %I', ix.index_name);
      EXECUTE def;
    ELSE
      tmp := left('qm_tnt_' || md5(ix.index_name), 60);
      def := regexp_replace(def, '^CREATE UNIQUE INDEX \S+ ON ', 'CREATE UNIQUE INDEX ' || quote_ident(tmp) || ' ON ');
      EXECUTE def;
      EXECUTE format('ALTER TABLE %I DROP CONSTRAINT %I', ix.table_name, ix.conname);
      EXECUTE format('ALTER TABLE %I ADD CONSTRAINT %I %s USING INDEX %I', ix.table_name, ix.conname,
        CASE ix.contype WHEN 'p' THEN 'PRIMARY KEY' ELSE 'UNIQUE' END, tmp);
    END IF;
    changed := changed + 1;
  END LOOP;

  -- 4. Recreate the foreign keys with tenant_id leading.
  FOREACH def IN ARRAY fks LOOP
    EXECUTE def;
  END LOOP;

  -- 5. Row-level security on every tenant table.
  FOR t IN
    SELECT c.oid, c.relname, c.relrowsecurity, c.relforcerowsecurity FROM pg_class c
    WHERE c.relnamespace = current_schema()::regnamespace AND c.relkind = 'r'
      AND c.relname NOT IN ('qm_tenant', 'tenants', 'qm_schema_migrations') AND c.relname NOT LIKE 'pg\_%'
      AND (NOT c.relrowsecurity OR NOT c.relforcerowsecurity
           OR NOT EXISTS (SELECT 1 FROM pg_policy p WHERE p.polrelid = c.oid AND p.polname = 'qm_tenant_isolation'))
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t.relname);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t.relname);
    IF NOT EXISTS (SELECT 1 FROM pg_policy p WHERE p.polrelid = t.oid AND p.polname = 'qm_tenant_isolation') THEN
      EXECUTE format('CREATE POLICY qm_tenant_isolation ON %I USING (tenant_id = qm_tenant_id() OR qm_tenant_bypass()) '
        'WITH CHECK (tenant_id = qm_tenant_id() OR qm_tenant_bypass())', t.relname);
    END IF;
    changed := changed + 1;
  END LOOP;

  -- 6. Stored functions and triggers that upsert name tenant_id in their conflict target.
  FOR fn IN
    SELECT p.oid FROM pg_proc p
    WHERE p.pronamespace = current_schema()::regnamespace AND p.prokind = 'f'
      AND p.proname NOT IN ('qm_tenantize', 'qm_tenant_id', 'qm_tenant_bypass')
      AND p.prosrc ~* 'ON CONFLICT\s*\((?!\s*tenant_id)'
  LOOP
    EXECUTE regexp_replace(pg_get_functiondef(fn.oid), 'ON CONFLICT(\s*)\((?!\s*tenant_id)', 'ON CONFLICT\1(tenant_id, ', 'gi');
    changed := changed + 1;
  END LOOP;
  RETURN changed;
END
$$;


--
-- Name: qm_turn_fence(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qm_turn_fence(p_turn text, p_token text) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
     DECLARE
       v_queue text;
       v_run uuid;
       v_ok boolean;
     BEGIN
       SELECT absurd_queue, absurd_run_id INTO v_queue, v_run FROM runs
        WHERE id = p_turn AND engine = 'absurd' AND status = 'running' AND lease_token = p_token
        FOR SHARE;
       IF v_queue IS NULL OR v_run IS NULL THEN
         RETURN false;
       END IF;
       EXECUTE format(
         'SELECT true FROM absurd.%I WHERE run_id = $1 AND ((state = ''running'' AND claimed_by = $2) OR state = ''cancelled'') FOR SHARE',
         'r_' || v_queue || COALESCE('_t' || left(replace(NULLIF(current_setting('qm.tenant_id', true), ''), '-', ''), 12), ''))
         INTO v_ok USING v_run, p_token;
       RETURN COALESCE(v_ok, false);
     END $_$;


--
-- Name: queued_posts_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queued_posts_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."post" := CASE WHEN jsonb_typeof(NEW.json->'post') <> 'null' THEN NEW.json->'post' END;
        NEW."first_failed_at" := CASE WHEN jsonb_typeof(NEW.json->'firstFailedAt') = 'number' THEN round((NEW.json->>'firstFailedAt')::numeric)::bigint END;
        NEW."last_error" := CASE WHEN jsonb_typeof(NEW.json->'lastError') = 'string' THEN NEW.json->>'lastError' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('post', to_jsonb(NEW."post"), 'firstFailedAt', to_jsonb(NEW."first_failed_at"), 'lastError', to_jsonb(NEW."last_error"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: recent_dm_posts_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.recent_dm_posts_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."posts" := CASE WHEN jsonb_typeof(NEW.json->'posts') <> 'null' THEN NEW.json->'posts' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('posts', to_jsonb(NEW."posts"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: safe_json(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.safe_json(t text) RETURNS json
    LANGUAGE plpgsql IMMUTABLE
    AS $$
        BEGIN RETURN t::json; EXCEPTION WHEN others THEN RETURN NULL; END $$;


--
-- Name: sandbox_defaults_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sandbox_defaults_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."sandbox_id" := CASE WHEN jsonb_typeof(NEW.json->'sandboxId') = 'string' THEN NEW.json->>'sandboxId' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('sandboxId', to_jsonb(NEW."sandbox_id"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: sandbox_resources_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sandbox_resources_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."backend" := CASE WHEN jsonb_typeof(NEW.json->'backend') = 'string' THEN NEW.json->>'backend' END;
        NEW."owner_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'ownerScopeId') = 'string' THEN NEW.json->>'ownerScopeId' END;
        NEW."backing_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'backingScopeId') = 'string' THEN NEW.json->>'backingScopeId' END;
        NEW."name" := CASE WHEN jsonb_typeof(NEW.json->'name') = 'string' THEN NEW.json->>'name' END;
        NEW."created_by" := CASE WHEN jsonb_typeof(NEW.json->'createdBy') = 'string' THEN NEW.json->>'createdBy' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'string' THEN NEW.json->>'createdAt' END;
        NEW."legacy" := CASE WHEN jsonb_typeof(NEW.json->'legacy') = 'boolean' THEN (NEW.json->'legacy')::boolean END;
        NEW."state" := CASE WHEN jsonb_typeof(NEW.json->'state') = 'string' THEN NEW.json->>'state' END;
        NEW."machine_id" := CASE WHEN jsonb_typeof(NEW.json->'machineId') = 'string' THEN NEW.json->>'machineId' END;
        NEW."cleanup_pending" := CASE WHEN jsonb_typeof(NEW.json->'cleanupPending') = 'boolean' THEN (NEW.json->'cleanupPending')::boolean END;
        NEW."holders" := CASE WHEN jsonb_typeof(NEW.json->'holders') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'holders')) END;
        NEW."spec" := CASE WHEN jsonb_typeof(NEW.json->'spec') <> 'null' THEN NEW.json->'spec' END;
        NEW."error" := CASE WHEN jsonb_typeof(NEW.json->'error') = 'string' THEN NEW.json->>'error' END;
        NEW."job_only" := CASE WHEN jsonb_typeof(NEW.json->'jobOnly') = 'boolean' THEN (NEW.json->'jobOnly')::boolean END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'backend', to_jsonb(NEW."backend"), 'ownerScopeId', to_jsonb(NEW."owner_scope_id"), 'backingScopeId', to_jsonb(NEW."backing_scope_id"), 'name', to_jsonb(NEW."name"), 'createdBy', to_jsonb(NEW."created_by"), 'createdAt', to_jsonb(NEW."created_at"), 'legacy', to_jsonb(NEW."legacy"), 'state', to_jsonb(NEW."state"), 'machineId', to_jsonb(NEW."machine_id"), 'cleanupPending', to_jsonb(NEW."cleanup_pending"), 'holders', to_jsonb(NEW."holders"), 'spec', to_jsonb(NEW."spec"), 'error', to_jsonb(NEW."error"), 'jobOnly', to_jsonb(NEW."job_only"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: secret_drops_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.secret_drops_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."owner_id" := CASE WHEN jsonb_typeof(NEW.json->'ownerId') = 'string' THEN NEW.json->>'ownerId' END;
        NEW."org_id" := CASE WHEN jsonb_typeof(NEW.json->'orgId') = 'string' THEN NEW.json->>'orgId' END;
        NEW."service" := CASE WHEN jsonb_typeof(NEW.json->'service') = 'string' THEN NEW.json->>'service' END;
        NEW."env_key" := CASE WHEN jsonb_typeof(NEW.json->'envKey') = 'string' THEN NEW.json->>'envKey' END;
        NEW."host" := CASE WHEN jsonb_typeof(NEW.json->'host') = 'string' THEN NEW.json->>'host' END;
        NEW."fields" := CASE WHEN jsonb_typeof(NEW.json->'fields') <> 'null' THEN NEW.json->'fields' END;
        NEW."purpose" := CASE WHEN jsonb_typeof(NEW.json->'purpose') = 'string' THEN NEW.json->>'purpose' END;
        NEW."requested_by" := CASE WHEN jsonb_typeof(NEW.json->'requestedBy') = 'string' THEN NEW.json->>'requestedBy' END;
        NEW."audience_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'audienceScopeId') = 'string' THEN NEW.json->>'audienceScopeId' END;
        NEW."scope_version" := CASE WHEN jsonb_typeof(NEW.json->'scopeVersion') = 'string' THEN NEW.json->>'scopeVersion' END;
        NEW."grant_mode" := CASE WHEN jsonb_typeof(NEW.json->'grantMode') = 'string' THEN NEW.json->>'grantMode' END;
        NEW."destination" := CASE WHEN jsonb_typeof(NEW.json->'destination') <> 'null' THEN NEW.json->'destination' END;
        NEW."thread_ref" := CASE WHEN jsonb_typeof(NEW.json->'threadRef') = 'string' THEN NEW.json->>'threadRef' END;
        NEW."requires_token" := CASE WHEN jsonb_typeof(NEW.json->'requiresToken') = 'boolean' THEN (NEW.json->'requiresToken')::boolean END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('ownerId', to_jsonb(NEW."owner_id"), 'orgId', to_jsonb(NEW."org_id"), 'service', to_jsonb(NEW."service"), 'envKey', to_jsonb(NEW."env_key"), 'host', to_jsonb(NEW."host"), 'fields', to_jsonb(NEW."fields"), 'purpose', to_jsonb(NEW."purpose"), 'requestedBy', to_jsonb(NEW."requested_by"), 'audienceScopeId', to_jsonb(NEW."audience_scope_id"), 'scopeVersion', to_jsonb(NEW."scope_version"), 'grantMode', to_jsonb(NEW."grant_mode"), 'destination', to_jsonb(NEW."destination"), 'threadRef', to_jsonb(NEW."thread_ref"), 'requiresToken', to_jsonb(NEW."requires_token"), 'createdAt', to_jsonb(NEW."created_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: session_mailbox_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.session_mailbox_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."recipient_id" := CASE WHEN jsonb_typeof(NEW.json->'recipientId') = 'string' THEN NEW.json->>'recipientId' END;
        NEW."sender_id" := CASE WHEN jsonb_typeof(NEW.json->'senderId') = 'string' THEN NEW.json->>'senderId' END;
        NEW."actor" := CASE WHEN jsonb_typeof(NEW.json->'actor') <> 'null' THEN NEW.json->'actor' END;
        NEW."text" := CASE WHEN jsonb_typeof(NEW.json->'text') = 'string' THEN NEW.json->>'text' END;
        NEW."source_entry_seq" := CASE WHEN jsonb_typeof(NEW.json->'sourceEntrySeq') = 'number' THEN round((NEW.json->>'sourceEntrySeq')::numeric)::bigint END;
        NEW."audience" := CASE WHEN jsonb_typeof(NEW.json->'audience') <> 'null' THEN NEW.json->'audience' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."consumed" := CASE WHEN jsonb_typeof(NEW.json->'consumed') = 'boolean' THEN (NEW.json->'consumed')::boolean END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'recipientId', to_jsonb(NEW."recipient_id"), 'senderId', to_jsonb(NEW."sender_id"), 'actor', to_jsonb(NEW."actor"), 'text', to_jsonb(NEW."text"), 'sourceEntrySeq', to_jsonb(NEW."source_entry_seq"), 'audience', to_jsonb(NEW."audience"), 'createdAt', to_jsonb(NEW."created_at"), 'consumed', to_jsonb(NEW."consumed"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: session_shares_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.session_shares_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."session_id" := CASE WHEN jsonb_typeof(NEW.json->'sessionId') = 'string' THEN NEW.json->>'sessionId' END;
        NEW."audience" := CASE WHEN jsonb_typeof(NEW.json->'audience') = 'string' THEN NEW.json->>'audience' END;
        NEW."created_by" := CASE WHEN jsonb_typeof(NEW.json->'createdBy') = 'string' THEN NEW.json->>'createdBy' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."visibility" := CASE WHEN jsonb_typeof(NEW.json->'visibility') <> 'null' THEN NEW.json->'visibility' END;
        NEW."messages" := CASE WHEN jsonb_typeof(NEW.json->'messages') <> 'null' THEN NEW.json->'messages' END;
        NEW."files" := CASE WHEN jsonb_typeof(NEW.json->'files') <> 'null' THEN NEW.json->'files' END;
        NEW."token" := NEW.id;
      ELSE
        NEW.id := NEW."token";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('token', to_jsonb(NEW.id), 'sessionId', to_jsonb(NEW."session_id"), 'audience', to_jsonb(NEW."audience"), 'createdBy', to_jsonb(NEW."created_by"), 'createdAt', to_jsonb(NEW."created_at"), 'visibility', to_jsonb(NEW."visibility"), 'messages', to_jsonb(NEW."messages"), 'files', to_jsonb(NEW."files"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: skill_bundles_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.skill_bundles_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."commit" := CASE WHEN jsonb_typeof(NEW.json->'commit') = 'string' THEN NEW.json->>'commit' END;
        NEW."files" := CASE WHEN jsonb_typeof(NEW.json->'files') <> 'null' THEN NEW.json->'files' END;
        NEW."hash" := CASE WHEN jsonb_typeof(NEW.json->'hash') = 'string' THEN NEW.json->>'hash' END;
        NEW."pack_id" := NEW.id;
      ELSE
        NEW.id := NEW."pack_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('packId', to_jsonb(NEW.id), 'commit', to_jsonb(NEW."commit"), 'files', to_jsonb(NEW."files"), 'hash', to_jsonb(NEW."hash"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: skill_packs_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.skill_packs_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."kind" := CASE WHEN jsonb_typeof(NEW.json->'kind') = 'string' THEN NEW.json->>'kind' END;
        NEW."url" := CASE WHEN jsonb_typeof(NEW.json->'url') = 'string' THEN NEW.json->>'url' END;
        NEW."ref" := CASE WHEN jsonb_typeof(NEW.json->'ref') = 'string' THEN NEW.json->>'ref' END;
        NEW."sync_mode" := CASE WHEN jsonb_typeof(NEW.json->'syncMode') = 'string' THEN NEW.json->>'syncMode' END;
        NEW."trust_tier" := CASE WHEN jsonb_typeof(NEW.json->'trustTier') = 'string' THEN NEW.json->>'trustTier' END;
        NEW."config" := CASE WHEN jsonb_typeof(NEW.json->'config') <> 'null' THEN NEW.json->'config' END;
        NEW."target_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'targetScopeId') = 'string' THEN NEW.json->>'targetScopeId' END;
        NEW."subset" := CASE WHEN jsonb_typeof(NEW.json->'subset') <> 'null' THEN NEW.json->'subset' END;
        NEW."auth_credential_slug" := CASE WHEN jsonb_typeof(NEW.json->'authCredentialSlug') = 'string' THEN NEW.json->>'authCredentialSlug' END;
        NEW."created_by" := CASE WHEN jsonb_typeof(NEW.json->'createdBy') = 'string' THEN NEW.json->>'createdBy' END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."last_import" := CASE WHEN jsonb_typeof(NEW.json->'lastImport') <> 'null' THEN NEW.json->'lastImport' END;
        NEW."update_available" := CASE WHEN jsonb_typeof(NEW.json->'updateAvailable') = 'boolean' THEN (NEW.json->'updateAvailable')::boolean END;
        NEW."available" := CASE WHEN jsonb_typeof(NEW.json->'available') = 'number' THEN round((NEW.json->>'available')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'kind', to_jsonb(NEW."kind"), 'url', to_jsonb(NEW."url"), 'ref', to_jsonb(NEW."ref"), 'syncMode', to_jsonb(NEW."sync_mode"), 'trustTier', to_jsonb(NEW."trust_tier"), 'config', to_jsonb(NEW."config"), 'targetScopeId', to_jsonb(NEW."target_scope_id"), 'subset', to_jsonb(NEW."subset"), 'authCredentialSlug', to_jsonb(NEW."auth_credential_slug"), 'createdBy', to_jsonb(NEW."created_by"), 'createdAt', to_jsonb(NEW."created_at"), 'lastImport', to_jsonb(NEW."last_import"), 'updateAvailable', to_jsonb(NEW."update_available"), 'available', to_jsonb(NEW."available"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: skills_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.skills_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."scope_id" := CASE WHEN jsonb_typeof(NEW.json->'scopeId') = 'string' THEN NEW.json->>'scopeId' END;
        NEW."manifest" := CASE WHEN jsonb_typeof(NEW.json->'manifest') <> 'null' THEN NEW.json->'manifest' END;
        NEW."status" := CASE WHEN jsonb_typeof(NEW.json->'status') = 'string' THEN NEW.json->>'status' END;
        NEW."created_by" := CASE WHEN jsonb_typeof(NEW.json->'createdBy') = 'string' THEN NEW.json->>'createdBy' END;
        NEW."version" := CASE WHEN jsonb_typeof(NEW.json->'version') = 'number' THEN round((NEW.json->>'version')::numeric)::bigint END;
        NEW."granted_capabilities" := CASE WHEN jsonb_typeof(NEW.json->'grantedCapabilities') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'grantedCapabilities')) END;
        NEW."approvals" := CASE WHEN jsonb_typeof(NEW.json->'approvals') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'approvals')) END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."last_used_at" := CASE WHEN jsonb_typeof(NEW.json->'lastUsedAt') = 'number' THEN round((NEW.json->>'lastUsedAt')::numeric)::bigint END;
        NEW."pack" := CASE WHEN jsonb_typeof(NEW.json->'pack') <> 'null' THEN NEW.json->'pack' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'scopeId', to_jsonb(NEW."scope_id"), 'manifest', to_jsonb(NEW."manifest"), 'status', to_jsonb(NEW."status"), 'createdBy', to_jsonb(NEW."created_by"), 'version', to_jsonb(NEW."version"), 'grantedCapabilities', to_jsonb(NEW."granted_capabilities"), 'approvals', to_jsonb(NEW."approvals"), 'createdAt', to_jsonb(NEW."created_at"), 'updatedAt', to_jsonb(NEW."updated_at"), 'lastUsedAt', to_jsonb(NEW."last_used_at"), 'pack', to_jsonb(NEW."pack"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: slack_accounts_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.slack_accounts_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."account_id" := CASE WHEN jsonb_typeof(NEW.json->'accountId') = 'string' THEN NEW.json->>'accountId' END;
        NEW."member_id" := CASE WHEN jsonb_typeof(NEW.json->'memberId') = 'string' THEN NEW.json->>'memberId' END;
        NEW."user_id" := CASE WHEN jsonb_typeof(NEW.json->'userId') = 'string' THEN NEW.json->>'userId' END;
        NEW."team_id" := CASE WHEN jsonb_typeof(NEW.json->'teamId') = 'string' THEN NEW.json->>'teamId' END;
        NEW."user" := CASE WHEN jsonb_typeof(NEW.json->'user') = 'string' THEN NEW.json->>'user' END;
        NEW."workspace" := CASE WHEN jsonb_typeof(NEW.json->'workspace') = 'string' THEN NEW.json->>'workspace' END;
        NEW."principal_id" := NEW.id;
      ELSE
        NEW.id := NEW."principal_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('principalId', to_jsonb(NEW.id), 'accountId', to_jsonb(NEW."account_id"), 'memberId', to_jsonb(NEW."member_id"), 'userId', to_jsonb(NEW."user_id"), 'teamId', to_jsonb(NEW."team_id"), 'user', to_jsonb(NEW."user"), 'workspace', to_jsonb(NEW."workspace"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: slack_emoji_catalog_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.slack_emoji_catalog_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."emoji" := CASE WHEN jsonb_typeof(NEW.json->'emoji') <> 'null' THEN NEW.json->'emoji' END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'emoji', to_jsonb(NEW."emoji"), 'updatedAt', to_jsonb(NEW."updated_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: slack_handled_events_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.slack_handled_events_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."at" := CASE WHEN jsonb_typeof(NEW.json->'at') = 'number' THEN round((NEW.json->>'at')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('at', to_jsonb(NEW."at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: slack_installation_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.slack_installation_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."disabled" := CASE WHEN jsonb_typeof(NEW.json->'disabled') = 'boolean' THEN (NEW.json->'disabled')::boolean END;
        NEW."service_blocked" := CASE WHEN jsonb_typeof(NEW.json->'serviceBlocked') = 'boolean' THEN (NEW.json->'serviceBlocked')::boolean END;
        NEW."bot_token_enc" := CASE WHEN jsonb_typeof(NEW.json->'botTokenEnc') = 'string' THEN NEW.json->>'botTokenEnc' END;
        NEW."app_token_enc" := CASE WHEN jsonb_typeof(NEW.json->'appTokenEnc') = 'string' THEN NEW.json->>'appTokenEnc' END;
        NEW."app_id" := CASE WHEN jsonb_typeof(NEW.json->'appId') = 'string' THEN NEW.json->>'appId' END;
        NEW."install_id" := CASE WHEN jsonb_typeof(NEW.json->'installId') = 'string' THEN NEW.json->>'installId' END;
        NEW."installed_at" := CASE WHEN jsonb_typeof(NEW.json->'installedAt') = 'number' THEN round((NEW.json->>'installedAt')::numeric)::bigint END;
        NEW."team_id" := CASE WHEN jsonb_typeof(NEW.json->'teamId') = 'string' THEN NEW.json->>'teamId' END;
        NEW."team_name" := CASE WHEN jsonb_typeof(NEW.json->'teamName') = 'string' THEN NEW.json->>'teamName' END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."updated_by" := CASE WHEN jsonb_typeof(NEW.json->'updatedBy') = 'string' THEN NEW.json->>'updatedBy' END;
        NEW."version" := CASE WHEN jsonb_typeof(NEW.json->'version') = 'string' THEN NEW.json->>'version' END;
        NEW."org_id" := NEW.id;
      ELSE
        NEW.id := NEW."org_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('orgId', to_jsonb(NEW.id), 'disabled', to_jsonb(NEW."disabled"), 'serviceBlocked', to_jsonb(NEW."service_blocked"), 'botTokenEnc', to_jsonb(NEW."bot_token_enc"), 'appTokenEnc', to_jsonb(NEW."app_token_enc"), 'appId', to_jsonb(NEW."app_id"), 'installId', to_jsonb(NEW."install_id"), 'installedAt', to_jsonb(NEW."installed_at"), 'teamId', to_jsonb(NEW."team_id"), 'teamName', to_jsonb(NEW."team_name"), 'updatedAt', to_jsonb(NEW."updated_at"), 'updatedBy', to_jsonb(NEW."updated_by"), 'version', to_jsonb(NEW."version"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: slack_session_status_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.slack_session_status_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."writer" := CASE WHEN jsonb_typeof(NEW.json->'writer') = 'string' THEN NEW.json->>'writer' END;
        NEW."account" := CASE WHEN jsonb_typeof(NEW.json->'account') = 'string' THEN NEW.json->>'account' END;
        NEW."channel" := CASE WHEN jsonb_typeof(NEW.json->'channel') = 'string' THEN NEW.json->>'channel' END;
        NEW."thread_ts" := CASE WHEN jsonb_typeof(NEW.json->'threadTs') = 'string' THEN NEW.json->>'threadTs' END;
        NEW."anchor_run_id" := CASE WHEN jsonb_typeof(NEW.json->'anchorRunId') = 'string' THEN NEW.json->>'anchorRunId' END;
        NEW."started_at" := CASE WHEN jsonb_typeof(NEW.json->'startedAt') = 'number' THEN round((NEW.json->>'startedAt')::numeric)::bigint END;
        NEW."card_id" := CASE WHEN jsonb_typeof(NEW.json->'cardId') = 'string' THEN NEW.json->>'cardId' END;
        NEW."card_ts" := CASE WHEN jsonb_typeof(NEW.json->'cardTs') = 'string' THEN NEW.json->>'cardTs' END;
        NEW."card_content" := CASE WHEN jsonb_typeof(NEW.json->'cardContent') = 'string' THEN NEW.json->>'cardContent' END;
        NEW."follow_url" := CASE WHEN jsonb_typeof(NEW.json->'followUrl') = 'string' THEN NEW.json->>'followUrl' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('writer', to_jsonb(NEW."writer"), 'account', to_jsonb(NEW."account"), 'channel', to_jsonb(NEW."channel"), 'threadTs', to_jsonb(NEW."thread_ts"), 'anchorRunId', to_jsonb(NEW."anchor_run_id"), 'startedAt', to_jsonb(NEW."started_at"), 'cardId', to_jsonb(NEW."card_id"), 'cardTs', to_jsonb(NEW."card_ts"), 'cardContent', to_jsonb(NEW."card_content"), 'followUrl', to_jsonb(NEW."follow_url"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: slack_staged_envelopes_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.slack_staged_envelopes_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."body" := CASE WHEN jsonb_typeof(NEW.json->'body') <> 'null' THEN NEW.json->'body' END;
        NEW."account" := CASE WHEN jsonb_typeof(NEW.json->'account') = 'string' THEN NEW.json->>'account' END;
        NEW."received_at" := CASE WHEN jsonb_typeof(NEW.json->'receivedAt') = 'number' THEN round((NEW.json->>'receivedAt')::numeric)::bigint END;
        NEW."attempts" := CASE WHEN jsonb_typeof(NEW.json->'attempts') = 'number' THEN round((NEW.json->>'attempts')::numeric)::bigint END;
        NEW."claimed_until" := CASE WHEN jsonb_typeof(NEW.json->'claimedUntil') = 'number' THEN round((NEW.json->>'claimedUntil')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('body', to_jsonb(NEW."body"), 'account', to_jsonb(NEW."account"), 'receivedAt', to_jsonb(NEW."received_at"), 'attempts', to_jsonb(NEW."attempts"), 'claimedUntil', to_jsonb(NEW."claimed_until"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: slack_task_acknowledgements_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.slack_task_acknowledgements_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."channel" := CASE WHEN jsonb_typeof(NEW.json->'channel') = 'string' THEN NEW.json->>'channel' END;
        NEW."emoji" := CASE WHEN jsonb_typeof(NEW.json->'emoji') = 'string' THEN NEW.json->>'emoji' END;
        NEW."target" := CASE WHEN jsonb_typeof(NEW.json->'target') = 'string' THEN NEW.json->>'target' END;
        NEW."previous" := CASE WHEN jsonb_typeof(NEW.json->'previous') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'previous')) END;
        NEW."finished" := CASE WHEN jsonb_typeof(NEW.json->'finished') = 'boolean' THEN (NEW.json->'finished')::boolean END;
        NEW."synced" := CASE WHEN jsonb_typeof(NEW.json->'synced') = 'boolean' THEN (NEW.json->'synced')::boolean END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('channel', to_jsonb(NEW."channel"), 'emoji', to_jsonb(NEW."emoji"), 'target', to_jsonb(NEW."target"), 'previous', to_jsonb(NEW."previous"), 'finished', to_jsonb(NEW."finished"), 'synced', to_jsonb(NEW."synced"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: soul_configs_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.soul_configs_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."content" := CASE WHEN jsonb_typeof(NEW.json->'content') = 'string' THEN NEW.json->>'content' END;
        NEW."version" := CASE WHEN jsonb_typeof(NEW.json->'version') = 'number' THEN round((NEW.json->>'version')::numeric)::bigint END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."updated_by" := CASE WHEN jsonb_typeof(NEW.json->'updatedBy') = 'string' THEN NEW.json->>'updatedBy' END;
        NEW."history" := CASE WHEN jsonb_typeof(NEW.json->'history') <> 'null' THEN NEW.json->'history' END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'content', to_jsonb(NEW."content"), 'version', to_jsonb(NEW."version"), 'updatedAt', to_jsonb(NEW."updated_at"), 'updatedBy', to_jsonb(NEW."updated_by"), 'history', to_jsonb(NEW."history"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: soul_history_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.soul_history_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."scope_id" := CASE WHEN jsonb_typeof(NEW.json->'scopeId') = 'string' THEN NEW.json->>'scopeId' END;
        NEW."content" := CASE WHEN jsonb_typeof(NEW.json->'content') = 'string' THEN NEW.json->>'content' END;
        NEW."version" := CASE WHEN jsonb_typeof(NEW.json->'version') = 'number' THEN round((NEW.json->>'version')::numeric)::bigint END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        NEW."updated_by" := CASE WHEN jsonb_typeof(NEW.json->'updatedBy') = 'string' THEN NEW.json->>'updatedBy' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW."scope_id"), 'content', to_jsonb(NEW."content"), 'version', to_jsonb(NEW."version"), 'updatedAt', to_jsonb(NEW."updated_at"), 'updatedBy', to_jsonb(NEW."updated_by"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: spend_usage_json(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.spend_usage_json(t text) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE
    AS $$
             DECLARE j jsonb;
             BEGIN
               IF t IS NULL OR octet_length(t) > 2000 OR NOT pg_input_is_valid(t, 'jsonb') THEN
                 RETURN NULL;
               END IF;
               j := t::jsonb;
               IF pg_input_is_valid(j ->> 'costUsd', 'double precision') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'input', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'output', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheRead', 'bigint') IS NOT FALSE
                  AND pg_input_is_valid(j ->> 'cacheWrite', 'bigint') IS NOT FALSE THEN
                 RETURN j;
               END IF;
               RETURN NULL;
             END
             $$;


--
-- Name: sprites_initialization_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sprites_initialization_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."initialization_pending" := CASE WHEN jsonb_typeof(NEW.json->'initializationPending') = 'boolean' THEN (NEW.json->'initializationPending')::boolean END;
        NEW."last_snapshot_ms" := CASE WHEN jsonb_typeof(NEW.json->'lastSnapshotMs') = 'number' THEN round((NEW.json->>'lastSnapshotMs')::numeric)::bigint END;
        NEW."home_dirty" := CASE WHEN jsonb_typeof(NEW.json->'homeDirty') = 'boolean' THEN (NEW.json->'homeDirty')::boolean END;
        NEW."snapshot_error" := CASE WHEN jsonb_typeof(NEW.json->'snapshotError') = 'string' THEN NEW.json->>'snapshotError' END;
        NEW."checkpoint_id" := CASE WHEN jsonb_typeof(NEW.json->'checkpointId') = 'string' THEN NEW.json->>'checkpointId' END;
        NEW."checkpoint_at_ms" := CASE WHEN jsonb_typeof(NEW.json->'checkpointAtMs') = 'number' THEN round((NEW.json->>'checkpointAtMs')::numeric)::bigint END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('initializationPending', to_jsonb(NEW."initialization_pending"), 'lastSnapshotMs', to_jsonb(NEW."last_snapshot_ms"), 'homeDirty', to_jsonb(NEW."home_dirty"), 'snapshotError', to_jsonb(NEW."snapshot_error"), 'checkpointId', to_jsonb(NEW."checkpoint_id"), 'checkpointAtMs', to_jsonb(NEW."checkpoint_at_ms"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: suggested_activity_profiles_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.suggested_activity_profiles_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."cron_id" := CASE WHEN jsonb_typeof(NEW.json->'cronId') = 'string' THEN NEW.json->>'cronId' END;
        NEW."arming" := CASE WHEN jsonb_typeof(NEW.json->'arming') = 'boolean' THEN (NEW.json->'arming')::boolean END;
        NEW."timezone" := CASE WHEN jsonb_typeof(NEW.json->'timezone') = 'string' THEN NEW.json->>'timezone' END;
        NEW."last_seen_at" := CASE WHEN jsonb_typeof(NEW.json->'lastSeenAt') = 'number' THEN round((NEW.json->>'lastSeenAt')::numeric)::bigint END;
        NEW."last_bootstrap_at" := CASE WHEN jsonb_typeof(NEW.json->'lastBootstrapAt') = 'number' THEN round((NEW.json->>'lastBootstrapAt')::numeric)::bigint END;
        NEW."dismissal_refresh_at" := CASE WHEN jsonb_typeof(NEW.json->'dismissalRefreshAt') = 'number' THEN round((NEW.json->>'dismissalRefreshAt')::numeric)::bigint END;
        NEW."managed_action" := CASE WHEN jsonb_typeof(NEW.json->'managedAction') = 'string' THEN NEW.json->>'managedAction' END;
        NEW."seeds" := CASE WHEN jsonb_typeof(NEW.json->'seeds') <> 'null' THEN NEW.json->'seeds' END;
        NEW."dismissed" := CASE WHEN jsonb_typeof(NEW.json->'dismissed') <> 'null' THEN NEW.json->'dismissed' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('cronId', to_jsonb(NEW."cron_id"), 'arming', to_jsonb(NEW."arming"), 'timezone', to_jsonb(NEW."timezone"), 'lastSeenAt', to_jsonb(NEW."last_seen_at"), 'lastBootstrapAt', to_jsonb(NEW."last_bootstrap_at"), 'dismissalRefreshAt', to_jsonb(NEW."dismissal_refresh_at"), 'managedAction', to_jsonb(NEW."managed_action"), 'seeds', to_jsonb(NEW."seeds"), 'dismissed', to_jsonb(NEW."dismissed"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: unfulfilled_insights_flag_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.unfulfilled_insights_flag_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."on" := CASE WHEN jsonb_typeof(NEW.json->'on') = 'boolean' THEN (NEW.json->'on')::boolean END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'on', to_jsonb(NEW."on"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: web_ui_state_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.web_ui_state_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."value" := CASE WHEN jsonb_typeof(NEW.json->'value') <> 'null' THEN NEW.json->'value' END;
        NEW."updated_at" := CASE WHEN jsonb_typeof(NEW.json->'updatedAt') = 'number' THEN round((NEW.json->>'updatedAt')::numeric)::bigint END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('value', to_jsonb(NEW."value"), 'updatedAt', to_jsonb(NEW."updated_at"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: webhook_history_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.webhook_history_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."events" := CASE WHEN jsonb_typeof(NEW.json->'events') <> 'null' THEN NEW.json->'events' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('events', to_jsonb(NEW."events"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: webhooks_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.webhooks_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."owner_scope_id" := CASE WHEN jsonb_typeof(NEW.json->'ownerScopeId') = 'string' THEN NEW.json->>'ownerScopeId' END;
        NEW."owner" := CASE WHEN jsonb_typeof(NEW.json->'owner') = 'string' THEN NEW.json->>'owner' END;
        NEW."created_by" := CASE WHEN jsonb_typeof(NEW.json->'createdBy') = 'string' THEN NEW.json->>'createdBy' END;
        NEW."owner_consented_at" := CASE WHEN jsonb_typeof(NEW.json->'ownerConsentedAt') = 'number' THEN round((NEW.json->>'ownerConsentedAt')::numeric)::bigint END;
        NEW."destination" := CASE WHEN jsonb_typeof(NEW.json->'destination') <> 'null' THEN NEW.json->'destination' END;
        NEW."enabled" := CASE WHEN jsonb_typeof(NEW.json->'enabled') = 'boolean' THEN (NEW.json->'enabled')::boolean END;
        NEW."created_at" := CASE WHEN jsonb_typeof(NEW.json->'createdAt') = 'number' THEN round((NEW.json->>'createdAt')::numeric)::bigint END;
        NEW."last_fired_at" := CASE WHEN jsonb_typeof(NEW.json->'lastFiredAt') = 'number' THEN round((NEW.json->>'lastFiredAt')::numeric)::bigint END;
        NEW."action" := CASE WHEN jsonb_typeof(NEW.json->'action') = 'string' THEN NEW.json->>'action' END;
        NEW."verification" := CASE WHEN jsonb_typeof(NEW.json->'verification') <> 'null' THEN NEW.json->'verification' END;
        NEW."filters" := CASE WHEN jsonb_typeof(NEW.json->'filters') <> 'null' THEN NEW.json->'filters' END;
        NEW."last_delivery_id" := CASE WHEN jsonb_typeof(NEW.json->'lastDeliveryId') = 'string' THEN NEW.json->>'lastDeliveryId' END;
        NEW."last_error" := CASE WHEN jsonb_typeof(NEW.json->'lastError') = 'string' THEN NEW.json->>'lastError' END;
        
      ELSE
        
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('id', to_jsonb(NEW.id), 'ownerScopeId', to_jsonb(NEW."owner_scope_id"), 'owner', to_jsonb(NEW."owner"), 'createdBy', to_jsonb(NEW."created_by"), 'ownerConsentedAt', to_jsonb(NEW."owner_consented_at"), 'destination', to_jsonb(NEW."destination"), 'enabled', to_jsonb(NEW."enabled"), 'createdAt', to_jsonb(NEW."created_at"), 'lastFiredAt', to_jsonb(NEW."last_fired_at"), 'action', to_jsonb(NEW."action"), 'verification', to_jsonb(NEW."verification"), 'filters', to_jsonb(NEW."filters"), 'lastDeliveryId', to_jsonb(NEW."last_delivery_id"), 'lastError', to_jsonb(NEW."last_error"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


--
-- Name: webui_model_configs_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.webui_model_configs_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
      IF TG_OP = 'INSERT' AND NEW.json IS NOT NULL OR TG_OP = 'UPDATE' AND NEW.json IS DISTINCT FROM OLD.json THEN
        NEW."ids" := CASE WHEN jsonb_typeof(NEW.json->'ids') = 'array' THEN ARRAY(SELECT jsonb_array_elements_text(NEW.json->'ids')) END;
        NEW."scope_id" := NEW.id;
      ELSE
        NEW.id := NEW."scope_id";
        NEW.json := (SELECT COALESCE(jsonb_object_agg(k, v), '{}'::jsonb)
          FROM jsonb_each(jsonb_build_object('scopeId', to_jsonb(NEW.id), 'ids', to_jsonb(NEW."ids"))) AS e(k, v)
          WHERE jsonb_typeof(v) <> 'null');
      END IF;
      RETURN NEW;
    END $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: c_jobs; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_jobs (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_jobs_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_jobs_t111111110000 (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_background; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_background (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_background_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_background_t111111110000 (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_delegated; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_delegated (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_delegated_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_delegated_t111111110000 (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_people; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_people (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: c_turns_people_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.c_turns_people_t111111110000 (
    task_id uuid NOT NULL,
    checkpoint_name text NOT NULL,
    state jsonb,
    status text DEFAULT 'committed'::text NOT NULL,
    owner_run_id uuid,
    updated_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
)
WITH (fillfactor='70');


--
-- Name: e_jobs; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_jobs (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_jobs_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_jobs_t111111110000 (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_background; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_background (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_background_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_background_t111111110000 (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_delegated; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_delegated (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_delegated_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_delegated_t111111110000 (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_people; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_people (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: e_turns_people_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.e_turns_people_t111111110000 (
    event_name text NOT NULL,
    payload jsonb,
    emitted_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: queues; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.queues (
    queue_name text NOT NULL,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    storage_mode text DEFAULT 'unpartitioned'::text NOT NULL,
    default_partition text DEFAULT 'enabled'::text NOT NULL,
    partition_lookahead interval DEFAULT '28 days'::interval NOT NULL,
    partition_lookback interval DEFAULT '1 day'::interval NOT NULL,
    cleanup_ttl interval DEFAULT '30 days'::interval NOT NULL,
    cleanup_limit integer DEFAULT 1000 NOT NULL,
    detach_mode text DEFAULT 'none'::text NOT NULL,
    detach_min_age interval DEFAULT '30 days'::interval NOT NULL,
    CONSTRAINT queues_cleanup_limit_check CHECK ((cleanup_limit >= 1)),
    CONSTRAINT queues_cleanup_ttl_check CHECK ((cleanup_ttl >= '00:00:00'::interval)),
    CONSTRAINT queues_default_partition_check CHECK ((default_partition = ANY (ARRAY['enabled'::text, 'disabled'::text]))),
    CONSTRAINT queues_detach_min_age_check CHECK ((detach_min_age >= '00:00:00'::interval)),
    CONSTRAINT queues_detach_mode_check CHECK ((detach_mode = ANY (ARRAY['none'::text, 'empty'::text]))),
    CONSTRAINT queues_partition_lookahead_check CHECK ((partition_lookahead >= '00:00:00'::interval)),
    CONSTRAINT queues_partition_lookback_check CHECK ((partition_lookback >= '00:00:00'::interval)),
    CONSTRAINT queues_storage_mode_check CHECK ((storage_mode = ANY (ARRAY['unpartitioned'::text, 'partitioned'::text])))
);


--
-- Name: r_jobs; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_jobs (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_jobs_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_jobs_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_jobs_t111111110000 (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_jobs_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_background; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_background (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_background_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_background_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_background_t111111110000 (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_background_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_delegated; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_delegated (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_delegated_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_delegated_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_delegated_t111111110000 (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_delegated_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_people; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_people (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_people_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: r_turns_people_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.r_turns_people_t111111110000 (
    run_id uuid NOT NULL,
    task_id uuid NOT NULL,
    attempt integer NOT NULL,
    state text NOT NULL,
    claimed_by text,
    claim_expires_at timestamp with time zone,
    available_at timestamp with time zone NOT NULL,
    wake_event text,
    event_payload jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    result jsonb,
    failure_reason jsonb,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    CONSTRAINT r_turns_people_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_jobs; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_jobs (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_jobs_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_jobs_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_jobs_t111111110000 (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_jobs_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_background; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_background (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_background_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_background_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_background_t111111110000 (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_background_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_delegated; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_delegated (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_delegated_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_delegated_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_delegated_t111111110000 (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_delegated_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_people; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_people (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_people_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: t_turns_people_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.t_turns_people_t111111110000 (
    task_id uuid NOT NULL,
    task_name text NOT NULL,
    params jsonb NOT NULL,
    headers jsonb,
    retry_strategy jsonb,
    max_attempts integer,
    cancellation jsonb,
    enqueue_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL,
    first_started_at timestamp with time zone,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_run uuid,
    completed_payload jsonb,
    cancelled_at timestamp with time zone,
    idempotency_key text,
    CONSTRAINT t_turns_people_t111111110000_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'sleeping'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
)
WITH (fillfactor='70');


--
-- Name: w_jobs; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_jobs (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_jobs_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_jobs_t111111110000 (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_background; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_background (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_background_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_background_t111111110000 (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_delegated; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_delegated (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_delegated_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_delegated_t111111110000 (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_people; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_people (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: w_turns_people_t111111110000; Type: TABLE; Schema: absurd; Owner: -
--

CREATE TABLE absurd.w_turns_people_t111111110000 (
    task_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_name text NOT NULL,
    event_name text NOT NULL,
    timeout_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT absurd."current_time"() NOT NULL
);


--
-- Name: ack_emoji; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    names text[] NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.ack_emoji FORCE ROW LEVEL SECURITY;


--
-- Name: ack_emoji_picks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ack_emoji_picks (
    id bigint NOT NULL,
    org_id text NOT NULL,
    surface text NOT NULL,
    channel text NOT NULL,
    ts text NOT NULL,
    outcome text NOT NULL,
    picked text,
    icon text,
    message text,
    candidates text,
    model text,
    latency_ms integer,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.ack_emoji_picks FORCE ROW LEVEL SECURITY;


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ack_emoji_picks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ack_emoji_picks_id_seq OWNED BY public.ack_emoji_picks.id;


--
-- Name: acl_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acl_grants (
    owner_scope_id text NOT NULL,
    path text NOT NULL,
    grantee_scope_id text NOT NULL,
    permission text NOT NULL,
    granted_by text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.acl_grants FORCE ROW LEVEL SECURITY;


--
-- Name: acl_grants_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acl_grants_version (
    only_row boolean DEFAULT true NOT NULL,
    v bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    CONSTRAINT acl_grants_version_only_row_check CHECK (only_row)
);

ALTER TABLE ONLY public.acl_grants_version FORCE ROW LEVEL SECURITY;


--
-- Name: admin_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_grants (
    principal_id text NOT NULL,
    scope_id text NOT NULL,
    role text NOT NULL,
    granted_by text,
    created_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.admin_grants FORCE ROW LEVEL SECURITY;


--
-- Name: ambient_cursors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ambient_cursors (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    last_judged_ts text NOT NULL,
    last_judged_at bigint
);

ALTER TABLE ONLY public.ambient_cursors FORCE ROW LEVEL SECURITY;


--
-- Name: ambient_judgments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ambient_judgments (
    id bigint NOT NULL,
    org_id text NOT NULL,
    surface text NOT NULL,
    container text NOT NULL,
    decision text NOT NULL,
    reason text,
    asked_by text,
    prompt text,
    model text,
    latency_ms integer,
    ts_from text,
    ts_to text,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.ambient_judgments FORCE ROW LEVEL SECURITY;


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ambient_judgments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ambient_judgments_id_seq OWNED BY public.ambient_judgments.id;


--
-- Name: approval_grant_modes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grant_modes (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    modes jsonb NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.approval_grant_modes FORCE ROW LEVEL SECURITY;


--
-- Name: approval_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_grants (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    actor_id text NOT NULL,
    command text NOT NULL,
    scope text NOT NULL,
    created_at bigint NOT NULL,
    session_id text,
    approval_key text
);

ALTER TABLE ONLY public.approval_grants FORCE ROW LEVEL SECURITY;


--
-- Name: approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approvals (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    session_id text NOT NULL,
    command text NOT NULL,
    created_at bigint,
    reason text,
    matched text,
    purpose text,
    summary text,
    summary_detail text,
    approval_key text,
    grant_modes jsonb,
    request jsonb,
    blocks_input boolean,
    kind text
);

ALTER TABLE ONLY public.approvals FORCE ROW LEVEL SECURITY;


--
-- Name: attributed_turns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attributed_turns (
    session_id text NOT NULL,
    principal_id text NOT NULL,
    day bigint NOT NULL,
    turns bigint NOT NULL,
    first_at bigint NOT NULL,
    last_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.attributed_turns FORCE ROW LEVEL SECURITY;


--
-- Name: attributed_turns_dirty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attributed_turns_dirty (
    session_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.attributed_turns_dirty FORCE ROW LEVEL SECURITY;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    at bigint NOT NULL,
    principal_id text NOT NULL,
    action text NOT NULL,
    resource text NOT NULL,
    scope_label text NOT NULL,
    status text,
    detail text,
    idempotency_key text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.audit_log FORCE ROW LEVEL SECURITY;


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: auth_broker_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_broker_sessions (
    token_hash text NOT NULL,
    email text NOT NULL,
    authenticated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    absolute_expires_at timestamp with time zone NOT NULL,
    idle_seconds integer NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.auth_broker_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: auto_flagger_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_flagger_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    model_id text NOT NULL,
    rubric text NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.auto_flagger_configs FORCE ROW LEVEL SECURITY;


--
-- Name: aws_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aws_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.aws_sandbox_bodies FORCE ROW LEVEL SECURITY;


--
-- Name: base_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.base_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    embedding_model_id text,
    model_id text,
    cron_runtime jsonb,
    subagent_runtime jsonb,
    fallback_runtime jsonb,
    org_revision bigint,
    revision bigint,
    effort_level text,
    fast_mode boolean,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.base_model_configs FORCE ROW LEVEL SECURITY;


--
-- Name: blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blobs (
    tenant_id uuid NOT NULL,
    sha256 bytea NOT NULL,
    size bigint NOT NULL,
    mime text,
    storage_key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT blobs_sha256_check CHECK ((length(sha256) = 32)),
    CONSTRAINT blobs_size_check CHECK ((size >= 0)),
    CONSTRAINT blobs_storage_key_check CHECK ((storage_key <> ''::text))
);

ALTER TABLE ONLY public.blobs FORCE ROW LEVEL SECURITY;


--
-- Name: branding_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    branding jsonb NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.branding_configs FORCE ROW LEVEL SECURITY;


--
-- Name: browse_max_steps_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_max_steps_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    steps bigint NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.browse_max_steps_configs FORCE ROW LEVEL SECURITY;


--
-- Name: browse_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browse_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    model_id text NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.browse_model_configs FORCE ROW LEVEL SECURITY;


--
-- Name: browser_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.browser_sessions (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    state_enc text NOT NULL,
    updated_at bigint NOT NULL,
    principal_id text NOT NULL
);

ALTER TABLE ONLY public.browser_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: channel_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_files (
    org_id text NOT NULL,
    container text NOT NULL,
    ts text NOT NULL,
    file_id text NOT NULL,
    name text,
    mimetype text,
    created_at bigint NOT NULL,
    title text,
    size bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_files FORCE ROW LEVEL SECURITY;


--
-- Name: channel_header_pin_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_header_pin_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    "on" boolean NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.channel_header_pin_flag FORCE ROW LEVEL SECURITY;


--
-- Name: channel_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_messages (
    org_id text NOT NULL,
    container text NOT NULL,
    ts text NOT NULL,
    sub text,
    author_id text,
    author_name text,
    text text DEFAULT ''::text NOT NULL,
    mentions jsonb,
    self boolean DEFAULT false NOT NULL,
    bot boolean DEFAULT false NOT NULL,
    mentions_self boolean DEFAULT false NOT NULL,
    edited_at bigint,
    deleted boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    handled boolean DEFAULT false NOT NULL,
    tsv tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(text, ''::text))) STORED,
    deleted_at bigint,
    broadcast boolean DEFAULT false NOT NULL,
    subtype text,
    bot_id text,
    surface text DEFAULT 'slack'::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_messages FORCE ROW LEVEL SECURITY;


--
-- Name: channel_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_policy (
    org_id text NOT NULL,
    container text NOT NULL,
    orders text DEFAULT ''::text NOT NULL,
    bots jsonb DEFAULT '{}'::jsonb NOT NULL,
    set_by text,
    updated_at bigint NOT NULL,
    ambient_enabled boolean,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_policy FORCE ROW LEVEL SECURITY;


--
-- Name: channel_policy_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_policy_history (
    id bigint NOT NULL,
    org_id text NOT NULL,
    container text NOT NULL,
    orders text DEFAULT ''::text NOT NULL,
    set_by text,
    session_id text,
    created_at bigint NOT NULL,
    bots jsonb,
    ambient_enabled boolean,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_policy_history FORCE ROW LEVEL SECURITY;


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.channel_policy_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.channel_policy_history_id_seq OWNED BY public.channel_policy_history.id;


--
-- Name: channel_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_state (
    org_id text NOT NULL,
    container text NOT NULL,
    last_ts text,
    oldest_ts text,
    name text,
    kind text,
    members jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_at bigint NOT NULL,
    surface text DEFAULT 'slack'::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.channel_state FORCE ROW LEVEL SECURITY;


--
-- Name: command_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.command_policies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    policy jsonb NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.command_policies FORCE ROW LEVEL SECURITY;


--
-- Name: composio_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.composio_returns (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    url text,
    toolkit text NOT NULL,
    expires_at bigint NOT NULL
);

ALTER TABLE ONLY public.composio_returns FORCE ROW LEVEL SECURITY;


--
-- Name: connector_clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_clients (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    scope_id text NOT NULL,
    provider text NOT NULL,
    client_id text NOT NULL,
    secret_enc text NOT NULL,
    scopes text[],
    redirect_allowlist text[],
    consent_mode text,
    hosted_domain text,
    enabled boolean NOT NULL,
    updated_by text,
    updated_at bigint NOT NULL
);

ALTER TABLE ONLY public.connector_clients FORCE ROW LEVEL SECURITY;


--
-- Name: connector_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_status (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    checked_at bigint NOT NULL,
    providers jsonb NOT NULL,
    principal_id text NOT NULL
);

ALTER TABLE ONLY public.connector_status FORCE ROW LEVEL SECURITY;


--
-- Name: consent_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consent_links (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    principal_id text NOT NULL,
    org_id text,
    provider text NOT NULL,
    account_type text NOT NULL,
    redirect_uri text NOT NULL,
    return_to text,
    created_at bigint NOT NULL
);

ALTER TABLE ONLY public.consent_links FORCE ROW LEVEL SECURITY;


--
-- Name: context_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.context_requests (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    source text NOT NULL,
    created_at bigint NOT NULL,
    status text NOT NULL,
    query jsonb NOT NULL,
    result jsonb,
    error text,
    sealed_viewer_token text
);

ALTER TABLE ONLY public.context_requests FORCE ROW LEVEL SECURITY;


--
-- Name: credential_daily_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_daily_calls (
    slug text NOT NULL,
    day bigint NOT NULL,
    sent integer NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.credential_daily_calls FORCE ROW LEVEL SECURITY;


--
-- Name: credential_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_usage (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    slug text NOT NULL,
    host text NOT NULL,
    status text NOT NULL,
    upstream_status integer,
    scope_label text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.credential_usage FORCE ROW LEVEL SECURITY;


--
-- Name: credential_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credential_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credential_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credential_usage_id_seq OWNED BY public.credential_usage.id;


--
-- Name: cron_fires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cron_fires (
    cron_id text NOT NULL,
    fire_key text NOT NULL,
    thread_ref text NOT NULL,
    session_id text,
    fired_at bigint NOT NULL,
    scheduled_at bigint,
    ended_at bigint,
    status text,
    note text,
    reply text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.cron_fires FORCE ROW LEVEL SECURITY;


--
-- Name: cron_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cron_items (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    cron_id text NOT NULL,
    source_key text NOT NULL,
    source_summary text,
    source text,
    source_payload jsonb,
    conversation_key text,
    source_at double precision,
    inbox_preview jsonb,
    proposal jsonb,
    agent_drafts jsonb,
    agent_mention_keys text[],
    thread jsonb,
    status text NOT NULL,
    parked_reason text,
    acted_at bigint,
    action_kind text,
    action_result text,
    decision_at double precision,
    decision_token text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);

ALTER TABLE ONLY public.cron_items FORCE ROW LEVEL SECURITY;


--
-- Name: crons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crons (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    owner_scope_id text NOT NULL,
    owner text NOT NULL,
    created_by text NOT NULL,
    owner_consented_at bigint,
    destination jsonb,
    enabled boolean NOT NULL,
    created_at bigint NOT NULL,
    last_fired_at bigint,
    runtime jsonb,
    schedule jsonb NOT NULL,
    next_fire_at bigint,
    defer_until bigint,
    title text,
    archived boolean,
    action text,
    message text,
    inbox jsonb,
    unattended_grants text[],
    session_ref text,
    last_fire_note jsonb
);

ALTER TABLE ONLY public.crons FORCE ROW LEVEL SECURITY;


--
-- Name: custom_model_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_model_providers (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    name text NOT NULL,
    protocol text NOT NULL,
    base_url text NOT NULL,
    models jsonb NOT NULL,
    api_key_enc text,
    disabled boolean,
    updated_at bigint NOT NULL,
    updated_by text NOT NULL
);

ALTER TABLE ONLY public.custom_model_providers FORCE ROW LEVEL SECURITY;


--
-- Name: deactivated_principals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deactivated_principals (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    principal_id text NOT NULL,
    source text NOT NULL,
    at bigint NOT NULL
);

ALTER TABLE ONLY public.deactivated_principals FORCE ROW LEVEL SECURITY;


--
-- Name: decision_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_providers (
    provider_id text NOT NULL,
    protocol text NOT NULL,
    base_url text,
    credential text,
    updated_by text NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.decision_providers FORCE ROW LEVEL SECURITY;


--
-- Name: decision_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_rules (
    rule_id text NOT NULL,
    hook text NOT NULL,
    question text NOT NULL,
    options json NOT NULL,
    provider_id text NOT NULL,
    model text NOT NULL,
    mode text NOT NULL,
    on_error text NOT NULL,
    updated_by text NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    CONSTRAINT decision_rules_mode_check CHECK ((mode = ANY (ARRAY['off'::text, 'observe'::text, 'enforce'::text])))
);

ALTER TABLE ONLY public.decision_rules FORCE ROW LEVEL SECURITY;


--
-- Name: deploy_git_repos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deploy_git_repos (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    bundle_b64 text,
    blob_key text,
    etag text NOT NULL,
    updated_at bigint NOT NULL,
    deployment_id text NOT NULL
);

ALTER TABLE ONLY public.deploy_git_repos FORCE ROW LEVEL SECURITY;


--
-- Name: deployment_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_access (
    id text NOT NULL,
    last_access_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.deployment_access FORCE ROW LEVEL SECURITY;


--
-- Name: deployment_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_identity (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    org_id text NOT NULL
);

ALTER TABLE ONLY public.deployment_identity FORCE ROW LEVEL SECURITY;


--
-- Name: deployment_layer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployment_layer (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    content_hash text NOT NULL,
    version bigint NOT NULL,
    updated_at bigint NOT NULL,
    updated_by text NOT NULL,
    bundle jsonb NOT NULL,
    resolved jsonb NOT NULL,
    pending_audits jsonb
);

ALTER TABLE ONLY public.deployment_layer FORCE ROW LEVEL SECURITY;


--
-- Name: deployments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployments (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    owner_scope_id text NOT NULL,
    created_by text NOT NULL,
    created_in_scope text,
    default_audience jsonb,
    name text,
    display_name text,
    current_version bigint NOT NULL,
    status text NOT NULL,
    endpoint jsonb,
    always_on boolean,
    embed_ancestors text[],
    public boolean,
    applied_version bigint,
    last_access_at bigint,
    versions jsonb NOT NULL
);

ALTER TABLE ONLY public.deployments FORCE ROW LEVEL SECURITY;


--
-- Name: directory_channel_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_channel_members (
    org_id text NOT NULL,
    channel_id text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_channel_members FORCE ROW LEVEL SECURITY;


--
-- Name: directory_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_channels (
    org_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    name_lc text NOT NULL,
    is_private boolean DEFAULT false NOT NULL,
    is_external boolean DEFAULT false NOT NULL,
    roster_known boolean DEFAULT false NOT NULL,
    observed_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_channels FORCE ROW LEVEL SECURITY;


--
-- Name: directory_group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_group_members (
    org_id text NOT NULL,
    group_id text NOT NULL,
    principal_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_group_members FORCE ROW LEVEL SECURITY;


--
-- Name: directory_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_groups (
    org_id text NOT NULL,
    group_id text NOT NULL,
    roster_known boolean DEFAULT false NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_groups FORCE ROW LEVEL SECURITY;


--
-- Name: directory_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_members (
    org_id text NOT NULL,
    principal_id text NOT NULL,
    display_name text NOT NULL,
    display_name_lc text NOT NULL,
    type text NOT NULL,
    slack_id text,
    avatar_url text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_members FORCE ROW LEVEL SECURITY;


--
-- Name: directory_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_meta (
    org_id text NOT NULL,
    workspace_url text,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_meta FORCE ROW LEVEL SECURITY;


--
-- Name: directory_sync; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_sync (
    org_id text NOT NULL,
    members_hash text,
    channels_hash text,
    groups_hash text,
    channel_members_synced boolean DEFAULT false NOT NULL,
    updated_at bigint NOT NULL,
    members_synced_at bigint,
    channels_synced_at bigint,
    groups_synced_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.directory_sync FORCE ROW LEVEL SECURITY;


--
-- Name: durable_map_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.durable_map_versions (
    tbl text NOT NULL,
    v bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.durable_map_versions FORCE ROW LEVEL SECURITY;


--
-- Name: e2b_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.e2b_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    initialization_pending boolean,
    last_snapshot_ms bigint,
    home_dirty boolean,
    snapshot_error text,
    checkpoint_id text,
    checkpoint_at_ms bigint,
    sandbox_id text,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.e2b_sandbox_bodies FORCE ROW LEVEL SECURITY;


--
-- Name: egress_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_events (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    source text NOT NULL,
    host text NOT NULL,
    allowed boolean NOT NULL,
    scope_label text NOT NULL,
    port integer,
    verdict text,
    via text,
    peer_ip text,
    principal_id text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.egress_events FORCE ROW LEVEL SECURITY;


--
-- Name: egress_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.egress_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: egress_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.egress_events_id_seq OWNED BY public.egress_events.id;


--
-- Name: egress_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.egress_policies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    policy jsonb NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.egress_policies FORCE ROW LEVEL SECURITY;


--
-- Name: environment_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environment_attachments (
    scope_id text NOT NULL,
    environment_id text NOT NULL,
    attached_by text NOT NULL,
    attached_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.environment_attachments FORCE ROW LEVEL SECURITY;


--
-- Name: environments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environments (
    id text NOT NULL,
    org_id text NOT NULL,
    name text,
    owner_actor_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.environments FORCE ROW LEVEL SECURITY;


--
-- Name: error_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.error_events (
    id bigint NOT NULL,
    ts bigint NOT NULL,
    scope_label text NOT NULL,
    category text NOT NULL,
    code text NOT NULL,
    message text NOT NULL,
    session_id text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.error_events FORCE ROW LEVEL SECURITY;


--
-- Name: error_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.error_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: error_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.error_events_id_seq OWNED BY public.error_events.id;


--
-- Name: external_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_members (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    expires_at bigint,
    kind text,
    invite_id text,
    invited_by text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);

ALTER TABLE ONLY public.external_members FORCE ROW LEVEL SECURITY;


--
-- Name: external_slack_participants_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_slack_participants_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    "on" boolean NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.external_slack_participants_flag FORCE ROW LEVEL SECURITY;


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    enabled_scopes text[] NOT NULL,
    updated_at bigint NOT NULL,
    updated_by text NOT NULL,
    feature_name text NOT NULL
);

ALTER TABLE ONLY public.feature_flags FORCE ROW LEVEL SECURITY;


--
-- Name: file_artifact_deletions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_artifact_deletions (
    id text NOT NULL,
    deleted_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.file_artifact_deletions FORCE ROW LEVEL SECURITY;


--
-- Name: file_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_artifacts (
    id text NOT NULL,
    kind text DEFAULT 'file'::text NOT NULL,
    owner_scope_id text NOT NULL,
    path text NOT NULL,
    name text NOT NULL,
    mimetype text NOT NULL,
    size_bytes bigint NOT NULL,
    blob_key text,
    sha256 text,
    direction text NOT NULL,
    created_by text NOT NULL,
    created_in_scope text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    source text DEFAULT 'live'::text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.file_artifacts FORCE ROW LEVEL SECURITY;


--
-- Name: idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    at bigint NOT NULL,
    claim text,
    key text NOT NULL
);

ALTER TABLE ONLY public.idempotency FORCE ROW LEVEL SECURITY;


--
-- Name: individual_model_auth_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.individual_model_auth_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    "on" boolean NOT NULL,
    provider text,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.individual_model_auth_flag FORCE ROW LEVEL SECURITY;


--
-- Name: interactive_fast_mode_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interactive_fast_mode_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    "on" boolean NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.interactive_fast_mode_flag FORCE ROW LEVEL SECURITY;


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    tenant_id uuid NOT NULL,
    session_id text NOT NULL,
    seq bigint NOT NULL,
    turn_id uuid,
    kind public.item_kind NOT NULL,
    author text,
    call_id text,
    elicit_id text,
    wake_cause public.wake_cause,
    error_code text,
    text text,
    tool text,
    step integer,
    variant text,
    is_error boolean,
    hidden boolean,
    external_id text,
    through_seq bigint,
    target_seq bigint,
    approved boolean,
    blob_sha bytea,
    search tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, COALESCE(text, ''::text))) STORED,
    body jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT items_approved_kind CHECK (((approved IS NULL) OR (kind = 'ElicitationResponse'::public.item_kind))),
    CONSTRAINT items_author_check CHECK ((author <> ''::text)),
    CONSTRAINT items_author_kind CHECK (((author IS NULL) OR (kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'ElicitationResponse'::public.item_kind, 'Stop'::public.item_kind, 'RuntimeChange'::public.item_kind])))),
    CONSTRAINT items_blob_sha_kind CHECK (((blob_sha IS NULL) OR (kind = 'ToolResult'::public.item_kind))),
    CONSTRAINT items_body_check CHECK ((jsonb_typeof(body) = 'object'::text)),
    CONSTRAINT items_call_id_check CHECK ((call_id <> ''::text)),
    CONSTRAINT items_call_id_kind CHECK (((call_id IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind])))),
    CONSTRAINT items_elicit_id_check CHECK ((elicit_id <> ''::text)),
    CONSTRAINT items_elicit_id_kind CHECK (((elicit_id IS NOT NULL) = (kind = ANY (ARRAY['Elicitation'::public.item_kind, 'ElicitationResponse'::public.item_kind])))),
    CONSTRAINT items_error_code_check CHECK ((error_code <> ''::text)),
    CONSTRAINT items_error_code_kind CHECK (((error_code IS NOT NULL) = (kind = 'Error'::public.item_kind))),
    CONSTRAINT items_external_id_check CHECK ((external_id <> ''::text)),
    CONSTRAINT items_external_id_kind CHECK (((external_id IS NULL) OR (kind = 'UserMessage'::public.item_kind))),
    CONSTRAINT items_hidden_kind CHECK (((hidden IS NULL) OR (kind = 'UserMessage'::public.item_kind))),
    CONSTRAINT items_is_error_kind CHECK (((is_error IS NULL) OR (kind = 'ToolResult'::public.item_kind))),
    CONSTRAINT items_seq_check CHECK ((seq >= 0)),
    CONSTRAINT items_step_check CHECK ((step >= 0)),
    CONSTRAINT items_step_kind CHECK (((step IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind, 'Reasoning'::public.item_kind, 'AgentMessage'::public.item_kind])))),
    CONSTRAINT items_target_seq_kind CHECK (((target_seq IS NULL) OR (kind = 'Retraction'::public.item_kind))),
    CONSTRAINT items_text_check CHECK ((text <> ''::text)),
    CONSTRAINT items_text_kind CHECK (((text IS NULL) OR (kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind, 'AgentMessage'::public.item_kind, 'Reasoning'::public.item_kind, 'ToolResult'::public.item_kind, 'Error'::public.item_kind, 'ContextCompaction'::public.item_kind])))),
    CONSTRAINT items_through_seq_kind CHECK (((through_seq IS NULL) OR (kind = 'ContextCompaction'::public.item_kind))),
    CONSTRAINT items_tool_check CHECK ((tool <> ''::text)),
    CONSTRAINT items_tool_kind CHECK (((tool IS NULL) OR (kind = ANY (ARRAY['ToolCall'::public.item_kind, 'ToolResult'::public.item_kind])))),
    CONSTRAINT items_variant_check CHECK ((variant = ANY (ARRAY['narration'::text, 'files_delivered'::text]))),
    CONSTRAINT items_variant_kind CHECK (((variant IS NULL) OR (kind = 'AgentMessage'::public.item_kind))),
    CONSTRAINT items_wake_cause_kind CHECK (((wake_cause IS NOT NULL) = (kind = 'Wake'::public.item_kind)))
);

ALTER TABLE ONLY public.items FORCE ROW LEVEL SECURITY;


--
-- Name: keychain_asks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_asks (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    credential_id text NOT NULL,
    owner_id text NOT NULL,
    requester_id text NOT NULL,
    org_id text,
    requester_scope_id text NOT NULL,
    requester_destination jsonb,
    requester_thread_ref text,
    requester_seq bigint,
    requester_message_ts text,
    purpose text NOT NULL,
    requested_mode text,
    status text NOT NULL,
    created_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    resolved_at bigint,
    grant_id text,
    note text,
    notified_at bigint
);

ALTER TABLE ONLY public.keychain_asks FORCE ROW LEVEL SECURITY;


--
-- Name: keychain_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_credentials (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    owner_id text NOT NULL,
    org_id text,
    service text NOT NULL,
    kind text NOT NULL,
    env_key text,
    targets text[],
    host text,
    account_label text,
    fields jsonb,
    broker jsonb,
    refresh jsonb,
    managed text,
    secret_enc text NOT NULL,
    fingerprint text NOT NULL,
    origin text,
    expires_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    target text,
    username text
);

ALTER TABLE ONLY public.keychain_credentials FORCE ROW LEVEL SECURITY;


--
-- Name: keychain_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keychain_grants (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    credential_id text NOT NULL,
    owner_id text NOT NULL,
    org_id text,
    audience_scope_id text NOT NULL,
    mode text NOT NULL,
    purpose text NOT NULL,
    status text NOT NULL,
    created_at bigint NOT NULL,
    expires_at bigint,
    revoked_at bigint,
    used_at bigint,
    used_by text,
    ask_id text
);

ALTER TABLE ONLY public.keychain_grants FORCE ROW LEVEL SECURITY;


--
-- Name: llm_prompt_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_prompt_envelopes (
    hash text NOT NULL,
    body text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.llm_prompt_envelopes FORCE ROW LEVEL SECURITY;


--
-- Name: local_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.local_sandbox_bodies FORCE ROW LEVEL SECURITY;


--
-- Name: loop_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loop_items (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.loop_items FORCE ROW LEVEL SECURITY;


--
-- Name: loops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loops (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.loops FORCE ROW LEVEL SECURITY;


--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_servers (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    auth text NOT NULL,
    credential_scope text,
    credential_host text,
    credential_account_type text,
    bearer_token text,
    client_id text,
    client_secret text,
    oauth_authorize_url text,
    oauth_token_url text,
    oauth_scopes text[],
    tools jsonb,
    approval text,
    catalog boolean,
    attest_actor boolean,
    read_only boolean NOT NULL,
    enabled boolean NOT NULL,
    updated_at bigint NOT NULL,
    updated_by text NOT NULL
);

ALTER TABLE ONLY public.mcp_servers FORCE ROW LEVEL SECURITY;


--
-- Name: memory_capture_pending; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_capture_pending (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    scope_id text NOT NULL,
    actor_id text,
    conversation_scope_id text NOT NULL,
    session_id text,
    idempotency_key text,
    sensitivity text,
    inherited_facts jsonb,
    turns jsonb NOT NULL,
    token text NOT NULL,
    at bigint NOT NULL
);

ALTER TABLE ONLY public.memory_capture_pending FORCE ROW LEVEL SECURITY;


--
-- Name: memory_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_facts (
    id bigint NOT NULL,
    scope_id text NOT NULL,
    text text NOT NULL,
    sensitivity text NOT NULL,
    sources text[] DEFAULT '{}'::text[] NOT NULL,
    source_unknown boolean NOT NULL,
    author text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    deleted_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    text_hash text NOT NULL
);

ALTER TABLE ONLY public.memory_facts FORCE ROW LEVEL SECURITY;


--
-- Name: memory_facts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.memory_facts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: memory_facts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.memory_facts_id_seq OWNED BY public.memory_facts.id;


--
-- Name: memory_tidy_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory_tidy_profiles (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    cron_id text,
    arming boolean
);

ALTER TABLE ONLY public.memory_tidy_profiles FORCE ROW LEVEL SECURITY;


--
-- Name: modal_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modal_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    initialization_pending boolean,
    last_snapshot_ms bigint,
    home_dirty boolean,
    snapshot_error text,
    checkpoint_id text,
    checkpoint_at_ms bigint,
    sandbox_id text,
    created_at_ms bigint,
    expires_at_ms bigint,
    last_activity_ms bigint,
    org_id text,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.modal_sandbox_bodies FORCE ROW LEVEL SECURITY;


--
-- Name: model_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_credentials (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    secret_enc text,
    disabled boolean,
    updated_at bigint NOT NULL,
    updated_by text NOT NULL,
    provider text NOT NULL
);

ALTER TABLE ONLY public.model_credentials FORCE ROW LEVEL SECURITY;


--
-- Name: monitors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monitors (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    owner_scope_id text NOT NULL,
    owner text NOT NULL,
    created_by text NOT NULL,
    owner_consented_at bigint,
    destination jsonb,
    enabled boolean NOT NULL,
    created_at bigint NOT NULL,
    last_fired_at bigint,
    process_id text NOT NULL,
    command text NOT NULL,
    purpose text,
    thread_ref text NOT NULL,
    instructions text,
    pattern text,
    cursor bigint NOT NULL,
    tail text,
    expires_at bigint,
    last_error text
);

ALTER TABLE ONLY public.monitors FORCE ROW LEVEL SECURITY;


--
-- Name: oauth_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_flows (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    provider text NOT NULL,
    principal_id text NOT NULL,
    redirect_uri text NOT NULL,
    issued_at bigint NOT NULL,
    return_to text,
    org_id text,
    account_type text,
    client_ref text,
    code_verifier text,
    consent_link_id text,
    nonce text NOT NULL
);

ALTER TABLE ONLY public.oauth_flows FORCE ROW LEVEL SECURITY;


--
-- Name: org_ambient_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_ambient_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    "on" boolean NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.org_ambient_flag FORCE ROW LEVEL SECURITY;


--
-- Name: participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.participants (
    session_id text NOT NULL,
    principal_id text NOT NULL,
    valid_from bigint NOT NULL,
    valid_to bigint,
    valid_from_seq integer,
    valid_to_seq integer,
    title text,
    archived boolean DEFAULT false NOT NULL,
    pinned boolean DEFAULT false NOT NULL,
    color text,
    read_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.participants FORCE ROW LEVEL SECURITY;


--
-- Name: principal_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.principal_links (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    principal_id text NOT NULL,
    canonical_id text NOT NULL,
    evidence text NOT NULL,
    linked_by text NOT NULL,
    created_at bigint NOT NULL
);

ALTER TABLE ONLY public.principal_links FORCE ROW LEVEL SECURITY;


--
-- Name: process_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_sessions (
    process_id text NOT NULL,
    scope_id text NOT NULL,
    kind text NOT NULL,
    command text NOT NULL,
    started_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    status text NOT NULL,
    session_ref text,
    run_id text,
    sandbox_id text,
    purpose text,
    credential_files jsonb,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.process_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    org_id text NOT NULL,
    name text NOT NULL,
    owner_id text NOT NULL,
    member_ids text[] NOT NULL,
    channel_member_ids text[],
    slack_channel jsonb,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);

ALTER TABLE ONLY public.projects FORCE ROW LEVEL SECURITY;


--
-- Name: qm_schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_schema_migrations (
    id text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: qm_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.qm_settings FORCE ROW LEVEL SECURITY;


--
-- Name: qm_tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qm_tenant (
    id uuid NOT NULL
);


--
-- Name: queued_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.queued_posts (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    post jsonb NOT NULL,
    first_failed_at bigint NOT NULL,
    last_error text NOT NULL
);

ALTER TABLE ONLY public.queued_posts FORCE ROW LEVEL SECURITY;


--
-- Name: rate_limit_windows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limit_windows (
    principal_id text NOT NULL,
    window_start bigint NOT NULL,
    count integer NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.rate_limit_windows FORCE ROW LEVEL SECURITY;


--
-- Name: recent_dm_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recent_dm_posts (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    posts jsonb NOT NULL
);

ALTER TABLE ONLY public.recent_dm_posts FORCE ROW LEVEL SECURITY;


--
-- Name: run_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_activity (
    id bigint NOT NULL,
    run_id text NOT NULL,
    seq bigint NOT NULL,
    parent_seq bigint,
    type text NOT NULL,
    payload jsonb NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.run_activity FORCE ROW LEVEL SECURITY;


--
-- Name: run_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_activity_id_seq OWNED BY public.run_activity.id;


--
-- Name: run_signals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_signals (
    id bigint NOT NULL,
    run_id text NOT NULL,
    kind text NOT NULL,
    text text,
    payload jsonb,
    created_at bigint NOT NULL,
    consumed_at bigint,
    dedupe_key text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.run_signals FORCE ROW LEVEL SECURITY;


--
-- Name: run_signals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.run_signals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run_signals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.run_signals_id_seq OWNED BY public.run_signals.id;


--
-- Name: runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runs (
    id text NOT NULL,
    session_id text NOT NULL,
    status text NOT NULL,
    request text NOT NULL,
    result text,
    idempotency_key text,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    lease_token text,
    lease_expires_at bigint,
    worker_id text,
    created_at bigint NOT NULL,
    started_at bigint,
    finished_at bigint,
    delivery_state text,
    error_attempts integer DEFAULT 0 NOT NULL,
    seq bigint NOT NULL,
    turn_user_seq bigint,
    retry_after bigint DEFAULT 0 NOT NULL,
    returned_at bigint,
    last_stop text,
    claim_priority smallint DEFAULT 2 NOT NULL,
    preemptions integer DEFAULT 0 NOT NULL,
    engine text DEFAULT 'legacy'::text NOT NULL,
    absurd_queue text,
    absurd_task_id uuid,
    absurd_run_id uuid,
    fair_key text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.runs FORCE ROW LEVEL SECURITY;


--
-- Name: runs_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.runs_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: runs_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.runs_seq_seq OWNED BY public.runs.seq;


--
-- Name: sandbox_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_defaults (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    sandbox_id text,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.sandbox_defaults FORCE ROW LEVEL SECURITY;


--
-- Name: sandbox_resource_rollout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_resource_rollout (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.sandbox_resource_rollout FORCE ROW LEVEL SECURITY;


--
-- Name: sandbox_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_resources (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    backend text NOT NULL,
    owner_scope_id text NOT NULL,
    backing_scope_id text NOT NULL,
    name text NOT NULL,
    created_by text NOT NULL,
    created_at text NOT NULL,
    legacy boolean NOT NULL,
    state text NOT NULL,
    machine_id text,
    cleanup_pending boolean,
    holders text[],
    spec jsonb,
    error text,
    job_only boolean
);

ALTER TABLE ONLY public.sandbox_resources FORCE ROW LEVEL SECURITY;


--
-- Name: sandbox_routing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sandbox_routing (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.sandbox_routing FORCE ROW LEVEL SECURITY;


--
-- Name: secret_drops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secret_drops (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    owner_id text NOT NULL,
    org_id text,
    service text NOT NULL,
    env_key text,
    host text,
    fields jsonb,
    purpose text NOT NULL,
    requested_by text NOT NULL,
    audience_scope_id text,
    scope_version text,
    grant_mode text,
    destination jsonb,
    thread_ref text,
    requires_token boolean,
    created_at bigint NOT NULL
);

ALTER TABLE ONLY public.secret_drops FORCE ROW LEVEL SECURITY;


--
-- Name: security_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_postures (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.security_postures FORCE ROW LEVEL SECURITY;


--
-- Name: session_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_goals (
    session_id text NOT NULL,
    objective text NOT NULL,
    status text NOT NULL,
    floor jsonb,
    token_cap bigint,
    tokens_used bigint DEFAULT 0 NOT NULL,
    active_ms bigint,
    active_since timestamp with time zone,
    completion_note text,
    cancel_note text,
    governor jsonb,
    pause_reason text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    CONSTRAINT session_goals_status_check CHECK ((status = ANY (ARRAY['active'::text, 'paused'::text, 'complete'::text, 'cancelled'::text])))
);

ALTER TABLE ONLY public.session_goals FORCE ROW LEVEL SECURITY;


--
-- Name: session_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_leases (
    session_id text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    holder text,
    acquired_at bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.session_leases FORCE ROW LEVEL SECURITY;


--
-- Name: session_llm_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_llm_requests (
    id text NOT NULL,
    session_id text NOT NULL,
    turn_seq integer,
    step integer NOT NULL,
    model text NOT NULL,
    scope_label text NOT NULL,
    truncated boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL,
    ttft_ms integer,
    duration_ms integer,
    step_gap_ms integer,
    tool_wall_json text,
    usage_json text,
    transport_json text,
    gap_phases_json text,
    prompt_hash text,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    spend_cost_usd double precision,
    spend_input bigint,
    spend_output bigint,
    spend_cache_read bigint,
    spend_cache_write bigint
);

ALTER TABLE ONLY public.session_llm_requests FORCE ROW LEVEL SECURITY;


--
-- Name: session_mailbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_mailbox (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    recipient_id text NOT NULL,
    sender_id text NOT NULL,
    actor jsonb NOT NULL,
    text text NOT NULL,
    source_entry_seq bigint,
    audience jsonb NOT NULL,
    created_at bigint NOT NULL,
    consumed boolean
);

ALTER TABLE ONLY public.session_mailbox FORCE ROW LEVEL SECURITY;


--
-- Name: session_pins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_pins (
    id text NOT NULL,
    session_id text NOT NULL,
    text text,
    entry_seq integer,
    added_by text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.session_pins FORCE ROW LEVEL SECURITY;


--
-- Name: session_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_shares (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    session_id text NOT NULL,
    audience text NOT NULL,
    created_by text NOT NULL,
    created_at bigint NOT NULL,
    visibility jsonb NOT NULL,
    messages jsonb NOT NULL,
    files jsonb NOT NULL,
    token text NOT NULL
);

ALTER TABLE ONLY public.session_shares FORCE ROW LEVEL SECURITY;


--
-- Name: session_spend_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_spend_days (
    day bigint NOT NULL,
    rows jsonb NOT NULL,
    updated_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.session_spend_days FORCE ROW LEVEL SECURITY;


--
-- Name: session_spend_dirty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_spend_dirty (
    day bigint,
    session_id text,
    writer xid8 DEFAULT pg_current_xact_id() NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    CONSTRAINT session_spend_dirty_check CHECK ((num_nonnulls(day, session_id) = 1))
);

ALTER TABLE ONLY public.session_spend_dirty FORCE ROW LEVEL SECURITY;


--
-- Name: session_turn_pointers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_turn_pointers (
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    thread_ref text NOT NULL,
    active_turn_id text,
    updated_at bigint NOT NULL
);

ALTER TABLE ONLY public.session_turn_pointers FORCE ROW LEVEL SECURITY;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    type text NOT NULL,
    scope_id text NOT NULL,
    thread_ref text NOT NULL,
    created_at bigint NOT NULL,
    title text,
    channel_name text,
    surface text,
    last_activity bigint,
    messages integer,
    turns integer,
    forked_from_session_id text,
    forked_from_title text,
    fork_boundary_seq integer,
    origin text,
    origin_id text,
    parent_session_id text,
    spawn_meta text,
    first_user_preview text,
    last_user_preview text,
    client_tools jsonb,
    last_user_activity bigint,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
)
WITH (fillfactor='70');

ALTER TABLE ONLY public.sessions FORCE ROW LEVEL SECURITY;


--
-- Name: sharing_postures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sharing_postures (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.sharing_postures FORCE ROW LEVEL SECURITY;


--
-- Name: skill_bundles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_bundles (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    commit text NOT NULL,
    files jsonb NOT NULL,
    hash text NOT NULL,
    pack_id text NOT NULL
);

ALTER TABLE ONLY public.skill_bundles FORCE ROW LEVEL SECURITY;


--
-- Name: skill_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_packs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    kind text NOT NULL,
    url text NOT NULL,
    ref text NOT NULL,
    sync_mode text NOT NULL,
    trust_tier text NOT NULL,
    config jsonb,
    target_scope_id text NOT NULL,
    subset jsonb NOT NULL,
    auth_credential_slug text,
    created_by text NOT NULL,
    created_at bigint NOT NULL,
    last_import jsonb,
    update_available boolean,
    available bigint
);

ALTER TABLE ONLY public.skill_packs FORCE ROW LEVEL SECURITY;


--
-- Name: skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skills (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    scope_id text NOT NULL,
    manifest jsonb NOT NULL,
    status text NOT NULL,
    created_by text NOT NULL,
    version bigint NOT NULL,
    granted_capabilities text[] NOT NULL,
    approvals text[] NOT NULL,
    created_at bigint,
    updated_at bigint,
    last_used_at bigint,
    pack jsonb
);

ALTER TABLE ONLY public.skills FORCE ROW LEVEL SECURITY;


--
-- Name: slack_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_accounts (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    account_id text NOT NULL,
    member_id text NOT NULL,
    user_id text NOT NULL,
    team_id text NOT NULL,
    "user" text NOT NULL,
    workspace text NOT NULL,
    principal_id text NOT NULL
);

ALTER TABLE ONLY public.slack_accounts FORCE ROW LEVEL SECURITY;


--
-- Name: slack_emoji_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_emoji_catalog (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    emoji jsonb NOT NULL,
    updated_at bigint NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.slack_emoji_catalog FORCE ROW LEVEL SECURITY;


--
-- Name: slack_handled_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_handled_events (
    id text NOT NULL,
    json jsonb NOT NULL,
    at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.slack_handled_events FORCE ROW LEVEL SECURITY;


--
-- Name: slack_installation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_installation (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    disabled boolean NOT NULL,
    service_blocked boolean,
    bot_token_enc text,
    app_token_enc text,
    app_id text,
    install_id text,
    installed_at bigint,
    team_id text,
    team_name text,
    updated_at bigint NOT NULL,
    updated_by text NOT NULL,
    version text NOT NULL,
    org_id text NOT NULL
);

ALTER TABLE ONLY public.slack_installation FORCE ROW LEVEL SECURITY;


--
-- Name: slack_session_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_session_status (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    writer text,
    account text NOT NULL,
    channel text NOT NULL,
    thread_ts text NOT NULL,
    anchor_run_id text NOT NULL,
    started_at bigint,
    card_id text,
    card_ts text,
    card_content text,
    follow_url text
);

ALTER TABLE ONLY public.slack_session_status FORCE ROW LEVEL SECURITY;


--
-- Name: slack_staged_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_staged_envelopes (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    body jsonb NOT NULL,
    account text NOT NULL,
    received_at bigint NOT NULL,
    attempts bigint NOT NULL,
    claimed_until bigint
);

ALTER TABLE ONLY public.slack_staged_envelopes FORCE ROW LEVEL SECURITY;


--
-- Name: slack_task_acknowledgements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slack_task_acknowledgements (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    channel text NOT NULL,
    emoji text NOT NULL,
    target text NOT NULL,
    previous text[] NOT NULL,
    finished boolean NOT NULL,
    synced boolean
);

ALTER TABLE ONLY public.slack_task_acknowledgements FORCE ROW LEVEL SECURITY;


--
-- Name: soul_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    content text NOT NULL,
    version bigint NOT NULL,
    updated_at bigint,
    updated_by text,
    history jsonb,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.soul_configs FORCE ROW LEVEL SECURITY;


--
-- Name: soul_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soul_history (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    scope_id text NOT NULL,
    content text NOT NULL,
    version bigint NOT NULL,
    updated_at bigint,
    updated_by text
);

ALTER TABLE ONLY public.soul_history FORCE ROW LEVEL SECURITY;


--
-- Name: source_auth_replay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_auth_replay (
    event_id text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.source_auth_replay FORCE ROW LEVEL SECURITY;


--
-- Name: sprites_initialization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sprites_initialization (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    initialization_pending boolean,
    last_snapshot_ms bigint,
    home_dirty boolean,
    snapshot_error text,
    checkpoint_id text,
    checkpoint_at_ms bigint,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.sprites_initialization FORCE ROW LEVEL SECURITY;


--
-- Name: suggested_activity_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suggested_activity_profiles (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    cron_id text,
    arming boolean,
    timezone text NOT NULL,
    last_seen_at bigint NOT NULL,
    last_bootstrap_at bigint,
    dismissal_refresh_at bigint,
    managed_action text,
    seeds jsonb,
    dismissed jsonb
);

ALTER TABLE ONLY public.suggested_activity_profiles FORCE ROW LEVEL SECURITY;


--
-- Name: superserve_config_epochs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superserve_config_epochs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.superserve_config_epochs FORCE ROW LEVEL SECURITY;


--
-- Name: superserve_sandbox_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superserve_sandbox_bodies (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.superserve_sandbox_bodies FORCE ROW LEVEL SECURITY;


--
-- Name: swarm_board_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.swarm_board_channels (
    swarm_id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    created_by text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.swarm_board_channels FORCE ROW LEVEL SECURITY;


--
-- Name: swarm_board_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.swarm_board_posts (
    id text NOT NULL,
    swarm_id text NOT NULL,
    channel text NOT NULL,
    thread_id text,
    author_id text NOT NULL,
    author_name text NOT NULL,
    body text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    notify_pending boolean DEFAULT false NOT NULL
);

ALTER TABLE ONLY public.swarm_board_posts FORCE ROW LEVEL SECURITY;


--
-- Name: swarm_board_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.swarm_board_subscriptions (
    swarm_id text NOT NULL,
    member_id text NOT NULL,
    channel text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.swarm_board_subscriptions FORCE ROW LEVEL SECURITY;


--
-- Name: swarm_boards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.swarm_boards (
    swarm_id text NOT NULL,
    created_by text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.swarm_boards FORCE ROW LEVEL SECURITY;


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_members (
    team_id text NOT NULL,
    principal_id text NOT NULL,
    role text NOT NULL,
    added_by text NOT NULL,
    added_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    CONSTRAINT team_members_role_check CHECK ((role = ANY (ARRAY['member'::text, 'admin'::text])))
);

ALTER TABLE ONLY public.team_members FORCE ROW LEVEL SECURITY;


--
-- Name: team_rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_rooms (
    team_id text NOT NULL,
    scope_id text NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.team_rooms FORCE ROW LEVEL SECURITY;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    team_id text NOT NULL,
    name text NOT NULL,
    isolated_in_open boolean DEFAULT false NOT NULL,
    created_by text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.teams FORCE ROW LEVEL SECURITY;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid NOT NULL,
    slug text NOT NULL,
    org_id text NOT NULL,
    hosts text[] DEFAULT '{}'::text[] NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    env jsonb DEFAULT '{}'::jsonb NOT NULL,
    secret_env bytea,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenants_status_check CHECK ((status = ANY (ARRAY['active'::text, 'suspended'::text])))
);


--
-- Name: tool_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_calls (
    run_id text NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    call_index integer NOT NULL,
    output text NOT NULL,
    created_at bigint NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL
);

ALTER TABLE ONLY public.tool_calls FORCE ROW LEVEL SECURITY;


--
-- Name: unfulfilled_insights_flag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unfulfilled_insights_flag (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    "on" boolean NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.unfulfilled_insights_flag FORCE ROW LEVEL SECURITY;


--
-- Name: web_ui_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_ui_state (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    value jsonb,
    updated_at bigint NOT NULL
);

ALTER TABLE ONLY public.web_ui_state FORCE ROW LEVEL SECURITY;


--
-- Name: webhook_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_history (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    events jsonb NOT NULL
);

ALTER TABLE ONLY public.webhook_history FORCE ROW LEVEL SECURITY;


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    owner_scope_id text NOT NULL,
    owner text NOT NULL,
    created_by text NOT NULL,
    owner_consented_at bigint,
    destination jsonb,
    enabled boolean NOT NULL,
    created_at bigint NOT NULL,
    last_fired_at bigint,
    action text NOT NULL,
    verification jsonb NOT NULL,
    filters jsonb,
    last_delivery_id text,
    last_error text
);

ALTER TABLE ONLY public.webhooks FORCE ROW LEVEL SECURITY;


--
-- Name: webui_model_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webui_model_configs (
    id text NOT NULL,
    json jsonb NOT NULL,
    tenant_id uuid DEFAULT public.qm_tenant_id() NOT NULL,
    ids text[] NOT NULL,
    scope_id text NOT NULL
);

ALTER TABLE ONLY public.webui_model_configs FORCE ROW LEVEL SECURITY;


--
-- Name: ack_emoji_picks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks ALTER COLUMN id SET DEFAULT nextval('public.ack_emoji_picks_id_seq'::regclass);


--
-- Name: ambient_judgments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments ALTER COLUMN id SET DEFAULT nextval('public.ambient_judgments_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: channel_policy_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history ALTER COLUMN id SET DEFAULT nextval('public.channel_policy_history_id_seq'::regclass);


--
-- Name: credential_usage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage ALTER COLUMN id SET DEFAULT nextval('public.credential_usage_id_seq'::regclass);


--
-- Name: egress_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events ALTER COLUMN id SET DEFAULT nextval('public.egress_events_id_seq'::regclass);


--
-- Name: error_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events ALTER COLUMN id SET DEFAULT nextval('public.error_events_id_seq'::regclass);


--
-- Name: memory_facts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts ALTER COLUMN id SET DEFAULT nextval('public.memory_facts_id_seq'::regclass);


--
-- Name: run_activity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity ALTER COLUMN id SET DEFAULT nextval('public.run_activity_id_seq'::regclass);


--
-- Name: run_signals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals ALTER COLUMN id SET DEFAULT nextval('public.run_signals_id_seq'::regclass);


--
-- Name: runs seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs ALTER COLUMN seq SET DEFAULT nextval('public.runs_seq_seq'::regclass);


--
-- Data for Name: c_jobs; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: c_jobs_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: c_turns_background; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: c_turns_background_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: c_turns_delegated; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: c_turns_delegated_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: c_turns_people; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: c_turns_people_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: e_jobs; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: e_jobs_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: e_turns_background; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: e_turns_background_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: e_turns_delegated; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: e_turns_delegated_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: e_turns_people; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: e_turns_people_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: queues; Type: TABLE DATA; Schema: absurd; Owner: -
--

INSERT INTO absurd.queues VALUES ('turns_people', '2026-10-26 15:39:13.281062+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('turns_delegated', '2026-10-26 15:39:13.357036+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('turns_background', '2026-10-26 15:39:13.442448+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('jobs', '2026-10-27 17:43:26.464455+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('turns_people_t111111110000', '2026-10-26 15:39:24.326528+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('turns_delegated_t111111110000', '2026-10-26 15:39:24.415583+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('turns_background_t111111110000', '2026-10-26 15:39:24.502395+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');
INSERT INTO absurd.queues VALUES ('jobs_t111111110000', '2026-10-27 17:43:26.678029+00', 'unpartitioned', 'enabled', '28 days', '1 day', '7 days', 1000, 'none', '30 days');


--
-- Data for Name: r_jobs; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: r_jobs_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: r_turns_background; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: r_turns_background_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: r_turns_delegated; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: r_turns_delegated_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: r_turns_people; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: r_turns_people_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: t_jobs; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: t_jobs_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: t_turns_background; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: t_turns_background_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: t_turns_delegated; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: t_turns_delegated_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: t_turns_people; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: t_turns_people_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: w_jobs; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: w_jobs_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: w_turns_background; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: w_turns_background_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: w_turns_delegated; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: w_turns_delegated_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: w_turns_people; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: w_turns_people_t111111110000; Type: TABLE DATA; Schema: absurd; Owner: -
--



--
-- Data for Name: ack_emoji; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ack_emoji_picks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: acl_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: acl_grants_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.acl_grants_version VALUES (true, 2, 'b7ab8aa5-c18b-405a-af1c-c2515e2593e9');


--
-- Data for Name: admin_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ambient_cursors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ambient_judgments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_grant_modes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approvals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: attributed_turns; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: attributed_turns_dirty; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_broker_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auto_flagger_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: aws_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: base_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: blobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: branding_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: browse_max_steps_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: browse_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: browser_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_header_pin_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_messages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_policy; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_policy_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_state; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: command_policies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: composio_returns; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: connector_clients; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: connector_status; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: consent_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: context_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: credential_daily_calls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: credential_usage; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cron_fires; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cron_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: crons; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: custom_model_providers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deactivated_principals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: decision_providers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: decision_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deploy_git_repos; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deployment_access; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deployment_identity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deployment_layer; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deployments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: directory_channel_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: directory_channels; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: directory_group_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: directory_groups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: directory_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: directory_meta; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: directory_sync; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: durable_map_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: e2b_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: egress_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: egress_policies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: environment_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: environments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: error_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: external_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: external_slack_participants_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_artifact_deletions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_artifacts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: idempotency; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: individual_model_auth_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: interactive_fast_mode_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: keychain_asks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: keychain_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: keychain_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: llm_prompt_envelopes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: local_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: loop_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: loops; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mcp_servers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: memory_capture_pending; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: memory_facts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: memory_tidy_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: modal_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: monitors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oauth_flows; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: org_ambient_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: participants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: principal_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: process_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: qm_schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_schema_migrations VALUES ('absurd/0.5.1', '4f8dd2e6249339a7c89d650d4d71b5a04228cf329a45f515a834acdeca3864e9', '2026-10-26 15:39:13.254118+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0001', '11758af3276004ec5ba9f283d35867d074999b2413b1ab6d74a4545e8fba16fa', '2026-10-26 15:39:13.516158+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0002', '86f3cbd7981ea8e137a31f6e66936ce53654c013c6f20dbb9924692a2263ed0d', '2026-10-26 15:39:13.526648+00');
INSERT INTO public.qm_schema_migrations VALUES ('acl/grants/0003-file-ids', '2ad7a5a68acb5da6ed801d2b4c1d56391e14bf1eef0356948f661c5a293825de', '2026-10-26 15:39:13.535254+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0001', '542f2a64d2814b329f2c1ad2eb8ed2728e8044b78efa6343eafb5598bc83cb1d', '2026-10-26 15:39:13.540278+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/audit-log/0002', 'bce8b31764744856dab57f8ced3a2e33b36e5896ff0f915152dc466741be3828', '2026-10-26 15:39:13.565458+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/grants/0001', '1a92727b41adaa11bf3029a419a8a5ca9213b0fbab91df905b7e58803cc73ce4', '2026-10-26 15:39:13.57144+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0001', '42188c2f50734398496ddd5a47a9ec3c15a507059c713a4a6ced0b0b81d908eb', '2026-10-26 15:39:13.581393+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0002', 'eb3194ec38847b601025c41b99616c4385770930074e808b21e53af9463d7ad0', '2026-10-26 15:39:13.610232+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/credential_usage/0003', '74b2011593ba178ca8decc6f7c82528f7bd161c4651fc2700a78839dac32fc04', '2026-10-26 15:39:13.611927+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/egress_events/0001', 'cfbf4ab51c2b0a4ac45eaeeb7a7011d7b2a4a4d9c21072473ed27400b03fe054', '2026-10-26 15:39:13.621712+00');
INSERT INTO public.qm_schema_migrations VALUES ('admin/scoped-events/error_events/0001', 'd5bab01c9f83042aace325e98636b614bcb8a6d77fedaed373f02efde282f5b8', '2026-10-26 15:39:13.639243+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/broker-sessions/0001', '2f958c4c732f8a8a79cb1d31215236fea9565ee2ce5e62270952b889ec5c1265', '2026-10-26 15:39:13.660169+00');
INSERT INTO public.qm_schema_migrations VALUES ('auth/replay-dedupe/0001', '8714fae4d626c773edfacf59d807e324955a205abb2be2bc76753cdbbc14adf7', '2026-10-26 15:39:13.67754+00');
INSERT INTO public.qm_schema_migrations VALUES ('cron/fires/0001', '462f9f784160d6e31019707b7df3c35ef0a2979fd3c9fb9d4d581fb89de6cad1', '2026-10-26 15:39:13.692597+00');
INSERT INTO public.qm_schema_migrations VALUES ('decisions/0001', '5259b744d814f2aae9b056e69f4488b87276b8db7eeb17d140d6e89bab93218a', '2026-10-26 15:39:13.711146+00');
INSERT INTO public.qm_schema_migrations VALUES ('delivery/store/0007-drop', '9f662d39f4ae88a5050475b17bc79410a3faa6f9f91ce83c26b177c91c3acaaa', '2026-10-26 15:39:13.733447+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/access/0001', 'fa35b86cbdfa9e8766ac5e47ffc926986b87ec5bad3ef1d7070fb8e2a1f3f9c2', '2026-10-26 15:39:13.735422+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0001', 'c47a45848f9d225ff601c9df13dc272349c7df7525e7e2417f33d68be7672cc1', '2026-10-26 15:39:13.754107+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0002', '4da6cc4f2496dd53d6381faea3f9f8e16e55394cfe46de516a692ede8157e8b0', '2026-10-26 15:39:13.838007+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0003', '1aaf42502793ebc31b253b12903cf192d2d8d6bcc9e4c1d31e834ed385f2a030', '2026-10-26 15:39:13.840725+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0004', '5376eae39ee0e8d99157e30b6edfbe8b35a0a0998bc4766a86529a45c0e83c4d', '2026-10-26 15:39:13.856682+00');
INSERT INTO public.qm_schema_migrations VALUES ('directory/store/0005', '38afbb8d963f48be05d5837f7f06e9f531229316c973c5f87eaa790e2611a8d9', '2026-10-26 15:39:13.859303+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ack_emoji/0001', 'b5cc8b58d6905bf400f15326b4fa4fd3517171dc7e3a2108d23ccc936612ab57', '2026-10-26 15:39:13.861616+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/ambient_cursors/0001', 'af7f98b52db7c0fe09648b4ca964f6ccaeb1bbe283cc4d39184f8084db465551', '2026-10-26 15:39:13.880795+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grant_modes/0001', '71fcc4c066ec51b5ea8529444cadf6b02193c31760bde9adbf1d198d31c5829a', '2026-10-26 15:39:13.891615+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approval_grants/0001', '584a7fe0f0a43a421793efed03be20afc249a2ce02dd3ff4924e4cd536ebbc9d', '2026-10-26 15:39:13.901319+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/0001', 'cd76491910753bae97e30680661f57cdde84d6583d724198cba5e0d71032dcb5', '2026-10-26 15:39:13.912253+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/lookup-sessionid-drop', 'f97131836d0b702bc1a1693e03bd5d97558a5aa95c5324ec0ce4a8b357814141', '2026-10-26 15:39:13.922476+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/lookup-sessionid-hash', 'cc98fbd26fca3ecf2c80295e1057e90abbcde3481211ce9082daed8aeedab4f3', '2026-10-26 15:39:13.931+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/select-sessionid', 'e44a660c6180087f9a8b08be2493eedd0595d4029552b08e3c089d2be47796f4', '2026-10-26 15:39:13.943142+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/approvals/stats-sessionid', 'c3c521e26580047f3e4b337f1cf2713f30c21e3d3b8c4c44d699b4dd17e7be45', '2026-10-26 15:39:13.944838+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/auto_flagger_configs/0001', '9a05f950a2b795595aae939eb60be8564511ac523a19961af482051a42c16ff5', '2026-10-26 15:39:13.948236+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/aws_sandbox_bodies/0001', '190bacea57ed75da62849825a5e3206905422d5ffc9f2192d9039222306b378d', '2026-10-26 15:39:13.958167+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/base_model_configs/0001', '7ee3b9db6bc36c92985dddf061cba7ef0b5d736fb44452febaef04c50211624e', '2026-10-26 15:39:13.968449+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/branding_configs/0001', '06c1123ae332e721fe619c8614392636ff446d1a47cd42396e8d3d819ade6dac', '2026-10-26 15:39:13.979861+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browse_max_steps_configs/0001', 'ae78a8a7cd7a78fc6886bbeb9241aadc057b4958713499e0591be82e878f2e41', '2026-10-26 15:39:13.990019+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browse_model_configs/0001', '1e06c0cfef0dae9b35d698363d2268d44e3715c0d51210b955f1870d67fa0c02', '2026-10-26 15:39:13.99986+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/browser_sessions/0001', '49bcab3ee00cac7b5aa4b3eaa303cfffc34521de73d763cbc4dd204a7a0e8b6f', '2026-10-26 15:39:14.010324+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/channel_header_pin_flag/0001', 'e8f344ed5c29eb3d19ec1a095947f1219e19ddbf0c2b70abdb0784d7c7b0465e', '2026-10-26 15:39:14.020795+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/command_policies/0001', '3b924df4ca67254193724e9a509ce0ee76f1d52bb42c2e0f80f0d408e046749d', '2026-10-26 15:39:14.031559+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/composio_returns/0001', 'e2c6917d12757feffde5140a25db74adeef597fecfa970ab81f5775b0d802460', '2026-10-26 15:39:14.043116+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/connector_clients/0001', 'c8e67053c62396d17890f6d5cbccf60c2097b520ceeb1005007ce4c7ffd38ab9', '2026-10-26 15:39:14.053026+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/connector_status/0001', '6c6632c1e1eae187d4ee42d04ff898901d613a0e7dadfd3056ebd040e97c2219', '2026-10-26 15:39:14.064171+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/consent_links/0001', '4023e872f3c4ef2342dd2db8d0a936662868024875a139162d5c1960dfe5a6db', '2026-10-26 15:39:14.07573+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/context_requests/0001', 'c06306bda2afa606283f9a391786e561e5f0854b3efe5c9b761813acd3238b87', '2026-10-26 15:39:14.086101+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/cron_items/0001', '0b16ff9849b8701115c2ac3e5486753c854623a586d8a60be95aa23c7b61f5dd', '2026-10-26 15:39:14.096171+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/cron_items/lookup-cronid-drop', '73226a4cc40bd4e240836e74ab06a8deb66e9f11751865419428330d6fd07f65', '2026-10-26 15:39:14.106153+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/cron_items/lookup-cronid-hash', 'b60775d1cd6885c70bdb43fdf74b70e297deb9e225daa3ac48214f90a4cf003d', '2026-10-26 15:39:14.114778+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/cron_items/select-cronid', 'ba50d129c2d7ae3cfbea934278f49bec01e60eeecbcc0ba551cf4539e9467949', '2026-10-26 15:39:14.127443+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/cron_items/stats-cronid', '7885f49cc713c07e2dc56adaa65cdab3efb9a17342839b5a019762bf28ab0183', '2026-10-26 15:39:14.129523+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0001', '0235672021171d1e58bd485fae8b56090ed58be3a12b156dc7491ac3d825dea3', '2026-10-26 15:39:14.13213+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0001-drop-run-as', '95e375cb70abd7dff68cf61a371167695b3e3427c31f38a9722142c244b0f97a', '2026-10-26 15:39:14.142689+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0002-loops-to-crons', '61ac2ad5d1909cfbe1119e0e16519a0f6e551a653d154b132349305ac12cd20a', '2026-10-26 15:39:14.153829+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/custom_model_providers/0001', '151ac01f9e2a37c511b3f56296050b37a7a4c9c13c7ef946259d5805def997d6', '2026-10-26 15:39:14.165913+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deactivated_principals/0001', '74cf2f5e2185abf08a2c93da115858a42c6f10fe94d814815342888e735ee355', '2026-10-26 15:39:14.177671+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deploy_git_repos/0001', '4957c2777766eb31eaa136953ed5046bc298d8341aab69a43545594f0970ea4c', '2026-10-26 15:39:14.188348+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_identity/0001', '11b012ea31d25b354799885bfc8f1f68a8e9ca2108d72ccee7102a36cbaa1c1b', '2026-10-26 15:39:14.199084+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployment_layer/0001', '1e9f09c7e5ca32924a4074a7cca5fff79865d31794515c02cd287b337b419803', '2026-10-26 15:39:14.210382+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/deployments/0001', 'f592ba8aeb41d74822e3960e9632d29adfba5bd0e79c7f21fc91e7258ad0e555', '2026-10-26 15:39:14.220229+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/e2b_sandbox_bodies/0001', '86fde308e21c9f2855750b885fc7a2c860eec53662e9713979cb5af7b6a844a0', '2026-10-26 15:39:14.222505+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/egress_policies/0001', 'e26a4391eabca30277592e928b512beacfa4d9388ebb189a6d22b7acc388c775', '2026-10-26 15:39:14.232369+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_members/0001', 'ea7b43915e8761f9148a2cff9f5c401e192a25b4b71b9535c0ee4710f1fdcba6', '2026-10-26 15:39:14.243513+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/external_slack_participants_flag/0001', '4c7dbf123c9b99cd85215958cfd9581b83e634b2e02b405548c2777001836291', '2026-10-26 15:39:14.253077+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/feature_flags/0001', '10919fe9fb09ca1141ed38917d5d11b6dad1f53f7f35724b03ad33ebb0712319', '2026-10-26 15:39:14.263232+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/idempotency/0001', 'e171e640e06976d6c0f869c90a3775c68a3ef228f78b56da4edbe7a0e29d7f9f', '2026-10-26 15:39:14.274112+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/individual_model_auth_flag/0001', '80e854a8e2377cb348357c97a3485c9739f4abdd65c3bbab523a0d911b7bb19d', '2026-10-26 15:39:14.288418+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/interactive_fast_mode_flag/0001', '3a1e6bcaa71527b414f5bb5f98610230cda67463b86823723b9283cc4b93aaf0', '2026-10-26 15:39:14.298654+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/internal_member_overrides/0002-drop', 'bababa8a7b29a956b7b90a33a4981f655b8e397a4a440b1fda639179cf5222d9', '2026-10-26 15:39:14.310745+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_asks/0001', 'aef8c37ef4fffa25f96ead4d5ae73b5bcb0b60aa7248050f9bd69d6c064a3a55', '2026-10-26 15:39:14.314143+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0001', 'b7dd2271dfd424898bc65f6adb658b8b51b07f0a9e6a9ef47b5e76fe51c0eda7', '2026-10-26 15:39:14.326105+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/0002-delete-auto-captured-logins', 'e2c3d2c3fb7d240450004a535a8af950db3b6ff35ca284da0f393ec31c0b4fde', '2026-10-26 15:39:14.337853+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/lookup-ownerid-drop', '460b2be11208138a00b181b518ca38bc58322dcd37f158ff672496b3fc1248c1', '2026-10-26 15:39:14.349977+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/lookup-ownerid-hash', '84860ad9d9f1634d9bf17e0a928a6d11513200dc6fb43c881928bf933d6da455', '2026-10-26 15:39:14.358917+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/select-ownerid', '6ce3ea87541dd9462ef96981c7c3aac35120340f6477a319b46806f717a90039', '2026-10-26 15:39:14.371618+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_credentials/stats-ownerid', 'fa449596f80d2fb3d6eff92f3d52a5e82a58db3c5556520b9fc273a5403d7773', '2026-10-26 15:39:14.373841+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/0001', '6331a8b0daa7ae875d6b09457f7ca1f865812e9a036efa23186793632f94d3d4', '2026-10-26 15:39:14.376792+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/lookup-ownerid-drop', 'b0d3eb453249ac97e0271a551c0b69f7ff93591507521ae1ffde71ce0cd3cee8', '2026-10-26 15:39:14.379304+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/lookup-ownerid-hash', 'c7f3b4ab099eadee97ffb0d0e30a949b63bab34a1356773c9efa85ef5f87063e', '2026-10-26 15:39:14.388339+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/select-ownerid', '2f8bc9481bd50e162894c41aaca606fb666eadae3600ef2297512d6c27e9c33a', '2026-10-26 15:39:14.402894+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/keychain_grants/stats-ownerid', '504fbbd9176f279f9c9ce9e2e58c475196dbbdc3c6697e81704ae568753ec676', '2026-10-26 15:39:14.40453+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/local_sandbox_bodies/0001', '8ddedfb7055df7571b770f0835d30c47892655123031f453aa765ee995348c18', '2026-10-26 15:39:14.407882+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/mcp_servers/0001', '656e5902aface901aa8ccea2d404b26454bdf5fc59b0523132b9c339e08b7800', '2026-10-26 15:39:14.418615+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/memory_tidy_profiles/0001', '9b4bb200823266468b607b2f81f3a50bd860cf25c41f980ddb0a61d9ea5e643e', '2026-10-26 15:39:14.4291+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/modal_sandbox_bodies/0001', 'e5a58d41d449a16030a2f8bce471141fe85753cf3e17fe112dfdafea1cf7ddb0', '2026-10-26 15:39:14.440667+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_credentials/0001', 'ede2f544fbfa17aadf339b7830db978823fdd8ffd626f900816c22bb26817474', '2026-10-26 15:39:14.452056+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/model_registry/0002-drop', 'dd86b4efd9ab54d0a1678bde9502e53fe2aab03327d8b6bc00f5d4ce5fd82c8f', '2026-10-26 15:39:14.464265+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/monitors/0001', '352b4ae3e97e45c43ffebb22ddafe1fadc56a37ac025a61d660eb0007613b580', '2026-10-26 15:39:14.467132+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/oauth_flows/0001', '043983772bd290d5722456d63082a660c76e26fe9b6fad0e4a46baa138140f4b', '2026-10-26 15:39:14.479045+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/org_ambient_flag/0001', '7934678d620174a9abb1571803f937a6828cfad2bfe3dd3714d73d44a2679bc5', '2026-10-26 15:39:14.489829+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/pinned_skills/0002-drop', '182c675b050a7a76d0d4283945e26a6e0449972b27fe104c9aeab0fd0452666a', '2026-10-26 15:39:14.500651+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/principal_links/0001', '3b3529b8c4a3803a044be89c7881e1aa1e9e1b430f1e5e5d15f49d80e002c38a', '2026-10-26 15:39:14.502887+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/projects/0001', 'c3542e30f1dc3a4200d39f2043e94c5e9e9d641902bcdc83cdde198ce79f36f3', '2026-10-26 15:39:14.513498+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/queued_posts/0001', 'b17cc1893878b663b2107f1f050dbfb395ae51fa4347c89e6a174e61b5e1515c', '2026-10-26 15:39:14.524914+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/recent_dm_posts/0001', '26601d1a20ca7ce8e30cf7e0892043a4cbb0d3eda33e84062480953d9a228170', '2026-10-26 15:39:14.536829+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_defaults/0001', '781d981103854e2b2c71435edb92d150e76aa8d93a4d519cd0b44c3fd2cb9921', '2026-10-26 15:39:14.547851+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resources/0001', '162e15a2d6f50446d52b17d3ee77f2461ee0ec1c0207b09498e21d335ebc2bdd', '2026-10-26 15:39:14.557666+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/secret_drops/0001', 'd53b8ea0189d918d65ec2f1f521bd1ea1ce7fdf533f516e365cc91732e016b96', '2026-10-26 15:39:14.568161+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/security_postures/0001', '811ad86fa544d98be740f332eb0315a9935d16b5a48ba0cec1516b819998c27d', '2026-10-26 15:39:14.577582+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/0001', 'ef49edb075b1c00c3bcff3526b595f74ca1d16704e497a83fdede49f21f515d6', '2026-10-26 15:39:14.588203+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/lookup-recipientid-drop', '0515b8739e932343b78ec1052a9e80c773febf0860ded4409618c7e3e3a4aa4f', '2026-10-26 15:39:14.598473+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/lookup-recipientid-hash', 'd4acbff880f7e84d2a1f1eac9ddb44aaa1781e104830c8e2d297ad5c2b324f77', '2026-10-26 15:39:14.607287+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/select-recipientid', '0f783946ba4ea3d80a9542d6a9bc3996678cd465abf0dfa4769c6788e3efe260', '2026-10-26 15:39:14.619306+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_mailbox/stats-recipientid', '6899798a87557911875dfed8682094a5f6ebc0b3f535b9794f28b4705aff0807', '2026-10-26 15:39:14.620787+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/session_shares/0001', '77d2a755c000aad13df96fdf9433b717b79c5ad8a5e11ac671ea33379aa55f1e', '2026-10-26 15:39:14.623359+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sharing_postures/0001', '16f5bcc02513285518e6913f70c043dda0d44fa4d0bdbe14ec578b5f06f1d178', '2026-10-26 15:39:14.633215+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_bundles/0001', 'e3e3974648f7657b6dca0c331b64d90f36529e9c3ffec1ae05282a370c0ba1ec', '2026-10-26 15:39:14.644324+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skill_packs/0001', 'ec3020db9e97c12b42fd33acc59bac01b741616fb2ac31327f6180068d35f708', '2026-10-26 15:39:14.654536+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/skills/0001', 'efe2a0c8ad67467be845d93206eddea17c15784175006b9a1cc82615ad0a33ea', '2026-10-26 15:39:14.666049+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_accounts/0001', '48ff469a6b3ccaa72d47ce443808b2be4ef38640dec7ba8733419789d5c6e8b9', '2026-10-26 15:39:14.677404+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_emoji_catalog/0001', '72e45c26308d61173a6de2ae9e78bbae52dc943e6f12981fa51455d273253a1a', '2026-10-26 15:39:14.687748+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_installation/0001', '31b96f65fded9ee0898ccf44766f6e542d30b0deb3b8da0d06381839be94764c', '2026-10-26 15:39:14.698063+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_session_status/0001', '211ec9c63a6104511f45ee1f2315e49f5b749e9fb2a8780dfdf5b6174ef0bc51', '2026-10-26 15:39:14.708393+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_staged_envelopes/0001', 'c3a5173bc2f0bf0e739fee4a59214c5e2d6236374f44a925016e74ac48188375', '2026-10-26 15:39:14.718428+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/slack_task_acknowledgements/0001', 'bf9fad755c2e7c4dcbb795ad589832b78136e41cac793b0decf98cf180acdcc4', '2026-10-26 15:39:14.728663+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_configs/0001', '8528037c99399b8fdcba2e29dc7dccbc0bb359d6cd5e9ca8f4e0d34a6fc7a4e3', '2026-10-26 15:39:14.739645+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/soul_history/0001', '2a9607ecb96935a95b97fdefc042c7517a58802c4cf9fcee67d7e8da3a4603e2', '2026-10-26 15:39:14.750946+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0001', 'f0850d1e9f12f26babce849b90b52eab95b81530aabf802e87f160a395985ba3', '2026-10-26 15:39:14.762573+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/suggested_activity_profiles/0001-nightly-on-use', '319965364d5048237981818039583f6e2d97e2f69553906fb8311b569867d720', '2026-10-26 15:39:14.772797+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_config_epochs/0001', '03a29556205a6f0e0a80fb7e1b828de610ad20169b342cb80623685a31496477', '2026-10-26 15:39:14.776026+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/superserve_sandbox_bodies/0001', '49673eb711120ab7e1fb3d0b5d5dd2d9ffccaa59c331e88112d5c82d907c6220', '2026-10-26 15:39:14.787255+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/swarms/0002-drop', '6fd03996fb6c9b0b5ea06db198f83a16cf39dafbf7bc9fddb8965e54b3030635', '2026-10-26 15:39:14.798284+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/triggers/0001-drop-recipient-consent', '690a465b166e66765bd18fc38375020f8b9adbc3d503e384e307d2e02c00c320', '2026-10-26 15:39:14.801472+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/turn_wall_clock_configs/0002-drop', '4b4ebf24b233ddccbb94d3b562b09e87adfe3e64eb1a4f2792ab192036f6b781', '2026-10-26 15:39:14.813501+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/unfulfilled_insights_flag/0001', '6039de5aad6758a517701cab7a47ee158162e21bf79f965f71d780bf9fc41d22', '2026-10-26 15:39:14.816435+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/web_ui_state/0001', 'c432e9df04d30e5533c79ae12ec1564541072ce1138af9ea320f08c533a7cac0', '2026-10-26 15:39:14.828034+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhook_history/0001', '5d99f7bc000a792e237082339eccb490bf124c0dfe7fb14f816b8978e73ec7b4', '2026-10-26 15:39:14.838204+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0001', '95a66510c7e6983e713290d0066264128baa406a19f390af6ba18873e2360c28', '2026-10-26 15:39:14.8484+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webhooks/0002-disable-rows-orphaned-by-webhook-removal', '5049d35f8e432183fed151377a615e25ec6a97677b7a7ec7da57b155c7425db7', '2026-10-26 15:39:14.850647+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/webui_model_configs/0001', '37bb44ffc7579effc5c0ea6c47fc8e7a231207c2e123711daaac34b79f379983', '2026-10-26 15:39:14.853239+00');
INSERT INTO public.qm_schema_migrations VALUES ('environments/store/0001', 'f6eb00919601e6c50bca7857a93061761d2bd1a31396ed7cf9373f93c8ffcae7', '2026-10-26 15:39:14.86369+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0001', '568d83afca3a8ce6287cbe85ad570612d9bb01ad0a8b7d78aa54e6fdc1dc1b0e', '2026-10-26 15:39:14.888243+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0002', 'fc47df852bd24c895b47e97d407eec54a71db90f407c5731627d82b2c63b5819', '2026-10-26 15:39:14.909093+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0000-records-column', '450e71b07659508640f782635a5019fa31b906cc63fdc97e7236d28b0d4c3aea', '2026-10-26 15:39:14.919855+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0001', 'cc560bef4c54ea2007b66eb46bf7258b70c9de98da901348f271c5da38c06597', '2026-10-26 15:39:14.922256+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0001', '5ca2d3af76a021c55ec15829f5798347851f3d73df53f36041dc04fbb2253324', '2026-10-26 15:39:14.937053+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0002', '3677d509807832aecda3cf903f22c42bc3d31a6d9c97b4156f981d376f589999', '2026-10-26 15:39:14.952487+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0003', 'd24a770a83eddffda0658e3e650a3c420ffddb6f68c379d5933f720b2e98cb19', '2026-10-26 15:39:14.954601+00');
INSERT INTO public.qm_schema_migrations VALUES ('processes/registry/0004', '9c17b6f267eb528657ab97b7bf27735d1c8aa5b8eaefdfe9489346839ea89052', '2026-10-26 15:39:14.956563+00');
INSERT INTO public.qm_schema_migrations VALUES ('ratelimit/limiter/0001', '27463ccd35e5a63321d9a3abb88d5691a23919ad6a9cee945645ce4e487d9437', '2026-10-26 15:39:14.958642+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/crons/0001', '1e33169a8550366f1651f4a9be634b8c04293f3cc197cbf7f741c45af798b632', '2026-10-26 15:39:14.968395+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/deploys/0001', '97db7e33f1bd293034b3e1eb24909bb28ac2c31db3c128dc8d378bd18b91929e', '2026-10-26 15:39:14.971657+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/skills/0001', '77217c6a8da2b9714ede4668b3b52497b83399c65bea3b9c9a311e9565d4d5ef', '2026-10-26 15:39:14.974721+00');
INSERT INTO public.qm_schema_migrations VALUES ('resource-search/webhooks/0001', 'afdb2392eed83a8db7402eececbbdaebbc1563444c21616db1998fd330e40881', '2026-10-26 15:39:14.981449+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/activity/0001', '985e4430016c037b986909566aceb68f53870fc50a71158dbaf73c1c5a15c509', '2026-10-26 15:39:14.984262+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0001', 'f94f67b5c878383af0026a0a44b1f252f83585dec0e12b79b9db6e8de841cacf', '2026-10-26 15:39:15.00142+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/signals/0002', '5eaf490533f72a518bd27d4846b052532a7715976e2e5b3b3432b16d1416bb59', '2026-10-26 15:39:15.900843+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0001', '07a121d0fa4e8ae4049e0574939dbf938c8615dc39ce29b74805a7e8ccb4ad0f', '2026-10-26 15:39:15.930375+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0002', 'c0fc23238fbe0ace56a28278bcb6cadfb100eb2c24ee83ce873588d466930270', '2026-10-26 15:39:16.054526+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0003', '8594c46c02ee90d43292a4c083fedea6c72d93b5f414f75e9e20d2db51b1b595', '2026-10-26 15:39:16.110954+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0004', '287116e5f86a67157788d505fecb2ea319974509b5ce35df6febfc8b9f059d6b', '2026-10-26 15:39:16.114084+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0004-subagent-returns', '390cf57f79622a535c61b02f59c3727d49d7bc51ac7710da184a24352415ad52', '2026-10-26 15:39:16.116611+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0005-session-history', '98df79620c5dfbedcc8b3b1ea38ada86d7948a0fd2fb6f9f8646c2c826b30612', '2026-10-26 15:39:16.144054+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0006-terminal-finished', 'c1b9fac31ffd7f3e0e19ae28007a3a0870f64ba04c1c6b608153dcc262970920', '2026-10-26 15:39:16.155832+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0007-last-stop', '3112c3322da219fd1be29ff632b726a529864794f3659846e320cf6ba54cbe56', '2026-10-26 15:39:16.157887+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0008-claim-priority', 'd67a00e019c5343ea8a03ec0b1e851f714de191cd8f1ba404263665105ba61ad', '2026-10-26 15:39:16.160132+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0009-claim-priority-index', '9922f90b6cea5da7af6ad0cbff5b718cd741c68260a2420abdb2889f441ef8ef', '2026-10-26 15:39:16.181686+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0010-drop-turn-metrics', 'cc3fdea1e8cfc3979dab84d9474d09741aee1d882875519eef9f0ebeeacc94b0', '2026-10-26 15:39:16.183664+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0011-turn-engine', '19f17b8388ec6184be64548b0f944a4f5e8abed18fb8097e2398b7d38cdfe3e5', '2026-10-26 15:39:16.186588+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0012-turn-engine-indexes', 'f7143920515057b8ad8b5736bdb3b207d92f5de191cbf3bbe2b5f2fca5ea7103', '2026-10-26 15:39:16.223496+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0013-turn-fairness', 'cae259a475a766c868f021f7017b92e2e09f2664f7a24568028f32830851f9ce', '2026-10-26 15:39:16.225299+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0014-turn-fairness-index', '1d9fb42b948d43e00eb1499cf533cc55a249ae9b78a6ae0f2c51d21249e1f070', '2026-10-26 15:39:16.26051+00');
INSERT INTO public.qm_schema_migrations VALUES ('runtime/0002-drop-harness-choice', '2e7a8523090c84d00b557197f2e3038b5b2fd418e6b3b4b08c10ef0cf596a792', '2026-10-26 15:39:16.262698+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0001', 'cf56c9f6488806677a229698193ef6dd7cb74300c343bdb1930c17702c5ccf2f', '2026-10-26 15:39:16.266733+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0002', 'ca9877865861adf81cfb433750327462aedcfa1e60d4e87a7845d1a77f64c2ec', '2026-10-26 15:39:16.362472+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0003', 'fd77efdccf169dee81da809a54313be30a0aaf92cdea4f6c33e34555bb2396c8', '2026-10-26 15:39:16.464805+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0004', '856cc6940c934b59e37d511271630f77d72b235c92ab0e2e2085207d15750a75', '2026-10-26 15:39:16.46824+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0005', '4b0824aa4311df8c66b57b16f331e9dcf3dfc8d11c112a000d83f46b1fba1bd0', '2026-10-26 15:39:16.48214+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0006', '57037691db0c87e9eeb28927758ae35e426eb8a8b7f7b5b8440bb08817f39203', '2026-10-26 15:39:16.488182+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0007', '8322f0c560da60399baf59f0364e8125e836384cd8b4d9795bd1c114d4d7d514', '2026-10-26 15:39:16.511748+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0008', '4b32bec77fa021de97736856a70a45bf1e51e59e574987e0d044fe748ec4cf58', '2026-10-26 15:39:16.514339+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0009', '40558264e0589a236a8a5a688a42eb49acf8a774371b9e1c6a3e5e0a84065c7d', '2026-10-26 15:39:16.516607+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0010', '29832445f9d3bfaf0d97f11b2748a1ca533ff57c6f4bd96c594e83a6ab4f7c9a', '2026-10-26 15:39:16.532414+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0011', 'be590472124ab471453cfbbd7d3c1a0c57f792c97704707fba3682f4183f870d', '2026-10-26 15:39:16.535392+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0012', '6f52591c733daffdda7aca112ad5a21cfec5c0c36f97838d74b107a79b7100bf', '2026-10-26 15:39:16.538135+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0013', '86c8d0eff24f8f2deab4f33eccff6d0206b3a9a64943a812eec0965203dd5262', '2026-10-26 15:39:16.545102+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0014-search-write-through-v1', 'e91226e6e5897b86e296c43e75a3f8d00633a1a7752a46c4c9f7cabf44f3b747', '2026-10-26 15:39:16.563805+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0015-search-backfill-v1', '3f942dd9aefb26588756cd936f73e08704df8071454b1f3d6fba7fe41f373864', '2026-10-26 15:39:16.566928+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0016-status', '89fbf5684830326730fdbde5f2de9cea69dcc1661a5f9e17e897232d5d74c9b4', '2026-10-26 15:39:16.570035+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0016-tape-source-role', '2725fb5df8e2a82fe5936486e45e7f999bd0606cf3355d6bfbb01296d17374f7', '2026-10-26 15:39:16.572146+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0017-subagent-parentage', '46f54668e4e535b7e891170e85453eaa4ccb4f923f2fc666d0376967efa5295a', '2026-10-26 15:39:16.574441+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0017-transcript-entries', '828dfba948c6272dd747748c04ad777a0f84f5fde23d0b803fa5bf28872a6ef7', '2026-10-26 15:39:16.580686+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0018-llm-requests-created-at', '0f550cd1401ea9f6dc7d62c7d154e4a8a4624e8fb27d10e75ed2bc000a54f5e7', '2026-10-26 15:39:16.58834+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0019-participant-activity-indexes', '4bd9bfdadffe0d2c4de382feacce65c06987f061df940eecc7991699b1249348', '2026-10-26 15:39:16.614315+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0020-spend-usage-json', 'febf07cde8b9ffe09a497d44a0e524a5c994f7708a0fab6d245315e4ab1e717a', '2026-10-26 15:39:16.615873+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0020-spend-usage-json-size', '4f34eed7d24be1ea5e81263d9eb4dafa4a5c54da709332feb38b2f6fab6f7025', '2026-10-26 15:39:16.618136+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0020-spend-usage-json-size-plpgsql', '1d69838eefe8377d3f8010707c0ce816bafd340b3d9da3c0cc15bb4fad038e16', '2026-10-26 15:39:16.619961+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0021-spend-covering-index', 'e11f84353f7637fff2ccb5bf9aa54de9a9fe1494cd8181adf52676edf0bf8f5a', '2026-10-26 15:39:16.644059+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0022-spend-days', '66bddbc128d3257accf4501d5f2890a9cddf8b9ae5287b38dacabdaa4005bdad', '2026-10-26 15:39:16.645945+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0023-spend-days-backfill', '8c5baecc5ec81cf33f24c53c58bb6d93f7589458a4bd442ab67a19fa783398ca', '2026-10-26 15:39:16.666152+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0024-user-previews', 'ca1d0192587bdc5d07690988e7767c2d79d0f3ee8a1627fffcac24499d74df47', '2026-10-26 15:39:16.668894+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0025-org-activity-index', '00366567fac31a93877a9373dd7613084091565a4933372068d9d5fce9d9f4a1', '2026-10-26 15:39:16.6823+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0026-participant-read-at', 'a3949603eac7d7fb64dba0852a23b4ee7468717875774144e5d74d852e49418e', '2026-10-26 15:39:16.684148+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0027-agent-reply-index', '65af103073ef18b66547651fc007e4f1b704a98126e6974eea121ca877f1e090', '2026-10-26 15:39:16.69639+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0028-drop-run-tasks', '5aa0a3c8a071fffcddb859cdab12735dd331c97d3258da4807152b64e503ae22', '2026-10-26 15:39:16.69822+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0029-legacy-tape-steps', 'a103ebb697c0d2cdf4a843791127955ff6c42729ca1ba5880446e02aa24e7235', '2026-10-26 15:39:16.700201+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0030-legacy-tape-steps-size-guard', '3b7f668e1acedcda4613ba41110f62932b404ba93884c829aa209d744a7a12c8', '2026-10-26 15:39:16.731241+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0031-drop-session-tape', '3100b33fe1e55d5abe05f50b655f3ff73142e3608af3616ba4954209b5f42e5b', '2026-10-26 15:39:16.745577+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0032-session-goals', '67b3486e1426f893bfbf64fb5412083ca30a2287038afc358793c5222171dd2c', '2026-10-26 15:39:16.767005+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0033-client-tools', '3d46f3d967516132f7f67d0ce5ee46127a9a46761ad9d143aba12db374b293aa', '2026-10-26 15:39:16.814866+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0034-session-origin-backfill', '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', '2026-10-26 15:39:16.817964+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0035-items', 'b3f15f62b55af30d7f6b79f037a09d157ea1e1ad9aad5702742dff01263c016d', '2026-10-26 15:39:16.819854+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0035-items-keep-call-ids', 'cfddc304ecc65adc4dd9eca2fe6ddac6a53eb05bfd8ac9d282e420750d3c8f94', '2026-10-26 15:39:16.882218+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0036-items-cutover', '43c41a637d03afe4ce8d1314298783a8190c56da4e0d25aa3bf810c13fb6f439', '2026-10-26 15:39:16.885546+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0037-drop-legacy-history', '9454a05ac35a704ccd7027e7f7f07d4c97acc589009d107ca538028e57d1a7d8', '2026-10-26 15:39:16.892164+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0038-scoped-origin-pages', '7b4a021bdfa47d06b19676f0ab93ba251eff93f69547d1a777e5ff35ba0d6eeb', '2026-10-26 15:39:16.922336+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0039-items-call-id-digest-index', 'cffad89ce3e55cfb9db84abace87cc310ef3f5385520019b6523cb680de3ba4a', '2026-10-26 15:39:16.934071+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0040-items-call-id-digest-swap', '558e686736d1eba1d5fac1866fabe2433b5e0cf420123873e237ea7327409c38', '2026-10-26 15:39:16.935727+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0041-drop-inline-llm-request', '398ae13963cbb65985f948db602bcf952d396598f7edd10244960a6d398c2894', '2026-10-26 15:39:16.939275+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0042-llm-prompt-envelopes-created-at', '4dcffa4ab23b943c3fc761c0edb9f2e01cbbb8473d73823721695da765eec3ed', '2026-10-26 15:39:16.951961+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0043-last-user-activity', '6ac9dd6674c99c00f47b823cadddbbba866db625bb72713fb1b3b32e13a982a1', '2026-10-26 15:39:16.953861+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0044-last-user-activity-backfill', '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', '2026-10-26 15:39:16.956872+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ack-emoji-pick/0001', 'f810bb939d938048d4852a518c04ee315dc42e415e237a31b35129fe08678228', '2026-10-26 15:39:16.959064+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/ambient-judgment/0001', '70c0f2d71fdc4d464b4a9d35fcb078b5efdf4dc4fcf769f8379eaa1afb4ad61e', '2026-10-26 15:39:16.981015+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/channel-policy/0001', '5be6f79d080af7a40c4c28708c906359fab2e5cdb23ffd24823da12186fa19ef', '2026-10-26 15:39:17.003207+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0001', 'd823cafcb1d6fbe0400d4ec7cbf745d768af8d02b492681092b95136b706518d', '2026-10-26 15:39:17.024777+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0002', 'a940914e3f7a04f8508e88b31035c3b4d74438087f716b6d1832f90ed78c9357', '2026-10-26 15:39:17.089659+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0003', 'b3f05a3e976216b758fd8482c603917505c231787c853b46e8c76a7d80377f08', '2026-10-26 15:39:17.09266+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0004', 'e64e42c1db30b3f2fe0cf8de0a274316bba539131c677b8242cb11ab55304eee', '2026-10-26 15:39:17.107088+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0005', '0730c53e72559cdd0eba1830f2e243dd539dabfeceb2702161fc0511dabba8e0', '2026-10-26 15:39:17.109568+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0006', '17e5f4f46573989bf031b3c79a41f191bc614c53e265829bb7bd5a17cad19208', '2026-10-26 15:39:17.11181+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/store/0007', 'd56a4323978d8233aab8258422908b794bf960dc2059e252b3850e6da3902a36', '2026-10-26 15:39:17.115096+00');
INSERT INTO public.qm_schema_migrations VALUES ('teams/0001', '2b8c0d4f17fb526e042960f55feab31d269a33b644872e2c87266be47429a174', '2026-10-26 15:39:17.11766+00');
INSERT INTO public.qm_schema_migrations VALUES ('turns/0001-ledger', '232697d51c3a7fad84bba53124f9f16882663afdbfa7200c3490842ed27578d3', '2026-10-26 15:39:17.155779+00');
INSERT INTO public.qm_schema_migrations VALUES ('turns/0002-tenant-queues', 'eb721fd4eccba37068ede563b419b6a81392575d24a5963307ce1f79df555126', '2026-10-26 15:39:17.172468+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_resource_rollout/0001', 'dcd22153628d543510d7b0354f04f44e5ced4caace605e4d11fc5d2a23e4951a', '2026-10-26 15:39:23.06241+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sandbox_routing/0001', '87419da3caad64f369b0b2fab335aba22d336730b4a11abf8bddf24300a49448', '2026-10-26 15:39:23.27709+00');
INSERT INTO public.qm_schema_migrations VALUES ('absurd/jobs-queue', '4e1c02cb9dd0d4ebb46c3b5e94dd616019ed61d141298218348db0d747afd93a', '2026-10-27 17:43:26.463595+00');
INSERT INTO public.qm_schema_migrations VALUES ('cron/fires/0002-retire-legacy-history', '4beaa8c51a26d9181cda820f9d9dfd4086e1553f8daf573e5f8d013f5bb5a1b9', '2026-10-27 17:43:26.500582+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0004-inbox-item-source', '113b49da2a00b04e8f5a680b958a7c3654dd93ba1e164b9ad0fde20576e27418', '2026-10-27 17:43:26.509617+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/memory_capture_pending/0001', '03ccc07bb69000bd7cfaf29fe46d66c88a72804ae6cc037b59ce8d36d7274649', '2026-10-27 17:43:26.516236+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/sprites_initialization/0001', 'e987bfe4bd5996dcee71ab6963e051d5192325c6d06a71f4e9da7621df4a50a0', '2026-10-27 17:43:26.526733+00');
INSERT INTO public.qm_schema_migrations VALUES ('files/artifacts/0003', '1d8427a63c4b360e53c2fafd86696783f33eab3f888678e28c0981a7b3c06c9a', '2026-10-27 17:43:26.538341+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0002-text-hash', '3548fb7774545aa8d6ce9ab89eba26c8f4817b7865bb5b6d839011b52ea39a1e', '2026-10-27 17:43:26.5397+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0045-llm-request-spend-columns', '82c1d4b5e3d5f0e40653fc0c561a0f751190fd6034995aeca34167b9b0dfe4e1', '2026-10-27 17:43:26.552836+00');
INSERT INTO public.qm_schema_migrations VALUES ('surfaces/ui-state/0001-typed', '65c358cd2f082ddf7f7ba3b520a70bc872e3a8f87d36a53b8b2c4c298faf9228', '2026-10-27 17:43:34.847526+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0046-llm-request-spend-unparsed', '4804f4e1e2736467dbd5372c7d7fec3837244148d7edb868f093fd8d1e9b36ba', '2026-10-27 17:43:26.559439+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0047-drop-spend-json-indexes', '0eb83b5b2731dd579dc004a2f9ae293e852f20726a5770ad66bf2f9b02496bc4', '2026-10-27 17:43:26.56019+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0048-attributed-turns', 'c0afc9d8c2895891c5df15584c1c28476af586b2d037334c45585a0779068f98', '2026-10-27 17:43:26.562+00');
INSERT INTO public.qm_schema_migrations VALUES ('swarm-board/0001', 'bb1c2ca37f57babab001af5b279076dd572d105fae0852283bd16292ec60b596', '2026-10-27 17:43:26.571464+00');
INSERT INTO public.qm_schema_migrations VALUES ('baseline/0001', 'ce6b6272ae4d2f1f5d7737323fe3e9a57feb3f12d0abc3c6f00f7b052f41c2ce', '2026-10-27 17:43:34.59457+00');
INSERT INTO public.qm_schema_migrations VALUES ('absurd/0.5.1-unpartitioned', '331c613ecb5e22e169b4bbb5cf302cefcbe27ced5b0566f690bd6702982a872a', '2026-10-27 17:43:34.59583+00');
INSERT INTO public.qm_schema_migrations VALUES ('api/ambient-cursors/0001-typed', '112336b4fd180ee6883a962314fda4216962d28276f2664d3a5d25e8c7a5db67', '2026-10-27 17:43:34.606625+00');
INSERT INTO public.qm_schema_migrations VALUES ('api/context-requests/0001-typed', '37d40dc13fa960c47df648041a050f8bb6bcd803bcda425ab004da3a73e82e36', '2026-10-27 17:43:34.611141+00');
INSERT INTO public.qm_schema_migrations VALUES ('connectors/browser-sessions/0001-typed', '8832175f9ac52bcb984a1395ebef1a35a0bc598da56a84a1887ff4a932c71f11', '2026-10-27 17:43:34.614409+00');
INSERT INTO public.qm_schema_migrations VALUES ('connectors/composio-returns/0001-typed', '54eee670af6d2956ec79cb0eb130b68375480379f481f20593558829a432cd56', '2026-10-27 17:43:34.620003+00');
INSERT INTO public.qm_schema_migrations VALUES ('connectors/consent-links/0001-typed', '984218185648c193035b2d6f2015d9c4c0a367ee858d94c082c713869e803b07', '2026-10-27 17:43:34.623001+00');
INSERT INTO public.qm_schema_migrations VALUES ('connectors/oauth-flows/0001-typed', 'f3aa5e39580b477c3e2c2824f56e4a831102c8c82402ade0688fe6faf538aae3', '2026-10-27 17:43:34.625972+00');
INSERT INTO public.qm_schema_migrations VALUES ('connectors/slack-accounts/0001-typed', 'e8f3cebe1dfa836ff2ed30d0affe1528fbef8ae201b0d971edb875f4a2d01e89', '2026-10-27 17:43:34.631457+00');
INSERT INTO public.qm_schema_migrations VALUES ('core/approval-grants/0001-typed', 'ee5a429d2883a5c56bb07e1a3f6d5a41f572a9a6c45f7e92e78962e2b5fb8de3', '2026-10-27 17:43:34.636641+00');
INSERT INTO public.qm_schema_migrations VALUES ('core/approvals/0001-typed', '5d5a9894501f72dae89a5826e2964f4f887912106ccc533d707b0ebb687ac3a6', '2026-10-27 17:43:34.641404+00');
INSERT INTO public.qm_schema_migrations VALUES ('credentials/connector-status/0001-typed', 'f6cc9742caf151cbe823682aaedcbe6b4340b08203da02b697e200e632827098', '2026-10-27 17:43:34.647929+00');
INSERT INTO public.qm_schema_migrations VALUES ('credentials/keychain/0001-typed-creds', '5b69368bd06ec5db5e84d750c83519887cc69bcebe9af687743415ff61f5d2a9', '2026-10-27 17:43:34.652832+00');
INSERT INTO public.qm_schema_migrations VALUES ('credentials/keychain/0002-typed-grants', 'a706fcc23ac907ecd0fdd550e745891a8014d963d558e50858a195c029b4f404', '2026-10-27 17:43:34.660004+00');
INSERT INTO public.qm_schema_migrations VALUES ('credentials/keychain/0003-typed-asks', '3765b239ba520856648b8a0d6a6dfa6040b3d995dfa78c723cad9c645a501981', '2026-10-27 17:43:34.668707+00');
INSERT INTO public.qm_schema_migrations VALUES ('credentials/secret-drops/0001-typed', 'e610dc3f581994688b51da9f28bc705a00fe41845767f5c388f4ffbc3d145328', '2026-10-27 17:43:34.673583+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/deploy_git_repos/0001-typed', '16a45183d7661822f3900e9c070de001647d5eb3d7faa3b5174371efdf1a9aeb', '2026-10-27 17:43:34.677813+00');
INSERT INTO public.qm_schema_migrations VALUES ('deploy/deployments/0001-typed', 'c87ffd349749999ee19f8dfe34bea29ebaf36949646d4462776dccd7f162a281', '2026-10-27 17:43:34.682579+00');
INSERT INTO public.qm_schema_migrations VALUES ('deployment/layer/0001-typed', '71137c5f865f933685917f7e5e0781d3b007c496dda14332ba5d074883b902e8', '2026-10-27 17:43:34.689435+00');
INSERT INTO public.qm_schema_migrations VALUES ('durable-map/crons/0005-inbox-conversation-key', '7aab780e37a8cfe60ed615bddc9feba8ed9aafb9bbea760e65d72ef5254eae47', '2026-10-27 17:43:34.693006+00');
INSERT INTO public.qm_schema_migrations VALUES ('feature-flags/store/0001-typed', 'f23f5b19be09bf1a4e967cf0f1cfe65697bd44641c224e2ac848e7bbda1ac178', '2026-10-27 17:43:34.694465+00');
INSERT INTO public.qm_schema_migrations VALUES ('idempotency/store/0001-typed', 'fc1c1fee433eace02b7c746525663b1b72d63d599fd4936aaf3cbd5601c85a9f', '2026-10-27 17:43:34.699468+00');
INSERT INTO public.qm_schema_migrations VALUES ('identity/deactivated-principals/0001-typed', 'cf59b9aa1e767ccbb7bbd54da2d5a01d28903ad9099656967965bf0bc304bfba', '2026-10-27 17:43:34.705865+00');
INSERT INTO public.qm_schema_migrations VALUES ('identity/external-members/0001-typed', 'f424f47235ad5d4ec0ac49725a88cf65ba722c2a39c1218006e49d4fc0ffc6c1', '2026-10-27 17:43:34.708985+00');
INSERT INTO public.qm_schema_migrations VALUES ('identity/principal-links/0001-typed', '2292eddde2c509fe8efb9221dba7516d59d722db18c58903eea09f73377fe5de', '2026-10-27 17:43:34.712254+00');
INSERT INTO public.qm_schema_migrations VALUES ('mcp/servers/0001-typed', 'b958359c5a988045a9ee14baf6047c9175059a1630ef11f9b652e25707011c8e', '2026-10-27 17:43:34.71563+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/capture-pending/0001-typed', '4b2c0aae865a6bffddb11191ac5e9c16c369c6940839f27c932312b4e233072a', '2026-10-27 17:43:34.719684+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/facts/0003-text-hash-not-null', 'cca2b36a2a4619d6089bea18782376d6fba81a638591df53ff7381e243795759', '2026-10-27 17:43:34.722955+00');
INSERT INTO public.qm_schema_migrations VALUES ('memory/tidy-profiles/0001-typed', '5d5c7d5134041c6bc18532e77f3ebdf116aaccf13567a78095301c4737eea019', '2026-10-27 17:43:34.724498+00');
INSERT INTO public.qm_schema_migrations VALUES ('model/credentials/0001-typed', '600e23dce14ceb1170a184535a82d4381d61c3d279fc96f72a9abe355b8acfdf', '2026-10-27 17:43:34.727622+00');
INSERT INTO public.qm_schema_migrations VALUES ('model/custom-providers/0001-typed', '5662ce32d9d3191cfa22b90cb5fe806e8b9cc747cc4a1a716b3198aab996f091', '2026-10-27 17:43:34.732684+00');
INSERT INTO public.qm_schema_migrations VALUES ('projects/store/0001-typed', '0473c8d86321b7cbc3afd4baf1bba915b481094abe6d9e6827e725552970aae4', '2026-10-27 17:43:34.736484+00');
INSERT INTO public.qm_schema_migrations VALUES ('runs/store/0013-turn-origin-backfill', '7feeb1f2c66eb6ef709aff689fdf413f3d7049eb0d762b08a86e29862f5e3b09', '2026-10-27 17:43:34.74213+00');
INSERT INTO public.qm_schema_migrations VALUES ('runtime/0003-promote-legacy-base-models', 'eb766612e9fd611b44d69f71ad7ff6583fbbaf96e0bf160be99faae661e7c41a', '2026-10-27 17:43:34.745423+00');
INSERT INTO public.qm_schema_migrations VALUES ('sandbox/e2b_sandbox_bodies/0001-typed', 'b44fdb623ca3861fbe2db55bad292e03d63fc483bb91fcbbd063c97517d62a24', '2026-10-27 17:43:34.746442+00');
INSERT INTO public.qm_schema_migrations VALUES ('sandbox/modal_sandbox_bodies/0001-typed', '1b3597a15563286f078e0ce2dd742f6423e135d5386c32d0180663bce54322fb', '2026-10-27 17:43:34.75157+00');
INSERT INTO public.qm_schema_migrations VALUES ('sandbox/sandbox_defaults/0001-typed', '8b8284c2f13a68d118f5a494e8faa84b7553f51dad753e988449eed1118cae70', '2026-10-27 17:43:34.75779+00');
INSERT INTO public.qm_schema_migrations VALUES ('sandbox/sandbox_resources/0001-typed', '63f46ba3242de4e42af03f144e04b1febcbf1a6fe1f1156d8ee8b37d31a97442', '2026-10-27 17:43:34.762113+00');
INSERT INTO public.qm_schema_migrations VALUES ('sandbox/sprites_initialization/0001-typed', '451f909b42f10cb6280d5667876c31205cbadba30a63fd296e9d368a1e80470f', '2026-10-27 17:43:34.766372+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/mailbox/0001-typed', 'b69580c6a8280b9450e55bf5f8eb3b8c5583feb4b7490cea4eb6c03569015d79', '2026-10-27 17:43:34.771115+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/shares/0001-typed', '1f773442391dbd1b4b5c02a4d7e08c2292e3ffd5f1d604db74dae54f3d1890ad', '2026-10-27 17:43:34.776973+00');
INSERT INTO public.qm_schema_migrations VALUES ('sessions/store/0049-attributed-turns-tenant', 'c64598a4e38d569215477bf9b7f7b0aee37ec292297b6119182ec85df8e997b1', '2026-10-27 17:43:34.782919+00');
INSERT INTO public.qm_schema_migrations VALUES ('skills/bundles/0001-typed', 'a20b55207dc3d79bbfb67c7e3d66848c7bf1718430216d2a854fb1361b1d21d6', '2026-10-27 17:43:34.785171+00');
INSERT INTO public.qm_schema_migrations VALUES ('skills/packs/0001-typed', 'b6c89034e39a59846bb788722351a9422fb89b7615975a608a3e019b18683433', '2026-10-27 17:43:34.79011+00');
INSERT INTO public.qm_schema_migrations VALUES ('skills/store/0001-typed', 'e73b74aee4054aaadb4b65d4139865ee4b9690cbe9c0ab9e81211bf07cb4335d', '2026-10-27 17:43:34.794187+00');
INSERT INTO public.qm_schema_migrations VALUES ('slack/handled-events/0001-typed', '7f96fd0a2ee28c7cea7273b1f264047956c46b6c4b326bc17f983cbda5fb53c4', '2026-10-27 17:43:34.801925+00');
INSERT INTO public.qm_schema_migrations VALUES ('slack/session-status/0001-typed', '1b65d7f7dddea71810f58d623bbe0f536c1e687264ea2852f3a477244bb7b0bc', '2026-10-27 17:43:34.810054+00');
INSERT INTO public.qm_schema_migrations VALUES ('slack/staged-envelopes/0001-typed', '376d15db7a52e755119fbd74abbeec1f92d902efefaa1c2ed8451f8ca8e50d19', '2026-10-27 17:43:34.814072+00');
INSERT INTO public.qm_schema_migrations VALUES ('slack/task-acks/0001-typed', '2a9ad0bbfd27b5b2fb23517b7ec2d9d22d9f67301c0128fcd40e44639f3fd369', '2026-10-27 17:43:34.817599+00');
INSERT INTO public.qm_schema_migrations VALUES ('suggestions/activity-profiles/0001-typed', '6d2180f6a1bde38fae7b54dfb6fe77f2ed07be372e802b0bc7f6afdbd7293989', '2026-10-27 17:43:34.820843+00');
INSERT INTO public.qm_schema_migrations VALUES ('surface-cache/channel-policy/0003-orders-into-instructions', 'a47c3d4c3c62b65458a63c2417283e39a2aefa17acf1337cd43e52de513f568d', '2026-10-27 17:43:34.824236+00');
INSERT INTO public.qm_schema_migrations VALUES ('surfaces/queued-posts/0001-typed', '35854b90aaae4c6f257ae2b1d23d39a49f6bdc07fd82baac198373dcf8bc2bb3', '2026-10-27 17:43:34.831596+00');
INSERT INTO public.qm_schema_migrations VALUES ('surfaces/recent-dm-posts/0001-typed', '2f48c057201c8c83c99e85c23a5afa85618e5bcaeb1de6290509eed3043cd100', '2026-10-27 17:43:34.836622+00');
INSERT INTO public.qm_schema_migrations VALUES ('surfaces/slack-installation/0001-typed', 'df5e82de493cfa564830db35361323e20a8a2ac17c3ad7bb286be133aaec3c47', '2026-10-27 17:43:34.84043+00');
INSERT INTO public.qm_schema_migrations VALUES ('swarm-board/0002', '411af6a23f44effa0e2fd2961cc5af03cd38506212afc07786c64a5cb9eda083', '2026-10-27 17:43:34.850409+00');
INSERT INTO public.qm_schema_migrations VALUES ('triggers/cron-items/0001-typed', 'b5ec8f8bfb78744696afe937aa20d3cfb22dca2107a5900366db9d520572d3a8', '2026-10-27 17:43:34.853375+00');
INSERT INTO public.qm_schema_migrations VALUES ('triggers/crons/0001-typed', '4e18132573c58ee299bbbd5793ccee69a9d88e46f5aba2a25e3b95aa2589963d', '2026-10-27 17:43:34.863043+00');
INSERT INTO public.qm_schema_migrations VALUES ('triggers/crons/0002-owner-index', '6dd17182db56ed503a3c70ad42dd0bc1c6dc676937c96ec4ad9f2281a662a51f', '2026-10-27 17:43:34.869547+00');
INSERT INTO public.qm_schema_migrations VALUES ('triggers/monitors/0001-typed', '210befd47d22ebe505b795dfb75fc8d2747f22f1946cd8512dc333321fa50812', '2026-10-27 17:43:34.872378+00');
INSERT INTO public.qm_schema_migrations VALUES ('triggers/monitors/0002-owner-index', '62c6b92099098c4a525902adba3f8b6be77b3cdcd1540ddb017efb65c550b328', '2026-10-27 17:43:34.876599+00');
INSERT INTO public.qm_schema_migrations VALUES ('triggers/webhook-history/0001-typed', 'd55b5bc6a6c6dd02ffbe42802191f0c6c4d11e456102f0dc1d8345d7e1c11733', '2026-10-27 17:43:34.879117+00');
INSERT INTO public.qm_schema_migrations VALUES ('triggers/webhooks/0001-typed', 'd4b8d0c34f1878c84cb4d278fc7e06809a9e2703d26ddf7076efd55120fa7385', '2026-10-27 17:43:34.881823+00');
INSERT INTO public.qm_schema_migrations VALUES ('triggers/webhooks/0002-owner-index', '06432a175de7147a5bac50e1438160485474e5aed24d6584a67d34fb0eac6bd3', '2026-10-27 17:43:34.886496+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/ack_emoji/0001', '8a13d3cffbd75eefbd954edb9d4ca743893f48e0273cf490c9473d68eae1102b', '2026-10-27 17:43:34.888819+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/approval_grant_modes/0001', '6d0260bded85e8fa41b7fb8606dca004a86b5435c32a1d47a34215be6e021102', '2026-10-27 17:43:34.893481+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/auto_flagger_configs/0001', 'e026b23d371a085a7e530c488f7994ebdda05483ec721db90486012510f76fce', '2026-10-27 17:43:34.897928+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/base_model_configs/0001', '61b121dbd92ea3a589b6664fe4aaea6486e77dd7cee6c0f474c88fc667f2ff2c', '2026-10-27 17:43:34.902835+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/branding_configs/0001', 'b1914c65abc789b4ed11427469ba8009e42e960fb2b8b783eb18f38a28938c6c', '2026-10-27 17:43:34.907788+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/browse_max_steps_configs/0001', 'e8e05490f23d1baf5f8a32ac6203eea80fcd117ff62c2898898bbec81c01551f', '2026-10-27 17:43:34.912842+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/browse_model_configs/0001', 'bdbe48afa4d20dad7524f78cb37d3252fe7f1a69c74dab8c81974a9ffb6afc7d', '2026-10-27 17:43:34.917189+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/channel_header_pin_flag/0001', '7f727813b4facc87b9b714c81e8128f333ede39e3caaa8199e614f73013c1c5a', '2026-10-27 17:43:34.92134+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/command_policies/0001', '969087e6d7c2b2eea585d92ed12cfe962cb15293581adef2c01fe3e1570af223', '2026-10-27 17:43:34.925042+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/connector_clients/0001', '927fa630bbdcf4b71c8783d318a9a2de9639b64e4ff8de852c7dda97126e4fe5', '2026-10-27 17:43:34.929258+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/deployment_identity/0001', '3a85c340ed6caa6fc9241185235c107b0ef0130d6fcbad984a27ca0e69fcf1b0', '2026-10-27 17:43:34.93455+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/egress_policies/0001', '50ac92c6c3a11a79a8d4ce95c2946c9f32759a1feb3922bf24b6839d8350e77b', '2026-10-27 17:43:34.937028+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/external_slack_participants_flag/0001', '3f185da9f3886afa1107ac4bdbf067f3e7de7c7a3c81e2d732fc500a524c7af5', '2026-10-27 17:43:34.941041+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/individual_model_auth_flag/0001', '411846887e0a39c9a16af3ab8d95ef4ab32f3490f1dda22e0f54c43c411b9ab2', '2026-10-27 17:43:34.945885+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/interactive_fast_mode_flag/0001', '5fa2b917ffe818a72787eac35d85fcffb73fb63e43ce45a65bc7458dcc6083f2', '2026-10-27 17:43:34.95032+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/org_ambient_flag/0001', 'f83639707ae7f3ab08fe5ab82ec6b7e5b407b6a6bc6842503c98167789e9c28a', '2026-10-27 17:43:34.9545+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/slack_emoji_catalog/0001', 'e0e03d1c51825ec608de85bf4dc6f6f75321beeb3700610a88faf48e2893c112', '2026-10-27 17:43:34.959201+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/soul_configs/0001', '562c54e2de0969bad63f879b7c1868b9f495d7c28c1596eb8390022e16ef0df8', '2026-10-27 17:43:34.963514+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/soul_history/0001', '7809847eefad5fe5b4529d0b4be5a8c4392cca1536955565a90d586e18f08a69', '2026-10-27 17:43:34.967839+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/unfulfilled_insights_flag/0001', '43a33a87fb669f8d96e0eca28c14f74083948fbf0a2824e29078c89e2f1a889c', '2026-10-27 17:43:34.970685+00');
INSERT INTO public.qm_schema_migrations VALUES ('typed/config/webui_model_configs/0001', '668bda676ded878b62d5996a0b75d01871e9c9262974e4c768d4cc350b225132', '2026-10-27 17:43:34.974719+00');


--
-- Data for Name: qm_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: qm_tenant; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qm_tenant VALUES ('b7ab8aa5-c18b-405a-af1c-c2515e2593e9');


--
-- Data for Name: queued_posts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: rate_limit_windows; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recent_dm_posts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_activity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_signals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sandbox_defaults; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sandbox_resource_rollout; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sandbox_resources; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sandbox_routing; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: secret_drops; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: security_postures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_goals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_leases; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_llm_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_mailbox; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_pins; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_shares; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_spend_days; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_spend_dirty; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: session_turn_pointers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sharing_postures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: skill_packs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: slack_accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: slack_emoji_catalog; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: slack_handled_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: slack_installation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: slack_session_status; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: slack_staged_envelopes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: slack_task_acknowledgements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: soul_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: soul_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: source_auth_replay; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sprites_initialization; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: suggested_activity_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: superserve_config_epochs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: superserve_sandbox_bodies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: swarm_board_channels; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: swarm_board_posts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: swarm_board_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: swarm_boards; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_rooms; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.tenants VALUES ('11111111-0000-4000-8000-000000000001', 'closedai', 'closedai', '{closedai.example.test}', 'active', '{}', NULL, '2026-10-26 15:39:18.869348+00', '2026-10-26 15:39:18.869348+00');
INSERT INTO public.tenants VALUES ('11111111-0000-4000-8000-000000000002', 'kittenmittens', 'kittenmittens', '{kittenmittens.example.test}', 'active', '{}', NULL, '2026-10-26 15:39:18.869348+00', '2026-10-26 15:39:18.869348+00');
INSERT INTO public.tenants VALUES ('11111111-0000-4000-8000-000000000003', 'openaguy', 'openaguy', '{openaguy.example.test}', 'active', '{}', NULL, '2026-10-26 15:39:18.869348+00', '2026-10-26 15:39:18.869348+00');
INSERT INTO public.tenants VALUES ('11111111-0000-4000-8000-000000000004', 'mt-fake-1', 'mt-fake-1', '{mt-fake-1.example.test}', 'active', '{}', NULL, '2026-10-26 15:39:18.869348+00', '2026-10-26 15:39:18.869348+00');
INSERT INTO public.tenants VALUES ('11111111-0000-4000-8000-000000000005', 'mt-fake-2', 'mt-fake-2', '{mt-fake-2.example.test}', 'active', '{}', NULL, '2026-10-26 15:39:18.869348+00', '2026-10-26 15:39:18.869348+00');


--
-- Data for Name: tool_calls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: unfulfilled_insights_flag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: web_ui_state; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhook_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webui_model_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: ack_emoji_picks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ack_emoji_picks_id_seq', 1, false);


--
-- Name: ambient_judgments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ambient_judgments_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: channel_policy_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.channel_policy_history_id_seq', 1, false);


--
-- Name: credential_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credential_usage_id_seq', 1, false);


--
-- Name: egress_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.egress_events_id_seq', 1, false);


--
-- Name: error_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.error_events_id_seq', 1, false);


--
-- Name: memory_facts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.memory_facts_id_seq', 1, false);


--
-- Name: run_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.run_activity_id_seq', 1, false);


--
-- Name: run_signals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.run_signals_id_seq', 1, false);


--
-- Name: runs_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.runs_seq_seq', 1, false);


--
-- Name: c_jobs c_jobs_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_jobs
    ADD CONSTRAINT c_jobs_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_jobs_t111111110000 c_jobs_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_jobs_t111111110000
    ADD CONSTRAINT c_jobs_t111111110000_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_background c_turns_background_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_background
    ADD CONSTRAINT c_turns_background_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_background_t111111110000 c_turns_background_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_background_t111111110000
    ADD CONSTRAINT c_turns_background_t111111110000_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_delegated c_turns_delegated_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_delegated
    ADD CONSTRAINT c_turns_delegated_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_delegated_t111111110000 c_turns_delegated_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_delegated_t111111110000
    ADD CONSTRAINT c_turns_delegated_t111111110000_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_people c_turns_people_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_people
    ADD CONSTRAINT c_turns_people_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: c_turns_people_t111111110000 c_turns_people_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.c_turns_people_t111111110000
    ADD CONSTRAINT c_turns_people_t111111110000_pkey PRIMARY KEY (task_id, checkpoint_name);


--
-- Name: e_jobs e_jobs_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_jobs
    ADD CONSTRAINT e_jobs_pkey PRIMARY KEY (event_name);


--
-- Name: e_jobs_t111111110000 e_jobs_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_jobs_t111111110000
    ADD CONSTRAINT e_jobs_t111111110000_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_background e_turns_background_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_background
    ADD CONSTRAINT e_turns_background_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_background_t111111110000 e_turns_background_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_background_t111111110000
    ADD CONSTRAINT e_turns_background_t111111110000_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_delegated e_turns_delegated_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_delegated
    ADD CONSTRAINT e_turns_delegated_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_delegated_t111111110000 e_turns_delegated_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_delegated_t111111110000
    ADD CONSTRAINT e_turns_delegated_t111111110000_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_people e_turns_people_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_people
    ADD CONSTRAINT e_turns_people_pkey PRIMARY KEY (event_name);


--
-- Name: e_turns_people_t111111110000 e_turns_people_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.e_turns_people_t111111110000
    ADD CONSTRAINT e_turns_people_t111111110000_pkey PRIMARY KEY (event_name);


--
-- Name: queues queues_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.queues
    ADD CONSTRAINT queues_pkey PRIMARY KEY (queue_name);


--
-- Name: r_jobs r_jobs_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_jobs
    ADD CONSTRAINT r_jobs_pkey PRIMARY KEY (run_id);


--
-- Name: r_jobs_t111111110000 r_jobs_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_jobs_t111111110000
    ADD CONSTRAINT r_jobs_t111111110000_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_background r_turns_background_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_background
    ADD CONSTRAINT r_turns_background_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_background_t111111110000 r_turns_background_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_background_t111111110000
    ADD CONSTRAINT r_turns_background_t111111110000_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_delegated r_turns_delegated_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_delegated
    ADD CONSTRAINT r_turns_delegated_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_delegated_t111111110000 r_turns_delegated_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_delegated_t111111110000
    ADD CONSTRAINT r_turns_delegated_t111111110000_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_people r_turns_people_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_people
    ADD CONSTRAINT r_turns_people_pkey PRIMARY KEY (run_id);


--
-- Name: r_turns_people_t111111110000 r_turns_people_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.r_turns_people_t111111110000
    ADD CONSTRAINT r_turns_people_t111111110000_pkey PRIMARY KEY (run_id);


--
-- Name: t_jobs t_jobs_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_jobs
    ADD CONSTRAINT t_jobs_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_jobs t_jobs_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_jobs
    ADD CONSTRAINT t_jobs_pkey PRIMARY KEY (task_id);


--
-- Name: t_jobs_t111111110000 t_jobs_t111111110000_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_jobs_t111111110000
    ADD CONSTRAINT t_jobs_t111111110000_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_jobs_t111111110000 t_jobs_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_jobs_t111111110000
    ADD CONSTRAINT t_jobs_t111111110000_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_background t_turns_background_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_background
    ADD CONSTRAINT t_turns_background_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_background t_turns_background_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_background
    ADD CONSTRAINT t_turns_background_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_background_t111111110000 t_turns_background_t111111110000_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_background_t111111110000
    ADD CONSTRAINT t_turns_background_t111111110000_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_background_t111111110000 t_turns_background_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_background_t111111110000
    ADD CONSTRAINT t_turns_background_t111111110000_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_delegated t_turns_delegated_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_delegated
    ADD CONSTRAINT t_turns_delegated_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_delegated t_turns_delegated_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_delegated
    ADD CONSTRAINT t_turns_delegated_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_delegated_t111111110000 t_turns_delegated_t111111110000_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_delegated_t111111110000
    ADD CONSTRAINT t_turns_delegated_t111111110000_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_delegated_t111111110000 t_turns_delegated_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_delegated_t111111110000
    ADD CONSTRAINT t_turns_delegated_t111111110000_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_people t_turns_people_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_people
    ADD CONSTRAINT t_turns_people_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_people t_turns_people_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_people
    ADD CONSTRAINT t_turns_people_pkey PRIMARY KEY (task_id);


--
-- Name: t_turns_people_t111111110000 t_turns_people_t111111110000_idempotency_key_key; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_people_t111111110000
    ADD CONSTRAINT t_turns_people_t111111110000_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: t_turns_people_t111111110000 t_turns_people_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.t_turns_people_t111111110000
    ADD CONSTRAINT t_turns_people_t111111110000_pkey PRIMARY KEY (task_id);


--
-- Name: w_jobs w_jobs_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_jobs
    ADD CONSTRAINT w_jobs_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_jobs_t111111110000 w_jobs_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_jobs_t111111110000
    ADD CONSTRAINT w_jobs_t111111110000_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_background w_turns_background_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_background
    ADD CONSTRAINT w_turns_background_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_background_t111111110000 w_turns_background_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_background_t111111110000
    ADD CONSTRAINT w_turns_background_t111111110000_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_delegated w_turns_delegated_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_delegated
    ADD CONSTRAINT w_turns_delegated_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_delegated_t111111110000 w_turns_delegated_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_delegated_t111111110000
    ADD CONSTRAINT w_turns_delegated_t111111110000_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_people w_turns_people_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_people
    ADD CONSTRAINT w_turns_people_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: w_turns_people_t111111110000 w_turns_people_t111111110000_pkey; Type: CONSTRAINT; Schema: absurd; Owner: -
--

ALTER TABLE ONLY absurd.w_turns_people_t111111110000
    ADD CONSTRAINT w_turns_people_t111111110000_pkey PRIMARY KEY (run_id, step_name);


--
-- Name: ack_emoji_picks ack_emoji_picks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji_picks
    ADD CONSTRAINT ack_emoji_picks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: ack_emoji ack_emoji_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ack_emoji
    ADD CONSTRAINT ack_emoji_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: acl_grants acl_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants
    ADD CONSTRAINT acl_grants_pkey PRIMARY KEY (tenant_id, owner_scope_id, path, grantee_scope_id, permission);


--
-- Name: acl_grants_version acl_grants_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acl_grants_version
    ADD CONSTRAINT acl_grants_version_pkey PRIMARY KEY (tenant_id, only_row);


--
-- Name: admin_grants admin_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_grants
    ADD CONSTRAINT admin_grants_pkey PRIMARY KEY (tenant_id, principal_id, scope_id, role);


--
-- Name: ambient_cursors ambient_cursors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_cursors
    ADD CONSTRAINT ambient_cursors_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: ambient_judgments ambient_judgments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ambient_judgments
    ADD CONSTRAINT ambient_judgments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approval_grant_modes approval_grant_modes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grant_modes
    ADD CONSTRAINT approval_grant_modes_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approval_grants approval_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_grants
    ADD CONSTRAINT approval_grants_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: attributed_turns_dirty attributed_turns_dirty_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributed_turns_dirty
    ADD CONSTRAINT attributed_turns_dirty_pkey PRIMARY KEY (tenant_id, session_id);


--
-- Name: attributed_turns attributed_turns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributed_turns
    ADD CONSTRAINT attributed_turns_pkey PRIMARY KEY (tenant_id, session_id, principal_id, day);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: auth_broker_sessions auth_broker_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_broker_sessions
    ADD CONSTRAINT auth_broker_sessions_pkey PRIMARY KEY (tenant_id, token_hash);


--
-- Name: auto_flagger_configs auto_flagger_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_flagger_configs
    ADD CONSTRAINT auto_flagger_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: aws_sandbox_bodies aws_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_sandbox_bodies
    ADD CONSTRAINT aws_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: base_model_configs base_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.base_model_configs
    ADD CONSTRAINT base_model_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: blobs blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blobs
    ADD CONSTRAINT blobs_pkey PRIMARY KEY (tenant_id, sha256);


--
-- Name: branding_configs branding_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_configs
    ADD CONSTRAINT branding_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: browse_max_steps_configs browse_max_steps_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_max_steps_configs
    ADD CONSTRAINT browse_max_steps_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: browse_model_configs browse_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browse_model_configs
    ADD CONSTRAINT browse_model_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: browser_sessions browser_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.browser_sessions
    ADD CONSTRAINT browser_sessions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_files channel_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_files
    ADD CONSTRAINT channel_files_pkey PRIMARY KEY (tenant_id, org_id, container, ts, file_id);


--
-- Name: channel_header_pin_flag channel_header_pin_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_header_pin_flag
    ADD CONSTRAINT channel_header_pin_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_messages channel_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_messages
    ADD CONSTRAINT channel_messages_pkey PRIMARY KEY (tenant_id, org_id, container, ts);


--
-- Name: channel_policy_history channel_policy_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy_history
    ADD CONSTRAINT channel_policy_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: channel_policy channel_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_policy
    ADD CONSTRAINT channel_policy_pkey PRIMARY KEY (tenant_id, org_id, container);


--
-- Name: channel_state channel_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_state
    ADD CONSTRAINT channel_state_pkey PRIMARY KEY (tenant_id, org_id, container);


--
-- Name: command_policies command_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_policies
    ADD CONSTRAINT command_policies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: composio_returns composio_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composio_returns
    ADD CONSTRAINT composio_returns_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: connector_clients connector_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_clients
    ADD CONSTRAINT connector_clients_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: connector_status connector_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_status
    ADD CONSTRAINT connector_status_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: consent_links consent_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_links
    ADD CONSTRAINT consent_links_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: context_requests context_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.context_requests
    ADD CONSTRAINT context_requests_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: credential_daily_calls credential_daily_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_daily_calls
    ADD CONSTRAINT credential_daily_calls_pkey PRIMARY KEY (tenant_id, slug, day);


--
-- Name: credential_usage credential_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_usage
    ADD CONSTRAINT credential_usage_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: cron_fires cron_fires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_fires
    ADD CONSTRAINT cron_fires_pkey PRIMARY KEY (tenant_id, cron_id, fire_key);


--
-- Name: cron_items cron_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cron_items
    ADD CONSTRAINT cron_items_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: crons crons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crons
    ADD CONSTRAINT crons_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: custom_model_providers custom_model_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_model_providers
    ADD CONSTRAINT custom_model_providers_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deactivated_principals deactivated_principals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deactivated_principals
    ADD CONSTRAINT deactivated_principals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: decision_providers decision_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_providers
    ADD CONSTRAINT decision_providers_pkey PRIMARY KEY (tenant_id, provider_id);


--
-- Name: decision_rules decision_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_pkey PRIMARY KEY (tenant_id, rule_id);


--
-- Name: deploy_git_repos deploy_git_repos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_git_repos
    ADD CONSTRAINT deploy_git_repos_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_access deployment_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_identity deployment_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_identity
    ADD CONSTRAINT deployment_identity_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployment_layer deployment_layer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_layer
    ADD CONSTRAINT deployment_layer_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: deployments deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: directory_channel_members directory_channel_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channel_members
    ADD CONSTRAINT directory_channel_members_pkey PRIMARY KEY (tenant_id, org_id, channel_id, principal_id);


--
-- Name: directory_channels directory_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_channels
    ADD CONSTRAINT directory_channels_pkey PRIMARY KEY (tenant_id, org_id, channel_id);


--
-- Name: directory_group_members directory_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_group_members
    ADD CONSTRAINT directory_group_members_pkey PRIMARY KEY (tenant_id, org_id, group_id, principal_id);


--
-- Name: directory_groups directory_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_groups
    ADD CONSTRAINT directory_groups_pkey PRIMARY KEY (tenant_id, org_id, group_id);


--
-- Name: directory_members directory_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_members
    ADD CONSTRAINT directory_members_pkey PRIMARY KEY (tenant_id, org_id, principal_id);


--
-- Name: directory_meta directory_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_meta
    ADD CONSTRAINT directory_meta_pkey PRIMARY KEY (tenant_id, org_id);


--
-- Name: directory_sync directory_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_sync
    ADD CONSTRAINT directory_sync_pkey PRIMARY KEY (tenant_id, org_id);


--
-- Name: durable_map_versions durable_map_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.durable_map_versions
    ADD CONSTRAINT durable_map_versions_pkey PRIMARY KEY (tenant_id, tbl);


--
-- Name: e2b_sandbox_bodies e2b_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2b_sandbox_bodies
    ADD CONSTRAINT e2b_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: egress_events egress_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_events
    ADD CONSTRAINT egress_events_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: egress_policies egress_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.egress_policies
    ADD CONSTRAINT egress_policies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: environment_attachments environment_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_pkey PRIMARY KEY (tenant_id, scope_id);


--
-- Name: environments environments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: error_events error_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_events
    ADD CONSTRAINT error_events_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: external_members external_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_members
    ADD CONSTRAINT external_members_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: external_slack_participants_flag external_slack_participants_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_slack_participants_flag
    ADD CONSTRAINT external_slack_participants_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: file_artifact_deletions file_artifact_deletions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifact_deletions
    ADD CONSTRAINT file_artifact_deletions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: file_artifacts file_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_artifacts
    ADD CONSTRAINT file_artifacts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: idempotency idempotency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency
    ADD CONSTRAINT idempotency_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: individual_model_auth_flag individual_model_auth_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.individual_model_auth_flag
    ADD CONSTRAINT individual_model_auth_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: interactive_fast_mode_flag interactive_fast_mode_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interactive_fast_mode_flag
    ADD CONSTRAINT interactive_fast_mode_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (tenant_id, session_id, seq);


--
-- Name: keychain_asks keychain_asks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_asks
    ADD CONSTRAINT keychain_asks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: keychain_credentials keychain_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_credentials
    ADD CONSTRAINT keychain_credentials_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: keychain_grants keychain_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keychain_grants
    ADD CONSTRAINT keychain_grants_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: llm_prompt_envelopes llm_prompt_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_prompt_envelopes
    ADD CONSTRAINT llm_prompt_envelopes_pkey PRIMARY KEY (tenant_id, hash);


--
-- Name: local_sandbox_bodies local_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_sandbox_bodies
    ADD CONSTRAINT local_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loop_items loop_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loop_items
    ADD CONSTRAINT loop_items_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: loops loops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loops
    ADD CONSTRAINT loops_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: memory_capture_pending memory_capture_pending_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_capture_pending
    ADD CONSTRAINT memory_capture_pending_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: memory_facts memory_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_facts
    ADD CONSTRAINT memory_facts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: memory_tidy_profiles memory_tidy_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory_tidy_profiles
    ADD CONSTRAINT memory_tidy_profiles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: modal_sandbox_bodies modal_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modal_sandbox_bodies
    ADD CONSTRAINT modal_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: model_credentials model_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_credentials
    ADD CONSTRAINT model_credentials_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: monitors monitors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: oauth_flows oauth_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_flows
    ADD CONSTRAINT oauth_flows_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: org_ambient_flag org_ambient_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_ambient_flag
    ADD CONSTRAINT org_ambient_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: participants participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_pkey PRIMARY KEY (tenant_id, session_id, principal_id);


--
-- Name: principal_links principal_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.principal_links
    ADD CONSTRAINT principal_links_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: process_sessions process_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_sessions
    ADD CONSTRAINT process_sessions_pkey PRIMARY KEY (tenant_id, process_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: qm_schema_migrations qm_schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_schema_migrations
    ADD CONSTRAINT qm_schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: qm_settings qm_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_settings
    ADD CONSTRAINT qm_settings_pkey PRIMARY KEY (tenant_id, key);


--
-- Name: qm_tenant qm_tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qm_tenant
    ADD CONSTRAINT qm_tenant_pkey PRIMARY KEY (id);


--
-- Name: queued_posts queued_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queued_posts
    ADD CONSTRAINT queued_posts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: rate_limit_windows rate_limit_windows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit_windows
    ADD CONSTRAINT rate_limit_windows_pkey PRIMARY KEY (tenant_id, principal_id);


--
-- Name: recent_dm_posts recent_dm_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recent_dm_posts
    ADD CONSTRAINT recent_dm_posts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: run_activity run_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_activity
    ADD CONSTRAINT run_activity_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: run_signals run_signals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_signals
    ADD CONSTRAINT run_signals_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: runs runs_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_idempotency_key_key UNIQUE (tenant_id, idempotency_key);


--
-- Name: runs runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_defaults sandbox_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_defaults
    ADD CONSTRAINT sandbox_defaults_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_resource_rollout sandbox_resource_rollout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resource_rollout
    ADD CONSTRAINT sandbox_resource_rollout_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_resources sandbox_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_resources
    ADD CONSTRAINT sandbox_resources_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sandbox_routing sandbox_routing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sandbox_routing
    ADD CONSTRAINT sandbox_routing_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: secret_drops secret_drops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_drops
    ADD CONSTRAINT secret_drops_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: security_postures security_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_postures
    ADD CONSTRAINT security_postures_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_goals session_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_pkey PRIMARY KEY (tenant_id, session_id);


--
-- Name: session_leases session_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_leases
    ADD CONSTRAINT session_leases_pkey PRIMARY KEY (tenant_id, session_id);


--
-- Name: session_llm_requests session_llm_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_llm_requests
    ADD CONSTRAINT session_llm_requests_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_mailbox session_mailbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_mailbox
    ADD CONSTRAINT session_mailbox_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_pins session_pins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_pins
    ADD CONSTRAINT session_pins_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_shares session_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_shares
    ADD CONSTRAINT session_shares_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: session_spend_days session_spend_days_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_days
    ADD CONSTRAINT session_spend_days_pkey PRIMARY KEY (tenant_id, day);


--
-- Name: session_spend_dirty session_spend_dirty_day_writer_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_spend_dirty
    ADD CONSTRAINT session_spend_dirty_day_writer_key UNIQUE (tenant_id, day, writer);


--
-- Name: session_turn_pointers session_turn_pointers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_pointers
    ADD CONSTRAINT session_turn_pointers_pkey PRIMARY KEY (tenant_id, thread_ref);


--
-- Name: sessions sessions_fork_provenance_pair; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.sessions
    ADD CONSTRAINT sessions_fork_provenance_pair CHECK (((forked_from_session_id IS NULL) = (fork_boundary_seq IS NULL))) NOT VALID;


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: sessions sessions_thread_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_thread_ref_key UNIQUE (tenant_id, thread_ref);


--
-- Name: sharing_postures sharing_postures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sharing_postures
    ADD CONSTRAINT sharing_postures_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skill_bundles skill_bundles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_bundles
    ADD CONSTRAINT skill_bundles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skill_packs skill_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_packs
    ADD CONSTRAINT skill_packs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_accounts slack_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_accounts
    ADD CONSTRAINT slack_accounts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_emoji_catalog slack_emoji_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_emoji_catalog
    ADD CONSTRAINT slack_emoji_catalog_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_handled_events slack_handled_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_handled_events
    ADD CONSTRAINT slack_handled_events_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_installation slack_installation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_installation
    ADD CONSTRAINT slack_installation_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_session_status slack_session_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_session_status
    ADD CONSTRAINT slack_session_status_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_staged_envelopes slack_staged_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_staged_envelopes
    ADD CONSTRAINT slack_staged_envelopes_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: slack_task_acknowledgements slack_task_acknowledgements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slack_task_acknowledgements
    ADD CONSTRAINT slack_task_acknowledgements_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: soul_configs soul_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_configs
    ADD CONSTRAINT soul_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: soul_history soul_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soul_history
    ADD CONSTRAINT soul_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: source_auth_replay source_auth_replay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_auth_replay
    ADD CONSTRAINT source_auth_replay_pkey PRIMARY KEY (tenant_id, event_id);


--
-- Name: sprites_initialization sprites_initialization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprites_initialization
    ADD CONSTRAINT sprites_initialization_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: suggested_activity_profiles suggested_activity_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggested_activity_profiles
    ADD CONSTRAINT suggested_activity_profiles_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: superserve_config_epochs superserve_config_epochs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_config_epochs
    ADD CONSTRAINT superserve_config_epochs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: superserve_sandbox_bodies superserve_sandbox_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superserve_sandbox_bodies
    ADD CONSTRAINT superserve_sandbox_bodies_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: swarm_board_channels swarm_board_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swarm_board_channels
    ADD CONSTRAINT swarm_board_channels_pkey PRIMARY KEY (tenant_id, swarm_id, name);


--
-- Name: swarm_board_posts swarm_board_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swarm_board_posts
    ADD CONSTRAINT swarm_board_posts_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: swarm_board_subscriptions swarm_board_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swarm_board_subscriptions
    ADD CONSTRAINT swarm_board_subscriptions_pkey PRIMARY KEY (tenant_id, swarm_id, member_id, channel);


--
-- Name: swarm_boards swarm_boards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swarm_boards
    ADD CONSTRAINT swarm_boards_pkey PRIMARY KEY (tenant_id, swarm_id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (tenant_id, team_id, principal_id);


--
-- Name: team_rooms team_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_pkey PRIMARY KEY (tenant_id, team_id, scope_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (tenant_id, team_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: tool_calls tool_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_calls
    ADD CONSTRAINT tool_calls_pkey PRIMARY KEY (tenant_id, run_id, attempt, call_index);


--
-- Name: unfulfilled_insights_flag unfulfilled_insights_flag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unfulfilled_insights_flag
    ADD CONSTRAINT unfulfilled_insights_flag_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: web_ui_state web_ui_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_ui_state
    ADD CONSTRAINT web_ui_state_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webhook_history webhook_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_history
    ADD CONSTRAINT webhook_history_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: webui_model_configs webui_model_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webui_model_configs
    ADD CONSTRAINT webui_model_configs_pkey PRIMARY KEY (tenant_id, id);


--
-- Name: e_jobs_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_jobs_eai ON absurd.e_jobs USING btree (emitted_at);


--
-- Name: e_jobs_t111111110000_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_jobs_t111111110000_eai ON absurd.e_jobs_t111111110000 USING btree (emitted_at);


--
-- Name: e_turns_background_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_background_eai ON absurd.e_turns_background USING btree (emitted_at);


--
-- Name: e_turns_background_t111111110000_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_background_t111111110000_eai ON absurd.e_turns_background_t111111110000 USING btree (emitted_at);


--
-- Name: e_turns_delegated_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_delegated_eai ON absurd.e_turns_delegated USING btree (emitted_at);


--
-- Name: e_turns_delegated_t111111110000_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_delegated_t111111110000_eai ON absurd.e_turns_delegated_t111111110000 USING btree (emitted_at);


--
-- Name: e_turns_people_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_people_eai ON absurd.e_turns_people USING btree (emitted_at);


--
-- Name: e_turns_people_t111111110000_eai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX e_turns_people_t111111110000_eai ON absurd.e_turns_people_t111111110000 USING btree (emitted_at);


--
-- Name: r_jobs_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_jobs_cei ON absurd.r_jobs USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_jobs_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_jobs_sai ON absurd.r_jobs USING btree (state, available_at);


--
-- Name: r_jobs_t111111110000_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_jobs_t111111110000_cei ON absurd.r_jobs_t111111110000 USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_jobs_t111111110000_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_jobs_t111111110000_sai ON absurd.r_jobs_t111111110000 USING btree (state, available_at);


--
-- Name: r_jobs_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_jobs_t111111110000_ti ON absurd.r_jobs_t111111110000 USING btree (task_id);


--
-- Name: r_jobs_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_jobs_ti ON absurd.r_jobs USING btree (task_id);


--
-- Name: r_turns_background_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_cei ON absurd.r_turns_background USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_background_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_sai ON absurd.r_turns_background USING btree (state, available_at);


--
-- Name: r_turns_background_t111111110000_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_t111111110000_cei ON absurd.r_turns_background_t111111110000 USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_background_t111111110000_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_t111111110000_sai ON absurd.r_turns_background_t111111110000 USING btree (state, available_at);


--
-- Name: r_turns_background_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_t111111110000_ti ON absurd.r_turns_background_t111111110000 USING btree (task_id);


--
-- Name: r_turns_background_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_background_ti ON absurd.r_turns_background USING btree (task_id);


--
-- Name: r_turns_delegated_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_cei ON absurd.r_turns_delegated USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_delegated_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_sai ON absurd.r_turns_delegated USING btree (state, available_at);


--
-- Name: r_turns_delegated_t111111110000_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_t111111110000_cei ON absurd.r_turns_delegated_t111111110000 USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_delegated_t111111110000_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_t111111110000_sai ON absurd.r_turns_delegated_t111111110000 USING btree (state, available_at);


--
-- Name: r_turns_delegated_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_t111111110000_ti ON absurd.r_turns_delegated_t111111110000 USING btree (task_id);


--
-- Name: r_turns_delegated_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_delegated_ti ON absurd.r_turns_delegated USING btree (task_id);


--
-- Name: r_turns_people_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_cei ON absurd.r_turns_people USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_people_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_sai ON absurd.r_turns_people USING btree (state, available_at);


--
-- Name: r_turns_people_t111111110000_cei; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_t111111110000_cei ON absurd.r_turns_people_t111111110000 USING btree (claim_expires_at) WHERE ((state = 'running'::text) AND (claim_expires_at IS NOT NULL));


--
-- Name: r_turns_people_t111111110000_sai; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_t111111110000_sai ON absurd.r_turns_people_t111111110000 USING btree (state, available_at);


--
-- Name: r_turns_people_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_t111111110000_ti ON absurd.r_turns_people_t111111110000 USING btree (task_id);


--
-- Name: r_turns_people_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX r_turns_people_ti ON absurd.r_turns_people USING btree (task_id);


--
-- Name: t_jobs_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_jobs_ci ON absurd.t_jobs USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_jobs_t111111110000_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_jobs_t111111110000_ci ON absurd.t_jobs_t111111110000 USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_background_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_background_ci ON absurd.t_turns_background USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_background_t111111110000_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_background_t111111110000_ci ON absurd.t_turns_background_t111111110000 USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_delegated_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_delegated_ci ON absurd.t_turns_delegated USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_delegated_t111111110000_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_delegated_t111111110000_ci ON absurd.t_turns_delegated_t111111110000 USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_people_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_people_ci ON absurd.t_turns_people USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: t_turns_people_t111111110000_ci; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX t_turns_people_t111111110000_ci ON absurd.t_turns_people_t111111110000 USING btree (task_id) WHERE (cancellation IS NOT NULL);


--
-- Name: w_jobs_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_jobs_eni ON absurd.w_jobs USING btree (event_name);


--
-- Name: w_jobs_t111111110000_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_jobs_t111111110000_eni ON absurd.w_jobs_t111111110000 USING btree (event_name);


--
-- Name: w_jobs_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_jobs_t111111110000_ti ON absurd.w_jobs_t111111110000 USING btree (task_id);


--
-- Name: w_jobs_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_jobs_ti ON absurd.w_jobs USING btree (task_id);


--
-- Name: w_turns_background_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_background_eni ON absurd.w_turns_background USING btree (event_name);


--
-- Name: w_turns_background_t111111110000_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_background_t111111110000_eni ON absurd.w_turns_background_t111111110000 USING btree (event_name);


--
-- Name: w_turns_background_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_background_t111111110000_ti ON absurd.w_turns_background_t111111110000 USING btree (task_id);


--
-- Name: w_turns_background_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_background_ti ON absurd.w_turns_background USING btree (task_id);


--
-- Name: w_turns_delegated_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_delegated_eni ON absurd.w_turns_delegated USING btree (event_name);


--
-- Name: w_turns_delegated_t111111110000_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_delegated_t111111110000_eni ON absurd.w_turns_delegated_t111111110000 USING btree (event_name);


--
-- Name: w_turns_delegated_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_delegated_t111111110000_ti ON absurd.w_turns_delegated_t111111110000 USING btree (task_id);


--
-- Name: w_turns_delegated_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_delegated_ti ON absurd.w_turns_delegated USING btree (task_id);


--
-- Name: w_turns_people_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_people_eni ON absurd.w_turns_people USING btree (event_name);


--
-- Name: w_turns_people_t111111110000_eni; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_people_t111111110000_eni ON absurd.w_turns_people_t111111110000 USING btree (event_name);


--
-- Name: w_turns_people_t111111110000_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_people_t111111110000_ti ON absurd.w_turns_people_t111111110000 USING btree (task_id);


--
-- Name: w_turns_people_ti; Type: INDEX; Schema: absurd; Owner: -
--

CREATE INDEX w_turns_people_ti ON absurd.w_turns_people USING btree (task_id);


--
-- Name: ack_emoji_picks_org_channel_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_channel_created ON public.ack_emoji_picks USING btree (org_id, channel, created_at DESC);


--
-- Name: ack_emoji_picks_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_created ON public.ack_emoji_picks USING btree (org_id, created_at DESC, id DESC);


--
-- Name: ack_emoji_picks_org_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ack_emoji_picks_org_outcome ON public.ack_emoji_picks USING btree (org_id, outcome);


--
-- Name: ack_emoji_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ack_emoji_scope_id_key ON public.ack_emoji USING btree (tenant_id, scope_id);


--
-- Name: ambient_judgments_org_container_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_container_created ON public.ambient_judgments USING btree (org_id, container, created_at DESC);


--
-- Name: ambient_judgments_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_created ON public.ambient_judgments USING btree (org_id, created_at DESC, id DESC);


--
-- Name: ambient_judgments_org_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ambient_judgments_org_decision ON public.ambient_judgments USING btree (org_id, decision);


--
-- Name: approval_grant_modes_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX approval_grant_modes_scope_id_key ON public.approval_grant_modes USING btree (tenant_id, scope_id);


--
-- Name: approval_grants_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_grants_actor ON public.approval_grants USING btree (lower(btrim(actor_id)));


--
-- Name: approvals_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_session ON public.approvals USING btree (session_id);


--
-- Name: audit_log_by_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_action ON public.audit_log USING btree (action, at DESC);


--
-- Name: audit_log_by_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_at ON public.audit_log USING btree (at DESC);


--
-- Name: audit_log_by_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX audit_log_by_idempotency_key ON public.audit_log USING btree (tenant_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: audit_log_by_scope_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_by_scope_at ON public.audit_log USING btree (scope_label, at DESC);


--
-- Name: auth_broker_sessions_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_email ON public.auth_broker_sessions USING btree (email);


--
-- Name: auth_broker_sessions_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_broker_sessions_expiry ON public.auth_broker_sessions USING btree (expires_at);


--
-- Name: auto_flagger_configs_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX auto_flagger_configs_scope_id_key ON public.auto_flagger_configs USING btree (tenant_id, scope_id);


--
-- Name: base_model_configs_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX base_model_configs_scope_id_key ON public.base_model_configs USING btree (tenant_id, scope_id);


--
-- Name: branding_configs_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX branding_configs_scope_id_key ON public.branding_configs USING btree (tenant_id, scope_id);


--
-- Name: browse_max_steps_configs_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX browse_max_steps_configs_scope_id_key ON public.browse_max_steps_configs USING btree (tenant_id, scope_id);


--
-- Name: browse_model_configs_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX browse_model_configs_scope_id_key ON public.browse_model_configs USING btree (tenant_id, scope_id);


--
-- Name: browser_sessions_principal_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX browser_sessions_principal_id_key ON public.browser_sessions USING btree (tenant_id, principal_id);


--
-- Name: channel_header_pin_flag_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX channel_header_pin_flag_scope_id_key ON public.channel_header_pin_flag USING btree (tenant_id, scope_id);


--
-- Name: channel_messages_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_by_container ON public.channel_messages USING btree (org_id, container, ts);


--
-- Name: channel_messages_by_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_by_sub ON public.channel_messages USING btree (org_id, container, sub, ts);


--
-- Name: channel_messages_deleted_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_deleted_by_container ON public.channel_messages USING btree (org_id, container, deleted_at) WHERE (deleted_at > 0);


--
-- Name: channel_messages_edited_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_edited_by_container ON public.channel_messages USING btree (org_id, container, edited_at) WHERE (edited_at > 0);


--
-- Name: channel_messages_live_by_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_live_by_container ON public.channel_messages USING btree (org_id, container) WHERE (deleted = false);


--
-- Name: channel_messages_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_messages_tsv ON public.channel_messages USING gin (tsv);


--
-- Name: channel_policy_history_container; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_policy_history_container ON public.channel_policy_history USING btree (org_id, container, id DESC);


--
-- Name: command_policies_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX command_policies_scope_id_key ON public.command_policies USING btree (tenant_id, scope_id);


--
-- Name: connector_clients_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX connector_clients_scope_id ON public.connector_clients USING btree (scope_id);


--
-- Name: connector_status_principal_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX connector_status_principal_id_key ON public.connector_status USING btree (tenant_id, principal_id);


--
-- Name: credential_usage_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_scope_ts ON public.credential_usage USING btree (scope_label, ts DESC);


--
-- Name: credential_usage_by_slug_ts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_slug_ts_id ON public.credential_usage USING btree (slug, ts DESC, id DESC);


--
-- Name: credential_usage_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX credential_usage_by_ts ON public.credential_usage USING btree (ts DESC);


--
-- Name: cron_items_conversation_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cron_items_conversation_key ON public.cron_items USING btree (conversation_key);


--
-- Name: cron_items_cron_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cron_items_cron_id ON public.cron_items USING btree (cron_id);


--
-- Name: crons_owner_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_owner_scope_id ON public.crons USING btree (owner_scope_id);


--
-- Name: crons_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crons_resource_search_gin ON public.crons USING gin (to_tsvector('simple'::regconfig, ((((COALESCE(title, ''::text) || ' '::text) || COALESCE(action, ''::text)) || ' '::text) || COALESCE(message, ''::text))));


--
-- Name: decision_rules_hook; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX decision_rules_hook ON public.decision_rules USING btree (hook) WHERE (mode <> 'off'::text);


--
-- Name: deploy_git_repos_deployment_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX deploy_git_repos_deployment_id_key ON public.deploy_git_repos USING btree (tenant_id, deployment_id);


--
-- Name: deployments_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX deployments_name_unique ON public.deployments USING btree (tenant_id, name) WHERE (name IS NOT NULL);


--
-- Name: deployments_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deployments_resource_search_gin ON public.deployments USING gin (to_tsvector('simple'::regconfig, ((COALESCE(display_name, name, ''::text) || ' '::text) || COALESCE(name, ''::text))));


--
-- Name: directory_channels_lower_cid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_lower_cid ON public.directory_channels USING btree (org_id, lower(channel_id));


--
-- Name: directory_channels_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_channels_name ON public.directory_channels USING btree (org_id, name_lc);


--
-- Name: directory_group_members_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_group_members_principal ON public.directory_group_members USING btree (org_id, principal_id, group_id);


--
-- Name: directory_members_lower_pid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_lower_pid ON public.directory_members USING btree (org_id, lower(principal_id));


--
-- Name: directory_members_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX directory_members_name ON public.directory_members USING btree (org_id, display_name_lc);


--
-- Name: e2b_sandbox_bodies_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX e2b_sandbox_bodies_scope_id_key ON public.e2b_sandbox_bodies USING btree (tenant_id, scope_id);


--
-- Name: egress_events_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_by_scope_ts ON public.egress_events USING btree (scope_label, ts DESC);


--
-- Name: egress_events_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX egress_events_by_ts ON public.egress_events USING btree (ts DESC);


--
-- Name: egress_policies_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX egress_policies_scope_id_key ON public.egress_policies USING btree (tenant_id, scope_id);


--
-- Name: environment_attachments_by_env; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_attachments_by_env ON public.environment_attachments USING btree (environment_id);


--
-- Name: error_events_by_scope_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_scope_ts ON public.error_events USING btree (scope_label, ts DESC);


--
-- Name: error_events_by_session_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_session_ts ON public.error_events USING btree (session_id, ts DESC);


--
-- Name: error_events_by_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX error_events_by_ts ON public.error_events USING btree (ts DESC);


--
-- Name: external_slack_participants_flag_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX external_slack_participants_flag_scope_id_key ON public.external_slack_participants_flag USING btree (tenant_id, scope_id);


--
-- Name: feature_flags_feature_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX feature_flags_feature_name_key ON public.feature_flags USING btree (tenant_id, feature_name);


--
-- Name: file_artifacts_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_document ON public.file_artifacts USING btree (COALESCE(created_in_scope, owner_scope_id), sha256) WHERE (sha256 IS NOT NULL);


--
-- Name: file_artifacts_owner_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_owner_created ON public.file_artifacts USING btree (owner_scope_id, created_at DESC, id DESC);


--
-- Name: file_artifacts_owner_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_owner_path ON public.file_artifacts USING btree (owner_scope_id, path);


--
-- Name: file_artifacts_scope_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_artifacts_scope_created ON public.file_artifacts USING btree (created_in_scope, created_at DESC, id DESC) WHERE (enabled = true);


--
-- Name: idempotency_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idempotency_at ON public.idempotency USING btree (at);


--
-- Name: idempotency_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idempotency_key_key ON public.idempotency USING btree (tenant_id, key);


--
-- Name: idx_cron_fires_cron_fired_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cron_fires_cron_fired_at ON public.cron_fires USING btree (cron_id, fired_at DESC);


--
-- Name: idx_cron_fires_thread_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cron_fires_thread_ref ON public.cron_fires USING btree (thread_ref);


--
-- Name: idx_proc_scope_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proc_scope_status ON public.process_sessions USING btree (scope_id, status);


--
-- Name: idx_run_activity_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_activity_created ON public.run_activity USING btree (created_at);


--
-- Name: idx_run_activity_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_activity_run ON public.run_activity USING btree (run_id, id);


--
-- Name: idx_run_signals_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_run_signals_pending ON public.run_signals USING btree (run_id) WHERE (consumed_at IS NULL);


--
-- Name: idx_runs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_created ON public.runs USING btree (created_at DESC);


--
-- Name: idx_runs_fair_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_fair_key ON public.runs USING btree (fair_key, status) WHERE ((fair_key IS NOT NULL) AND (status = ANY (ARRAY['queued'::text, 'pending'::text, 'running'::text])));


--
-- Name: idx_runs_one_running_per_session; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_runs_one_running_per_session ON public.runs USING btree (tenant_id, session_id) WHERE (status = 'running'::text);


--
-- Name: idx_runs_pending_child_returns; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_pending_child_returns ON public.runs USING btree (id) WHERE ((status = ANY (ARRAY['done'::text, 'failed'::text])) AND (returned_at IS NULL) AND (session_id ~~ 'agent:main:subagent:%'::text));


--
-- Name: idx_runs_pending_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_pending_priority ON public.runs USING btree (claim_priority, created_at, seq) WHERE (status = 'pending'::text);


--
-- Name: idx_runs_session_active_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_active_created ON public.runs USING btree (session_id, created_at DESC) WHERE (status = ANY (ARRAY['pending'::text, 'running'::text]));


--
-- Name: idx_runs_session_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_created_seq ON public.runs USING btree (session_id, created_at DESC, seq DESC);


--
-- Name: idx_runs_session_in_flight; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_in_flight ON public.runs USING btree (session_id, created_at, seq) WHERE (status = ANY (ARRAY['queued'::text, 'pending'::text, 'running'::text]));


--
-- Name: idx_runs_session_queued; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_session_queued ON public.runs USING btree (session_id, claim_priority, created_at, seq) WHERE (status = 'queued'::text);


--
-- Name: idx_runs_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created ON public.runs USING btree (status, created_at);


--
-- Name: idx_runs_status_created_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_status_created_seq ON public.runs USING btree (status, created_at, seq);


--
-- Name: idx_runs_terminal_finished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_runs_terminal_finished ON public.runs USING btree (finished_at, id) WHERE (status = ANY (ARRAY['done'::text, 'failed'::text]));


--
-- Name: idx_sessions_parent_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_parent_session_id ON public.sessions USING btree (parent_session_id) WHERE (parent_session_id IS NOT NULL);


--
-- Name: idx_swarm_board_posts_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_swarm_board_posts_channel ON public.swarm_board_posts USING btree (swarm_id, channel, created_at);


--
-- Name: idx_swarm_board_posts_notify; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_swarm_board_posts_notify ON public.swarm_board_posts USING btree (swarm_id, created_at) WHERE notify_pending;


--
-- Name: idx_swarm_board_posts_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_swarm_board_posts_thread ON public.swarm_board_posts USING btree (swarm_id, thread_id, created_at);


--
-- Name: individual_model_auth_flag_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX individual_model_auth_flag_scope_id_key ON public.individual_model_auth_flag USING btree (tenant_id, scope_id);


--
-- Name: interactive_fast_mode_flag_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX interactive_fast_mode_flag_scope_id_key ON public.interactive_fast_mode_flag USING btree (tenant_id, scope_id);


--
-- Name: items_by_elicit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_elicit ON public.items USING btree (tenant_id, session_id, elicit_id) WHERE (elicit_id IS NOT NULL);


--
-- Name: items_by_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_external_id ON public.items USING btree (tenant_id, session_id, external_id) WHERE (external_id IS NOT NULL);


--
-- Name: items_by_turn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_by_turn ON public.items USING btree (tenant_id, turn_id, seq) WHERE (turn_id IS NOT NULL);


--
-- Name: items_one_call_per_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX items_one_call_per_kind ON public.items USING btree (tenant_id, session_id, kind, md5(call_id)) WHERE (call_id IS NOT NULL);


--
-- Name: items_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_search ON public.items USING gin (tenant_id, session_id, search);


--
-- Name: items_session_kind_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX items_session_kind_created ON public.items USING btree (tenant_id, session_id, kind, created_at);


--
-- Name: keychain_credentials_owner_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_credentials_owner_fold ON public.keychain_credentials USING btree (lower(owner_id));


--
-- Name: keychain_grants_audience; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_audience ON public.keychain_grants USING btree (audience_scope_id);


--
-- Name: keychain_grants_credential; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_credential ON public.keychain_grants USING btree (credential_id);


--
-- Name: keychain_grants_owner_fold; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX keychain_grants_owner_fold ON public.keychain_grants USING btree (lower(owner_id));


--
-- Name: llm_prompt_envelopes_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX llm_prompt_envelopes_created_at ON public.llm_prompt_envelopes USING btree (created_at);


--
-- Name: memory_facts_live; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX memory_facts_live ON public.memory_facts USING btree (scope_id, id) WHERE (deleted_at IS NULL);


--
-- Name: modal_sandbox_bodies_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX modal_sandbox_bodies_scope_id_key ON public.modal_sandbox_bodies USING btree (tenant_id, scope_id);


--
-- Name: model_credentials_provider_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX model_credentials_provider_key ON public.model_credentials USING btree (tenant_id, provider);


--
-- Name: monitors_owner_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX monitors_owner_scope_id ON public.monitors USING btree (owner_scope_id);


--
-- Name: oauth_flows_nonce_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX oauth_flows_nonce_key ON public.oauth_flows USING btree (tenant_id, nonce);


--
-- Name: org_ambient_flag_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX org_ambient_flag_scope_id_key ON public.org_ambient_flag USING btree (tenant_id, scope_id);


--
-- Name: participants_by_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX participants_by_principal ON public.participants USING btree (principal_id, session_id);


--
-- Name: projects_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_org ON public.projects USING btree (org_id);


--
-- Name: qm_tenant_singleton; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX qm_tenant_singleton ON public.qm_tenant USING btree ((true));


--
-- Name: run_signals_by_dedupe_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX run_signals_by_dedupe_key ON public.run_signals USING btree (tenant_id, dedupe_key) WHERE (dedupe_key IS NOT NULL);


--
-- Name: sandbox_defaults_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sandbox_defaults_scope_id_key ON public.sandbox_defaults USING btree (tenant_id, scope_id);


--
-- Name: session_llm_requests_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_by_session ON public.session_llm_requests USING btree (session_id, created_at, step);


--
-- Name: session_llm_requests_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_created_at ON public.session_llm_requests USING btree (created_at);


--
-- Name: session_llm_requests_screens; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_screens ON public.session_llm_requests USING btree (created_at DESC) WHERE (step = '-1'::integer);


--
-- Name: session_llm_requests_spend_unparsed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_llm_requests_spend_unparsed ON public.session_llm_requests USING btree (id) WHERE ((usage_json IS NOT NULL) AND (spend_cost_usd IS NULL));


--
-- Name: session_mailbox_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_mailbox_recipient ON public.session_mailbox USING btree (recipient_id);


--
-- Name: session_pins_by_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_pins_by_session ON public.session_pins USING btree (session_id, created_at);


--
-- Name: session_shares_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX session_shares_token_key ON public.session_shares USING btree (tenant_id, token);


--
-- Name: session_turn_pointers_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_turn_pointers_active ON public.session_turn_pointers USING btree (tenant_id, updated_at) WHERE (active_turn_id IS NOT NULL);


--
-- Name: sessions_by_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_activity ON public.sessions USING btree (COALESCE(last_activity, created_at) DESC, id DESC);


--
-- Name: sessions_by_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_scope ON public.sessions USING btree (scope_id, created_at DESC);


--
-- Name: sessions_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC);


--
-- Name: sessions_conversations_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_conversations_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC) WHERE (origin = 'conversation'::text);


--
-- Name: sessions_other_background_by_scope_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_other_background_by_scope_activity ON public.sessions USING btree (scope_id, COALESCE(last_activity, created_at) DESC, id DESC) WHERE (origin <> ALL (ARRAY['conversation'::text, 'cron'::text]));


--
-- Name: skill_bundles_pack_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX skill_bundles_pack_id_key ON public.skill_bundles USING btree (tenant_id, pack_id);


--
-- Name: skills_resource_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_resource_name_idx ON public.skills USING btree (((manifest ->> 'name'::text)));


--
-- Name: skills_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_resource_search_gin ON public.skills USING gin (to_tsvector('simple'::regconfig, ((COALESCE((manifest ->> 'name'::text), ''::text) || ' '::text) || COALESCE((manifest ->> 'description'::text), ''::text))));


--
-- Name: skills_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skills_scope_id ON public.skills USING btree (scope_id);


--
-- Name: slack_accounts_principal_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX slack_accounts_principal_id_key ON public.slack_accounts USING btree (tenant_id, principal_id);


--
-- Name: slack_emoji_catalog_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX slack_emoji_catalog_scope_id_key ON public.slack_emoji_catalog USING btree (tenant_id, scope_id);


--
-- Name: slack_handled_events_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX slack_handled_events_at ON public.slack_handled_events USING btree (at);


--
-- Name: slack_installation_org_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX slack_installation_org_id_key ON public.slack_installation USING btree (tenant_id, org_id);


--
-- Name: soul_configs_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX soul_configs_scope_id_key ON public.soul_configs USING btree (tenant_id, scope_id);


--
-- Name: source_auth_replay_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_auth_replay_expires_at ON public.source_auth_replay USING btree (expires_at);


--
-- Name: sprites_initialization_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sprites_initialization_scope_id_key ON public.sprites_initialization USING btree (tenant_id, scope_id);


--
-- Name: team_members_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_members_principal ON public.team_members USING btree (principal_id);


--
-- Name: team_rooms_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_rooms_scope ON public.team_rooms USING btree (scope_id);


--
-- Name: unfulfilled_insights_flag_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unfulfilled_insights_flag_scope_id_key ON public.unfulfilled_insights_flag USING btree (tenant_id, scope_id);


--
-- Name: webhooks_owner_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_owner_scope_id ON public.webhooks USING btree (owner_scope_id);


--
-- Name: webhooks_resource_search_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_resource_search_gin ON public.webhooks USING gin (to_tsvector('simple'::regconfig, ((COALESCE(action, ''::text) || ' '::text) || COALESCE((verification ->> 'scheme'::text), ''::text))));


--
-- Name: webui_model_configs_scope_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX webui_model_configs_scope_id_key ON public.webui_model_configs USING btree (tenant_id, scope_id);


--
-- Name: ack_emoji ack_emoji_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ack_emoji_bump AFTER INSERT OR DELETE OR UPDATE ON public.ack_emoji FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('ack_emoji');


--
-- Name: ack_emoji ack_emoji_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ack_emoji_sync BEFORE INSERT OR UPDATE ON public.ack_emoji FOR EACH ROW EXECUTE FUNCTION public.ack_emoji_sync();


--
-- Name: acl_grants acl_grants_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER acl_grants_bump AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.acl_grants FOR EACH STATEMENT EXECUTE FUNCTION public.acl_grants_bump_version();


--
-- Name: ambient_cursors ambient_cursors_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ambient_cursors_bump AFTER INSERT OR DELETE OR UPDATE ON public.ambient_cursors FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('ambient_cursors');


--
-- Name: ambient_cursors ambient_cursors_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ambient_cursors_sync BEFORE INSERT OR UPDATE ON public.ambient_cursors FOR EACH ROW EXECUTE FUNCTION public.ambient_cursors_sync();


--
-- Name: approval_grant_modes approval_grant_modes_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER approval_grant_modes_bump AFTER INSERT OR DELETE OR UPDATE ON public.approval_grant_modes FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('approval_grant_modes');


--
-- Name: approval_grant_modes approval_grant_modes_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER approval_grant_modes_sync BEFORE INSERT OR UPDATE ON public.approval_grant_modes FOR EACH ROW EXECUTE FUNCTION public.approval_grant_modes_sync();


--
-- Name: approval_grants approval_grants_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER approval_grants_bump AFTER INSERT OR DELETE OR UPDATE ON public.approval_grants FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('approval_grants');


--
-- Name: approval_grants approval_grants_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER approval_grants_sync BEFORE INSERT OR UPDATE ON public.approval_grants FOR EACH ROW EXECUTE FUNCTION public.approval_grants_sync();


--
-- Name: approvals approvals_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER approvals_bump AFTER INSERT OR DELETE OR UPDATE ON public.approvals FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('approvals');


--
-- Name: approvals approvals_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER approvals_sync BEFORE INSERT OR UPDATE ON public.approvals FOR EACH ROW EXECUTE FUNCTION public.approvals_sync();


--
-- Name: auto_flagger_configs auto_flagger_configs_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER auto_flagger_configs_bump AFTER INSERT OR DELETE OR UPDATE ON public.auto_flagger_configs FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('auto_flagger_configs');


--
-- Name: auto_flagger_configs auto_flagger_configs_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER auto_flagger_configs_sync BEFORE INSERT OR UPDATE ON public.auto_flagger_configs FOR EACH ROW EXECUTE FUNCTION public.auto_flagger_configs_sync();


--
-- Name: base_model_configs base_model_configs_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER base_model_configs_bump AFTER INSERT OR DELETE OR UPDATE ON public.base_model_configs FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('base_model_configs');


--
-- Name: base_model_configs base_model_configs_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER base_model_configs_sync BEFORE INSERT OR UPDATE ON public.base_model_configs FOR EACH ROW EXECUTE FUNCTION public.base_model_configs_sync();


--
-- Name: blobs blobs_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER blobs_immutable BEFORE DELETE OR UPDATE ON public.blobs FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: blobs blobs_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER blobs_no_truncate BEFORE TRUNCATE ON public.blobs FOR EACH STATEMENT EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: branding_configs branding_configs_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER branding_configs_bump AFTER INSERT OR DELETE OR UPDATE ON public.branding_configs FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('branding_configs');


--
-- Name: branding_configs branding_configs_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER branding_configs_sync BEFORE INSERT OR UPDATE ON public.branding_configs FOR EACH ROW EXECUTE FUNCTION public.branding_configs_sync();


--
-- Name: browse_max_steps_configs browse_max_steps_configs_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER browse_max_steps_configs_bump AFTER INSERT OR DELETE OR UPDATE ON public.browse_max_steps_configs FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('browse_max_steps_configs');


--
-- Name: browse_max_steps_configs browse_max_steps_configs_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER browse_max_steps_configs_sync BEFORE INSERT OR UPDATE ON public.browse_max_steps_configs FOR EACH ROW EXECUTE FUNCTION public.browse_max_steps_configs_sync();


--
-- Name: browse_model_configs browse_model_configs_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER browse_model_configs_bump AFTER INSERT OR DELETE OR UPDATE ON public.browse_model_configs FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('browse_model_configs');


--
-- Name: browse_model_configs browse_model_configs_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER browse_model_configs_sync BEFORE INSERT OR UPDATE ON public.browse_model_configs FOR EACH ROW EXECUTE FUNCTION public.browse_model_configs_sync();


--
-- Name: browser_sessions browser_sessions_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER browser_sessions_bump AFTER INSERT OR DELETE OR UPDATE ON public.browser_sessions FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('browser_sessions');


--
-- Name: browser_sessions browser_sessions_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER browser_sessions_sync BEFORE INSERT OR UPDATE ON public.browser_sessions FOR EACH ROW EXECUTE FUNCTION public.browser_sessions_sync();


--
-- Name: channel_header_pin_flag channel_header_pin_flag_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER channel_header_pin_flag_bump AFTER INSERT OR DELETE OR UPDATE ON public.channel_header_pin_flag FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('channel_header_pin_flag');


--
-- Name: channel_header_pin_flag channel_header_pin_flag_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER channel_header_pin_flag_sync BEFORE INSERT OR UPDATE ON public.channel_header_pin_flag FOR EACH ROW EXECUTE FUNCTION public.channel_header_pin_flag_sync();


--
-- Name: command_policies command_policies_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER command_policies_bump AFTER INSERT OR DELETE OR UPDATE ON public.command_policies FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('command_policies');


--
-- Name: command_policies command_policies_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER command_policies_sync BEFORE INSERT OR UPDATE ON public.command_policies FOR EACH ROW EXECUTE FUNCTION public.command_policies_sync();


--
-- Name: composio_returns composio_returns_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER composio_returns_bump AFTER INSERT OR DELETE OR UPDATE ON public.composio_returns FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('composio_returns');


--
-- Name: composio_returns composio_returns_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER composio_returns_sync BEFORE INSERT OR UPDATE ON public.composio_returns FOR EACH ROW EXECUTE FUNCTION public.composio_returns_sync();


--
-- Name: connector_clients connector_clients_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER connector_clients_bump AFTER INSERT OR DELETE OR UPDATE ON public.connector_clients FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('connector_clients');


--
-- Name: connector_clients connector_clients_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER connector_clients_sync BEFORE INSERT OR UPDATE ON public.connector_clients FOR EACH ROW EXECUTE FUNCTION public.connector_clients_sync();


--
-- Name: connector_status connector_status_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER connector_status_bump AFTER INSERT OR DELETE OR UPDATE ON public.connector_status FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('connector_status');


--
-- Name: connector_status connector_status_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER connector_status_sync BEFORE INSERT OR UPDATE ON public.connector_status FOR EACH ROW EXECUTE FUNCTION public.connector_status_sync();


--
-- Name: consent_links consent_links_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER consent_links_bump AFTER INSERT OR DELETE OR UPDATE ON public.consent_links FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('consent_links');


--
-- Name: consent_links consent_links_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER consent_links_sync BEFORE INSERT OR UPDATE ON public.consent_links FOR EACH ROW EXECUTE FUNCTION public.consent_links_sync();


--
-- Name: context_requests context_requests_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER context_requests_bump AFTER INSERT OR DELETE OR UPDATE ON public.context_requests FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('context_requests');


--
-- Name: context_requests context_requests_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER context_requests_sync BEFORE INSERT OR UPDATE ON public.context_requests FOR EACH ROW EXECUTE FUNCTION public.context_requests_sync();


--
-- Name: cron_items cron_items_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cron_items_bump AFTER INSERT OR DELETE OR UPDATE ON public.cron_items FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('cron_items');


--
-- Name: cron_items cron_items_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cron_items_sync BEFORE INSERT OR UPDATE ON public.cron_items FOR EACH ROW EXECUTE FUNCTION public.cron_items_sync();


--
-- Name: crons crons_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER crons_bump AFTER INSERT OR DELETE OR UPDATE ON public.crons FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('crons');


--
-- Name: crons crons_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER crons_sync BEFORE INSERT OR UPDATE ON public.crons FOR EACH ROW EXECUTE FUNCTION public.crons_sync();


--
-- Name: custom_model_providers custom_model_providers_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER custom_model_providers_bump AFTER INSERT OR DELETE OR UPDATE ON public.custom_model_providers FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('custom_model_providers');


--
-- Name: custom_model_providers custom_model_providers_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER custom_model_providers_sync BEFORE INSERT OR UPDATE ON public.custom_model_providers FOR EACH ROW EXECUTE FUNCTION public.custom_model_providers_sync();


--
-- Name: deactivated_principals deactivated_principals_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deactivated_principals_bump AFTER INSERT OR DELETE OR UPDATE ON public.deactivated_principals FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('deactivated_principals');


--
-- Name: deactivated_principals deactivated_principals_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deactivated_principals_sync BEFORE INSERT OR UPDATE ON public.deactivated_principals FOR EACH ROW EXECUTE FUNCTION public.deactivated_principals_sync();


--
-- Name: deploy_git_repos deploy_git_repos_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deploy_git_repos_bump AFTER INSERT OR DELETE OR UPDATE ON public.deploy_git_repos FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('deploy_git_repos');


--
-- Name: deploy_git_repos deploy_git_repos_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deploy_git_repos_sync BEFORE INSERT OR UPDATE ON public.deploy_git_repos FOR EACH ROW EXECUTE FUNCTION public.deploy_git_repos_sync();


--
-- Name: deployment_identity deployment_identity_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deployment_identity_bump AFTER INSERT OR DELETE OR UPDATE ON public.deployment_identity FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('deployment_identity');


--
-- Name: deployment_identity deployment_identity_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deployment_identity_sync BEFORE INSERT OR UPDATE ON public.deployment_identity FOR EACH ROW EXECUTE FUNCTION public.deployment_identity_sync();


--
-- Name: deployment_layer deployment_layer_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deployment_layer_bump AFTER INSERT OR DELETE OR UPDATE ON public.deployment_layer FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('deployment_layer');


--
-- Name: deployment_layer deployment_layer_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deployment_layer_sync BEFORE INSERT OR UPDATE ON public.deployment_layer FOR EACH ROW EXECUTE FUNCTION public.deployment_layer_sync();


--
-- Name: deployments deployments_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deployments_bump AFTER INSERT OR DELETE OR UPDATE ON public.deployments FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('deployments');


--
-- Name: deployments deployments_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deployments_sync BEFORE INSERT OR UPDATE ON public.deployments FOR EACH ROW EXECUTE FUNCTION public.deployments_sync();


--
-- Name: e2b_sandbox_bodies e2b_sandbox_bodies_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER e2b_sandbox_bodies_bump AFTER INSERT OR DELETE OR UPDATE ON public.e2b_sandbox_bodies FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('e2b_sandbox_bodies');


--
-- Name: e2b_sandbox_bodies e2b_sandbox_bodies_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER e2b_sandbox_bodies_sync BEFORE INSERT OR UPDATE ON public.e2b_sandbox_bodies FOR EACH ROW EXECUTE FUNCTION public.e2b_sandbox_bodies_sync();


--
-- Name: egress_policies egress_policies_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER egress_policies_bump AFTER INSERT OR DELETE OR UPDATE ON public.egress_policies FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('egress_policies');


--
-- Name: egress_policies egress_policies_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER egress_policies_sync BEFORE INSERT OR UPDATE ON public.egress_policies FOR EACH ROW EXECUTE FUNCTION public.egress_policies_sync();


--
-- Name: external_members external_members_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER external_members_bump AFTER INSERT OR DELETE OR UPDATE ON public.external_members FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('external_members');


--
-- Name: external_members external_members_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER external_members_sync BEFORE INSERT OR UPDATE ON public.external_members FOR EACH ROW EXECUTE FUNCTION public.external_members_sync();


--
-- Name: external_slack_participants_flag external_slack_participants_flag_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER external_slack_participants_flag_bump AFTER INSERT OR DELETE OR UPDATE ON public.external_slack_participants_flag FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('external_slack_participants_flag');


--
-- Name: external_slack_participants_flag external_slack_participants_flag_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER external_slack_participants_flag_sync BEFORE INSERT OR UPDATE ON public.external_slack_participants_flag FOR EACH ROW EXECUTE FUNCTION public.external_slack_participants_flag_sync();


--
-- Name: feature_flags feature_flags_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER feature_flags_bump AFTER INSERT OR DELETE OR UPDATE ON public.feature_flags FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('feature_flags');


--
-- Name: feature_flags feature_flags_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER feature_flags_sync BEFORE INSERT OR UPDATE ON public.feature_flags FOR EACH ROW EXECUTE FUNCTION public.feature_flags_sync();


--
-- Name: idempotency idempotency_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER idempotency_bump AFTER INSERT OR DELETE OR UPDATE ON public.idempotency FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('idempotency');


--
-- Name: idempotency idempotency_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER idempotency_sync BEFORE INSERT OR UPDATE ON public.idempotency FOR EACH ROW EXECUTE FUNCTION public.idempotency_sync();


--
-- Name: individual_model_auth_flag individual_model_auth_flag_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER individual_model_auth_flag_bump AFTER INSERT OR DELETE OR UPDATE ON public.individual_model_auth_flag FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('individual_model_auth_flag');


--
-- Name: individual_model_auth_flag individual_model_auth_flag_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER individual_model_auth_flag_sync BEFORE INSERT OR UPDATE ON public.individual_model_auth_flag FOR EACH ROW EXECUTE FUNCTION public.individual_model_auth_flag_sync();


--
-- Name: interactive_fast_mode_flag interactive_fast_mode_flag_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER interactive_fast_mode_flag_bump AFTER INSERT OR DELETE OR UPDATE ON public.interactive_fast_mode_flag FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('interactive_fast_mode_flag');


--
-- Name: interactive_fast_mode_flag interactive_fast_mode_flag_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER interactive_fast_mode_flag_sync BEFORE INSERT OR UPDATE ON public.interactive_fast_mode_flag FOR EACH ROW EXECUTE FUNCTION public.interactive_fast_mode_flag_sync();


--
-- Name: items items_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_append_only BEFORE UPDATE ON public.items FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: items items_attribution_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_attribution_dirty AFTER INSERT ON public.items FOR EACH ROW WHEN ((new.kind = ANY (ARRAY['UserMessage'::public.item_kind, 'SteeringMessage'::public.item_kind]))) EXECUTE FUNCTION public.mark_attribution_dirty();


--
-- Name: items items_delete_through_session; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_delete_through_session BEFORE DELETE ON public.items FOR EACH ROW EXECUTE FUNCTION public.forbid_direct_delete();


--
-- Name: items items_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER items_no_truncate BEFORE TRUNCATE ON public.items FOR EACH STATEMENT EXECUTE FUNCTION public.forbid_mutation();


--
-- Name: keychain_asks keychain_asks_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER keychain_asks_bump AFTER INSERT OR DELETE OR UPDATE ON public.keychain_asks FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('keychain_asks');


--
-- Name: keychain_asks keychain_asks_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER keychain_asks_sync BEFORE INSERT OR UPDATE ON public.keychain_asks FOR EACH ROW EXECUTE FUNCTION public.keychain_asks_sync();


--
-- Name: keychain_credentials keychain_credentials_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER keychain_credentials_bump AFTER INSERT OR DELETE OR UPDATE ON public.keychain_credentials FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('keychain_credentials');


--
-- Name: keychain_credentials keychain_credentials_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER keychain_credentials_sync BEFORE INSERT OR UPDATE ON public.keychain_credentials FOR EACH ROW EXECUTE FUNCTION public.keychain_credentials_sync();


--
-- Name: keychain_grants keychain_grants_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER keychain_grants_bump AFTER INSERT OR DELETE OR UPDATE ON public.keychain_grants FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('keychain_grants');


--
-- Name: keychain_grants keychain_grants_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER keychain_grants_sync BEFORE INSERT OR UPDATE ON public.keychain_grants FOR EACH ROW EXECUTE FUNCTION public.keychain_grants_sync();


--
-- Name: mcp_servers mcp_servers_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mcp_servers_bump AFTER INSERT OR DELETE OR UPDATE ON public.mcp_servers FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('mcp_servers');


--
-- Name: mcp_servers mcp_servers_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mcp_servers_sync BEFORE INSERT OR UPDATE ON public.mcp_servers FOR EACH ROW EXECUTE FUNCTION public.mcp_servers_sync();


--
-- Name: memory_capture_pending memory_capture_pending_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER memory_capture_pending_bump AFTER INSERT OR DELETE OR UPDATE ON public.memory_capture_pending FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('memory_capture_pending');


--
-- Name: memory_capture_pending memory_capture_pending_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER memory_capture_pending_sync BEFORE INSERT OR UPDATE ON public.memory_capture_pending FOR EACH ROW EXECUTE FUNCTION public.memory_capture_pending_sync();


--
-- Name: memory_facts memory_facts_text_hash; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER memory_facts_text_hash BEFORE INSERT OR UPDATE OF text ON public.memory_facts FOR EACH ROW EXECUTE FUNCTION public.memory_facts_text_hash();


--
-- Name: memory_tidy_profiles memory_tidy_profiles_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER memory_tidy_profiles_bump AFTER INSERT OR DELETE OR UPDATE ON public.memory_tidy_profiles FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('memory_tidy_profiles');


--
-- Name: memory_tidy_profiles memory_tidy_profiles_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER memory_tidy_profiles_sync BEFORE INSERT OR UPDATE ON public.memory_tidy_profiles FOR EACH ROW EXECUTE FUNCTION public.memory_tidy_profiles_sync();


--
-- Name: modal_sandbox_bodies modal_sandbox_bodies_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER modal_sandbox_bodies_bump AFTER INSERT OR DELETE OR UPDATE ON public.modal_sandbox_bodies FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('modal_sandbox_bodies');


--
-- Name: modal_sandbox_bodies modal_sandbox_bodies_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER modal_sandbox_bodies_sync BEFORE INSERT OR UPDATE ON public.modal_sandbox_bodies FOR EACH ROW EXECUTE FUNCTION public.modal_sandbox_bodies_sync();


--
-- Name: model_credentials model_credentials_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER model_credentials_bump AFTER INSERT OR DELETE OR UPDATE ON public.model_credentials FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('model_credentials');


--
-- Name: model_credentials model_credentials_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER model_credentials_sync BEFORE INSERT OR UPDATE ON public.model_credentials FOR EACH ROW EXECUTE FUNCTION public.model_credentials_sync();


--
-- Name: monitors monitors_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER monitors_bump AFTER INSERT OR DELETE OR UPDATE ON public.monitors FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('monitors');


--
-- Name: monitors monitors_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER monitors_sync BEFORE INSERT OR UPDATE ON public.monitors FOR EACH ROW EXECUTE FUNCTION public.monitors_sync();


--
-- Name: oauth_flows oauth_flows_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER oauth_flows_bump AFTER INSERT OR DELETE OR UPDATE ON public.oauth_flows FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('oauth_flows');


--
-- Name: oauth_flows oauth_flows_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER oauth_flows_sync BEFORE INSERT OR UPDATE ON public.oauth_flows FOR EACH ROW EXECUTE FUNCTION public.oauth_flows_sync();


--
-- Name: org_ambient_flag org_ambient_flag_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER org_ambient_flag_bump AFTER INSERT OR DELETE OR UPDATE ON public.org_ambient_flag FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('org_ambient_flag');


--
-- Name: org_ambient_flag org_ambient_flag_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER org_ambient_flag_sync BEFORE INSERT OR UPDATE ON public.org_ambient_flag FOR EACH ROW EXECUTE FUNCTION public.org_ambient_flag_sync();


--
-- Name: participants participants_attribution_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER participants_attribution_dirty AFTER INSERT OR DELETE OR UPDATE ON public.participants FOR EACH ROW EXECUTE FUNCTION public.mark_attribution_dirty();


--
-- Name: principal_links principal_links_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER principal_links_bump AFTER INSERT OR DELETE OR UPDATE ON public.principal_links FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('principal_links');


--
-- Name: principal_links principal_links_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER principal_links_sync BEFORE INSERT OR UPDATE ON public.principal_links FOR EACH ROW EXECUTE FUNCTION public.principal_links_sync();


--
-- Name: projects projects_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER projects_bump AFTER INSERT OR DELETE OR UPDATE ON public.projects FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('projects');


--
-- Name: projects projects_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER projects_sync BEFORE INSERT OR UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.projects_sync();


--
-- Name: queued_posts queued_posts_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER queued_posts_bump AFTER INSERT OR DELETE OR UPDATE ON public.queued_posts FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('queued_posts');


--
-- Name: queued_posts queued_posts_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER queued_posts_sync BEFORE INSERT OR UPDATE ON public.queued_posts FOR EACH ROW EXECUTE FUNCTION public.queued_posts_sync();


--
-- Name: recent_dm_posts recent_dm_posts_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER recent_dm_posts_bump AFTER INSERT OR DELETE OR UPDATE ON public.recent_dm_posts FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('recent_dm_posts');


--
-- Name: recent_dm_posts recent_dm_posts_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER recent_dm_posts_sync BEFORE INSERT OR UPDATE ON public.recent_dm_posts FOR EACH ROW EXECUTE FUNCTION public.recent_dm_posts_sync();


--
-- Name: sandbox_defaults sandbox_defaults_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sandbox_defaults_bump AFTER INSERT OR DELETE OR UPDATE ON public.sandbox_defaults FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('sandbox_defaults');


--
-- Name: sandbox_defaults sandbox_defaults_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sandbox_defaults_sync BEFORE INSERT OR UPDATE ON public.sandbox_defaults FOR EACH ROW EXECUTE FUNCTION public.sandbox_defaults_sync();


--
-- Name: sandbox_resources sandbox_resources_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sandbox_resources_bump AFTER INSERT OR DELETE OR UPDATE ON public.sandbox_resources FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('sandbox_resources');


--
-- Name: sandbox_resources sandbox_resources_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sandbox_resources_sync BEFORE INSERT OR UPDATE ON public.sandbox_resources FOR EACH ROW EXECUTE FUNCTION public.sandbox_resources_sync();


--
-- Name: secret_drops secret_drops_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER secret_drops_bump AFTER INSERT OR DELETE OR UPDATE ON public.secret_drops FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('secret_drops');


--
-- Name: secret_drops secret_drops_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER secret_drops_sync BEFORE INSERT OR UPDATE ON public.secret_drops FOR EACH ROW EXECUTE FUNCTION public.secret_drops_sync();


--
-- Name: session_llm_requests session_llm_requests_spend_columns; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER session_llm_requests_spend_columns BEFORE INSERT OR UPDATE OF usage_json ON public.session_llm_requests FOR EACH ROW EXECUTE FUNCTION public.llm_request_spend_columns();


--
-- Name: session_llm_requests session_llm_requests_spend_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER session_llm_requests_spend_dirty AFTER INSERT OR DELETE OR UPDATE OF created_at, session_id, model, usage_json ON public.session_llm_requests FOR EACH ROW EXECUTE FUNCTION public.invalidate_request_spend();


--
-- Name: session_mailbox session_mailbox_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER session_mailbox_bump AFTER INSERT OR DELETE OR UPDATE ON public.session_mailbox FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('session_mailbox');


--
-- Name: session_mailbox session_mailbox_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER session_mailbox_sync BEFORE INSERT OR UPDATE ON public.session_mailbox FOR EACH ROW EXECUTE FUNCTION public.session_mailbox_sync();


--
-- Name: session_shares session_shares_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER session_shares_bump AFTER INSERT OR DELETE OR UPDATE ON public.session_shares FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('session_shares');


--
-- Name: session_shares session_shares_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER session_shares_sync BEFORE INSERT OR UPDATE ON public.session_shares FOR EACH ROW EXECUTE FUNCTION public.session_shares_sync();


--
-- Name: sessions sessions_spend_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sessions_spend_dirty AFTER INSERT OR DELETE OR UPDATE OF id, scope_id, origin, thread_ref, parent_session_id ON public.sessions FOR EACH ROW EXECUTE FUNCTION public.invalidate_session_spend();


--
-- Name: skill_bundles skill_bundles_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER skill_bundles_bump AFTER INSERT OR DELETE OR UPDATE ON public.skill_bundles FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('skill_bundles');


--
-- Name: skill_bundles skill_bundles_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER skill_bundles_sync BEFORE INSERT OR UPDATE ON public.skill_bundles FOR EACH ROW EXECUTE FUNCTION public.skill_bundles_sync();


--
-- Name: skill_packs skill_packs_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER skill_packs_bump AFTER INSERT OR DELETE OR UPDATE ON public.skill_packs FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('skill_packs');


--
-- Name: skill_packs skill_packs_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER skill_packs_sync BEFORE INSERT OR UPDATE ON public.skill_packs FOR EACH ROW EXECUTE FUNCTION public.skill_packs_sync();


--
-- Name: skills skills_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER skills_bump AFTER INSERT OR DELETE OR UPDATE ON public.skills FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('skills');


--
-- Name: skills skills_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER skills_sync BEFORE INSERT OR UPDATE ON public.skills FOR EACH ROW EXECUTE FUNCTION public.skills_sync();


--
-- Name: slack_accounts slack_accounts_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_accounts_bump AFTER INSERT OR DELETE OR UPDATE ON public.slack_accounts FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('slack_accounts');


--
-- Name: slack_accounts slack_accounts_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_accounts_sync BEFORE INSERT OR UPDATE ON public.slack_accounts FOR EACH ROW EXECUTE FUNCTION public.slack_accounts_sync();


--
-- Name: slack_emoji_catalog slack_emoji_catalog_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_emoji_catalog_bump AFTER INSERT OR DELETE OR UPDATE ON public.slack_emoji_catalog FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('slack_emoji_catalog');


--
-- Name: slack_emoji_catalog slack_emoji_catalog_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_emoji_catalog_sync BEFORE INSERT OR UPDATE ON public.slack_emoji_catalog FOR EACH ROW EXECUTE FUNCTION public.slack_emoji_catalog_sync();


--
-- Name: slack_handled_events slack_handled_events_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_handled_events_bump AFTER INSERT OR DELETE OR UPDATE ON public.slack_handled_events FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('slack_handled_events');


--
-- Name: slack_handled_events slack_handled_events_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_handled_events_sync BEFORE INSERT OR UPDATE ON public.slack_handled_events FOR EACH ROW EXECUTE FUNCTION public.slack_handled_events_sync();


--
-- Name: slack_installation slack_installation_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_installation_bump AFTER INSERT OR DELETE OR UPDATE ON public.slack_installation FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('slack_installation');


--
-- Name: slack_installation slack_installation_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_installation_sync BEFORE INSERT OR UPDATE ON public.slack_installation FOR EACH ROW EXECUTE FUNCTION public.slack_installation_sync();


--
-- Name: slack_session_status slack_session_status_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_session_status_bump AFTER INSERT OR DELETE OR UPDATE ON public.slack_session_status FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('slack_session_status');


--
-- Name: slack_session_status slack_session_status_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_session_status_sync BEFORE INSERT OR UPDATE ON public.slack_session_status FOR EACH ROW EXECUTE FUNCTION public.slack_session_status_sync();


--
-- Name: slack_staged_envelopes slack_staged_envelopes_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_staged_envelopes_bump AFTER INSERT OR DELETE OR UPDATE ON public.slack_staged_envelopes FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('slack_staged_envelopes');


--
-- Name: slack_staged_envelopes slack_staged_envelopes_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_staged_envelopes_sync BEFORE INSERT OR UPDATE ON public.slack_staged_envelopes FOR EACH ROW EXECUTE FUNCTION public.slack_staged_envelopes_sync();


--
-- Name: slack_task_acknowledgements slack_task_acknowledgements_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_task_acknowledgements_bump AFTER INSERT OR DELETE OR UPDATE ON public.slack_task_acknowledgements FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('slack_task_acknowledgements');


--
-- Name: slack_task_acknowledgements slack_task_acknowledgements_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER slack_task_acknowledgements_sync BEFORE INSERT OR UPDATE ON public.slack_task_acknowledgements FOR EACH ROW EXECUTE FUNCTION public.slack_task_acknowledgements_sync();


--
-- Name: soul_configs soul_configs_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER soul_configs_bump AFTER INSERT OR DELETE OR UPDATE ON public.soul_configs FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('soul_configs');


--
-- Name: soul_configs soul_configs_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER soul_configs_sync BEFORE INSERT OR UPDATE ON public.soul_configs FOR EACH ROW EXECUTE FUNCTION public.soul_configs_sync();


--
-- Name: soul_history soul_history_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER soul_history_bump AFTER INSERT OR DELETE OR UPDATE ON public.soul_history FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('soul_history');


--
-- Name: soul_history soul_history_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER soul_history_sync BEFORE INSERT OR UPDATE ON public.soul_history FOR EACH ROW EXECUTE FUNCTION public.soul_history_sync();


--
-- Name: sprites_initialization sprites_initialization_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sprites_initialization_bump AFTER INSERT OR DELETE OR UPDATE ON public.sprites_initialization FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('sprites_initialization');


--
-- Name: sprites_initialization sprites_initialization_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sprites_initialization_sync BEFORE INSERT OR UPDATE ON public.sprites_initialization FOR EACH ROW EXECUTE FUNCTION public.sprites_initialization_sync();


--
-- Name: suggested_activity_profiles suggested_activity_profiles_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER suggested_activity_profiles_bump AFTER INSERT OR DELETE OR UPDATE ON public.suggested_activity_profiles FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('suggested_activity_profiles');


--
-- Name: suggested_activity_profiles suggested_activity_profiles_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER suggested_activity_profiles_sync BEFORE INSERT OR UPDATE ON public.suggested_activity_profiles FOR EACH ROW EXECUTE FUNCTION public.suggested_activity_profiles_sync();


--
-- Name: unfulfilled_insights_flag unfulfilled_insights_flag_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unfulfilled_insights_flag_bump AFTER INSERT OR DELETE OR UPDATE ON public.unfulfilled_insights_flag FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('unfulfilled_insights_flag');


--
-- Name: unfulfilled_insights_flag unfulfilled_insights_flag_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unfulfilled_insights_flag_sync BEFORE INSERT OR UPDATE ON public.unfulfilled_insights_flag FOR EACH ROW EXECUTE FUNCTION public.unfulfilled_insights_flag_sync();


--
-- Name: web_ui_state web_ui_state_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER web_ui_state_bump AFTER INSERT OR DELETE OR UPDATE ON public.web_ui_state FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('web_ui_state');


--
-- Name: web_ui_state web_ui_state_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER web_ui_state_sync BEFORE INSERT OR UPDATE ON public.web_ui_state FOR EACH ROW EXECUTE FUNCTION public.web_ui_state_sync();


--
-- Name: webhook_history webhook_history_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER webhook_history_bump AFTER INSERT OR DELETE OR UPDATE ON public.webhook_history FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('webhook_history');


--
-- Name: webhook_history webhook_history_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER webhook_history_sync BEFORE INSERT OR UPDATE ON public.webhook_history FOR EACH ROW EXECUTE FUNCTION public.webhook_history_sync();


--
-- Name: webhooks webhooks_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER webhooks_bump AFTER INSERT OR DELETE OR UPDATE ON public.webhooks FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('webhooks');


--
-- Name: webhooks webhooks_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER webhooks_sync BEFORE INSERT OR UPDATE ON public.webhooks FOR EACH ROW EXECUTE FUNCTION public.webhooks_sync();


--
-- Name: webui_model_configs webui_model_configs_bump; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER webui_model_configs_bump AFTER INSERT OR DELETE OR UPDATE ON public.webui_model_configs FOR EACH STATEMENT EXECUTE FUNCTION public.qm_durable_map_bump('webui_model_configs');


--
-- Name: webui_model_configs webui_model_configs_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER webui_model_configs_sync BEFORE INSERT OR UPDATE ON public.webui_model_configs FOR EACH ROW EXECUTE FUNCTION public.webui_model_configs_sync();


--
-- Name: decision_rules decision_rules_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_rules
    ADD CONSTRAINT decision_rules_provider_id_fkey FOREIGN KEY (tenant_id, provider_id) REFERENCES public.decision_providers(tenant_id, provider_id);


--
-- Name: deployment_access deployment_access_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployment_access
    ADD CONSTRAINT deployment_access_id_fkey FOREIGN KEY (tenant_id, id) REFERENCES public.deployments(tenant_id, id) ON DELETE CASCADE;


--
-- Name: environment_attachments environment_attachments_environment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_attachments
    ADD CONSTRAINT environment_attachments_environment_id_fkey FOREIGN KEY (tenant_id, environment_id) REFERENCES public.environments(tenant_id, id);


--
-- Name: items items_blob; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_blob FOREIGN KEY (tenant_id, blob_sha) REFERENCES public.blobs(tenant_id, sha256);


--
-- Name: items items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_session_id_fkey FOREIGN KEY (tenant_id, session_id) REFERENCES public.sessions(tenant_id, id) ON DELETE CASCADE;


--
-- Name: session_goals session_goals_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_goals
    ADD CONSTRAINT session_goals_session_id_fkey FOREIGN KEY (tenant_id, session_id) REFERENCES public.sessions(tenant_id, id) ON DELETE CASCADE;


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (tenant_id, team_id) REFERENCES public.teams(tenant_id, team_id) ON DELETE CASCADE;


--
-- Name: team_rooms team_rooms_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rooms
    ADD CONSTRAINT team_rooms_team_id_fkey FOREIGN KEY (tenant_id, team_id) REFERENCES public.teams(tenant_id, team_id) ON DELETE CASCADE;


--
-- Name: ack_emoji; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ack_emoji ENABLE ROW LEVEL SECURITY;

--
-- Name: ack_emoji_picks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ack_emoji_picks ENABLE ROW LEVEL SECURITY;

--
-- Name: acl_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.acl_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: acl_grants_version; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.acl_grants_version ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: ambient_cursors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ambient_cursors ENABLE ROW LEVEL SECURITY;

--
-- Name: ambient_judgments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ambient_judgments ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_grant_modes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_grant_modes ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: approvals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approvals ENABLE ROW LEVEL SECURITY;

--
-- Name: attributed_turns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.attributed_turns ENABLE ROW LEVEL SECURITY;

--
-- Name: attributed_turns_dirty; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.attributed_turns_dirty ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: auth_broker_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auth_broker_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: auto_flagger_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auto_flagger_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: aws_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.aws_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: base_model_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.base_model_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: blobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.blobs ENABLE ROW LEVEL SECURITY;

--
-- Name: branding_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.branding_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: browse_max_steps_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.browse_max_steps_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: browse_model_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.browse_model_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: browser_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.browser_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_files; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_files ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_header_pin_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_header_pin_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_policy; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_policy ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_policy_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_policy_history ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_state ENABLE ROW LEVEL SECURITY;

--
-- Name: command_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.command_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: composio_returns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.composio_returns ENABLE ROW LEVEL SECURITY;

--
-- Name: connector_clients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.connector_clients ENABLE ROW LEVEL SECURITY;

--
-- Name: connector_status; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.connector_status ENABLE ROW LEVEL SECURITY;

--
-- Name: consent_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.consent_links ENABLE ROW LEVEL SECURITY;

--
-- Name: context_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.context_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_daily_calls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credential_daily_calls ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_usage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credential_usage ENABLE ROW LEVEL SECURITY;

--
-- Name: cron_fires; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cron_fires ENABLE ROW LEVEL SECURITY;

--
-- Name: cron_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cron_items ENABLE ROW LEVEL SECURITY;

--
-- Name: crons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.crons ENABLE ROW LEVEL SECURITY;

--
-- Name: custom_model_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.custom_model_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: deactivated_principals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deactivated_principals ENABLE ROW LEVEL SECURITY;

--
-- Name: decision_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decision_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: decision_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decision_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: deploy_git_repos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deploy_git_repos ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_access; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_access ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_identity; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_identity ENABLE ROW LEVEL SECURITY;

--
-- Name: deployment_layer; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployment_layer ENABLE ROW LEVEL SECURITY;

--
-- Name: deployments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deployments ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_channel_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_channel_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_channels; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_channels ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_group_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_group_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_members ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_meta; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_meta ENABLE ROW LEVEL SECURITY;

--
-- Name: directory_sync; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.directory_sync ENABLE ROW LEVEL SECURITY;

--
-- Name: durable_map_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.durable_map_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: e2b_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.e2b_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: egress_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.egress_events ENABLE ROW LEVEL SECURITY;

--
-- Name: egress_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.egress_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: environment_attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.environment_attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: environments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.environments ENABLE ROW LEVEL SECURITY;

--
-- Name: error_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.error_events ENABLE ROW LEVEL SECURITY;

--
-- Name: external_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_members ENABLE ROW LEVEL SECURITY;

--
-- Name: external_slack_participants_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_slack_participants_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_flags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;

--
-- Name: file_artifact_deletions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_artifact_deletions ENABLE ROW LEVEL SECURITY;

--
-- Name: file_artifacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_artifacts ENABLE ROW LEVEL SECURITY;

--
-- Name: idempotency; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.idempotency ENABLE ROW LEVEL SECURITY;

--
-- Name: individual_model_auth_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.individual_model_auth_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: interactive_fast_mode_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.interactive_fast_mode_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.items ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_asks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_asks ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: keychain_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.keychain_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: llm_prompt_envelopes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.llm_prompt_envelopes ENABLE ROW LEVEL SECURITY;

--
-- Name: local_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.local_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: loop_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loop_items ENABLE ROW LEVEL SECURITY;

--
-- Name: loops; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.loops ENABLE ROW LEVEL SECURITY;

--
-- Name: mcp_servers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mcp_servers ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_capture_pending; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_capture_pending ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_facts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_facts ENABLE ROW LEVEL SECURITY;

--
-- Name: memory_tidy_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.memory_tidy_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: modal_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.modal_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: model_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.model_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: monitors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.monitors ENABLE ROW LEVEL SECURITY;

--
-- Name: oauth_flows; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.oauth_flows ENABLE ROW LEVEL SECURITY;

--
-- Name: org_ambient_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_ambient_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: participants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.participants ENABLE ROW LEVEL SECURITY;

--
-- Name: principal_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.principal_links ENABLE ROW LEVEL SECURITY;

--
-- Name: process_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.process_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: projects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

--
-- Name: qm_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qm_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: ack_emoji qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.ack_emoji USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: ack_emoji_picks qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.ack_emoji_picks USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: acl_grants qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.acl_grants USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: acl_grants_version qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.acl_grants_version USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: admin_grants qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.admin_grants USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: ambient_cursors qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.ambient_cursors USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: ambient_judgments qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.ambient_judgments USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: approval_grant_modes qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.approval_grant_modes USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: approval_grants qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.approval_grants USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: approvals qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.approvals USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: attributed_turns qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.attributed_turns USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: attributed_turns_dirty qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.attributed_turns_dirty USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: audit_log qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.audit_log USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: auth_broker_sessions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.auth_broker_sessions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: auto_flagger_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.auto_flagger_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: aws_sandbox_bodies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.aws_sandbox_bodies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: base_model_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.base_model_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: blobs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.blobs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: branding_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.branding_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: browse_max_steps_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.browse_max_steps_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: browse_model_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.browse_model_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: browser_sessions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.browser_sessions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_files qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_files USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_header_pin_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_header_pin_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_messages qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_messages USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_policy qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_policy USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_policy_history qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_policy_history USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: channel_state qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.channel_state USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: command_policies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.command_policies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: composio_returns qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.composio_returns USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: connector_clients qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.connector_clients USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: connector_status qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.connector_status USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: consent_links qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.consent_links USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: context_requests qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.context_requests USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: credential_daily_calls qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.credential_daily_calls USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: credential_usage qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.credential_usage USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: cron_fires qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.cron_fires USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: cron_items qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.cron_items USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: crons qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.crons USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: custom_model_providers qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.custom_model_providers USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deactivated_principals qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deactivated_principals USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: decision_providers qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.decision_providers USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: decision_rules qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.decision_rules USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deploy_git_repos qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deploy_git_repos USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deployment_access qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deployment_access USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deployment_identity qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deployment_identity USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deployment_layer qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deployment_layer USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: deployments qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.deployments USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_channel_members qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_channel_members USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_channels qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_channels USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_group_members qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_group_members USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_groups qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_groups USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_members qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_members USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_meta qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_meta USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: directory_sync qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.directory_sync USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: durable_map_versions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.durable_map_versions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: e2b_sandbox_bodies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.e2b_sandbox_bodies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: egress_events qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.egress_events USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: egress_policies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.egress_policies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: environment_attachments qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.environment_attachments USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: environments qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.environments USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: error_events qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.error_events USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: external_members qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.external_members USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: external_slack_participants_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.external_slack_participants_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: feature_flags qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.feature_flags USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: file_artifact_deletions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.file_artifact_deletions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: file_artifacts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.file_artifacts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: idempotency qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.idempotency USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: individual_model_auth_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.individual_model_auth_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: interactive_fast_mode_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.interactive_fast_mode_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: items qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.items USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: keychain_asks qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.keychain_asks USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: keychain_credentials qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.keychain_credentials USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: keychain_grants qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.keychain_grants USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: llm_prompt_envelopes qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.llm_prompt_envelopes USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: local_sandbox_bodies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.local_sandbox_bodies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: loop_items qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.loop_items USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: loops qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.loops USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: mcp_servers qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.mcp_servers USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: memory_capture_pending qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.memory_capture_pending USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: memory_facts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.memory_facts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: memory_tidy_profiles qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.memory_tidy_profiles USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: modal_sandbox_bodies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.modal_sandbox_bodies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: model_credentials qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.model_credentials USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: monitors qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.monitors USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: oauth_flows qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.oauth_flows USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: org_ambient_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.org_ambient_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: participants qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.participants USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: principal_links qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.principal_links USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: process_sessions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.process_sessions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: projects qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.projects USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: qm_settings qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.qm_settings USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: queued_posts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.queued_posts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: rate_limit_windows qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.rate_limit_windows USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: recent_dm_posts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.recent_dm_posts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: run_activity qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.run_activity USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: run_signals qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.run_signals USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: runs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.runs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sandbox_defaults qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sandbox_defaults USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sandbox_resource_rollout qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sandbox_resource_rollout USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sandbox_resources qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sandbox_resources USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sandbox_routing qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sandbox_routing USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: secret_drops qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.secret_drops USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: security_postures qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.security_postures USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_goals qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_goals USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_leases qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_leases USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_llm_requests qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_llm_requests USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_mailbox qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_mailbox USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_pins qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_pins USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_shares qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_shares USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_spend_days qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_spend_days USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_spend_dirty qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_spend_dirty USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: session_turn_pointers qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.session_turn_pointers USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sessions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sessions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sharing_postures qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sharing_postures USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: skill_bundles qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.skill_bundles USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: skill_packs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.skill_packs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: skills qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.skills USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_accounts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_accounts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_emoji_catalog qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_emoji_catalog USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_handled_events qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_handled_events USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_installation qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_installation USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_session_status qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_session_status USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_staged_envelopes qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_staged_envelopes USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: slack_task_acknowledgements qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.slack_task_acknowledgements USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: soul_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.soul_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: soul_history qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.soul_history USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: source_auth_replay qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.source_auth_replay USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: sprites_initialization qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.sprites_initialization USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: suggested_activity_profiles qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.suggested_activity_profiles USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: superserve_config_epochs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.superserve_config_epochs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: superserve_sandbox_bodies qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.superserve_sandbox_bodies USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: swarm_board_channels qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.swarm_board_channels USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: swarm_board_posts qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.swarm_board_posts USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: swarm_board_subscriptions qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.swarm_board_subscriptions USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: swarm_boards qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.swarm_boards USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: team_members qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.team_members USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: team_rooms qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.team_rooms USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: teams qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.teams USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: tool_calls qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.tool_calls USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: unfulfilled_insights_flag qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.unfulfilled_insights_flag USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: web_ui_state qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.web_ui_state USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: webhook_history qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.webhook_history USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: webhooks qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.webhooks USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: webui_model_configs qm_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qm_tenant_isolation ON public.webui_model_configs USING (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass())) WITH CHECK (((tenant_id = public.qm_tenant_id()) OR public.qm_tenant_bypass()));


--
-- Name: queued_posts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.queued_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: rate_limit_windows; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rate_limit_windows ENABLE ROW LEVEL SECURITY;

--
-- Name: recent_dm_posts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recent_dm_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: run_activity; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.run_activity ENABLE ROW LEVEL SECURITY;

--
-- Name: run_signals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.run_signals ENABLE ROW LEVEL SECURITY;

--
-- Name: runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runs ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_defaults; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_defaults ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_resource_rollout; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_resource_rollout ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_resources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_resources ENABLE ROW LEVEL SECURITY;

--
-- Name: sandbox_routing; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sandbox_routing ENABLE ROW LEVEL SECURITY;

--
-- Name: secret_drops; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.secret_drops ENABLE ROW LEVEL SECURITY;

--
-- Name: security_postures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.security_postures ENABLE ROW LEVEL SECURITY;

--
-- Name: session_goals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_goals ENABLE ROW LEVEL SECURITY;

--
-- Name: session_leases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_leases ENABLE ROW LEVEL SECURITY;

--
-- Name: session_llm_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_llm_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: session_mailbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_mailbox ENABLE ROW LEVEL SECURITY;

--
-- Name: session_pins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_pins ENABLE ROW LEVEL SECURITY;

--
-- Name: session_shares; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_shares ENABLE ROW LEVEL SECURITY;

--
-- Name: session_spend_days; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_spend_days ENABLE ROW LEVEL SECURITY;

--
-- Name: session_spend_dirty; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_spend_dirty ENABLE ROW LEVEL SECURITY;

--
-- Name: session_turn_pointers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_turn_pointers ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sharing_postures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sharing_postures ENABLE ROW LEVEL SECURITY;

--
-- Name: skill_bundles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skill_bundles ENABLE ROW LEVEL SECURITY;

--
-- Name: skill_packs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skill_packs ENABLE ROW LEVEL SECURITY;

--
-- Name: skills; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skills ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_emoji_catalog; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_emoji_catalog ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_handled_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_handled_events ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_installation; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_installation ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_session_status; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_session_status ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_staged_envelopes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_staged_envelopes ENABLE ROW LEVEL SECURITY;

--
-- Name: slack_task_acknowledgements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.slack_task_acknowledgements ENABLE ROW LEVEL SECURITY;

--
-- Name: soul_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.soul_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: soul_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.soul_history ENABLE ROW LEVEL SECURITY;

--
-- Name: source_auth_replay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.source_auth_replay ENABLE ROW LEVEL SECURITY;

--
-- Name: sprites_initialization; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sprites_initialization ENABLE ROW LEVEL SECURITY;

--
-- Name: suggested_activity_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suggested_activity_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: superserve_config_epochs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.superserve_config_epochs ENABLE ROW LEVEL SECURITY;

--
-- Name: superserve_sandbox_bodies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.superserve_sandbox_bodies ENABLE ROW LEVEL SECURITY;

--
-- Name: swarm_board_channels; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.swarm_board_channels ENABLE ROW LEVEL SECURITY;

--
-- Name: swarm_board_posts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.swarm_board_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: swarm_board_subscriptions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.swarm_board_subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: swarm_boards; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.swarm_boards ENABLE ROW LEVEL SECURITY;

--
-- Name: team_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;

--
-- Name: team_rooms; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.team_rooms ENABLE ROW LEVEL SECURITY;

--
-- Name: teams; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;

--
-- Name: tool_calls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tool_calls ENABLE ROW LEVEL SECURITY;

--
-- Name: unfulfilled_insights_flag; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.unfulfilled_insights_flag ENABLE ROW LEVEL SECURITY;

--
-- Name: web_ui_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.web_ui_state ENABLE ROW LEVEL SECURITY;

--
-- Name: webhook_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhook_history ENABLE ROW LEVEL SECURITY;

--
-- Name: webhooks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhooks ENABLE ROW LEVEL SECURITY;

--
-- Name: webui_model_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webui_model_configs ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--


